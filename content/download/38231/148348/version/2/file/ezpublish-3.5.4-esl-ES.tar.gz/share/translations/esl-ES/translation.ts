<!DOCTYPE TS><TS>
<context>
    <name>contentstructuremenu/show_content_structure</name>
    <message>
        <source>Node ID: %node_id Visibility: %visibility</source>
        <translation>ID del nudo: %node_id Visibilidad: %visibility</translation>
    </message>
</context>
<context>
    <name>design/admin/class/classlist</name>
    <message>
        <source>%group_name [Class group]</source>
        <translation>%group_name [Grupo de clases]</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this class group.</source>
        <translation>Editar este grupo de clases.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove this class group.</source>
        <translation>Eliminar este grupo de clases.</translation>
    </message>
    <message>
        <source>Back to class groups.</source>
        <translation>Volver a los grupos de clases.</translation>
    </message>
    <message>
        <source>Classes inside &lt;%group_name&gt; [%class_count]</source>
        <translation>Clases en el grupo &lt;%group_name&gt; [%class_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>Objetos</translation>
    </message>
    <message>
        <source>Select class for removal.</source>
        <translation>Eligir la clase para eliminar.</translation>
    </message>
    <message>
        <source>Create a copy of the &lt;%class_name&gt; class.</source>
        <translation>Crear una copia de la clase &lt;%class_name&gt;.</translation>
    </message>
    <message>
        <source>Edit the &lt;%class_name&gt; class.</source>
        <translation>Editar la clase &lt;%class_name&gt;.</translation>
    </message>
    <message>
        <source>There are no classes in this group.</source>
        <translation>No hay clases en este grupo.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected classes from the &lt;%class_group_name&gt; class group.</source>
        <translation>Eliminar las clases seleccionadas del grupo de clase &lt;%class_group_name&gt;.</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Nueva clase</translation>
    </message>
    <message>
        <source>Create a new class within the &lt;%class_group_name&gt; class group.</source>
        <translation>Crear una nueva clase dentro del grupo de clase &lt;%class_group_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/class/datatype/browse_objectrelation_placement</name>
    <message>
        <source>Choose node for default selection</source>
        <translation>Eligir el nudo para la selección por defecto</translation>
    </message>
    <message>
        <source>Select the item that you want to be the default selection and click &quot;OK&quot;.</source>
        <translation>Elige el elemento para la selección por defecto y haz click en &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/class/datatype/browse_objectrelationlist_placement</name>
    <message>
        <source>Choose initial location</source>
        <translation>Elige la ubicación inicial</translation>
    </message>
    <message>
        <source>Select the location that should be the default location and click &quot;OK&quot;.</source>
        <translation>Elige la ubicación por defecto y haz click en &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/class/edit</name>
    <message>
        <source>The class definition could not be stored.</source>
        <translation>La definición de la clase no puede ser guardada.</translation>
    </message>
    <message>
        <source>The following information is either missing or invalid</source>
        <translation>La información siguiente falta o no esta valida</translation>
    </message>
    <message>
        <source>The class definition was successfully stored.</source>
        <translation>La definición de clase fue guardada correctamente.</translation>
    </message>
    <message>
        <source>Edit &lt;%class_name&gt; [Class]</source>
        <translation>Editar &lt;%class_name&gt; [Clase]</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Use this field to set the informal name of the class. The name field can contain whitespaces and special characters.</source>
        <translation>Usar este campo para poner el nombre informal de la clase. El nombre del campo puede contener espacios y caracteres especiales.</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Use this field to set the internal name of the class. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
        <translation>Usar este campo para el nombre interno de la clase. Este identificador será usado en las plantillas y en el código PHP. Caracteres permitidos: letras, números y subrayado.</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Patrón de nombre de objeto</translation>
    </message>
    <message>
        <source>Use this field to configure how the name of the objects are generated (also applies to nice URLs). Type in the identifiers of the attributes that should be used. The identifiers must be enclosed in angle brackets. Text outside angle brackets will be included as is.</source>
        <translation>Usar este campo para configurar como se generarán los nombres de los objetos (también afecta a las URL). Poner los identificadores de los atributos que deben ser usados. Los identificadores tienen que estar entre paréntesis angulares (&quot;&lt;&gt;&quot;). El texto fuera de los paréntesis angulares será incluido de forma literal.
</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Contenedor</translation>
    </message>
    <message>
        <source>Use this checkbox to allow instances of the class to have sub items. If checked, it will be possible to create new sub-items. If not checked, the sub items will not be displayed.</source>
        <translation>Usar esta opción para permitir que las instancias de la clase tengan sub-elementos. Si esta selecionado, será posible crear nuevos sub-elementos. Sino, los sub-elementos no se verán.</translation>
    </message>
    <message>
        <source>Select attribute for removal. Click the &quot;Remove selected attributes&quot; button to actually remove the selected attributes.</source>
        <translation>Elige los atributos para eliminar. Haz click en el botón &quot;Eliminar los atributos seleccionados&quot; para realmente eliminar los atributos seleccionados.</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Bajar</translation>
    </message>
    <message>
        <source>Use the order buttons to set the order of the class attributes. The up arrow moves the attribute one place up. The down arrow moves the attribute one place down.</source>
        <translation>Usa los botónes de orden para fijar el orden de los atributos de la clase. La flecha arriba mueve el atributo una linéa más arriba. La flecha abajo mueve el  atributo una linéa más abajo.</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Use this field to set the informal name of the attribute. This field can contain whitespaces and special characters.</source>
        <translation>Usar este campo para el nombre informal del atributo. Este campo puede contener espacios y caracteres especiales.</translation>
    </message>
    <message>
        <source>Use this field to set the internal name of the attribute. The identifier will be used in templates and in PHP code. Allowed characters: letters, numbers and underscore.</source>
        <translation>Usar este campo para el nombre interno del atributo. Este identificador será usado en las plantillas y en el código PHP. Caracteres permitidos: letres, números y subrayado.</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the user should be forced to enter information into the attribute.</source>
        <translation>Usar esta opción para controlar si el usuario tiene que estar obligado de poner contenido para este atributo.</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Obligatorio</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the contents of the attribute should be indexed by the search engine.</source>
        <translation>Usar esta opción para controlar si el contenido de este atributo tiene que ser indexado por el motor de búsqueda.</translation>
    </message>
    <message>
        <source>The &lt;%datatype_name&gt; datatype does not support search indexing.</source>
        <translation>El tipo de datos &lt;%datatype_name&gt; no soporta indexación de búsqueda.</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Incluye en la búsqueda</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the attribute should collect input from users.</source>
        <translation>Usar esta opción para controlar si el atributo tiene que recoger información entrada por los usuarios.</translation>
    </message>
    <message>
        <source>The &lt;%datatype_name&gt; datatype can not be used as an information collector.</source>
        <translation>El tipo de datos &lt;%datatype_name&gt; no puede recoger información.</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Recolector de información</translation>
    </message>
    <message>
        <source>Use this checkbox for attributes that contain non-translatable content.</source>
        <translation>Usar esta opción para los atributos que tienen un contenido que no se puede traducir.</translation>
    </message>
    <message>
        <source>Disable translation</source>
        <translation>Descativar la traducción</translation>
    </message>
    <message>
        <source>This class does not have any attributes.</source>
        <translation>Esta clase no tiene ningún atributos.</translation>
    </message>
    <message>
        <source>Remove selected attributes</source>
        <translation>Eliminar los atributos seleccionados</translation>
    </message>
    <message>
        <source>Remove the selected attributes.</source>
        <translation>Eliminar los atributos seleccionados.</translation>
    </message>
    <message>
        <source>Add attribute</source>
        <translation>Añadir un atributo</translation>
    </message>
    <message>
        <source>Add a new attribute to the class. Use the menu on the left to select the attribute type.</source>
        <translation>Añadir un nuevo atributo a la clase. Usar el menu en la parte izquierda para eligir el tipo de atributo.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Store changes and exit from edit mode.</source>
        <translation>Guardar los cambios y salir del modo de edición.</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Store changes and continue editing.</source>
        <translation>Guardar los cambios y seguir editando.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Discard all changes and exit from edit mode.</source>
        <translation>Cancelar todos los cambios y salir del modo de edición.</translation>
    </message>
    <message>
        <source>The class definition contains the following errors:</source>
        <translation>La definición de esta clase contiene los errorres siguientes:</translation>
    </message>
</context>
<context>
    <name>design/admin/class/edit_denied</name>
    <message>
        <source>Class edit conflict</source>
        <translation>Conflicto de edición de clase</translation>
    </message>
    <message>
        <source>This class is already being edited by someone else.</source>
        <translation>Otro usuario ya esta modificando esta clase.</translation>
    </message>
    <message>
        <source>The class is temporarly locked and thus it can not be edited by you.</source>
        <translation>La clase está bloqueada temporalmente y no puede ser editada.</translation>
    </message>
    <message>
        <source>Possible actions</source>
        <translation>Acciones posibles</translation>
    </message>
    <message>
        <source>Contact the person who is editing the class.</source>
        <translation>Contactar con la persona que está editando la clase.</translation>
    </message>
    <message>
        <source>Wait until the lock expires and try again.</source>
        <translation>Espera hasta que caduque el bloqueo y prueba otra vez.</translation>
    </message>
    <message>
        <source>Edit &lt;%class_name&gt; [Class]</source>
        <translation>Editar la clase &lt;%class_name&gt; [Clase]</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Current modifier</source>
        <translation>Editor actual</translation>
    </message>
    <message>
        <source>Unlock time</source>
        <translation>Tiempo restante para desbloqueo</translation>
    </message>
    <message>
        <source>The class will be available for editing once it has been stored by the current modifier or when it is unlocked by the system.</source>
        <translation>La clase estará disponible para editar cuando el editor actual guarde sus cambios o cuando sea desbloqueada por el sistema.</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Inténtalo de nuevo</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/class/groupedit</name>
    <message>
        <source>Edit &lt;%group_name&gt; [Class group]</source>
        <translation>Editar &lt;%group_name&gt; [Grupo de clases]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/class/grouplist</name>
    <message>
        <source>Class groups [%group_count]</source>
        <translation>Grupos de clases [%group_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Select class group for removal.</source>
        <translation>Seleccionar grupo de clases para eliminar.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%class_group_name&gt; class group.</source>
        <translation>Editar el grupo de clases &lt;%class_group_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove the selected class groups. This will also remove all classes that only exist within the selected groups.</source>
        <translation>Eliminar los grupos de clases seleccionados. Esta acción eliminará todas las clases que existan dentro de los grupos seleccionados.</translation>
    </message>
    <message>
        <source>New class group</source>
        <translation>Nuevo grupo de clases</translation>
    </message>
    <message>
        <source>Create a new class group.</source>
        <translation>Crear un nuevo grupo de clases.</translation>
    </message>
    <message>
        <source>Recently modified classes</source>
        <translation>Clases modificadas recientemente</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Edit the &lt;%class_name&gt; class.</source>
        <translation>Editar la clase &lt;%class_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/class/removeclass</name>
    <message>
        <source>Confirm class removal</source>
        <translation>Confirmar la eliminación de la clase</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the classes?</source>
        <translation>¿Estás seguro de que quieres eliminar las clases?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this class?</source>
        <translation>¿Estás seguro de que quieres eliminar esta clase?</translation>
    </message>
    <message>
        <source>You do not have permissions to remove classes.</source>
        <translation>No tienes permisos para eliminar clases.</translation>
    </message>
    <message>
        <source>The %1 class was already removed from the group but still exists in other groups.</source>
        <translation>La clase %1 ya se habia eliminado del grupo pero todavía existe en otros grupos.</translation>
    </message>
    <message>
        <source>The %1 classes were already removed from the group but still exist in other groups.</source>
        <translation>Las clases %1 ya se habian eliminado del grupo pero todavía existen en otros grupos.</translation>
    </message>
    <message>
        <source>Removing class &lt;%1&gt; will result in the removal of %2 object.</source>
        <translation>Eliminando la clase &lt;%1&gt; se eliminará el objeto %2.</translation>
    </message>
    <message>
        <source>Removing class &lt;%1&gt; will result in the removal of %2 objects.</source>
        <translation>Eliminando la clase &lt;%1&gt; se eliminarán %2 objetos.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/class/removegroup</name>
    <message>
        <source>Confirm class group removal</source>
        <translation>Confirmar la eliminación del grupo de clases</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the class group?</source>
        <translation>¿Estás seguro de que quieres eliminar el grupo de clases?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the class groups?</source>
        <translation>¿Estás seguro de que quieres eliminar los grupos de clases?</translation>
    </message>
    <message>
        <source>The following classes will be removed from the &lt;%group_name&gt; class group</source>
        <translation>Las siguientes clases se eliminarán del grupo de clases &lt;%group_name&gt;</translation>
    </message>
    <message>
        <source>%objects objects will be removed</source>
        <translation>%objects objetos serán eliminados</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/class/view</name>
    <message>
        <source>Input did not validate</source>
        <translation>Los datos no se validaron</translation>
    </message>
    <message>
        <source>%class_name [Class]</source>
        <translation>%class_name [Clase]</translation>
    </message>
    <message>
        <source>Last modified: %time, %username</source>
        <translation>Última modificación: %time, %username</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Patrón de nombre de objeto</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Contenedor</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Object count</source>
        <translation>Número de objetos</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atributos</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Parámetros</translation>
    </message>
    <message>
        <source>Is required</source>
        <translation>Es requerido</translation>
    </message>
    <message>
        <source>Is not required</source>
        <translation>No es requerido</translation>
    </message>
    <message>
        <source>Is searchable</source>
        <translation>Es buscable</translation>
    </message>
    <message>
        <source>Is not searchable</source>
        <translation>No es buscable</translation>
    </message>
    <message>
        <source>Collects information</source>
        <translation>Recoge información</translation>
    </message>
    <message>
        <source>Does not collect information</source>
        <translation>No recoge información</translation>
    </message>
    <message>
        <source>Translation is disabled</source>
        <translation>La traducción está desactivada</translation>
    </message>
    <message>
        <source>Translation is enabled</source>
        <translation>La traducción está activada</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this class.</source>
        <translation>Editar esta clase.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Member of class groups [%group_count]</source>
        <translation>Miembro de grupos de clases [%group_count]</translation>
    </message>
    <message>
        <source>Class group</source>
        <translation>Grupo de clases</translation>
    </message>
    <message>
        <source>Select class group for removal.</source>
        <translation>Elegir el grupo de clases para eliminar.</translation>
    </message>
    <message>
        <source>Remove from selected</source>
        <translation>Eliminar de la selección</translation>
    </message>
    <message>
        <source>Remove the &lt;%class_name&gt; class from the selected class groups.</source>
        <translation>Eliminar la clase &lt;%class_name&gt; de los grupos de clases seleccionados.</translation>
    </message>
    <message>
        <source>Select a group which the &lt;%class_name&gt; class should be added to.</source>
        <translation>Seleccionar un grupo en el que la clase &lt;%class_name&gt; debe ser añadida.</translation>
    </message>
    <message>
        <source>Add to class group</source>
        <translation>Añadir al grupo de clases</translation>
    </message>
    <message>
        <source>Add the &lt;%class_name&gt; class to the group specified in the menu on the left.</source>
        <translation>Añadir la clase &lt;%class_name&gt; al grupo indicado en el menú de la izquierda.</translation>
    </message>
    <message>
        <source>The &lt;%class_name&gt; class already exists within all class groups.</source>
        <translation>La clase &lt;%class_name&gt; ya existe en todos los grupos de clases.</translation>
    </message>
    <message>
        <source>No group</source>
        <translation>No hay grupo</translation>
    </message>
    <message>
        <source>Override templates [%1]</source>
        <translation>Sobreescribir plantillas [%1]</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Sobreescribir</translation>
    </message>
    <message>
        <source>Source template</source>
        <translation>Plantilla fuente</translation>
    </message>
    <message>
        <source>Override template</source>
        <translation>Sobreescribir plantilla</translation>
    </message>
    <message>
        <source>View template overrides for the &lt;%source_template_name&gt; template.</source>
        <translation>Ver plantillas sobreescritas de la plantilla &lt;%source_template_name&gt;.</translation>
    </message>
    <message>
        <source>Edit the override template for the &lt;%override_name&gt; override.</source>
        <translation>Editar la plantilla sobreescrita para la sobreescritura &lt;%override_name&gt;.</translation>
    </message>
    <message>
        <source>This class does not have any class-level override templates.</source>
        <translation>Esta clase no tiene ninguna sobreescritura de plantilla a nivel de clase.</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration</name>
    <message>
        <source>Approval</source>
        <translation>Aprobación</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/group/view/list</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Lista de grupos para &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>No hay elementos en el grupo.</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/group_tree</name>
    <message>
        <source>Groups</source>
        <translation>Grupos</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/full/ezapprove</name>
    <message>
        <source>Approval</source>
        <translation>Aprobación</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>El objeto de contenido %1 espera aprobación antes de poder ser publicado.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>¿Si quieres puedes enviar un mensaje a la persona que tiene que dar su aprobación?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>El objeto de contenido %1 necesita tu aprobación antes de poder ser publicado.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>¿Apruebas que el objeto de contenido sea publicado?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>El objeto de contenido %1 fue aprobado y será publicado cuando el flujo de trabajo de publicación continúe.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>El objeto de contenido %1 no fue aceptado pero está disponible de nuevo como borrador.</translation>
    </message>
    <message>
        <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
        <translation>Puedes volver a editar el borrador y publicarlo, en este caso necesitarás de nuevo una aprobación.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Editar el objeto</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>El objeto de contenido %1 no fue aceptado pero estará disponible para el autor como borrador.</translation>
    </message>
    <message>
        <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
        <translation>El autor puede volver a editar el borrador y publicarlo de nuevo, en este caso se crea un nuevo elemento de aprobación.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Añadir comentario</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Aprobar</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Denegar</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Participantes</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Mensajes</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/handler/view/line/ezapprove</name>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 espera aprobación del editor</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 fue aprobado para publicación</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 no fue aprobado para publicación</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 espera tu aprobación</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/item_list</name>
    <message>
        <source>Subject</source>
        <translation>Asunto</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Leído</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>No leído</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactivo</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/view/element/ezapprove_comment</name>
    <message>
        <source>Posted: %1</source>
        <translation>Enviado %1</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/view/list</name>
    <message>
        <source>Group tree for &apos;%1&apos;</source>
        <translation>Árbol del grupo &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>design/admin/collaboration/view/summary</name>
    <message>
        <source>Item list</source>
        <translation>Lista de elementos</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>No hay nuevos datos que tratar.</translation>
    </message>
    <message>
        <source>Group tree</source>
        <translation>Árbol de grupo</translation>
    </message>
</context>
<context>
    <name>design/admin/content/bookmark</name>
    <message>
        <source>My bookmarks [%bookmark_count]</source>
        <translation>Mis favoritos [%bookmark_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Select bookmark for removal.</source>
        <translation>Elegir favoritos para eliminar.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit &lt;%bookmark_name&gt;.</source>
        <translation>Editar &lt;%bookmark_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit the contents of &lt;%bookmark_name&gt;.</source>
        <translation>No tienes permisos para editar el contenido de &lt;%bookmark_name&gt;.</translation>
    </message>
    <message>
        <source>There are no bookmarks in the list.</source>
        <translation>No hay favoritos en la lista.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected bookmarks.</source>
        <translation>Eliminar los favoritos seleccionados.</translation>
    </message>
    <message>
        <source>Add items</source>
        <translation>Añadir elementos</translation>
    </message>
    <message>
        <source>Add items to your personal bookmark list.</source>
        <translation>Añadir elementos a tu lista personal de favoritos.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse</name>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Para seleccionar objetos, elige la opción más adecuada y haz clic en el botón &quot;Elegir&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Para seleccionar un objeto que es un hijo de uno de los objetos visualizados, pulsa sobre el nombre del objeto y obtendrás la lista de los hijos del objeto.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <source>Top level</source>
        <translation>Nivel más alto</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_bookmark</name>
    <message>
        <source>Choose items to bookmark</source>
        <translation>Elige los elementos para añadir a favoritos</translation>
    </message>
    <message>
        <source>Select the items that you want to bookmark using the checkboxes and click &quot;OK&quot;.</source>
        <translation>Elige los elementos para añadir a favoritos marcando las casillas y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_export</name>
    <message>
        <source>Choose export node</source>
        <translation>Elige un nodo de exportación</translation>
    </message>
    <message>
        <source>Select the item that you want to export using the checkboxes and click &quot;OK&quot;.</source>
        <translation>Elige los elementos a exportar marcando las casillas y pulsa &quot;OK&quot;. </translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_first_placement</name>
    <message>
        <source>Choose location for new &lt;%classname&gt;</source>
        <translation>Elige ubicación para la nueva clase &lt;%classname&gt;</translation>
    </message>
    <message>
        <source>Choose a location for the new &lt;%classname&gt; using the radiobuttons and click &quot;OK&quot;.</source>
        <translation>Elige ubicación para la nueva clase &lt;%classname&gt; usando los botones radio y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_move_node</name>
    <message>
        <source>Choose location for copy of &lt;%object_name&gt;</source>
        <translation>Elige ubicación para la copia de &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location the copy of &lt;%object_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Elige una nueva ubicación para la copia de &lt;%object_name&gt; usando los botones radio y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
    <message>
        <source>Choose a new location for &lt;%object_name&gt;</source>
        <translation>Elige una nueva ubicación para &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location for &lt;%object_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Elige una nueva ubicación para &lt;%object_name&gt; usando los botones radio y pulsa &quot;OK&quot;.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_move_placement</name>
    <message>
        <source>Choose a new location for &lt;%version_name&gt;</source>
        <translation>Elige una nueva ubicación para &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>Choose a new location for &lt;%version_name&gt; using the radio buttons and click &quot;OK&quot;.</source>
        <translation>Elige una nueva ubicación para &lt;%version_name&gt; usando los botones radio y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>The previous location was &lt;%previous_location&gt;.</source>
        <translation>La ubicación anterior era &lt;%previous_location&gt;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_placement</name>
    <message>
        <source>Choose locations for &lt;%version_name&gt;</source>
        <translation>Elige ubicaciones para &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>Choose locations for &lt;%version_name&gt; using the checkboxes and click &quot;OK&quot;.</source>
        <translation>Elige ubicaciones para &lt;%version_name&gt; usando las casillas y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_related</name>
    <message>
        <source>Choose objects that you wish to relate to &lt;%version_name&gt;</source>
        <translation>Elige los objetos que quieres relacionar con &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>Use the checkboxes to choose the objects that you wish to relate to &lt;%version_name&gt;.</source>
        <translation>Usa las casillas para elegir los objetos que quieres relacionar con &lt;%version_name&gt;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/content/browse_swap_node</name>
    <message>
        <source>Choose the exchanging node for &lt;%object_name&gt;</source>
        <translation>Elige el nodo de intercambio para &lt;%object_name&gt;</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the node with which you want to swap &lt;%object_name&gt;.</source>
        <translation>Usa los botones radio para elegir el nodo con el cual quieres &lt;%object_name&gt;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Usa los botones radio para elegir el nodo con el cual quieres cambiar &lt;%object_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/collectedinfo/feedback</name>
    <message>
        <source>Feedback for %feedbackname</source>
        <translation>Feedback para %feedbackname</translation>
    </message>
    <message>
        <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
        <translation>Ya has enviado datos a este feedback. Los datos que se han enviado previamente son los siguientes.</translation>
    </message>
    <message>
        <source>Thanks for your feedback, the following information was collected.</source>
        <translation>Gracias por tu feedback. Se ha almacenado la siguiente información.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Volver al sitio</translation>
    </message>
</context>
<context>
    <name>design/admin/content/collectedinfo/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Formulario %formname</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Ya has enviado datos a este formulario. Los datos que se han enviado previamente son los siguientes.</translation>
    </message>
    <message>
        <source>Collected information</source>
        <translation>Información recogida</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
</context>
<context>
    <name>design/admin/content/collectedinfo/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Encuesta %pollname</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Los usuarios anónimos no pueden votar en esta encuesta. Regístrate antes, por favor.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Ya has votado en esta encuesta.</translation>
    </message>
    <message>
        <source>Poll results</source>
        <translation>Resultados de la encuesta</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>%count votos totales</translation>
    </message>
</context>
<context>
    <name>design/admin/content/confirmtranslationremove</name>
    <message>
        <source>Confirm language removal</source>
        <translation>Confirmar eliminación de lenguaje</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the language?</source>
        <translation>¿Estás seguro de que quieres eliminar este lenguaje?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the languages?</source>
        <translation>¿Estás seguro de que quieres eliminar estos lenguajes?</translation>
    </message>
    <message>
        <source>Removing &lt;%1&gt; will also result in the removal of %2 translated versions.</source>
        <translation>Eliminando &lt;%1&gt; eliminarás %2 versiones traducidas.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/content/datatype</name>
    <message>
        <source>Option set name</source>
        <translation>Nombre de la lista de opciones</translation>
    </message>
</context>
<context>
    <name>design/admin/content/datatype/ezuser</name>
    <message>
        <source>User ID</source>
        <translation>ID de usuario</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
</context>
<context>
    <name>design/admin/content/draft</name>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>My drafts [%draft_count]</source>
        <translation>Mis borradores [%draft_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Select draft for removal.</source>
        <translation>Elegir borrador para eliminar.</translation>
    </message>
    <message>
        <source>Edit &lt;%draft_name&gt;.</source>
        <translation>Editar &lt;%draft_name&gt;.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>There are no drafts that belong to you.</source>
        <translation>No tienes ningún borrador propio.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected drafts.</source>
        <translation>Eliminar borradores seleccionados.</translation>
    </message>
    <message>
        <source>Remove all</source>
        <translation>Eliminar todos</translation>
    </message>
    <message>
        <source>Remove all drafts that belong to you.</source>
        <translation>Eliminar todos tus borradores.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation>Editar &lt;%object_name&gt; [%class_name]</translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation>Traduciendo contenido de %from_lang a %to_lang</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para su publicación</translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation>Publicar los contenidos del borrador que se está editando. El borrador se convertirá en la versión publicada del objeto.</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Almacenar borrador</translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation>Almacenar los contenidos del borrador que estás editando y continuar con la edición. Usa este botón para guardar periódicamente tu trabajo mientras editas.</translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation>Descartar borrador</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>¿Estás seguro de que quieres descartar el borrador?</translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation>Descartar el borrador que estás editando. También se eliminarán las traducciones del borrador (si hay).</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Profundidad</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Identificador de clase</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Nombre de clase</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Locations [%locations]</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Sub elementos</translation>
    </message>
    <message>
        <source>Sorting of sub items</source>
        <translation>Ordenación de los sub elementos</translation>
    </message>
    <message>
        <source>Current visibility</source>
        <translation>Visibilidad actual</translation>
    </message>
    <message>
        <source>Visibility after publishing</source>
        <translation>Visibilidad tras publicar</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this location.</source>
        <translation>No tienes permisos para eliminar esta ubicación.</translation>
    </message>
    <message>
        <source>Select location for removal.</source>
        <translation>Elegir la ubicación para eliminar.</translation>
    </message>
    <message>
        <source>Use this menu to set the sorting method for the sub items of the respective location.</source>
        <translation>Usar este menú para indicar el método de ordenación de los sub elementos de la respectiva ubicación.</translation>
    </message>
    <message>
        <source>Use this menu to set the sorting direction for the sub items of the respective location.</source>
        <translation>Usar este menú para indicar la dirección de ordenación de los sub elementos de la respectiva ubicación.</translation>
    </message>
    <message>
        <source>Desc.</source>
        <translation>Desc.</translation>
    </message>
    <message>
        <source>Asc.</source>
        <translation>Asc.</translation>
    </message>
    <message>
        <source>Hidden by parent</source>
        <translation>Oculto por el padre</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Visible</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Sin cambios</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Oculto</translation>
    </message>
    <message>
        <source>Use these radio buttons to specify the main location (main node) for the object being edited.</source>
        <translation>Usar los botones radio para especificar la ubicación principal (nodo principal) del objeto que estás editando.</translation>
    </message>
    <message>
        <source>Move to another location.</source>
        <translation>Mover a otra ubicación.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected locations.</source>
        <translation>Eliminar las ubicaciones seleccionadas.</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Añadir ubicaciones</translation>
    </message>
    <message>
        <source>Add one or more locations for the object being edited.</source>
        <translation>Añadir una o más ubicaciones para el objeto que estás editando.</translation>
    </message>
    <message>
        <source>You can not add or remove locations because the object being edited belongs to a top node.</source>
        <translation>No puedes añadir o eliminar ubicaciones porque el objeto que estás editando pertenece a un nodo raíz.</translation>
    </message>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>View and manage (copy, delete, etc.) the versions of this object.</source>
        <translation>Ver y gestionar (copiar, eliminar, etc.) las versiones de este objeto.</translation>
    </message>
    <message>
        <source>You can not manage the versions of this object because there is only one version available (the one that is being edited).</source>
        <translation>No puedes gestionar las versiones de este objeto porque sólo hay una versión disponible (la que está siendo editada).</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Borrador actual</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <source>View the draft that is being edited.</source>
        <translation>Ver el borrador que estás editando.</translation>
    </message>
    <message>
        <source>Store and exit</source>
        <translation>Almacenar y salir</translation>
    </message>
    <message>
        <source>Store the draft that is being edited and exit from edit mode.</source>
        <translation>Almacenar el borrador que estás editando y salir del modo de edición.</translation>
    </message>
    <message>
        <source>Translations [%translation_count]</source>
        <translation>Traducciones [%translation_count]</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (No hay información de &quot;locale&quot; disponible)</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the selected translation of the draft that is being edited.</source>
        <translation>Editar la traducción seleccionada del borrador que estás editando.</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traducir</translation>
    </message>
    <message>
        <source>Edit the selected translation of the draft using the content being edited as a reference.</source>
        <translation>Editar la traducción seleccionada del borrador usando el contenido editado como referencia.</translation>
    </message>
    <message>
        <source>The draft that is being edited only exists in one language; thus this button is disabled.</source>
        <translation>El borrador que estás editando sólo existe en un lenguaje; por eso este botón está desactivado.</translation>
    </message>
    <message>
        <source>Manage translations</source>
        <translation>Gestionar traducciones</translation>
    </message>
    <message>
        <source>View and manage (add/remove) translations for the draft that is being edited.</source>
        <translation>Ver y gestionar (añadir/eliminar) traducciones para el borrador que estás editando.</translation>
    </message>
    <message>
        <source>Related objects [%related_objects]</source>
        <translation>Objetos relacionados [%related_objects]</translation>
    </message>
    <message>
        <source>Related images [%related_images]</source>
        <translation>Imágenes relacionadas [%related_images]</translation>
    </message>
    <message>
        <source>Copy this code and paste it into an XML field.</source>
        <translation>Copia este código y pégalo en un campo XML.</translation>
    </message>
    <message>
        <source>Related files [%related_files]</source>
        <translation>Archivos relacionados [%related_files]</translation>
    </message>
    <message>
        <source>File type</source>
        <translation>Tipo de archivo</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>XML code</source>
        <translation>Código XML</translation>
    </message>
    <message>
        <source>Related content [%related_objects]</source>
        <translation>Contenido relacionado [%related_objects]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>There are no objects related to the one that is currently being edited.</source>
        <translation>No hay objetos relacionados con el objeto que estás editando actualmente.</translation>
    </message>
    <message>
        <source>Remove the selected items from the list(s) above. It is only the relations that will be removed. The items will not be deleted.</source>
        <translation>Eliminar los elementos seleccionados de la(s) lista(s) de arriba. Sólo se borrarán las relaciones. Los elementos no se borrarán. </translation>
    </message>
    <message>
        <source>Add existing</source>
        <translation>Añadir existente</translation>
    </message>
    <message>
        <source>Add an existing item as a related object.</source>
        <translation>Añadir un elemento existente como un objeto relacionado.</translation>
    </message>
    <message>
        <source>Upload new</source>
        <translation>Subir nuevo</translation>
    </message>
    <message>
        <source>Upload a file and add it as a related object.</source>
        <translation>Subir un archivo y añadirlo como objeto relacionado.</translation>
    </message>
    <message>
        <source>The draft could not be stored.</source>
        <translation>El borrador no se pudo almacenar.</translation>
    </message>
    <message>
        <source>Required data is either missing or is invalid</source>
        <translation>Falta información requerida o no es válida</translation>
    </message>
    <message>
        <source>The following locations are invalid</source>
        <translation>Las siguientes ubicaciones no son válidas</translation>
    </message>
    <message>
        <source>The draft was only partially stored.</source>
        <translation>Sólo se almacenó una parte del borrador.</translation>
    </message>
    <message>
        <source>The draft was successfully stored.</source>
        <translation>El borrador se almacenó con éxito.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit_attribute</name>
    <message>
        <source>not translatable</source>
        <translation>no se puede traducir</translation>
    </message>
    <message>
        <source>required</source>
        <translation>obligatorio</translation>
    </message>
    <message>
        <source>information collector</source>
        <translation>recolector de información</translation>
    </message>
</context>
<context>
    <name>design/admin/content/edit_draft</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Possible edit conflict</source>
        <translation>Posible conflicto de edición</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else. In addition, it is already being edited by you.</source>
        <translation>Este objeto está siendo editado por alguien más. Además, ya lo estás editando.</translation>
    </message>
    <message>
        <source>You should contact the other user(s) to make sure that you are not stepping on anyone&apos;s toes.</source>
        <translation>Debes contactar con los otro(s) usuario(s) para estar seguro de que no estas sobrescribiendo sus datos. </translation>
    </message>
    <message>
        <source>The most recently modified draft is version #%version, created by %creator, last changed: %modified.</source>
        <translation>La última versión modificada del borrador es la versión #%version, creada por %creator, última modificación: %modified.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.</source>
        <translation>Ya estás modificando este objeto.</translation>
    </message>
    <message>
        <source>Your most recently modified draft is version #%version, last changed: %modified.</source>
        <translation>Tu versión más reciente del borrador es la versión #%version, última modificación: %modified.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.</source>
        <translation>Alguien más ya esta editando este objeto.</translation>
    </message>
    <message>
        <source>Possible actions</source>
        <translation>Acciones posibles</translation>
    </message>
    <message>
        <source>Continue editing one of your drafts.</source>
        <translation>Continuar editando uno de tus borradores.</translation>
    </message>
    <message>
        <source>Create a new draft and start editing it.</source>
        <translation>Crear un nuevo borrador y empezar a editarlo.</translation>
    </message>
    <message>
        <source>Cancel the edit operation.</source>
        <translation>Cancelar la edición.</translation>
    </message>
    <message>
        <source>Current drafts [%draft_count]</source>
        <translation>Borradores actuales [%draft_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creado por</translation>
    </message>
    <message>
        <source>Select draft version #%version for editing.</source>
        <translation>Seleccionar la versión #%version del borrador para su edición.</translation>
    </message>
    <message>
        <source>You can not select draft version #%version for editing because it belongs to another user. Please select a draft that belongs to you or create a new draft and then edit it.</source>
        <translation>No puedes seleccionar la versión #%version del borrador para editar porque pertenece a otra persona. Por favor, selecciona uno de tus borradores o crea uno nuevo y editalo. </translation>
    </message>
    <message>
        <source>View the contents of version #%version. Default translation: %default_translation.</source>
        <translation>Ver el contenido de la versión #%version. Traducción por defecto: %default_translation.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Ver el contenido de la versión #%version_number. Traducción: %translation.</translation>
    </message>
    <message>
        <source>Edit selected</source>
        <translation>Editar seleccionado</translation>
    </message>
    <message>
        <source>Edit the selected draft.</source>
        <translation>Editar el borrador seleccionado.</translation>
    </message>
    <message>
        <source>You can not edit any of the drafts because none of them belong to you. Hint: Create a new draft, select it and edit it.</source>
        <translation>No puedes editar ningún borrador porque ninguno de ellos te pertenece. Crea un nuevo borrador, seleccionalo y editalo.</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nuevo borrador</translation>
    </message>
    <message>
        <source>Create a new draft. The contents of the new draft will copied from the published version.</source>
        <translation>Crear un nuevo borrador. El contenido del nuevo borrador se copiará de la versión publicada. </translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/content/pendinglist</name>
    <message>
        <source>My pending items [%pending_count]</source>
        <translation>Mis tareas pendientes [%pending_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>The pending list is empty.</source>
        <translation>La lista de tareas pendientes está vacía.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/removeassignment</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Borrador actual</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Confirm location removal</source>
        <translation>Confirmar ubicación a eliminar</translation>
    </message>
    <message>
        <source>Insufficient permissions</source>
        <translation>Permisos insuficientes</translation>
    </message>
    <message>
        <source>Some of the locations that are about to be removed contain sub items.</source>
        <translation>Algunas de las ubicaciones que estás a punto de eliminar contienen sub elementos.</translation>
    </message>
    <message>
        <source>Removing the locations will also result in the removal of the sub items.</source>
        <translation>Eliminar las ubicaciones también eliminará sus sub elementos.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the locations along with their contents?</source>
        <translation>¿Estás seguro de que quieres eliminar las ubicaciones y todos sus contenidos?</translation>
    </message>
    <message>
        <source>The locations marked with red contain items that you do not have permissions to remove.</source>
        <translation>Las ubicaciones marcadas en rojo contienen elementos de los cuales que no tienes permisos para eliminar.</translation>
    </message>
    <message>
        <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
        <translation>Pulsa el botón &quot;Cancelar&quot; y prueba eliminar sólo las ubicaciones que tengas permitido.</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Sub elementos</translation>
    </message>
    <message>
        <source>%child_count item</source>
        <translation>Elemento %child_count</translation>
    </message>
    <message>
        <source>%child_count items</source>
        <translation>%child_count elementos</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Remove the locations along with all the sub items.</source>
        <translation>Eliminar las ubicaciones y todos sus sub elementos.</translation>
    </message>
    <message>
        <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
        <translation>No puedes cotinuar porque no tienes permisos para eliminar algunas de las ubicaciones seleccionadas.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Cancel the removal of locations.</source>
        <translation>Cancelar la eliminación de ubicaciones.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/removeeditversion</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Borrador actual</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Confirm draft discard</source>
        <translation>Confirmar el descarte del borrador</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>¿Estás seguro de que quieres descartar el borrador?</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/content/removeobject</name>
    <message>
        <source>%child_count item</source>
        <translation>Elemento %child_count</translation>
    </message>
    <message>
        <source>%child_count items</source>
        <translation>%child_count elementos</translation>
    </message>
</context>
<context>
    <name>design/admin/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Búsqueda avanzada</translation>
    </message>
    <message>
        <source>Search for all of the following words</source>
        <translation>Buscar todas las siguientes palabras</translation>
    </message>
    <message>
        <source>Search for an exact phrase</source>
        <translation>Buscar una frase exacta</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Cualquier clase</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Atributo de clase</translation>
    </message>
    <message>
        <source>Any attribute</source>
        <translation>Cualquier atributo</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Actualizar atributos</translation>
    </message>
    <message>
        <source>In</source>
        <translation>En</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Cualquier sección</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Cualquier momento</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Último día</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Última semana</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Último mes</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Últimos tres meses</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Último año</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Vista por página</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 elementos</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 elementos</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 elementos</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 elementos</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 elementos</translation>
    </message>
    <message>
        <source>No results were found when searching for &lt;%1&gt;</source>
        <translation>No se han encontrado resultados al buscar por &lt;%1&gt;</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Search for &lt;%1&gt; returned %2 matches</source>
        <translation>La búsqueda de &lt;%1&gt; devolvió %2 coincidencias</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Todo el contenido</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>La misma ubicación</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2.</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Para obtener más opciones intenta la %1Búsqueda avanzada%2.</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Las siguientes palabras fueron excluidas de la búsqueda</translation>
    </message>
    <message>
        <source>No results were found while searching for &lt;%1&gt;</source>
        <translation>No se han encontrado resultados al buscar por &lt;%1&gt;</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Trucos de búsqueda</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Comprobar la ortografía de las palabras clave.</translation>
    </message>
    <message>
        <source>Try changing some keywords e.g. car instead of cars.</source>
        <translation>Intenta cambiar algunas palabras clave. Por ejemplo: coche en lugar de coches.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Intenta palabras claves más generales.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>Menos palabras clave ofrecen más resultados. Intenta reducir las palabras clave hasta que obtengas un resultado.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translate</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Borrador actual</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Confirm translation removal</source>
        <translation>Confirmar eliminación de traducción</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the translation?</source>
        <translation>¿Estás seguro de que quieres eliminar la traducción?</translation>
    </message>
    <message>
        <source>The following translation (along with translated content) will be removed from the draft</source>
        <translation>La siguiente traducción (junto con su contenido) se eliminará del borrador</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the translations?</source>
        <translation>¿Estás seguro de que quieres eliminar las traducciones?</translation>
    </message>
    <message>
        <source>The following translations (along with translated content) will be removed from the draft</source>
        <translation>Las siguientes traducciones (junto con sus contenidos) se eliminarán del borrador</translation>
    </message>
    <message>
        <source>(No locale information available.)</source>
        <translation>(No hay información de &quot;locale&quot; disponible)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Translations for &lt;%object_name&gt; [%translation_count]</source>
        <translation>Traducciones para &lt;%object_name&gt; [%translation_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>&quot;Locale&quot;</translation>
    </message>
    <message>
        <source>Select translation for removal.</source>
        <translation>Elegir traducción para eliminar.</translation>
    </message>
    <message>
        <source>(Unable to display because of unknown locale!)</source>
        <translation>(Imposible mostrar porque la &quot;locale&quot; es desconocida!)</translation>
    </message>
    <message>
        <source>There are no translations available.</source>
        <translation>No hay traducciones disponibles.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove the selected translations from the draft that is being edited.</source>
        <translation>Eliminar las traducciones seleccionadas del borrador que estás editando.</translation>
    </message>
    <message>
        <source>Select a translation you wish to add to the draft that is being edited.</source>
        <translation>Elige la traducción que deseas añadir al borrador que estás editando.</translation>
    </message>
    <message>
        <source>All available translations have been added to the draft that is being edited.</source>
        <translation>Todas las traducciones disponibles han sido añadidas al borrador que estás editando.</translation>
    </message>
    <message>
        <source>No languages</source>
        <translation>No hay lenguajes</translation>
    </message>
    <message>
        <source>Add translation</source>
        <translation>Añadir traducción</translation>
    </message>
    <message>
        <source>Add the selected translation to the draft that is being edited.</source>
        <translation>Añadir la traducción seleccionada al borrador que estás editando.</translation>
    </message>
    <message>
        <source>Back to edit mode</source>
        <translation>Volver al modo de edición</translation>
    </message>
    <message>
        <source>Go back to edit mode.</source>
        <translation>Volver al modo de edición.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translationnew</name>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Nueva traducción para contenido</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizada</translation>
    </message>
    <message>
        <source>Name of custom translation</source>
        <translation>Nombre de la traducción personalizada</translation>
    </message>
    <message>
        <source>Locale for custom translation</source>
        <translation>&quot;Locale&quot; para traducción personalizada</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translations</name>
    <message>
        <source>Available languages for translation of content [%translations_count]</source>
        <translation>Lenguajes disponibles para la traducción de contenido [%translations_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir selección.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>&quot;Locale&quot;</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>The default language can not be removed.</source>
        <translation>El lenguaje predeterminado no puede ser eliminado.</translation>
    </message>
    <message>
        <source>Select language for removal.</source>
        <translation>Elegir lenguaje para eliminar.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected languages.</source>
        <translation>Eliminar los lenguajes seleccionados.</translation>
    </message>
    <message>
        <source>Add language</source>
        <translation>Añadir lenguaje</translation>
    </message>
    <message>
        <source>Add a new language. The new language can then be used when translating content.</source>
        <translation>Añadir un nuevo lenguaje. El nuevo lenguaje se podrá utilizar para traducir contenido.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/translationview</name>
    <message>
        <source>%translation [Translation]</source>
        <translation>%translation [Traducción]</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Locale</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>%locale [Locale]</source>
        <translation>%locale [Locale]</translation>
    </message>
    <message>
        <source>Charset</source>
        <translation>Juego de caracteres</translation>
    </message>
    <message>
        <source>Not set</source>
        <translation>No fijado</translation>
    </message>
    <message>
        <source>Allowed charsets</source>
        <translation>Juego de caracteres permitidos</translation>
    </message>
    <message>
        <source>Country name</source>
        <translation>Nombre del país</translation>
    </message>
    <message>
        <source>Country comment</source>
        <translation>Comentario del país</translation>
    </message>
    <message>
        <source>Country code</source>
        <translation>Código del país</translation>
    </message>
    <message>
        <source>Country variation</source>
        <translation>Variación del país</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Nombre del idioma</translation>
    </message>
    <message>
        <source>International language name</source>
        <translation>Nombre internacional del lenguaje</translation>
    </message>
    <message>
        <source>Language code</source>
        <translation>Código del lenguaje</translation>
    </message>
    <message>
        <source>Language comment</source>
        <translation>Comentario del lenguaje</translation>
    </message>
    <message>
        <source>Locale code</source>
        <translation>Código de &quot;locale&quot;</translation>
    </message>
    <message>
        <source>Full locale code</source>
        <translation>Código completo de &quot;locale&quot;</translation>
    </message>
    <message>
        <source>HTTP locale code</source>
        <translation>Código HTTP de &quot;locale&quot;</translation>
    </message>
    <message>
        <source>Decimal symbol</source>
        <translation>Símbolo de decimales</translation>
    </message>
    <message>
        <source>Thousands separator</source>
        <translation>Separador de millares</translation>
    </message>
    <message>
        <source>Decimal count</source>
        <translation>Número de decimales</translation>
    </message>
    <message>
        <source>Negative symbol</source>
        <translation>Símbolo negativo</translation>
    </message>
    <message>
        <source>Positive symbol</source>
        <translation>Símbolo positivo</translation>
    </message>
    <message>
        <source>Currency decimal symbol</source>
        <translation>Símbolo de decimales para la divisa</translation>
    </message>
    <message>
        <source>Currency thousands separator</source>
        <translation>Separador de millares para la divisa</translation>
    </message>
    <message>
        <source>Currency decimal count</source>
        <translation>Número de decimales para la divisa</translation>
    </message>
    <message>
        <source>Currency negative symbol</source>
        <translation>Símbolo negativo para la divisa</translation>
    </message>
    <message>
        <source>Currency positive symbol</source>
        <translation>Símbolo positivo para la divisa</translation>
    </message>
    <message>
        <source>Currency symbol</source>
        <translation>Símbolo de la divisa</translation>
    </message>
    <message>
        <source>Currency name</source>
        <translation>Nombre de la divisa</translation>
    </message>
    <message>
        <source>Currency short name</source>
        <translation>Nombre corto de la divisa</translation>
    </message>
    <message>
        <source>First day of week</source>
        <translation>Primer día de la semana</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lunes</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Domingo</translation>
    </message>
    <message>
        <source>Weekday names</source>
        <translation>Nombre de los días de la semana</translation>
    </message>
    <message>
        <source>Month names</source>
        <translation>Nombre de los meses</translation>
    </message>
</context>
<context>
    <name>design/admin/content/trash</name>
    <message>
        <source>Trash [%list_count]</source>
        <translation>Papelera [%list_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Use these checkboxes to mark items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
        <translation>Usar las casillas de verificación para marcar los elementos a eliminar. Pulsa el botón &quot;Eliminar seleccionados&quot; para eliminar los elementos seleccionados.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>There are no items in the trash</source>
        <translation>No hay elementos en la papelera</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Permanently remove the selected items.</source>
        <translation>Eliminar permanentemente los elementos seleccionados.</translation>
    </message>
    <message>
        <source>Empty trash</source>
        <translation>Vaciar papelera</translation>
    </message>
    <message>
        <source>Permanently remove all items from the trash.</source>
        <translation>Eliminar permanentemente todos los elementos de la papelera.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/upload</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>Current draft</source>
        <translation>Borrador actual</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>The file could not be uploaded</source>
        <translation>No se pudo subir el archivo</translation>
    </message>
    <message>
        <source>The following errors occurred</source>
        <translation>Ocurrieron los siguientes errores</translation>
    </message>
    <message>
        <source>File upload</source>
        <translation>Subir archivo</translation>
    </message>
    <message>
        <source>Choose a file from your local machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
        <translation>Elige un archivo de tu máquina y pulsa el botón &quot;Subir&quot;. Se creará un objeto del tipo del archivo subido y se colocará en la ubicación seleccionada.</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Subir archivo</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>The location where the uploaded file should be placed.</source>
        <translation>La ubicación donde se guardará el archivo subido.</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Select the file that you wish to upload.</source>
        <translation>Elige el archivo que quieres subir.</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Proceed with uploading the selected file.</source>
        <translation>Proceder con la subida del archivo seleccionado.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Abort the upload operation and go back to where you came from.</source>
        <translation>Abortar la operación de subida y volver donde procedes.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/upload_related</name>
    <message>
        <source>Upload a file and relate it to &lt;%version_name&gt;</source>
        <translation>Subir un archivo y asociarlo a &lt;%version_name&gt;</translation>
    </message>
    <message>
        <source>This operation allows you to upload a file and add it as a related object.</source>
        <translation>Esta operación te permite subir un archivo y añadirlo como objeto relacionado.</translation>
    </message>
    <message>
        <source>When the file is uploaded, an object will be created according to the type of the file.</source>
        <translation>Cuando se ha suba el archivo, se creará un objeto del tipo del fichero.</translation>
    </message>
    <message>
        <source>The newly created object will be placed within the chosen location.</source>
        <translation>El objeto recién creado se colocará en la ubicación seleccionada.</translation>
    </message>
    <message>
        <source>The newly created object will be automatically related to the draft being edited (&lt;%version_name&gt;).</source>
        <translation>El objeto recién creado se asociará automaticamente al borrador que se está editando (&lt;%version_name&gt;).</translation>
    </message>
    <message>
        <source>Select the file you wish to upload and click the &quot;Upload&quot; button.</source>
        <translation>Elege el archivo que quieres subir y pulsa el botón &quot;Subir&quot;.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/urltranslator</name>
    <message>
        <source>The destination URL &lt;%destination_url&gt; does not exist in the system.</source>
        <translation>La URL de destino &lt;%destination_url&gt; no existe en el sistema.</translation>
    </message>
    <message>
        <source>New system URL forwarding</source>
        <translation>Nueva URL de redirección de sistema</translation>
    </message>
    <message>
        <source>System URL</source>
        <translation>URL de sistema</translation>
    </message>
    <message>
        <source>Example: /services</source>
        <translation>Ejemplo: /services</translation>
    </message>
    <message>
        <source>Example: /content/view/full/42</source>
        <translation>Ejemplo: /content/view/full/42</translation>
    </message>
    <message>
        <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system.</source>
        <translation>Usar este campo para indicar la dirección relativa a la raiz del sistema que debe ser traducida en otra URL. Esta dirección no tiene porque existir en el sistema actual.</translation>
    </message>
    <message>
        <source>Use this field to enter a valid system URL. A system URL is easily recognized since it consists of several parts separated by a &quot;/&quot;.</source>
        <translation>Usar este campo para indicar una URL de sistema válida. Una URL de sistema se reconoce facilmente ya que contiene varias partes separadas por &quot;/&quot;.</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <source>Click this button to add a new system URL forwarding. System URL forwarding is used to forward any URL to a system URL in eZ publish.</source>
        <translation>Pulsar este botón para añadir una nueva redirección de URL de sistema. La redirección de URL de sistema se usa para redirigie cualquier URL a una URL de sistema en eZ publish.</translation>
    </message>
    <message>
        <source>New virtual URL forwarding</source>
        <translation>Nueva redirección de URL virtual</translation>
    </message>
    <message>
        <source>Existing virtual URL</source>
        <translation>URL virtual existente</translation>
    </message>
    <message>
        <source>Example: /about/service</source>
        <translation>Ejemplo: /about/service</translation>
    </message>
    <message>
        <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object.</source>
        <translation>Usar este campo para indicar una URL virtual válida existente en el sistema. Una URL virtual esta generada por el sistema y suele contener parte del contenido de un objeto.</translation>
    </message>
    <message>
        <source>Click this button to add a new virtual URL forwarding. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish.</source>
        <translation>Pulsar este botón para añadir una nueva redirección de URL virtual. La redirección de URL virtual se usa para redirigir cualquier URL a una URL virtual existente en eZ publish.</translation>
    </message>
    <message>
        <source>New virtual URL forwarding with wildcard</source>
        <translation>Nueva redirección a URL virtual con asterisco</translation>
    </message>
    <message>
        <source>Redirecting URL</source>
        <translation>Redirigiendo URL</translation>
    </message>
    <message>
        <source>Example: /developer/*</source>
        <translation>Ejemplo: /developer/*</translation>
    </message>
    <message>
        <source>Example</source>
        <translation>Ejemplo</translation>
    </message>
    <message>
        <source>Use this field to enter an address relative to the root of the system that should be translated into another URL. This address does not have to exist in your current system. You can place a star anywhere in the URL which will match an arbitrary number of characters.</source>
        <translation>Usar este campo para indicar una dirección relativa a la raiz del sistema que debe ser traducida en otra URL. Esta dirección no tiene porque existir en el sistema actual. Puedes colocar un asterisco en cualquier parte de la URL, esto hará coincidir un número arbitrario de carácteres.</translation>
    </message>
    <message>
        <source>Use this field to enter a valid existing virtual URL in the system. A virtual URL is generated by the system and usually contains part of the content of an object. Any characters matched by a star in the source URL can be transfered to the destination URL by inserting {1\} where appropriate.</source>
        <translation>Usar este campo para indicar una URL virtual valida y existente en el sistema. Una URL virtual esta generado por el sistema y suele contener parte del contenido de un objeto. Cualquier carácter que coincida por el asterisco en la URL de origen será transferido a la URL de destino insertando {1\} en el lugar adecuado.</translation>
    </message>
    <message>
        <source>Use this checkbox to select if eZ publish should perform an internal redirect or a browser redirect. An internal redirect simply redirects the old URL to the new one without notifying the browser. A browser redirect makes the browser abort the current request and reload with the new URL. A browser redirect can be useful if you want the browser URL field to be updated.</source>
        <translation>Usar esta opicón para elegir si eZ publish debe realizar una redirección interna o una redirección de navegador. Una redirección interna simplemente redirige la URL antigua a una nueva sin notificar al navegador. Una redirección de navegador hace que el navegador aborte la petición actual y recargue la nueva URL. Una redirección de navegador puede ser de ayuda si quieres que el campo URL del navegador sea actualizado.</translation>
    </message>
    <message>
        <source>Click this button to add a new virtual URL forwarding with wildcard match. Virtual URL forwarding is used to forward any URL to an existing virtual URL in eZ publish. The wildcard match is useful if you have moved a complete tree from one place to another.</source>
        <translation>Pulsar este botón para añadir una nueva redirección de URL virtual con asterisco. La redirección virtual de URL se usa para redirigir cualquier URL a una URL virtual existente en eZ publish. El uso del asterisco puede ser de ayuda si has movido un árbol completo de un sitio a otro.</translation>
    </message>
    <message>
        <source>Custom URL translations [%alias_count]</source>
        <translation>Traducciones de URL personalizadas [%alias_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Source URL</source>
        <translation>URL origen</translation>
    </message>
    <message>
        <source>Destination URL</source>
        <translation>URL de destino</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Select URL translation for removal.</source>
        <translation>Elegir traducción de URL para eliminar.</translation>
    </message>
    <message>
        <source>Forwards to</source>
        <translation>Redirige a</translation>
    </message>
    <message>
        <source>Wildcard forwarding</source>
        <translation>Redirección con asterisco</translation>
    </message>
    <message>
        <source>System forwarding</source>
        <translation>Redirección de sistema</translation>
    </message>
    <message>
        <source>Virtual forwarding</source>
        <translation>Redirección virtual</translation>
    </message>
    <message>
        <source>There are no custom URL translations.</source>
        <translation>No hay ninguna traducción de URL personalizada.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected URL translations.</source>
        <translation>Eliminar las traducciones de URL seleccionadas.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields in the list above.</source>
        <translation>Pulsa este botón para guardar los cambios si has modificado algún campo de la lista de arriba.</translation>
    </message>
    <message>
        <source>New virtual URL</source>
        <translation>Nueva URL virtual</translation>
    </message>
    <message>
        <source>New virtual URL wildcard</source>
        <translation>Nueva URL virtual con asterisco</translation>
    </message>
</context>
<context>
    <name>design/admin/content/versions</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Esta versión no es un borrador</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>La versión %1 ya no está disponible para ser editada. Sólo los borradores pueden ser editados.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Para editar esta versión, crea una copia.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>La versión no es tuya</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>No eres el creador de la versión %1. Sólo puedes editar tus borradores.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>No se pudo crear una nueva versión</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>El límite de historial de versiones ha sido excedido y las versiones no archivadas pueden ser eliminadas por el sistema.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Puedes cambiar tu configuración de historial de versiones en content.ini. También puedes eliminar versiones de borradores o editar los borradores existentes.</translation>
    </message>
    <message>
        <source>Versions for &lt;%object_name&gt; [%version_count]</source>
        <translation>Versiones de &lt;%object_name&gt; [%version_count]</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creado por</translation>
    </message>
    <message>
        <source>Select version #%version_number for removal.</source>
        <translation>Elegir versión #%version_number para eliminar.</translation>
    </message>
    <message>
        <source>Version #%version_number can not be removed because it is either the published version of the object or because you do not have permissions to remove it.</source>
        <translation>La versión #%version_number no se puede eliminar porque o bien es la versión publicada del objeto o no tienes permisos para eliminarla.</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Default translation: %default_translation.</source>
        <translation>Ver los contenidos de la versión #%version_number. Traducción predeterminada: %default_translation.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Pendiente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Archivada</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Rechazada</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Translation: %translation.</source>
        <translation>Ver los contenidos de la versión #%version_number. Traducción: %translation.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Create a copy of version #%version_number.</source>
        <translation>Crear una copia de la versión #%version_number.</translation>
    </message>
    <message>
        <source>You can not make copies of versions because you do not have permissions to edit the object.</source>
        <translation>No puedes hacer copias de versiones porque no tienes permisos para editar el objeto.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the contents of version #%version_number.</source>
        <translation>Editar los cotenidos de la versión #%version_number.</translation>
    </message>
    <message>
        <source>You can not edit the contents of version #%version_number either because it is not a draft or because you do not have permissions to edit the object.</source>
        <translation>No puedes editar los contenidos de la versión #%version_number porque o bien no es un borrador o no tienes permisos para editar el objeto.</translation>
    </message>
    <message>
        <source>This object does not have any versions.</source>
        <translation>Este objeto no tiene ninguna versión.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove the selected versions from the object.</source>
        <translation>Eliminar las versiones seleccionadas del objeto.</translation>
    </message>
</context>
<context>
    <name>design/admin/content/view/versionview</name>
    <message>
        <source>Object information</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>Manage versions</source>
        <translation>Gestionar versiones</translation>
    </message>
    <message>
        <source>View and manage (copy, delete, etc.) the versions of this object.</source>
        <translation>Ver y gestionar (copiar, eliminar, etc.) las versiones de este objeto.</translation>
    </message>
    <message>
        <source>You can not manage the versions of this object because there is only one version available (the one that is being displayed).</source>
        <translation>No puedes gestionar las versiones de este objeto porque sólo hay una versión disponible (la que se está mostrando).</translation>
    </message>
    <message>
        <source>Version information</source>
        <translation>Información de la versión</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <source>Published / current</source>
        <translation>Publicado / actual</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Pendiente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Guardado</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Rechazado</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>View control</source>
        <translation>Ver control</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (No hay información de &quot;locale&quot; disponible)</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Diseño</translation>
    </message>
    <message>
        <source>Update view</source>
        <translation>Actualizar vista</translation>
    </message>
    <message>
        <source>View the version that is currently being displayed using the selected language, location and design.</source>
        <translation>Ver la versión actual usando el lenguaje seleccionado, la ubicación y el diseño.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the draft that is being displayed.</source>
        <translation>Editar el borrador que estás viendo.</translation>
    </message>
    <message>
        <source>This version is not a draft and thus it can not be edited.</source>
        <translation>Esta versión no es un borrador y por eso no puede ser editada.</translation>
    </message>
</context>
<context>
    <name>design/admin/contentstructuremenu</name>
    <message>
        <source>Fold/Unfold</source>
        <translation>Plegar/Desplegar</translation>
    </message>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>[%classname] Haz click en el icono para ver el menú contextual.</translation>
    </message>
</context>
<context>
    <name>design/admin/error/kernel</name>
    <message>
        <source>The requested page could not be displayed. (1)</source>
        <translation>No se pudo mostrar la página solicitada. (1)</translation>
    </message>
    <message>
        <source>The system is unable to display the requested page because of security issues.</source>
        <translation>El sistema no puede mostrar la página solicitada por temas de seguridad.</translation>
    </message>
    <message>
        <source>Possible reasons</source>
        <translation>Posibles razones</translation>
    </message>
    <message>
        <source>Your account does not have the proper privileges to access the requested page.</source>
        <translation>Tu cuenta no tiene los privilegios adecuados para acceder a la página solicitada.</translation>
    </message>
    <message>
        <source>You are not logged into the system. Please log in.</source>
        <translation>No estás conectado en el sistema. Por favor conectate.</translation>
    </message>
    <message>
        <source>The requested page does not exist. Try changing the URL.</source>
        <translation>La página solicitada no existe. Prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>The following permission setting is required</source>
        <translation>El siguiente permiso es requerido</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Click the &quot;Log in&quot; button in order to log in.</source>
        <translation>Pulsa el botón &quot;Conectar&quot; para conectarte.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Conectar</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (2)</source>
        <translation>No se pudo mostrar la página solicitada. (2)</translation>
    </message>
    <message>
        <source>The resource you requested was not found.</source>
        <translation>El recurso que has pedido no se ha encontrado.</translation>
    </message>
    <message>
        <source>The ID number or the name of the resource was misspelled. Try changing the URL.</source>
        <translation>El ID o el nombre del recurso está mal escrito. Prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>The resource is no longer available.</source>
        <translation>El recurso ya no existe.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (20)</source>
        <translation>No se pudo mostrar la página solicitada. (20)</translation>
    </message>
    <message>
        <source>The requested address or module could not be found.</source>
        <translation>No se pudo encontrar la dirección o el módulo solicitado.</translation>
    </message>
    <message>
        <source>The address was misspelled. Try changing the URL.</source>
        <translation>La dirección está mal escrita. Prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>The name of the module was misspelled. Try changing the URL.</source>
        <translation>El nombre del módulo está mal escrito. Prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>There is no &lt;%module&gt; module available on this site.</source>
        <translation>No hay ningún módulo &lt;%module&gt; disponible en este sitio.</translation>
    </message>
    <message>
        <source>The site is using URL matching to determine which siteaccess to use, but the name of the siteaccess is missing from the URL. Try to add the name of the siteaccess, it should be specified before the name of the module.</source>
        <translation>Este sitio usa la URL para determinar cual acceso de sitio usar, pero el nombre de acceso de sitio falta en la URL. Intenta añadir el nombre del acceso de sitio, debe aparecer antes del nombre del módulo.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (21)</source>
        <translation>No se pudo mostrar la página solicitada. (21)</translation>
    </message>
    <message>
        <source>The requested view &lt;%view&gt; could not be found in the &lt;%module&gt; module.</source>
        <translation>No se encontró la vista solicitada &lt;%view&gt; en el módulo &lt;%module&gt;.</translation>
    </message>
    <message>
        <source>The name of the view was misspelled. Try changing the URL.</source>
        <translation>El nombre de la vista está mal escrito. Prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>The &lt;%module&gt; module does not have a &lt;%view&gt; view.</source>
        <translation>El módulo &lt;%module&gt; no tiene una vista &lt;%view&gt;.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (22)</source>
        <translation>No se pudo mostrar la página solicitada. (22)</translation>
    </message>
    <message>
        <source>The requested view can not be accessed.</source>
        <translation>No se puede acceder a la vista solicitada.</translation>
    </message>
    <message>
        <source>The &lt;%view&gt; within the &lt;%module&gt; is disabled and thus it can not be accessed.</source>
        <translation>La vista &lt;%view&gt; está desactivada dentro de &lt;%module&gt;, no se puede accder.</translation>
    </message>
    <message>
        <source>The requested module can not be accessed.</source>
        <translation>No se puede acceder al módulo solicitado.</translation>
    </message>
    <message>
        <source>The &lt;%module&gt; module is disabled and thus it can not be accessed.</source>
        <translation>El módulo &lt;%module&gt; está desactivado y no se puede acceder.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (3)</source>
        <translation>No se pudo mostrar la página solicitada. (3)</translation>
    </message>
    <message>
        <source>The requested object is not available.</source>
        <translation>El objeto solicitado no está disponible.</translation>
    </message>
    <message>
        <source>The ID number of the object is incorrect. Please check the URL for spelling mistakes.</source>
        <translation>El ID del objeto es incorrecto. Por favor comprueba que no haya errores en la URL.</translation>
    </message>
    <message>
        <source>The object is no longer available.</source>
        <translation>El objeto ya no esta disponible.</translation>
    </message>
    <message>
        <source>The requested page could not be displayed. (4)</source>
        <translation>No se pudo mostrar la página solicitada. (4)</translation>
    </message>
    <message>
        <source>The requested object has been moved and thus it is no longer available at the specified address.</source>
        <translation>El objeto solicitado ha sido movido y ya no está disponible en la dirección especificada.</translation>
    </message>
    <message>
        <source>The system should automatically redirect you to the new location of the object.</source>
        <translation>El sistema intentará redirigirte automáticamente a la nueva ubicación del objeto.</translation>
    </message>
    <message>
        <source>If redirection fails, please click on the following address: %url.</source>
        <translation>Si la redirección falla, por favor haz click en las siguientes direccioines: %url.</translation>
    </message>
</context>
<context>
    <name>design/admin/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
</context>
<context>
    <name>design/admin/node/removenode</name>
    <message>
        <source>Remove node?</source>
        <translation>¿Eliminar nudo?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>¿Estás seguro de que quieres eliminar %1 del nudo %2?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove its %1 children.</source>
        <translation>Eliminando esta asignación también eliminarás su(s) %1 hijo(s).</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Los nudos eliminados pueden ser recuperados más tarde. Los podrás encontrar en la papelera.</translation>
    </message>
    <message>
        <source>Removing node assignment of %1</source>
        <translation>Eliminando la asignación del nudo de %1</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/node/removeobject</name>
    <message>
        <source>Confirm location removal</source>
        <translation>Confirmar ubicación a eliminar</translation>
    </message>
    <message>
        <source>Insufficient permissions</source>
        <translation>Permisos insuficientes</translation>
    </message>
    <message>
        <source>Some of the items that are about to be removed contain sub items.</source>
        <translation>Algunos de los elementos que estás a punto de eliminar contienen sub elementos.</translation>
    </message>
    <message>
        <source>Removing the items will also result in the removal of their sub items.</source>
        <translation>Eliminar los elementos también eliminará sus sub elementos.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the items along with their contents?</source>
        <translation>¿Estás seguro de que quieres eliminar los elementos y todos sus contenidos?</translation>
    </message>
    <message>
        <source>The lines marked with red contain items that you do not have permissions to remove.</source>
        <translation>Las líneas marcadas en rojo contienen elementos de los cuales que no tienes permisos para eliminar.</translation>
    </message>
    <message>
        <source>Click the &quot;Cancel&quot; button and try removing only the locations that you are allowed to remove.</source>
        <translation>Pulsa el botón &quot;Cancelar&quot; y prueba eliminar sólo las ubicaciones que tengas permitido.</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Elemento</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Sub elementos</translation>
    </message>
    <message>
        <source>If &quot;Move to trash&quot; is checked, the items will be moved to the trash instead of being permanently deleted.</source>
        <translation>Si &quot;Mover a la papelera&quot; está marcado, los elementos se moverán a la papelera en vez de eliminarlos para siempre.</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Mover a la papelera</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>You can not continue because you do not have permissions to remove some of the selected locations.</source>
        <translation>No puedes cotinuar porque no tienes permisos para eliminar algunas de las ubicaciones seleccionadas.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Cancel the removal of locations.</source>
        <translation>Cancelar la eliminación de ubicaciones.</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view</name>
    <message>
        <source>Two level index for &lt;%node_name&gt;</source>
        <translation>Dos niveles de indice para &lt;%node_name&gt;</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <source>Hide preview of content.</source>
        <translation>Ocultar la vista previa del contenido.</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Show preview of content.</source>
        <translation>Mostrar la vista previa del contenido.</translation>
    </message>
    <message>
        <source>Hide details.</source>
        <translation>Ocultar detalles.</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <source>Show details.</source>
        <translation>Mostrar detalles.</translation>
    </message>
    <message>
        <source>Hide available translations.</source>
        <translation>Ocultar las traducciones disponibles.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Show available translations.</source>
        <translation>Mostrar las traducciones disponibles.</translation>
    </message>
    <message>
        <source>Hide location overview.</source>
        <translation>Ocultar las ubicaciones.</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Ubicaciones</translation>
    </message>
    <message>
        <source>Show location overview.</source>
        <translation>Mostrar las ubicaciones.</translation>
    </message>
    <message>
        <source>Hide relation overview.</source>
        <translation>Ocultar las relaciones.</translation>
    </message>
    <message>
        <source>Relations</source>
        <translation>Relaciones</translation>
    </message>
    <message>
        <source>Show relation overview.</source>
        <translation>Mostrar las relaciones.</translation>
    </message>
    <message>
        <source>Hide role overview.</source>
        <translation>Ocultar los roles.</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Roles</translation>
    </message>
    <message>
        <source>Show role overview.</source>
        <translation>Mostrar los roles.</translation>
    </message>
    <message>
        <source>Hide policy overview.</source>
        <translation>Ocultar las políticas.</translation>
    </message>
    <message>
        <source>Policies</source>
        <translation>Políticas</translation>
    </message>
    <message>
        <source>Show policy overview.</source>
        <translation>Mostrar las políticas.</translation>
    </message>
    <message>
        <source>Up one level.</source>
        <translation>Subir un nivel.</translation>
    </message>
    <message>
        <source>Sub items [%children_count]</source>
        <translation>Sub elementos [%children_count]</translation>
    </message>
    <message>
        <source>Show 10 items per page.</source>
        <translation>Mostrar 10 elementos por página.</translation>
    </message>
    <message>
        <source>Show 50 items per page.</source>
        <translation>Mostrar 50 elementos por página.</translation>
    </message>
    <message>
        <source>Show 25 items per page.</source>
        <translation>Mostrar 25 elementos por página.</translation>
    </message>
    <message>
        <source>Display sub items using a simple list.</source>
        <translation>Mostrar sub elementos usando una lista simple.</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation>Diapositiva</translation>
    </message>
    <message>
        <source>Display sub items using a detailed list.</source>
        <translation>Mostrar sub elementos usando una lista detallada.</translation>
    </message>
    <message>
        <source>Detailed</source>
        <translation>Detallado</translation>
    </message>
    <message>
        <source>Display sub items as thumbnails.</source>
        <translation>Mostrar sub elementos como diapositivas.</translation>
    </message>
    <message>
        <source>The current item does not contain any sub items.</source>
        <translation>El elemento actual no contiene ningún sub elemento.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove the selected items from the list above.</source>
        <translation>Eliminar los elementos seleccionados de la lista de arriba.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove any of the items from the list above.</source>
        <translation>No tienes permisos para eliminar los elementos de la lista de arriba.</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Actualizar prioridades</translation>
    </message>
    <message>
        <source>Apply changes to the priorities of the items in the list above.</source>
        <translation>Aplicar cambios a las prioridades de los elementos de la lista de arriba.</translation>
    </message>
    <message>
        <source>You can not update the priorities because you do not have permissions to edit the current item or because a non-priority sorting method is used.</source>
        <translation>No puedes actualizar las prioridades porque no tienes permisos para editar el elemento actual o porque se ha usado un método de ordenación no prioritario.</translation>
    </message>
    <message>
        <source>Use this menu to select the type of item you wish to create and click the &quot;Create here&quot; button. The item will be created within the current location.</source>
        <translation>Usar este menú para seleccionar el tipo de elemento que deseas crear y pulsa el botón &quot;Crear aquí&quot;. El elemento se creará en la ubicación actual.</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Crear aquí</translation>
    </message>
    <message>
        <source>Create a new item within the current location. Use the menu on the left to select the type of the item.</source>
        <translation>Crear un nuevo elemento en la ubicación actual. Usar el menú de la izquierda para seleccionar el tipo de elemento.</translation>
    </message>
    <message>
        <source>Not available</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <source>You do not have permissions to create new items within the current location.</source>
        <translation>No tienes permisos para crear nuevos elementos en la ubicación actual.</translation>
    </message>
    <message>
        <source>Sorting</source>
        <translation>Orden</translation>
    </message>
    <message>
        <source>Class identifier</source>
        <translation>Identificador de clase</translation>
    </message>
    <message>
        <source>Class name</source>
        <translation>Nombre de clase</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Profundidad</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>You can not set the sorting method for the current location because you do not have permissions to edit the current item.</source>
        <translation>No puedes fijar el método de ordenación porque no tienes permisos para editar el elemento actual.</translation>
    </message>
    <message>
        <source>Use these controls to set the sorting method for the sub items of the current location.</source>
        <translation>Usar estos controles para fijar el método de ordenación de los elementos de la ubicación actual.</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Descendente</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Ascendente</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Visibility</source>
        <translation>Visibilidad</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Use these checkboxes to select items for removal. Click the &quot;Remove selected&quot; button to actually remove the selected items.</source>
        <translation>Usa estas casillas de verificación para seleccionar los elementos a eliminar. Pulsa el botón &quot;Eliminar la selección&quot; para eliminar los elementos seleccionados.</translation>
    </message>
    <message>
        <source>You do not have permissions to remove this item.</source>
        <translation>No tienes permisos para eliminar este elemento.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Use the priority fields to control the order in which the items appear. Use positive and negative integers. Click the &quot;Update priorities&quot; button to apply the changes.</source>
        <translation>Usa los campos de prioridad para controlar el orden en el cual aparecen los elementos. Usa números enteros positivos y negativos. Pulsa el botón &quot;Actualizar prioridades&quot; para aplicar los cambios.</translation>
    </message>
    <message>
        <source>You are not allowed to update the priorities because you do not have permissions to edit &lt;%node_name&gt;.</source>
        <translation>No puedes actualizar las prioridades porque no tienes permisos para editar &lt;%node_name&gt;.</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Create a copy of &lt;%child_name&gt;.</source>
        <translation>Crear una copia de &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You can not make a copy of &lt;%child_name&gt; because you do not have create permissions for &lt;%node_name&gt;.</source>
        <translation>No puedes hacer una copia de &lt;%child_name&gt; porque no tienes permisos de creación para &lt;%node_name&gt;.</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <source>Move &lt;%child_name&gt; to another location.</source>
        <translation>Mover &lt;%child_name&gt; a otra ubicación.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation>Editar &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit &lt;%child_name&gt;.</source>
        <translation>No tienes permisos para editar &lt;%child_name&gt;.</translation>
    </message>
    <message>
        <source>You do not have permissions remove this item.</source>
        <translation>No tienes permisos para eliminar este elemento.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit %child_name.</source>
        <translation>No tienes permisos para editar %child_name.</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creado por</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versiones</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID del nudo</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>ID del objeto</translation>
    </message>
    <message>
        <source>The information could not be collected.</source>
        <translation>La información no pudo ser recogida.</translation>
    </message>
    <message>
        <source>Required data is either missing or is invalid</source>
        <translation>Faltan datos obligatorios o no son válidos</translation>
    </message>
    <message>
        <source>Locations [%locations]</source>
        <translation>Ubicaciones [%locations]</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Sub items</source>
        <translation>Sub elementos</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>This location can not be removed either because you do not have permissions to remove it or because it is currently being displayed.</source>
        <translation>No se puede eliminar esta ubicación porque no tienes permisos para eliminarla o porque se está mostrando actualmente.</translation>
    </message>
    <message>
        <source>Select location for removal.</source>
        <translation>Elegir ubicación para eliminar.</translation>
    </message>
    <message>
        <source>down</source>
        <translation>abajo</translation>
    </message>
    <message>
        <source>up</source>
        <translation>arriba</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Oculto</translation>
    </message>
    <message>
        <source>Make location and all sub items visible.</source>
        <translation>Hacer visible la ubicación y todos sus sub elementos.</translation>
    </message>
    <message>
        <source>Reveal</source>
        <translation>Revelar</translation>
    </message>
    <message>
        <source>Hidden by superior</source>
        <translation>Oculto por superior</translation>
    </message>
    <message>
        <source>Hide location and all sub items.</source>
        <translation>Ocultar ubicación y todos sus sub elementos.</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Visible</translation>
    </message>
    <message>
        <source>Use these radio buttons to select the desired main location.</source>
        <translation>Usar los botones radio para elegir la ubicación principal.</translation>
    </message>
    <message>
        <source>The item being displayed has only one location and thus it does not make sense to set it.</source>
        <translation>El elemento que se está mostrando sólo tiene una ubicación, no tiene sentido fijarla.</translation>
    </message>
    <message>
        <source>You can not set the main location because you do not have permissions to edit the item being displayed.</source>
        <translation>No puedes fijar la ubicación porque no tienes permisos para editar el elemento que está siendo mostrado.</translation>
    </message>
    <message>
        <source>Remove selected locations from the list above.</source>
        <translation>Eliminar las ubicaciones seleccionadas de la lista de arriba.</translation>
    </message>
    <message>
        <source>There is no removable location.</source>
        <translation>No hay ninguna ubicación que se pueda eliminar.</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Añadir ubicaciones</translation>
    </message>
    <message>
        <source>Add one or more new locations.</source>
        <translation>Añadir una o más ubicaciones.</translation>
    </message>
    <message>
        <source>It is not possible to add locations to a top level node.</source>
        <translation>No es posible añadir ubicaciones a un nodo de nivel superior.</translation>
    </message>
    <message>
        <source>You can not remove any locations because you do not have permissions to edit the current item.</source>
        <translation>No puedes eliminar ninguna ubicación porque no tienes permisos para editar el elemento actual.</translation>
    </message>
    <message>
        <source>You can not add new locations because you do not have permissions to edit the current item.</source>
        <translation>No puedes añadir ninguna ubicación porque no tienes permisos para editar el elemento actual.</translation>
    </message>
    <message>
        <source>Set main</source>
        <translation>Fijar principal</translation>
    </message>
    <message>
        <source>Select the desired main location using the radio buttons above and click this button to store the setting.</source>
        <translation>Elige la ubicación principal deseada usando los botones radio de arriba y pulsa el botón de guardar la configuración.</translation>
    </message>
    <message>
        <source>You can not set the main location because there is only one location present.</source>
        <translation>No puedes fijar la ubicación principal porque sólo hay una ubicación presente.</translation>
    </message>
    <message>
        <source>You can not set the main location because you do not have permissions to edit the current item.</source>
        <translation>No puedes fijar la ubicación principal porque no tienes permisos para editar el elemento actual.</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>Subir un nivel</translation>
    </message>
    <message>
        <source>The &lt;%class_name&gt; class is not configured to contain any sub items.</source>
        <translation>La clase &lt;%class_name&gt; no está configurada para contener sub elementos.</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Edit the contents of this item.</source>
        <translation>Editar el contenido de este elemento.</translation>
    </message>
    <message>
        <source>You do not have permissions to edit this item.</source>
        <translation>No tienes permisos para editar este elemento.</translation>
    </message>
    <message>
        <source>Move this item to another location.</source>
        <translation>Mover este elemento a otra ubicación.</translation>
    </message>
    <message>
        <source>You do not have permissions to move this item to another location.</source>
        <translation>No tienes permisos para mover este elemento a otra ubicación.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation>Eliminar este elemento.</translation>
    </message>
    <message>
        <source>Available policies [%policy_count]</source>
        <translation>Políticas disponibles [%policy_count]</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Limitación</translation>
    </message>
    <message>
        <source>limited to %limitation_identifier %limitation_value</source>
        <translation>limitado a %limitation_identifier %limitation_value</translation>
    </message>
    <message>
        <source>all modules</source>
        <translation>todos los módulos</translation>
    </message>
    <message>
        <source>all functions</source>
        <translation>todas las funciones</translation>
    </message>
    <message>
        <source>No limitations</source>
        <translation>Sin limitaciones</translation>
    </message>
    <message>
        <source>There are no available policies.</source>
        <translation>No hay políticas disponibles.</translation>
    </message>
    <message>
        <source>Relations [%relation_count]</source>
        <translation>Relaciones [%relation_count]</translation>
    </message>
    <message>
        <source>Related objects [%related_objects_count]</source>
        <translation>Objetos relacionados [%related_objects_count]</translation>
    </message>
    <message>
        <source>The item being viewed does not make use of any other objects.</source>
        <translation>El elemento que estás viendo no usa ningún otro objeto.</translation>
    </message>
    <message>
        <source>Reverse related objects</source>
        <translation>Invertir objetos relacionados</translation>
    </message>
    <message>
        <source>The item being viewed is not in use by any other objects.</source>
        <translation>El elemento que estás viendo no está en uso por otros objetos.</translation>
    </message>
    <message>
        <source>Assigned roles [%roles_count]</source>
        <translation>Roles asignados [%roles_count]</translation>
    </message>
    <message>
        <source>No limitation</source>
        <translation>Sin limitaciones</translation>
    </message>
    <message>
        <source>Edit role.</source>
        <translation>Editar rol.</translation>
    </message>
    <message>
        <source>There are no assigned roles.</source>
        <translation>No hay roles asignados.</translation>
    </message>
    <message>
        <source>Translations [%translations]</source>
        <translation>Traducciones [%translations]</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Locale</translation>
    </message>
    <message>
        <source>View translation.</source>
        <translation>Ver traducción.</translation>
    </message>
    <message>
        <source>Hide object relation overview.</source>
        <translation>Ocultar los objetos relacionados.</translation>
    </message>
    <message>
        <source>Show object relation overview.</source>
        <translation>Mostrar los objetos relacionados.</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/line</name>
    <message>
        <source>Click on the icon to get a context sensitive menu.</source>
        <translation>Haz cick en el icono para ver el menú contextual.</translation>
    </message>
    <message>
        <source>Node ID: %node_id Visibility: %node_visibility</source>
        <translation>ID de nudo: %node_id Visibilidad: %node_visibility</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view/thumbnail</name>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>[%classname] Haz cick en el icono para ver el menú contextual.</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/collaboration</name>
    <message>
        <source>Collaboration notification</source>
        <translation>Notificación de colaboración</translation>
    </message>
    <message>
        <source>Choose which collaboration items you wish to get notifications for.</source>
        <translation>Elige de qué elementos de colaboración deseas recibir notificación.</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/handler/ezgeneraldigest/settings/edit</name>
    <message>
        <source>Receive all messages combined in one digest</source>
        <translation>Recibir todos los mensajes recogidos en una recopilación</translation>
    </message>
    <message>
        <source>Receive digests</source>
        <translation>Recibir recopilación</translation>
    </message>
    <message>
        <source>Daily, at</source>
        <translation>A diario, a las</translation>
    </message>
    <message>
        <source>Once per week, on </source>
        <translation>Una vez a la semana, el</translation>
    </message>
    <message>
        <source>Once per month, on day number</source>
        <translation>Una vez al mes, el día</translation>
    </message>
    <message>
        <source>If day number is larger than the number of days within the current month, the last day of the current month will be used.</source>
        <translation>Si el número de día es mayor que el número de dias del mes, se usará el último dia del mes. </translation>
    </message>
</context>
<context>
    <name>design/admin/notification/handler/ezsubtree/settings/edit</name>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>My item notifications [%notification_count]</source>
        <translation>Mis notificaciones de elemento [%notification_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Select item for removal.</source>
        <translation>Elegir elemento para eliminar.</translation>
    </message>
    <message>
        <source>You have not subscribed to receive notifications about any items.</source>
        <translation>No estás subscrito para recibir notificaciones sobre elementos.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected items.</source>
        <translation>Eliminar los elementos seleccionados.</translation>
    </message>
    <message>
        <source>Add items</source>
        <translation>Añadir elementos</translation>
    </message>
    <message>
        <source>Add items to your personal notification list.</source>
        <translation>Añadir elementos a tu lista de notificaciones personal.</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/runfilter</name>
    <message>
        <source>The notification filter processed all available notification events.</source>
        <translation>El filtro de notificación ha procesado todos los eventos de notificación disponibles.</translation>
    </message>
    <message>
        <source>The notification time event was spawned.</source>
        <translation>Se ha generado el evento de notificación de tiempo.</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Notificación</translation>
    </message>
    <message>
        <source>Run notification filter</source>
        <translation>Arrancar filtro de notificación</translation>
    </message>
    <message>
        <source>Spawn time event</source>
        <translation>Generar evento de tiempo</translation>
    </message>
</context>
<context>
    <name>design/admin/notification/settings</name>
    <message>
        <source>My notification settings</source>
        <translation>Mis configuraciones de notificación</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
</context>
<context>
    <name>design/admin/package</name>
    <message>
        <source>Please provide information on the changes.</source>
        <translation>Por favor, suministra información sobre los cambios.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Cambios</translation>
    </message>
    <message>
        <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterisk) ) at the beginning of the line. The change will continue to the next change marker.</source>
        <translation>Empieza a escribir la línea con un marcador ( %emstart-%emend (guillon) o %emstart*%emend (asterisco) ). El cambio afectará hasta el siguiente marcador.</translation>
    </message>
    <message>
        <source>Please provide some basic information for your package.</source>
        <translation>Por favor, suministra alguna información básica sobre el paquete.</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Nombre del paquete</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Package host</source>
        <translation>Alojamiento del paquete</translation>
    </message>
    <message>
        <source>Packager</source>
        <translation>Empaquetador</translation>
    </message>
    <message>
        <source>Please provide information on the maintainer of the package.</source>
        <translation>Por favor, suministra información sobre el mantenedor del paquete.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Maintainer name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Role</source>
        <comment>Maintainer role</comment>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Crear el paquete</translation>
    </message>
    <message>
        <source>Available wizards</source>
        <translation>Asistentes disponibles</translation>
    </message>
    <message>
        <source>Choose one of the following wizards for creating a package</source>
        <translation>Elige uno de los siguientes asistentes para crear un paquete</translation>
    </message>
    <message>
        <source>Specify export properties. The default settings will most likely be suitable for your needs.</source>
        <translation>Especifica las propiedades de exportación. Seguramente, la configuración por defecto es suficiente para tus necesidades.</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Varios</translation>
    </message>
    <message>
        <source>Include class definitions.</source>
        <translation>Incluir definición de clases.</translation>
    </message>
    <message>
        <source>Include templates related exported objects.</source>
        <translation>Incluir las plantillas relacionados con los objetos exportados.</translation>
    </message>
    <message>
        <source>Select templates from the following siteaccesses</source>
        <translation>Eligir las plantillas desde los siguientes accesos de sitio</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versiones</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>All versions</source>
        <translation>Todas las versiones</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <source>Select languages to export</source>
        <translation>Eligir los idiomas para exportar</translation>
    </message>
    <message>
        <source>Node assignments</source>
        <translation>Asignaciones de nudo</translation>
    </message>
    <message>
        <source>Keep all in selected nodes</source>
        <translation>Guardar todo en los nudos selecionados</translation>
    </message>
    <message>
        <source>Main only</source>
        <translation>Solo el principal</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objetos relacionados</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Please choose objects you wish to include in the package.</source>
        <translation>Por favor, elige los objetos que quiere incluir en el paquete.</translation>
    </message>
    <message>
        <source>Selected nodes</source>
        <translation>Nudos selecionados</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nudo</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Tipo de exportación</translation>
    </message>
    <message>
        <source>There are currently no objects selected for exportation</source>
        <translation>No hay ningún objeto seleccionado para la exportación </translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Add subtree</source>
        <translation>Añadir subarbol</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>Añadir nudo</translation>
    </message>
    <message>
        <source>Please select the site CSS file to be included in the package.</source>
        <translation>Por favor, elige el archivo CSS del sitio que quiere incluir en el paquete.</translation>
    </message>
    <message>
        <source>Please select the classes CSS file to be included in the package.</source>
        <translation>Por favor, elige los archivos CSS de clases que quiere incluir en el paquete.</translation>
    </message>
    <message>
        <source>Select an image file to be included in the package and click Next.
Click &quot;Next&quot; without choosing an image to continue to the next step.</source>
        <translation>Elige una imagen para incluir en el paquete y haz clic en Siguiente.
Haz clic en &quot;Siguiente&quot; sin escoger una imagen para ir al siguiente paso.</translation>
    </message>
    <message>
        <source>Currently added image files</source>
        <translation>Imagenes añadidas actualmente</translation>
    </message>
    <message>
        <source>Package wizard: %wizardname</source>
        <translation>Asistente de paquete: %wizardname</translation>
    </message>
    <message>
        <source>Install package</source>
        <translation>Instalar paquete</translation>
    </message>
    <message>
        <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
        <translation>El paquete se puede instalar en tu sistema. Con la instalación se copiarán archivos, se crearán clases de contenido, etc., todo dependiendo del paquete.
Si no quieres instalar ahora el paquete, lo puedes hacer más tarde en la página de vista para el paquete.</translation>
    </message>
    <message>
        <source>Install items</source>
        <translation>Instala los elementos</translation>
    </message>
    <message>
        <source>Skip installation</source>
        <translation>Saltar la instalación</translation>
    </message>
    <message>
        <source>Package install wizard: %wizardname</source>
        <translation>Asistente de instalación de paquete: %wizardname</translation>
    </message>
    <message>
        <source>Next %arrowright</source>
        <translation>Siguiente %arrowright</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Terminar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Upload package</source>
        <translation>Subir paquete</translation>
    </message>
    <message>
        <source>Select the file containing your package and click the upload button</source>
        <translation>Selecciona el archivo que contiene tu paquete y clica el botón de subida</translation>
    </message>
    <message>
        <source>Import package</source>
        <translation>Importar el paquete</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>No instalado</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Importado</translation>
    </message>
    <message>
        <source>Files [%collectionname]</source>
        <translation>Archivos [%colllectionname]</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Exportar a un archivo</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Maintainers</source>
        <translation>Mantenedores</translation>
    </message>
    <message>
        <source>Regarding eZ publish package &apos;%packagename&apos;</source>
        <translation>En relación al paquete eZpublish &apos;%packagename&apos;</translation>
    </message>
    <message>
        <source>Send e-mail to the maintainer</source>
        <translation>Enviar e-mail al mantenedor</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Lista de archivos</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/package/list</name>
    <message>
        <source>Remove section?</source>
        <translation>¿Eliminar sección?</translation>
    </message>
    <message>
        <source>Removal of packages</source>
        <translation>Eliminación de paquetes</translation>
    </message>
    <message>
        <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
        <translation>¿Estás seguro que quieres eliminar los siguientes paquetes?
Los paquetes se perderán para siempre.
Nota: los paquetes no serán desinstalados.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Package removal was canceled.</source>
        <translation>La eliminación de paquete fue cancelada.</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Paquetes</translation>
    </message>
    <message>
        <source>Repository</source>
        <translation>Repositorio</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Change repository</source>
        <translation>Cambiar repositorio</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>No instalado</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Importado</translation>
    </message>
    <message>
        <source>There are no packages matching the selected repository.</source>
        <translation>No hay ningún paquete que coincida con el repositorio seleccionado.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Import new package</source>
        <translation>Importar nuevo paquete</translation>
    </message>
    <message>
        <source>Create new package</source>
        <translation>Crear nuevo paquete</translation>
    </message>
</context>
<context>
    <name>design/admin/pagelayout</name>
    <message>
        <source>Content structure</source>
        <translation>Estructura de contenido</translation>
    </message>
    <message>
        <source>Manage the main content structure of the site.</source>
        <translation>Gestionar la estructura de contenido principal del sitio.</translation>
    </message>
    <message>
        <source>Media library</source>
        <translation>Biblioteca multimedia</translation>
    </message>
    <message>
        <source>Manage images, files, documents, etc.</source>
        <translation>Gestionar imágenes, archivos, documentos, etc.</translation>
    </message>
    <message>
        <source>User accounts</source>
        <translation>Cuentas de usuario</translation>
    </message>
    <message>
        <source>Manage users, user groups and permission settings.</source>
        <translation>Gestionar usuarios, grupos de usuarios y configuraciones de permisos.</translation>
    </message>
    <message>
        <source>Webshop</source>
        <translation>Tienda virtual</translation>
    </message>
    <message>
        <source>Manage customers, orders, discounts and VAT types; view sales statistics.</source>
        <translation>Gestionar clientes, pedidos, descuentos tipos de IVA; ver estadísticas de ventas.</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Diseño</translation>
    </message>
    <message>
        <source>Manage templates, menus, toolbars and other things related to appearence.</source>
        <translation>Gestionar plantillas, menús, barras de herramientas y otras cosas relacionadas con la apariencia.</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Configure settings and manage advanced functionality.</source>
        <translation>Configurar preferencias y gestionar funciones avanzadas.</translation>
    </message>
    <message>
        <source>My account</source>
        <translation>Mi cuenta</translation>
    </message>
    <message>
        <source>Manage items and settings that belong to your account.</source>
        <translation>Gestionar elementos y preferencias de tu cuenta.</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Search all content.</source>
        <translation>Buscar todo el contenido.</translation>
    </message>
    <message>
        <source>All content</source>
        <translation>Todo el cotenido</translation>
    </message>
    <message>
        <source>Search only from the current location.</source>
        <translation>Buscar sólo desde la ubicación actual.</translation>
    </message>
    <message>
        <source>Current location</source>
        <translation>Ubicación actual</translation>
    </message>
    <message>
        <source>The same location</source>
        <translation>La misma ubicación</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzada</translation>
    </message>
    <message>
        <source>Advanced search.</source>
        <translation>Búsqueda avanzada.</translation>
    </message>
    <message>
        <source>Current user</source>
        <translation>Usuario actual</translation>
    </message>
    <message>
        <source>Change name, e-mail, password, etc.</source>
        <translation>Cambiar nombre, e-mail, contraseña, etc.</translation>
    </message>
    <message>
        <source>Change information</source>
        <translation>Cambiar información</translation>
    </message>
    <message>
        <source>Change password for &lt;%username&gt;.</source>
        <translation>Cambiar contraseña para &lt;%username&gt;.</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>There is %basket_count item in the shopping basket.</source>
        <translation>Hay %basket_count elementos en la cesta.</translation>
    </message>
    <message>
        <source>Shopping basket (%basket_count)</source>
        <translation>Cesta (%basket_count)</translation>
    </message>
    <message>
        <source>There are %basket_count items in the shopping basket.</source>
        <translation>Hay %basket_count elementos en la cesta.</translation>
    </message>
    <message>
        <source>Logout from the system.</source>
        <translation>Desconectar del sistema.</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Desconectar</translation>
    </message>
    <message>
        <source>Change user info</source>
        <translation>Cambiar información de usuario</translation>
    </message>
    <message>
        <source>Hide bookmarks.</source>
        <translation>Ocultar favoritos.</translation>
    </message>
    <message>
        <source>Manage your personal bookmarks.</source>
        <translation>Gestionar tus favoritos.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Favoritos</translation>
    </message>
    <message>
        <source>[%classname] Click on the icon to get a context sensitive menu.</source>
        <translation>[%classname] Haz click en el icono para ver el menú contextual.</translation>
    </message>
    <message>
        <source>Add to bookmarks</source>
        <translation>Añadir a favoritos</translation>
    </message>
    <message>
        <source>Add the current item to your bookmarks.</source>
        <translation>Añadir el elemento actual a favoritos.</translation>
    </message>
    <message>
        <source>Show bookmarks.</source>
        <translation>Mostrar favoritos.</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/content/menu</name>
    <message>
        <source>Content structure</source>
        <translation>Estructura de contenido</translation>
    </message>
    <message>
        <source>View and manage the contents of the trash bin.</source>
        <translation>Ver y gestionar los contenidos de la papelera.</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño pequeño.</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Pequeño</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Mediano</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño grande.</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Grande</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño mediano.</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/media/menu</name>
    <message>
        <source>Media library</source>
        <translation>Biblioteca multimedia</translation>
    </message>
    <message>
        <source>View and manage the contents of the trash bin.</source>
        <translation>Ver y gestionar los contenidos de la papelera.</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño pequeño.</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Pequeño</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Mediano</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño grande.</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Grande</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño mediano.</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/my/menu</name>
    <message>
        <source>My account</source>
        <translation>Mi cuenta</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mis borradores</translation>
    </message>
    <message>
        <source>My pending items</source>
        <translation>Mis elementos pendientes</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Mis preferencias de notificación</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Mis favoritos</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Colaboración</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>My shopping basket</source>
        <translation>Mi carrito de compra</translation>
    </message>
    <message>
        <source>My wish list</source>
        <translation>Mi lista de deseos</translation>
    </message>
    <message>
        <source>Edit mode settings</source>
        <translation>Preferencias de modo de edición</translation>
    </message>
    <message>
        <source>on</source>
        <translation>activado</translation>
    </message>
    <message>
        <source>Disable location window when editing content.</source>
        <translation>Desactivar ventana de ubicación cuando se edite el contenido.</translation>
    </message>
    <message>
        <source>off</source>
        <translation>apagado</translation>
    </message>
    <message>
        <source>Enable location window when editing content.</source>
        <translation>Activar ventana de ubicación cuando se edite el contenido.</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Ubicaciones</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/setup/menu</name>
    <message>
        <source>Setup</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Cache management</source>
        <translation>Gestión de la caché</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Clases</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Extensiones</translation>
    </message>
    <message>
        <source>Global settings</source>
        <translation>Preferencias globales</translation>
    </message>
    <message>
        <source>Ini settings</source>
        <translation>Configuración de los Ini</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Notificación</translation>
    </message>
    <message>
        <source>PDF export</source>
        <comment>PDF export</comment>
        <translation>Exportar PDF</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Paquetes</translation>
    </message>
    <message>
        <source>RAD</source>
        <comment>Rapid Application Development</comment>
        <translation>RAD</translation>
    </message>
    <message>
        <source>Roles and policies</source>
        <translation>Roles y políticas</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <source>Search statistics</source>
        <translation>Buscar estadísticas</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Secciones</translation>
    </message>
    <message>
        <source>Sessions</source>
        <translation>Sesiones</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Información de sistema</translation>
    </message>
    <message>
        <source>Upgrade check</source>
        <translation>Búsqueda de actualizaciones</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Disparadores</translation>
    </message>
    <message>
        <source>URL management</source>
        <translation>Gestión de URL</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>Traductor de URL</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Flujos de trabajo</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/shop/menu</name>
    <message>
        <source>Shop</source>
        <translation>Tienda</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Clientes</translation>
    </message>
    <message>
        <source>Discounts</source>
        <translation>Descuentos</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>Pedidos</translation>
    </message>
    <message>
        <source>Product statistics</source>
        <translation>Estadísticas de productos</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Tipos de IVA</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/user/menu</name>
    <message>
        <source>Role information</source>
        <translation>Información de rol</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>User accounts</source>
        <translation>Cuentas de usuario</translation>
    </message>
    <message>
        <source>View and manage the contents of the trash bin.</source>
        <translation>Ver y gestionar los contenidos de la papelera.</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Manage permission settings.</source>
        <translation>Gestionar las preferencias de permisos.</translation>
    </message>
    <message>
        <source>Roles and policies</source>
        <translation>Roles y políticas</translation>
    </message>
    <message>
        <source>Change the left menu width to small size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño pequeño.</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Pequeño</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Mediano</translation>
    </message>
    <message>
        <source>Change the left menu width to large size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño mediano.</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Grande</translation>
    </message>
    <message>
        <source>Change the left menu width to medium size.</source>
        <translation>Cambiar el ancho del menú de la izquierda a tamaño grande.</translation>
    </message>
    <message>
        <source>Access control</source>
        <translation>Control de acceso</translation>
    </message>
</context>
<context>
    <name>design/admin/parts/visual/menu</name>
    <message>
        <source>Design</source>
        <translation>Diseño</translation>
    </message>
    <message>
        <source>Look and feel</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <source>Menu management</source>
        <translation>Gestión de menú</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Gestión de la barra de herramientas</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Plantillas</translation>
    </message>
</context>
<context>
    <name>design/admin/pdf/edit</name>
    <message>
        <source>PDF Export</source>
        <translation>Exportación PDF</translation>
    </message>
    <message>
        <source>%pdf_export_title [PDF export]</source>
        <translation>%pdf_export_title [exportación PDF]</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Portada</translation>
    </message>
    <message>
        <source>Display frontpage</source>
        <translation>Mostrar portada</translation>
    </message>
    <message>
        <source>Intro text</source>
        <translation>Texto introductorio</translation>
    </message>
    <message>
        <source>Sub text</source>
        <translation>Texto secundario</translation>
    </message>
    <message>
        <source>Source node</source>
        <translation>Nudo de origen</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>There is no source node.</source>
        <translation>No hay nudo de origen.</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>Export structure</source>
        <translation>Exportar estructura</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nudo</translation>
    </message>
    <message>
        <source>Tree</source>
        <translation>Árbol</translation>
    </message>
    <message>
        <source>Export classes (if exporting a tree)</source>
        <translation>Exportar clases (si se exportas un árbol)</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Tipo de exportación</translation>
    </message>
    <message>
        <source>Generate once</source>
        <translation>Generar una vez</translation>
    </message>
    <message>
        <source>Generate on the fly</source>
        <translation>Generar &quot;on the fly&quot;</translation>
    </message>
    <message>
        <source>Filename (if generated on the fly)</source>
        <translation>Nombre del archivo (si se genera &quot;on the fly&quot;)</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/pdf/list</name>
    <message>
        <source>PDF Exports [%export_count]</source>
        <translation>Exportaciones PDF [%export_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Select PDF export for removal.</source>
        <translation>Elegir exportación PDF para eliminar.</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation>Exportación PDF</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%pdf_export_name&gt; PDF export.</source>
        <translation>Editar la exportación PDF &lt;%pdf_export_name&gt;.</translation>
    </message>
    <message>
        <source>There are no PDF exports in the list.</source>
        <translation>No hay exportaciones PDF en la lista.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected PDF exports.</source>
        <translation>Eliminar las exportaciones PDF seleccionadas.</translation>
    </message>
    <message>
        <source>New PDF export</source>
        <translation>Nueva exportación PDF</translation>
    </message>
    <message>
        <source>Create a new PDF export.</source>
        <translation>Crear una nueva exportación PDF.</translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzada</translation>
    </message>
    <message>
        <source>Expand</source>
        <translation>Expander</translation>
    </message>
    <message>
        <source>Collapse</source>
        <translation>Contraer</translation>
    </message>
    <message>
        <source>Add to my bookmarks</source>
        <translation>Añadir a mis favoritos</translation>
    </message>
    <message>
        <source>Add to my notifications</source>
        <translation>Añadir a mis notificaciones</translation>
    </message>
    <message>
        <source>Swap with another node</source>
        <translation>Cambiar con otro nudo</translation>
    </message>
    <message>
        <source>Hide / unhide</source>
        <translation>Ocultar / mostrar</translation>
    </message>
    <message>
        <source>View index</source>
        <translation>Ver índice</translation>
    </message>
    <message>
        <source>View class</source>
        <translation>Ver clase</translation>
    </message>
    <message>
        <source>Edit class</source>
        <translation>Editar clase</translation>
    </message>
    <message>
        <source>Delete view cache</source>
        <translation>Borrar caché de vista</translation>
    </message>
    <message>
        <source>Delete template cache</source>
        <translation>Borrar caché de plantillas</translation>
    </message>
    <message>
        <source>Delete view cache from here</source>
        <translation>Borrar cache de vista desde aquí</translation>
    </message>
    <message>
        <source>Template overrides</source>
        <translation>Plantillas sobrescritas</translation>
    </message>
    <message>
        <source>New class override</source>
        <translation>Nueva clase sobrescrita</translation>
    </message>
    <message>
        <source>New node override</source>
        <translation>Nuevo nudo sobrescrito</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/article</name>
    <message>
        <source>Comments allowed</source>
        <translation>Se permiten comentarios</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/company</name>
    <message>
        <source>Contact information</source>
        <translation>Información de contacto</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Información adicional</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Contactos</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/feedbackform</name>
    <message>
        <source>Your E-mail address</source>
        <translation>Tu dirección de e-mail</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Asunto</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <source>Recipient</source>
        <translation>Receptor</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/folder</name>
    <message>
        <source>Show children</source>
        <translation>Mostrar hijos</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/person</name>
    <message>
        <source>Contact information</source>
        <translation>Información de contacto</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/poll</name>
    <message>
        <source>Result</source>
        <translation>Resultado</translation>
    </message>
</context>
<context>
    <name>design/admin/preview/product</name>
    <message>
        <source>Download this product sheet as PDF</source>
        <translation>Descargar una versión PDF de la descripción del producto</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Las personas que han comprado esto también han comprado</translation>
    </message>
</context>
<context>
    <name>design/admin/role/assign_limited_section</name>
    <message>
        <source>Select section</source>
        <translation>Seleccionar sección</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>There are no sections on the system.</source>
        <translation>No hay secciones en el sistema.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/role/createpolicystep1</name>
    <message>
        <source>Create a new policy for the &lt;%role_name&gt; role</source>
        <translation>Crear una nueva política para el rol &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Welcome to the policy wizard. This three step wizard will help you create a new policy which will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
        <translation>Bienvenido al asistente de políticas. Este asistente te ayudará en tres simples pasos a crear una nueva política que se añadirá al rol que estás editando. El asistente se puede abortar en cualquier momento pulsando el botón de &quot;Cancelar&quot;.</translation>
    </message>
    <message>
        <source>Step one: select module</source>
        <translation>Paso uno: elegir modulo</translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation>Instrucciones</translation>
    </message>
    <message>
        <source>Use the drop-down menu to select the module that you wish to grant access to.</source>
        <translation>Usar el menú desplegable para elegir el módulo al que deseas dar acceso.</translation>
    </message>
    <message>
        <source>Click one of the &quot;Grant..&quot; buttons (explained below) in order to go to the next step.</source>
        <translation>Clica uno de los botones &quot;Dar acceso&quot; (explicados abajo) para pasar al siguiente paso.</translation>
    </message>
    <message>
        <source>The &quot;Grant access to all functions&quot; button will create a policy that grants unlimited access to all functions of the selected module. If you wish to limit the access method to a specific function, use the &quot;Grant access to a function&quot; button. Please note that function limitation is only supported by some modules (the next step will reveal if it works or not).</source>
        <translation>El botón &quot;Dar acceso a todas las funciones&quot; creará una política que generará acceso ilimitado a todas las funciones del módulo seleccionado. Si deseas limitar el acceso a una función en específica, usa el botón &quot;Dar acceso a la función&quot;. Fíjate que limitar a una función es solo posible en algunos módulos (el siguiente paso nos dirá si funciona o no).</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Cada módulo</translation>
    </message>
    <message>
        <source>Grant access to all functions</source>
        <translation>Dar acceso para todas las funciones</translation>
    </message>
    <message>
        <source>Grant access to one function</source>
        <translation>Dar acceso para una función</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/role/createpolicystep2</name>
    <message>
        <source>Create a new policy for the &lt;%role_name&gt; role</source>
        <translation>Crear una nueva política para el rol &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
        <translation>Bienvenido al asistente de políticas. Este asistente te ayudará a crear una nueva política en tres pasos . La política se añadirá al rol que está siendo editando. El asistente se puede abortar en cualquier momento pulsando el botón de &quot;Cancelar&quot;.</translation>
    </message>
    <message>
        <source>Step one: select module [completed]</source>
        <translation>Paso uno: seleccionar modulo [completo]</translation>
    </message>
    <message>
        <source>Selected module</source>
        <translation>Módulo seleccionado</translation>
    </message>
    <message>
        <source>All modules</source>
        <translation>Todos los módulos</translation>
    </message>
    <message>
        <source>Selected access method</source>
        <translation>Método de acceso seleccionado</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Limitado</translation>
    </message>
    <message>
        <source>Step two: select function</source>
        <translation>Paso dos: seleccionar función</translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation>Instrucciones</translation>
    </message>
    <message>
        <source>Use the drop-down menu to select the function that you wish to grant access to.</source>
        <translation>Usar el menú desplegable para elegir la función a la que deseas dar acceso.</translation>
    </message>
    <message>
        <source>The &quot;Grant full access&quot; button will create a policy that grants unlimited access to the selected function within the module that was specified in step one. If you wish to limit the access method in some way, click the &quot;Grant limited access&quot; button. Function limitation is only supported by some functions. If unsupported, eZ publish will simply set up a policy with unlimited access to the selected function.</source>
        <translation>El botón &quot;Dar acceso completo&quot; creará una política que dará acceso ilimitado a la función seleccionada del módulo que se especificó en el paso uno. Si deseas limitar el método de acceso de alguna forma, pulsa el botón &quot;Dar acceso limitado&quot;. La limitación de función sólo es soportada por algunas funciones. Si no es soportada, eZ publish creará una política con acceso ilimitado a la función seleccionada.</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Grant full access</source>
        <translation>Dar acceso completo</translation>
    </message>
    <message>
        <source>Grant limited access</source>
        <translation>Dar acceso limitado</translation>
    </message>
    <message>
        <source>It is unfortunately not possible to grant limited access to all modules at once. To grant unlimited access to all modules and their functions, go back to step one and select &quot;Grant access to all functions&quot;. In order to grant limited access to different functions within different modules, you need to set up a collection of policies.</source>
        <translation>Desafortunadamente no es posible dar acceso limitado a todos los módulos de una sóla vez. Para dar acceso ilimitado a todos los módulos y sus funciones, vuelve al paso uno y elige &quot;Dar acceso a todas las funciones&quot;. Para dar acceso limitado a diferentes funciones dentro de distintos módulos, necesitas crear una colección de políticas.</translation>
    </message>
    <message>
        <source>The selected module (%module_name) does not support limitations on the function level. Please go back to step one and use the &quot;Grant access to all functions&quot; option instead.</source>
        <translation>El módulo seleccionado (%module_name) no soporta limitaciones a nivel de función. Por favor vuelve al paso uno y usa la opción &quot;Dar acceso a todas las funciones&quot;.</translation>
    </message>
    <message>
        <source>Go back to step one</source>
        <translation>Volver al paso uno</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/role/createpolicystep3</name>
    <message>
        <source>Create a new policy for the &lt;%role_name&gt; role</source>
        <translation>Crear una nueva política para el rol &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Welcome to the policy wizard. This three step wizard will help you set up a new policy. The policy will be added to the role that is currently being edited. The wizard can be aborted at any stage by using the &quot;Cancel&quot; button.</source>
        <translation>Bienvenido al asistente de políticas. Este asistente te ayudará a crear una nueva política en tres pasos . La política se añadirá al rol que está siendo editando. El asistente se puede abortar en cualquier momento pulsando el botón de &quot;Cancelar&quot;.</translation>
    </message>
    <message>
        <source>Step one: select module [completed]</source>
        <translation>Paso uno: seleccionar modulo [completo]</translation>
    </message>
    <message>
        <source>Selected module</source>
        <translation>Módulo seleccionado</translation>
    </message>
    <message>
        <source>All modules</source>
        <translation>Todos los módulos</translation>
    </message>
    <message>
        <source>Selected access method</source>
        <translation>Método de acceso seleccionado</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Limitado</translation>
    </message>
    <message>
        <source>Step two: select function [completed]</source>
        <translation>Paso dos: seleccionar función [completo]</translation>
    </message>
    <message>
        <source>Selected function</source>
        <translation>Función seleccionada</translation>
    </message>
    <message>
        <source>Step three: set function limitations</source>
        <translation>Paso tres: fijar limitaciones de función</translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation>Instrucciones</translation>
    </message>
    <message>
        <source>Set the desired function limitations using the controls below.</source>
        <translation>Fijar la limitación de función deseada usando los controles de abajo.</translation>
    </message>
    <message>
        <source>Click the &quot;OK&quot; button to finish the wizard. The policy will be added to the role that is currently being edited.</source>
        <translation>Haz click en &quot;OK&quot; para finalizar el asistente. La política se añadirá al rol que está siendo editando.</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Nodes [%node_count]</source>
        <translation>Nudos [%node_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>The node list is empty.</source>
        <translation>La lista de nudos está vacía.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Add nodes</source>
        <translation>Añadir nudos</translation>
    </message>
    <message>
        <source>Subtrees [%subtree_count]</source>
        <translation>Subárboles [%subtree_count]</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Subárbol</translation>
    </message>
    <message>
        <source>The subtree list is empty.</source>
        <translation>La lista de subárboles está vacía.</translation>
    </message>
    <message>
        <source>Add subtrees</source>
        <translation>Añadir subárboles</translation>
    </message>
    <message>
        <source>Go back to step one</source>
        <translation>Volver al paso uno</translation>
    </message>
    <message>
        <source>Go back to step two</source>
        <translation>Volver al paso dos</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/role/edit</name>
    <message>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Edit &lt;%role_name&gt; [Role]</source>
        <translation>Editar &lt;%role_name&gt; [Rol]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Policies</source>
        <translation>Políticas</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Limitaciones</translation>
    </message>
    <message>
        <source>Select policy for removal.</source>
        <translation>Elegir política para eliminar.</translation>
    </message>
    <message>
        <source>all modules</source>
        <translation>todos los módulos</translation>
    </message>
    <message>
        <source>all functions</source>
        <translation>todas las funciones</translation>
    </message>
    <message>
        <source>No limitations</source>
        <translation>Sin limitaciones</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the policy&apos;s function limitations.</source>
        <translation>Editar las limitaciones de función de la política.</translation>
    </message>
    <message>
        <source>There are no policies set up for this role.</source>
        <translation>No hay políticas para este rol.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected policies.</source>
        <translation>Eliminar las políticas seleccionadas.</translation>
    </message>
    <message>
        <source>New policy</source>
        <translation>Nueva política</translation>
    </message>
    <message>
        <source>Create a new policy.</source>
        <translation>Crear nueva política.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/role/list</name>
    <message>
        <source>Roles [%role_count]</source>
        <translation>Roles [%role_count]</translation>
    </message>
    <message>
        <source>Toggle selection</source>
        <translation>Invertir la selección</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Select role for removal.</source>
        <translation>Elegir rol para eliminar.</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Asignar</translation>
    </message>
    <message>
        <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
        <translation>Asignar el rol &lt;%role_name&gt; a un usuario o grupo de usuarios.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%role_name&gt; role.</source>
        <translation>Editar el rol &lt;%role_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected roles.</source>
        <translation>Eliminar los roles seleccionados.</translation>
    </message>
    <message>
        <source>New role</source>
        <translation>Nuevo rol</translation>
    </message>
    <message>
        <source>Create a new role.</source>
        <translation>Crear un nuevo rol.</translation>
    </message>
</context>
<context>
    <name>design/admin/role/policyedit</name>
    <message>
        <source>Edit &lt;%policy_name&gt; policy for &lt;%role_name&gt; role</source>
        <translation>Editar política &lt;%policy_name&gt; para el rol &lt;%role_name&gt;</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Function limitations</source>
        <translation>Limitaciones de función</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Nodes [%node_count]</source>
        <translation>Nudos [%node_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>The node list is empty.</source>
        <translation>La lista de nudos está vacía.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Add nodes</source>
        <translation>Añadir nudos</translation>
    </message>
    <message>
        <source>Subtrees [%subtree_count]</source>
        <translation>Subárboles [%subtree_count]</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Subárbol</translation>
    </message>
    <message>
        <source>The subtree list is empty.</source>
        <translation>La lista de subárboles está vacía.</translation>
    </message>
    <message>
        <source>Add subtrees</source>
        <translation>Añadir subárboles</translation>
    </message>
    <message>
        <source>The function limitations of this policy can not be edited. This is either because the function simply does not support limitations or because the function was assigned without limitations when the policy was created.</source>
        <translation>Las limitaciones de función de esta política no puede ser editada. Esto es debido a que la función no soporta limitaciones o porque la función fue asignada sin limitaciones cuando se creó la política.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/role/view</name>
    <message>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <source>%role_name [Role]</source>
        <translation>%role_name [Rol]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Policies [%policies_count]</source>
        <translation>Políticas [%policies_count]</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Limitación</translation>
    </message>
    <message>
        <source>all modules</source>
        <translation>todos los módulos</translation>
    </message>
    <message>
        <source>all functions</source>
        <translation>todas las funciones</translation>
    </message>
    <message>
        <source>No limitations</source>
        <translation>Sin limitaciones</translation>
    </message>
    <message>
        <source>There are no policies set up for this role.</source>
        <translation>No hay ninguna política para este rol.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this role.</source>
        <translation>Editar este rol.</translation>
    </message>
    <message>
        <source>Users and groups using the &lt;%role_name&gt; role [%users_count]</source>
        <translation>Usuarios y grupos que usan el rol &lt;%role_name&gt; [%users_count]</translation>
    </message>
    <message>
        <source>Toggle selection</source>
        <translation>Invertir la selección</translation>
    </message>
    <message>
        <source>User/group</source>
        <translation>Usuario/grupo</translation>
    </message>
    <message>
        <source>Select user or user group for removal.</source>
        <translation>Elegir usuario o grupo de usuarios para eliminar.</translation>
    </message>
    <message>
        <source>This role is not assigned to any users or user groups.</source>
        <translation>Este rol no está asignado a ningún usuario o grupo de usuarios.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected users and/or user groups.</source>
        <translation>Eliminar los usuarios y/o grupos de usuarios seleccionados.</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Asignar</translation>
    </message>
    <message>
        <source>Assign the &lt;%role_name&gt; role to a user or a user group.</source>
        <translation>Asignar el rol &lt;%role_name&gt; a un usuario o grupo de usuarios.</translation>
    </message>
    <message>
        <source>Select limitation.</source>
        <translation>Elegir limitación.</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Subárbol</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Assign with limitation</source>
        <translation>Asignar con limitación</translation>
    </message>
    <message>
        <source>Assign the &lt;%role_name&gt; role with limitation (specified to the left) to a user or a user group.</source>
        <translation>Asignar el rol &lt;%role_name&gt; con limitación (especificada a la izquierda) a un usuario o grupo de usuarios.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_destination</name>
    <message>
        <source>Choose a destination for RSS import</source>
        <translation>Elige el destino de RSS a importar</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a destination location for RSS import and click &quot;OK&quot;.</source>
        <translation>Usar los botones radio para elegir un destino para importar RSS y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_image</name>
    <message>
        <source>Choose image for RSS export</source>
        <translation>Elige imagen para exportar RSS</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose an image to use in the RSS export and click &quot;OK&quot;.</source>
        <translation>Usar los botones radio para elegir una imagen para exportar RSS y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_source</name>
    <message>
        <source>Choose source for RSS export</source>
        <translation>Elige el origen de RSS para exportar</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the item that you wish to export using RSS and click &quot;OK&quot;.</source>
        <translation>Usar los botones radio para elegir el elemento que deseas exportar usando RSS y pulsa &quot;OK&quot;.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/browse_user</name>
    <message>
        <source>Choose owner for RSS imported objects</source>
        <translation>Elige propietario de los objetos importados por RSS</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose a user and click &quot;OK&quot;. The user will become the owner of the objects that were imported using RSS.</source>
        <translation>Usar los botones radio para elegir el usuario y pulsa &quot;OK&quot;. El usuario será el propietario de los objetos exportados usando RSS.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_export</name>
    <message>
        <source>Edit &lt;%rss_export_name&gt; [RSS Export]</source>
        <translation>Editar &lt;%rss_export_name&gt; [Exportación RSS]</translation>
    </message>
    <message>
        <source>Invalid Input</source>
        <translation>Entrada invalida</translation>
    </message>
    <message>
        <source>If RSS Export is Active then a valid Access URL is required.</source>
        <translation>Si la Exportación RSS está Activa, se necesita una URL de acceso.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Name of the RSS export. This name is used in the administration interface only, to distinguish the different exports from each other.</source>
        <translation>Nombre de la exportación RSS. Este nombre se usa sólo en la interfaz de administración para distinguir las diferentes exportaciones. </translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Use the description field to write a text explaining what users can expect from the RSS export.</source>
        <translation>Usar el campo descripción para escribir un texto que explique lo que el usuario puede esperar de la exportación RSS.</translation>
    </message>
    <message>
        <source>Site URL</source>
        <translation>URL del sitio</translation>
    </message>
    <message>
        <source>Use this field to enter the base URL of your site. It is used to produce the URL&apos;s in the export.</source>
        <translation>Usar este campo para escribir la URL base de tu sitio. Se usa para producir la URL en la exportación. </translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>Click this button to select an image for the RSS export. Note that images only work with RSS version 2.0</source>
        <translation>Pulsa este botón para seleccionar una image para la exportación RSS. Recuerda que las imágenes sólo funcionan con la versión 2.0 de RSS</translation>
    </message>
    <message>
        <source>RSS version</source>
        <translation>Versión RSS</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the RSS version to use for the export. You must select RSS 2.0 in order to export the image selected above.</source>
        <translation>Usa el menú desplegable para seleccionar la versión RSS a usar para la exportación. Debes seleccionar RSS 2.0 para poder exportar la imagen seleccionada arriba.</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the RSS export is active or not. An inactive export will not be automatically updated.</source>
        <translation>Usa esta opción para controlar si la exportación RSS está activa o no. Una exportación inactiva no se actualizará automáticamente.</translation>
    </message>
    <message>
        <source>Access URL</source>
        <translation>URL de acceso</translation>
    </message>
    <message>
        <source>Use this field to set the URL where the RSS export should be available. Note that &quot;rss/feed/&quot; will be appended to the real URL. </source>
        <translation>Usa este campo para fijar la URL donde estará disponible la exportación RSS. Recuerda que &quot;rss/feed/&quot; se añadirá a la URL real.</translation>
    </message>
    <message>
        <source>Note: Each source fetches 5 objects from the first level.</source>
        <translation>Nota: Cada origen se asocia con 5 objetos del primer nivel.</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Origen</translation>
    </message>
    <message>
        <source>Source path</source>
        <translation>Ruta de origen</translation>
    </message>
    <message>
        <source>Click this button to select the source node for RSS export source. Objects of the type selected in the drop down below published as sub-items of the selected node will be included in the RSS export.</source>
        <translation>Pulsa este botón para seleccionar el nudo para el origen de la exportación RSS. Se incluirán en la exportación RSS los objetos del tipo seleccionado en el menú desplegable de abajo publicados como subelementos del nodo seleccionado.</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Use this drop down to select the type of object that triggers the export. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
        <translation>Usa el menú desplegable para seleccionar el tipo de objeto que dispara la exportación. Pulsa el botón &quot;Fijar&quot; para cargar el atributo correcto para los campos restantes.</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
        <translation>Pulsa este botón para cargar los valores correctos en los campos del menú desplegable de abajo. Usa el menú desplegable de la izquierda para seleccionar el tipo de clase correcto.</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>Use this drop-down to select which attribute that should be exported as the title of the RSS export entry.</source>
        <translation>Usar el menú desplegable para seleccionar qué atributo debe ser exportado como  el título de la exportación RSS.</translation>
    </message>
    <message>
        <source>Use this drop-down to select which attribute that should be exported as the description of the RSS export entry.</source>
        <translation>Usa el menú desplegable para seleccionar qué atributo será exportado como la descripción de la exportación RSS.</translation>
    </message>
    <message>
        <source>Remove this source</source>
        <translation>Eliminar este origen</translation>
    </message>
    <message>
        <source>Click to remove this source from the RSS export.</source>
        <translation>Pulsar para eliminar este origen de la exportación RSS.</translation>
    </message>
    <message>
        <source>Add source</source>
        <translation>Añadir origen</translation>
    </message>
    <message>
        <source>Click to add a new source to the RSS export.</source>
        <translation>Pulsar para añadir un nuevo origen a la exportación RSS.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Apply the changes and return to the RSS overview.</source>
        <translation>Aplicar los cambios y volver a la vista general del RSS.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the RSS overview.</source>
        <translation>Cancelar los cambios y volver a la vista general del RSS.</translation>
    </message>
    <message>
        <source>Use this field to enter the base URL of your site. It is used to produce the URLs in the export, composed by the Site URL (e.g. &quot;http://www.example.com/index.php&quot;) and the path to the object (e.g. &quot;/articles/my_article&quot;). The Site URL depends on your Webserver and eZ publish configuration.</source>
        <translation>Usar este campo para indicar la URL base de tu sitio. Se usa para producir las URLs en la exportación, compuestas por la URL del sitio (ej. &quot;http://www.example.com/index.php&quot;) y la ruta al objeto (ej. &quot;/articles/my_article&quot;). La URL del sitio depende de tu servidor Web y de la configuración del eZ publish.</translation>
    </message>
    <message>
        <source>Number of objects</source>
        <translation>Número de objetos</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the maximum number of objects included in the RSS feed.</source>
        <translation>Usa este menú desplegable para elegir el número máximo de objetos incluidos en el suministro RSS.</translation>
    </message>
    <message>
        <source>Main node only</source>
        <translation>Sólo el nodo principal</translation>
    </message>
    <message>
        <source>Check if you want to only feed the object from the main node.</source>
        <translation>Marcar si sólo quieres suministrar el objeto desde el nodo principal.</translation>
    </message>
    <message>
        <source>Subnodes</source>
        <translation>Subnodos</translation>
    </message>
    <message>
        <source>Activate this checkbox if also objects from the subnodes of the source should be feeded.</source>
        <translation>Activar esta casilla de verificación si se deben suministrar también los objetos de los subnodos de la raiz.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/edit_import</name>
    <message>
        <source>Edit &lt;%rss_import_name&gt; [RSS Import]</source>
        <translation>Editar &lt;%rss_import_name&gt; [Importación RSS]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Name of the RSS import. This name is used in the administration interface only, to distinguish the different imports from each other.</source>
        <translation>Nombre de la importación RSS. Este nombre se usa sólo en la interfaz de administración para distinguir las diferentes importaciones.</translation>
    </message>
    <message>
        <source>Source URL</source>
        <translation>URL de origen</translation>
    </message>
    <message>
        <source>Use this field to enter the source URL of the RSS feed to import.</source>
        <translation>Usar este campo para escribir la URL de origen del RSS a importar.</translation>
    </message>
    <message>
        <source>Destination path</source>
        <translation>Ruta de destino</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>Click this button to select the destination node where objects created by the import are located.</source>
        <translation>Pulsar este botón para elegir el nudo de destino donde se almacenarán los objetos generados por la importación.</translation>
    </message>
    <message>
        <source>Imported objects will be owned by</source>
        <translation>Los objetos importados serán propiedad de</translation>
    </message>
    <message>
        <source>Change user</source>
        <translation>Cambiar usuario</translation>
    </message>
    <message>
        <source>Click this button to select the user who should own the objects created by the import.</source>
        <translation>Pulsar este botón para elegir el usuario que será propietario de los objetos creados por la importación.</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Use this drop down to select the type of object the import should create. Click the &quot;Set&quot; button to load the correct attribute types for the remaining fields.</source>
        <translation>Usar el menú desplegable para elegir el tipo de objeto que creará la importación. Pulsar el botón &quot;Fijar&quot; para cargar los tipos de atributo correctos en los campos restantes.</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Click this button to load the correct values into the drop-down fields below. Use the drop-down menu on the left to select the correct class type.</source>
        <translation>Pulsar este botón para cargar los valores correctos en el menú desplegable de abajo. Usar el menú desplegable de la izquierda para elegir el tipo de clase correcto.</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the attribute that should bet set to the title information from the RSS stream.</source>
        <translation>Usar el menú desplegable para eligir los atributos que formarán el título desde el flujo RSS.</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorar</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the attribute that should be set to the URL information from the RSS stream.</source>
        <translation>Usar el menú desplegable para eligir los atributos que formarán la URL desde el flujo RSS.</translation>
    </message>
    <message>
        <source>Use this drop-down menu to select the attribute that should be set to the description information from the RSS stream.</source>
        <translation>Usar el menú desplegable para eligir los atributos que formarán la descripción desde el flujo RSS.</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Use this checkbox to control if the RSS feed is active or not. An inactive feed will not be automatically updated.</source>
        <translation>Usar esta opción para controlar si el flujo RSS está activa o no. Un flujo inactivo no se actualizará automáticamente.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Apply the changes and return to the RSS overview.</source>
        <translation>Aplicar los cambios y volver a la vista general del RSS.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Cancel the changes and return to the RSS overview.</source>
        <translation>Cancelar los cambios y volver a la vista general del RSS.</translation>
    </message>
</context>
<context>
    <name>design/admin/rss/list</name>
    <message>
        <source>RSS exports [%exports_count]</source>
        <translation>Exportaciones RSS [%exports_count]</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Invertir la selección</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Select RSS export for removal.</source>
        <translation>Elegir exportación RSS para eliminar.</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactivo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%name&gt; RSS export.</source>
        <translation>Editar la exportación RSS &lt;%name&gt;.</translation>
    </message>
    <message>
        <source>The RSS export list is empty.</source>
        <translation>La lista de exportaciones RSS está vacía.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected RSS exports.</source>
        <translation>Eliminar las exportaciones RSS seleccionadas.</translation>
    </message>
    <message>
        <source>New export</source>
        <translation>Nueva exportación</translation>
    </message>
    <message>
        <source>Create a new RSS export.</source>
        <translation>Crear una nueva exportación RSS.</translation>
    </message>
    <message>
        <source>RSS imports [%imports_count]</source>
        <translation>Importaciones RSS [%imports_count]</translation>
    </message>
    <message>
        <source>Select RSS import for removal.</source>
        <translation>Elegir importación RSS para eliminar.</translation>
    </message>
    <message>
        <source>Edit the &lt;%name&gt; RSS import.</source>
        <translation>Editar la importación RSS &lt;%name&gt;.</translation>
    </message>
    <message>
        <source>The RSS import list is empty.</source>
        <translation>La lista de importaciones RSS está vacía.</translation>
    </message>
    <message>
        <source>Remove selected RSS imports.</source>
        <translation>Eliminar las importaciones RSS seleccionadas.</translation>
    </message>
    <message>
        <source>New import</source>
        <translation>Nueva importación</translation>
    </message>
    <message>
        <source>Create a new RSS import.</source>
        <translation>Crear una nueva importación RSS.</translation>
    </message>
</context>
<context>
    <name>design/admin/search/stats</name>
    <message>
        <source>Search statistics</source>
        <translation>Estadísticas de búsqueda</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Frase</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Número de frases</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Promedio de resultados devueltos</translation>
    </message>
    <message>
        <source>The list is empty.</source>
        <translation>La lista está vacía.</translation>
    </message>
    <message>
        <source>Reset statistics</source>
        <translation>Resetear estadisticas</translation>
    </message>
    <message>
        <source>Clear the search log.</source>
        <translation>Vaciar el registro de búsqueda.</translation>
    </message>
</context>
<context>
    <name>design/admin/section/browse_assign</name>
    <message>
        <source>Choose start location for the &lt;%section_name&gt; section</source>
        <translation>Elegir la ubicación inicial para la sección &lt;%section_name&gt;</translation>
    </message>
    <message>
        <source>Use the radio buttons to select an item that should have the &lt;%section_name&gt; section assigned.</source>
        <translation>Usar los botones radio para elegir un elemento que debe tener asignado la sección &lt;%section_name&gt;.</translation>
    </message>
    <message>
        <source>Keep in mind that the section assignment of the sub items will also be changed.</source>
        <translation>Recuerda que también se cambiará la asignación de sección a los sub elementos.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/section/confirmremove</name>
    <message>
        <source>Confirm section removal</source>
        <translation>Confirmar eliminación de sección</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the section?</source>
        <translation>¿Estás seguro de que quieres eliminar la sección?</translation>
    </message>
    <message>
        <source>Are you sure you want to remove the sections?</source>
        <translation>¿Estás seguro de que quieres eliminar las secciones?</translation>
    </message>
    <message>
        <source>The following sections will be removed</source>
        <translation>Las siguientes secciones será eliminadas</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Alerta</translation>
    </message>
    <message>
        <source>Removing a section may corrupt permission settings, template output and other things in the system.</source>
        <translation>Eliminar una sección puede corromper la configuración de permisos, visualización de plantillas y otras cosas en el sistema. </translation>
    </message>
    <message>
        <source>Proceed only if you know what you are doing.</source>
        <translation>Procede sólo si sabes lo que estás haciendo.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/section/edit</name>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Edit &lt;%section_name&gt; [Section]</source>
        <translation>Editar &lt;%section_name&gt; [Sección]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Zona de navegación</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/section/list</name>
    <message>
        <source>Sections [%section_count]</source>
        <translation>Secciones [%section_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Select section for removal.</source>
        <translation>Elegir sección para eliminar.</translation>
    </message>
    <message>
        <source>section</source>
        <translation>sección</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Asignar</translation>
    </message>
    <message>
        <source>Assign the &lt;%section_name&gt; section to a subtree.</source>
        <translation>Asignar la sección &lt;%section_name&gt; a un subárbol.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%section_name&gt; section.</source>
        <translation>Editar la sección &lt;%section_name&gt;.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected sections.</source>
        <translation>Eliminar las secciones seleccionadas.</translation>
    </message>
    <message>
        <source>New section</source>
        <translation>Nueva sección</translation>
    </message>
    <message>
        <source>Create a new section.</source>
        <translation>Crear nueva sección.</translation>
    </message>
</context>
<context>
    <name>design/admin/section/view</name>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>%section_name [Section]</source>
        <translation>%section_name [Sección]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this section.</source>
        <translation>Editar esta sección.</translation>
    </message>
    <message>
        <source>Roles containing limitations associated with this section [%number_of_roles]</source>
        <translation>Roles que contienen limitaciones asociados con esta sección [%number_of_roles]</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Limited policies</source>
        <translation>Políticas limitadas</translation>
    </message>
    <message>
        <source>This section is not used to limit the policies of any role.</source>
        <translation>Esta sección no se usa para limitar las políticas de cualquier rol.</translation>
    </message>
    <message>
        <source>Users and user groups with role limitations associated with this section [%number_of_roles]</source>
        <translation>Usuarios y grupos de usuarios con limitaciones de rol asociados con esta sección [%number_of_roles]</translation>
    </message>
    <message>
        <source>User or user group</source>
        <translation>Usuario o grupo de usuarios</translation>
    </message>
    <message>
        <source>This section is not used for limiting roles that are assigned to users or user groups. </source>
        <translation>Esta sección no se usa para limitar roles asignados a usuarios o grupos de usuarios.</translation>
    </message>
    <message>
        <source>Objects within this section [%number_of_objects]</source>
        <translation>Objetos en esta sección [%number_of_objects]</translation>
    </message>
    <message>
        <source>This section is not assigned to any objects.</source>
        <translation>Esta sección no está asignada a ningún objeto.</translation>
    </message>
</context>
<context>
    <name>design/admin/settings</name>
    <message>
        <source>Edit setting %setting</source>
        <translation>Editar configuración %setting</translation>
    </message>
    <message>
        <source>New setting</source>
        <translation>Nueva configuración</translation>
    </message>
    <message>
        <source>Block</source>
        <translation>Bloque</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Setting: &lt;new setting&gt;</source>
        <translation>Configuración: &lt;nueva configuración&gt;</translation>
    </message>
    <message>
        <source>INI File</source>
        <translation>Archivo Ini</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Change setting type</source>
        <translation>Cambiar el tipo de configuración</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>A global setting will override a siteaccess setting</source>
        <translation>Una configuración global va a sobreescribir una configuración de acceso de sitio</translation>
    </message>
    <message>
        <source>Tip</source>
        <translation>Truco</translation>
    </message>
    <message>
        <source>To create an empty array leave the first line empty</source>
        <translation>Para crear una tabla vacía, dejar la primera línea vacía</translation>
    </message>
    <message>
        <source>Siteaccess setting</source>
        <translation>Configuración de acceso al sitio</translation>
    </message>
    <message>
        <source>Override setting (global)</source>
        <translation>Configuración de sobreescritura (global)</translation>
    </message>
    <message>
        <source>Global setting</source>
        <translation>Configuración global</translation>
    </message>
    <message>
        <source>Setting Name</source>
        <translation>Nombre de la configuración</translation>
    </message>
    <message>
        <source>Setting value</source>
        <translation>Valor de la configuración</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Activado</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Los datos no se validaron</translation>
    </message>
    <message>
        <source>%valfield is empty</source>
        <translation>%valfield está vacío</translation>
    </message>
    <message>
        <source>Variable %valfield already exists in section %block</source>
        <translation>La variable %valfield ya existe en la sección %block</translation>
    </message>
    <message>
        <source>Please choose another name that is not already taken</source>
        <translation>Por favor, elige otro nombre que no sea ya utilisado</translation>
    </message>
    <message>
        <source>%valfield is not allowed to contain spaces</source>
        <translation>%valfield no puede contener espacios</translation>
    </message>
    <message>
        <source>Writing setting: %setting_name to file: %filename failed.</source>
        <translation>Falló la escritura de la configuración %setting_name en el archivo %filename.</translation>
    </message>
    <message>
        <source>Make sure you have proper permissions to %path and try again.</source>
        <translation>Asegurate que tienes los permisos adecudados en %path y vuelve a intentarlo.</translation>
    </message>
    <message>
        <source>Name contains illegal character(s).</source>
        <translation>El nombre contiene caracteros ilegales.</translation>
    </message>
    <message>
        <source>Name should only contain A-Z and 0-9.</source>
        <translation>El nombre debe contener unicamente A-Z y 0-9.</translation>
    </message>
    <message>
        <source>%valfield does not contain a valid string.</source>
        <translation>%valfield no contiene una frase valida.</translation>
    </message>
    <message>
        <source>If the string is all numbers use the numeric type instead.</source>
        <translation>Si la frase solo contiene números, usar el tipo númerico.</translation>
    </message>
    <message>
        <source>%valfield does not contain a valid numeric</source>
        <translation>%valfield no contiene un valor númerico valido</translation>
    </message>
    <message>
        <source>A valid numeric can only contain 0-9 and one . (dot). </source>
        <translation>Un valor númerico solo puede contener 0-9 y un . (punto).</translation>
    </message>
    <message>
        <source>$valfield does not contain valid array.</source>
        <translation>$valfield no contiene una tabla valida.</translation>
    </message>
    <message>
        <source>View settings</source>
        <translation>Ver configuraciones</translation>
    </message>
    <message>
        <source>Using siteaccess</source>
        <translation>Usar acceso al sitio</translation>
    </message>
    <message>
        <source>%ini_file consist of %blocks section(s) and %setting_count different setting(s)</source>
        <translation>%ini_file tiene %blocks secciones y %setting_count diferentes configuraciones</translation>
    </message>
    <message>
        <source>Please select an ini file from the dropdown below</source>
        <translation>Por favor, elige un archivo ini desde el menú desplegable abajo</translation>
    </message>
    <message>
        <source>Select ini file to view</source>
        <translation>Elige el archivo ini para ver</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Elige un acceso al sitio</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Settings for %inifile in siteaccess %siteaccess</source>
        <translation>Configuraciones para %inifile en el acceso al sitio %siteaccess</translation>
    </message>
    <message>
        <source>[add setting]</source>
        <translation>[añadir configuración]</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
</context>
<context>
    <name>design/admin/setup</name>
    <message>
        <source>File consistency check OK.</source>
        <translation>Chequeo de consistencia de archivo OK.</translation>
    </message>
    <message>
        <source>Warning, it is not safe to upgrade without checking the modifications done to the following files</source>
        <translation>Alerta, no es seguro actualizar sin revisar las modificaciones hechas en los siguientes archivos</translation>
    </message>
    <message>
        <source>Database check OK.</source>
        <translation>Chequeo de base de datos OK.</translation>
    </message>
    <message>
        <source>The database is not consistent with the distribution database.</source>
        <translation>La base de datos no esta consistente con la base de datos de la distribución.</translation>
    </message>
    <message>
        <source>To synchronize your database with the distribution setup, run the following SQL commands</source>
        <translation>Para sincronizar tu base de datos con la configuración de la distribución, ejecuta los siguientes comandos SQL</translation>
    </message>
    <message>
        <source>System upgrade check</source>
        <translation>Chequeo de actualizaciones de sistema</translation>
    </message>
    <message>
        <source>Before upgrading eZ publish to a newer version, it is important to check that the current installation is ready for upgrading.</source>
        <translation>Antes de actualizar eZ publish a una versión más nueva, es importante asegurarse de que la instalación actual está lista para actualizar.</translation>
    </message>
    <message>
        <source>Remember to make a backup of the eZ publish directory and the database before you upgrade.</source>
        <translation>Recuerda hacer una copia de seguridad del directorio eZ publish y de la base de datos antes de actualizar.</translation>
    </message>
    <message>
        <source>File consistency check</source>
        <translation>Chequeo de consistencia de archivo</translation>
    </message>
    <message>
        <source>The file consistency tool checks if you have altered any of the files that came with the current installation. Altered files may be replaced by new versions which contain bugfixes, new features, etc. Make sure that you backup and then merge in your custom changes into the new versions of the files.</source>
        <translation>La herramienta de comprobación de consistencia de archivos verifica si se han modificado los archivos que vienen con la instalación actual. Los archivos modificados pueden ser reemplazados por versiones nuevas que contienen arreglos de fallo, nueva funcionalidades, etc. Asegurarse de hacer un backup y luego integrar sus cambios en las nuevas versiones de los archivos.</translation>
    </message>
    <message>
        <source>Database consistency check</source>
        <translation>Chequeo de consistencia de base de datos</translation>
    </message>
    <message>
        <source>The database consistency tool checks if the current database is consistent with the database schema that came with the eZ publish distribution. If there are any inconsistencies, the tool will suggest the necessary SQL statements that should be ran in order to bring the database into a consistent state. Please run the suggested SQL statements before upgrading.</source>
        <translation>La herramienta de comprobación de base de datos verifica si la base de datos actual esta consistente con el esquema de base de datos que viene con la distribución eZ Publish. Si hay cualquier diferencia, la herramienta sugere las necesarias peticiones SQL que se deben ejecutar para tener la base de datos en un estado consistente. Por favor, ejecutar las peticiones SQL sugeridas antes de actualizar.</translation>
    </message>
    <message>
        <source>The upgrade checking tools require a lot of resources and it may take some time to run them.</source>
        <translation>La herramienta de comprobación para la actualización requiere muchos recursos y puede tardar mucho tiempo para ejectuarse.</translation>
    </message>
    <message>
        <source>Check file consistency</source>
        <translation>Chequeo de consistencia de archivo</translation>
    </message>
    <message>
        <source>Check database consistency</source>
        <translation>Chequeo de consistencia de base de datos</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/cache</name>
    <message>
        <source>Content view cache was cleared</source>
        <translation>Se ha limpiado la caché de la vista de contenidos</translation>
    </message>
    <message>
        <source>All caches were cleared</source>
        <translation>Se ha limpiado todas las cachés</translation>
    </message>
    <message>
        <source>Ini file cache was cleared</source>
        <translation>Se ha limpiado la caché de archivos Ini</translation>
    </message>
    <message>
        <source>Template cache was cleared</source>
        <translation>Se ha limpiado la caché de las plantillas</translation>
    </message>
    <message>
        <source>The following caches were cleared</source>
        <translation>Las siguientes cachés han sido limpiadas</translation>
    </message>
    <message>
        <source>%name was cleared</source>
        <translation>%name ha sido limpiado</translation>
    </message>
    <message>
        <source>Clear caches</source>
        <translation>Limpiar las cachés</translation>
    </message>
    <message>
        <source>Template overrides and compiled templates</source>
        <translation>Plantillas sobreescritas y plantillas compiladas</translation>
    </message>
    <message>
        <source>Clear template caches</source>
        <translation>Limpiar cachés de plantillas</translation>
    </message>
    <message>
        <source>This operation will clear all the template override caches and the compiled templates. It may lead to weaker performance until the caches are up and running again.</source>
        <translation>Esta operación va ha limpiar todas las cachés de plantillas sobreescritas y compilidas. Puede provocar un rendimiento más bajo hasta que las cachés esten de nuevo creadas y utilizadas.</translation>
    </message>
    <message>
        <source>Content views and template blocks</source>
        <translation>Vistas de contenido y bloques de plantillas</translation>
    </message>
    <message>
        <source>Clear content caches</source>
        <translation>Limpiar cachés de contenido</translation>
    </message>
    <message>
        <source>This operation will clear all caches that are related to either template views or cache blocks inside the pagelayout template. Use it if you have modified templates or if you have changed something inside a cache block.</source>
        <translation>Esta operación va a limpiar todas las cachés que estan relacionadas o bien con las plantillas de vista o con los bloques de caché dentro de la plantilla &quot;pagelayout&quot;. Usarla si se ha modificado una plantilla o si se ha modificado algo dentro un bloque de caché.</translation>
    </message>
    <message>
        <source>Configuration (ini) caches</source>
        <translation>Configuración de caché (ini)</translation>
    </message>
    <message>
        <source>Clear ini caches</source>
        <translation>Limpiar la caché de archivos ini</translation>
    </message>
    <message>
        <source>This operation will clear all the configuration caches. Use it to force the system to re-read the configuration files if you have changed some settings.</source>
        <translation>Esta operación va a limpiar todas las cachés de configuración. Usarla para forzar el sistema a volver a leer los archivos de configuración si se ha modificado algunas configuraciones.</translation>
    </message>
    <message>
        <source>Everything</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Clear all caches</source>
        <translation>Limpiar todas las cachés</translation>
    </message>
    <message>
        <source>This operation will clear ALL the caches and may lead to long response times until the caches are up and running again.</source>
        <translation>Esta operación va a limpiar TODAS las cachés y puede provocor un tiempo de respuesta muy largo hasta que las cachés estan de nuevo generadas y usadas.</translation>
    </message>
    <message>
        <source>Fine-grained cache control</source>
        <translation>Control de caché fino</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <source>Select the &lt;%cache_name&gt; for clearing.</source>
        <translation>Elige el &lt;%cache_name&gt; para limpiar.</translation>
    </message>
    <message>
        <source>The &lt;%cache_name&gt; is disabled and thus it can not be marked for clearing.</source>
        <translation>El &lt;%cache_name&gt; esta deshabilitado y por eso no puede estar selecionado para limpiar.</translation>
    </message>
    <message>
        <source>Clear selected</source>
        <translation>Limpiar la selección</translation>
    </message>
    <message>
        <source>Clear the selected caches.</source>
        <translation>Limpiar las cachés seleccionadas.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/datatypecode</name>
    <message>
        <source>Constructor</source>
        <translation>Constructor</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/extensions</name>
    <message>
        <source>Available extensions [%extension_count]</source>
        <translation>Extensiones disponibles [%extension_count]</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Activate or deactivate extension. Use the &quot;Apply changes&quot; button to apply the changes.</source>
        <translation>Activar o desactivar extensión. Usar el botón &quot;Aplicar cambios&quot; para aplicar los cambios.</translation>
    </message>
    <message>
        <source>There are no available extensions.</source>
        <translation>No hay extensiones disponibles.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified the status of the checkboxes above.</source>
        <translation>Pulsa este botón para guardar los cambios si has modificado el estado de las casillas de verificación de arriba.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/info</name>
    <message>
        <source>System information</source>
        <translation>Información del sistema</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <translation>eZ publish</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Sitio</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>eZ publish version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <comment>eZ publish version</comment>
        <translation>Revisión SVN</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>eZ publish extensions</comment>
        <translation>Extensiones</translation>
    </message>
    <message>
        <source>Not in use.</source>
        <translation>No esta en uso.</translation>
    </message>
    <message>
        <source>PHP</source>
        <translation>PHP</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>PHP extensions</comment>
        <translation>Extensiones</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Varios</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>El modo salvado está encendido.</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>El modo salvado está apagado.</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>La restricción de basedir está encendida y fijada en %1.</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>La restricción de Basedir está apagada.</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>El registro de variable global está encendido.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>El registro de variable global está apagado.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>La subida de archivo está activada.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>La subida de archivo está apagada.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>El tamaño máximo del posteo de datos (texto y archivos) es %1.</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>El límite de memoria para un script es %1.</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>El tiempo máximo de ejecución es %1 segundos.</translation>
    </message>
    <message>
        <source>PHP Accelerator</source>
        <translation>Acelerador PHP</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>PHP Accelerator name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP Accelerator version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Version information could not be detected.</source>
        <translation>La información de versión no pudo ser detectada.</translation>
    </message>
    <message>
        <source>Status</source>
        <comment>PHP Accelerator status</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Enabled.</source>
        <translation>Activado.</translation>
    </message>
    <message>
        <source>Disabled.</source>
        <translation>Desactivado.</translation>
    </message>
    <message>
        <source>A known and active PHP accelerator could not be found.</source>
        <translation>No se pudo encontrar ningún acelerador PHP conocido y activo.</translation>
    </message>
    <message>
        <source>Webserver (software)</source>
        <comment>Webserver title</comment>
        <translation>Servidor web (herramienta)</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Webserver name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>Webserver version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Modules</source>
        <comment>Webserver modules</comment>
        <translation>Módulos</translation>
    </message>
    <message>
        <source>The modules of the webserver could not be detected.</source>
        <comment>Webserver modules</comment>
        <translation>No se pudieron detectar los módulos del servidor web.</translation>
    </message>
    <message>
        <source>eZ publish was unable to extract information from the webserver.</source>
        <translation>eZ publish no pudo extraer la información desde el servidor web.</translation>
    </message>
    <message>
        <source>Webserver (hardware)</source>
        <translation>Servidor web (maquina)</translation>
    </message>
    <message>
        <source>CPU</source>
        <comment>CPU info</comment>
        <translation>CPU</translation>
    </message>
    <message>
        <source>Memory</source>
        <comment>Memory info</comment>
        <translation>Memoria</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de datos</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>Database type</comment>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Server</source>
        <comment>Database server</comment>
        <translation>Servidor</translation>
    </message>
    <message>
        <source>Socket path</source>
        <comment>Database socket path</comment>
        <translation>Ruta de &quot;socket&quot;</translation>
    </message>
    <message>
        <source>Database name</source>
        <comment>Database name</comment>
        <translation>Nombre de la base de datos</translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <comment>Database retry count</comment>
        <translation>Contador de reintentos de conexión</translation>
    </message>
    <message>
        <source>Character set</source>
        <comment>Database charset</comment>
        <translation>Juego de caracteres</translation>
    </message>
    <message>
        <source>Internal</source>
        <translation>Interno</translation>
    </message>
    <message>
        <source>Slave database (read only)</source>
        <translation>Base de datos esclavo (solo lectura)</translation>
    </message>
    <message>
        <source>Database</source>
        <comment>Database name</comment>
        <translation>Base de datos</translation>
    </message>
    <message>
        <source>There is no slave database in use.</source>
        <translation>No hay base de datos esclavo en uso.</translation>
    </message>
    <message>
        <source>Script memory limit is Unlimited.</source>
        <translation>El límite de memoria para un script es ilimitado.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Ejemplo</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Constructor, no hace nada por defecto.</translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>\return una tabla con el nombre de operador de plantillas.</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Ejecuta la función PHP para la limpieza del operador y modifica \a $operatorValue.</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Código de ejemplo. Este código debe ser modificado para hacer lo que el operador debe hacer. Actualmente solo limpia texto.</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/rad</name>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Herramientas de Desarrollo de Aplicación Rápida</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools make the creation of new/extended functionality for eZ publish easier. Currently there are two RAD tools available: the template operator wizard and the datatype wizard. The template operator wizard basically generates a valid framework (PHP code) for a new template operator. The datatype wizard generates a valid framework (PHP code) for a new datatype.</source>
        <translation>Las herramientas de desarrollo de aplicación rápida (RAD) facilitan la creación de nuevas/avanzadas funcionalidades para eZ publish. Actualmente hay dos herramientas RAD disponibles: el asistente de operadores de plantilla y el asistente de tipo de datos. El asistente de operadores de plantilla basicamente genera un entorno de trabajo (código PHP) para un nuevo operador de plantilla. El asistente de tipo de datos genera un entorno de trabajo (código PHP) para un nuevo tipo de datos.</translation>
    </message>
    <message>
        <source>Available RAD tools</source>
        <translation>Herramientas RAD disponibles</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Asistente de operador de plantillas</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Asistente de tipo de datos</translation>
    </message>
    <message>
        <source>Template operator wizard (step 1 of 3)</source>
        <translation>Asistente de operador de plantillas (paso 1 de 3)</translation>
    </message>
    <message>
        <source>Welcome to the template operator wizard. Template operators are usually used for manipulating template variables. However, they can also be used to generate or fetch data. This wizard will take you through a couple of steps with some basic choices. When finished, eZ publish will generate a PHP framework for the a new operator (which will be available for download).</source>
        <translation>Bienvenido al asistente de operador de plantilla. Los operadores de plantilla se usan para manipular las variables de la plantilla. Non obstante, pueden ser usados también para generar o recoger datos. Este asistente simplifica el proceso en varios pasos con opciones básicas. Una vez acabado, eZ publish generará el entorno de trabajo PHP para el nuevo operador (el cual estará disponible para descargar). </translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/rad/datatype</name>
    <message>
        <source>Datatype wizard (step 1 of 3)</source>
        <translation>Asistente de tipo de datos (paso 1 de 3)</translation>
    </message>
    <message>
        <source>Welcome to the wizard for creating a new datatypes. Everything you store in your content objects are called attributes. These attributes are defined as a data types. To be able to customize the storing and validation of these attributes, you can create your own data types.</source>
        <translation>Bienvenido al asistente para crear un nuevo tipo de datos. Todo lo que guardas en los objetos de contenido se llama atributos. Estos atributos se definen como tipos de datos. Para poder personalizar el almacenamiento y validación de estos atributos puedes crear tus propios tipos de datos.</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Datatype wizard (step 2 of 3)</source>
        <translation>Asistente de tipo de datos (paso 2 de 3)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Descriptive name</source>
        <translation>Nombre descriptivo</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <translation>Gestionar entradas en nivel de clase</translation>
    </message>
    <message>
        <source>Datatype wizard (step 3 of 3)</source>
        <translation>Asistente de tipo de datos (paso 3 de 3)</translation>
    </message>
    <message>
        <source>Name of class</source>
        <translation>Nombre de la clase</translation>
    </message>
    <message>
        <source>Constant name</source>
        <translation>Nombre de la constante</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <translation>El creador del tipo de datos</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Handles the datatype %datatype_name. By using %datatype_name you can ...</source>
        <translation>Gestiona el tipo de datos %datatype_name. Usando %datatype_name puedes ...</translation>
    </message>
    <message>
        <source>Hint: The first line will be used as the brief description. The rest will become operator documentation.</source>
        <translation>Pista: La primera línea se usará como una breve descripción. El resto será documentación del operador.</translation>
    </message>
    <message>
        <source>Finish and generate</source>
        <translation>Acabar y generar</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/rad/templateoperator</name>
    <message>
        <source>Template operator wizard (step 2 of 3)</source>
        <translation>Asistente de operador de plantillas (paso 2 de 3)</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Handles input</source>
        <translation>Gestiona la entrada</translation>
    </message>
    <message>
        <source>Generates output</source>
        <translation>Genera la salida</translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation>Parámetros</translation>
    </message>
    <message>
        <source>No parameters</source>
        <translation>Sin parámetros</translation>
    </message>
    <message>
        <source>Named parameters</source>
        <translation>Parámetros nombrados</translation>
    </message>
    <message>
        <source>Sequential parameters</source>
        <translation>Parámetros secuenciales</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Template operator wizard (step 3 of 3)</source>
        <translation>Asistente de operador de plantillas (paso 3 de 3)</translation>
    </message>
    <message>
        <source>Class name</source>
        <translation>Nombre de clase</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Handles template operator %operator_name. By using %operator_name you can...</source>
        <translation>Gestiona el operador de plantillas %operator_name. Usando %operator_name puedes ...</translation>
    </message>
    <message>
        <source>Hint: The first line will be used for the brief description. The rest will become the documentation.</source>
        <translation>Pista: La primera línea se usará como una breve descripción. El resto será documentación.</translation>
    </message>
    <message>
        <source>Example code</source>
        <translation>Código de ejemplo</translation>
    </message>
    <message>
        <source>Hint: Feel free to add example code that demonstrates how the operator works.</source>
        <translation>Pista: Puedes añadir código de ejemplo que muestre cómo funciona el operador.</translation>
    </message>
    <message>
        <source>Finish and generate</source>
        <translation>Acabar y generar</translation>
    </message>
</context>
<context>
    <name>design/admin/setup/session</name>
    <message>
        <source>The sessions were successfully removed.</source>
        <translation>Las sesiones han sido eliminadas correctamente.</translation>
    </message>
    <message>
        <source>Session administration</source>
        <translation>Administración de sesión</translation>
    </message>
    <message>
        <source>Sessions</source>
        <translation>Sesiones</translation>
    </message>
    <message>
        <source>Total number of sessions</source>
        <translation>Total de sesiones</translation>
    </message>
    <message>
        <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
        <translation>Hay %logged_in_count usuarios registrados y %anonymous_count usuarios anónimos conectados.</translation>
    </message>
    <message>
        <source>WARNING! When you remove sessions, users that are logged in will be logged out from the system.</source>
        <translation>ALERTA! Cuando eliminas sesiones, los usuarios que están conectados serán desconectados del sistema.</translation>
    </message>
    <message>
        <source>Remove all sessions</source>
        <translation>Eliminar todas las sesiones</translation>
    </message>
    <message>
        <source>Remove timed out / old sessions</source>
        <translation>Eliminar las sesiones caducadas y antiguas</translation>
    </message>
    <message>
        <source>Filtered sessions</source>
        <translation>Sesiones filtradas</translation>
    </message>
    <message>
        <source>Displaying sessions for %username</source>
        <translation>Mostrando sesiones de %username</translation>
    </message>
    <message>
        <source>Sessions for all users</source>
        <translation>Sesiones de todos los usuarios</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Usuarios</translation>
    </message>
    <message>
        <source>Everyone</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>Registered users</source>
        <translation>Usuarios registrados</translation>
    </message>
    <message>
        <source>Anonymous users</source>
        <translation>Usuarios anónimos</translation>
    </message>
    <message>
        <source>Update list</source>
        <translation>Refrescar lista</translation>
    </message>
    <message>
        <source>Include inactive users</source>
        <translation>Incluir usuarios inactivos</translation>
    </message>
    <message>
        <source>Invert selection</source>
        <translation>Invertir la selección</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Conectar</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cuenta</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Full name</source>
        <translation>Nombre y apellido</translation>
    </message>
    <message>
        <source>Idle time</source>
        <translation>Tiempo de inactividad</translation>
    </message>
    <message>
        <source>Idle since</source>
        <translation>Inactivo desde</translation>
    </message>
    <message>
        <source>Select session for removal.</source>
        <translation>Elegir sesión para eliminar.</translation>
    </message>
    <message>
        <source>Time skew detected</source>
        <translation>Tiempo raro detectado</translation>
    </message>
    <message>
        <source>There are no sessions matching the selected options.</source>
        <translation>No hay ninguna sesión que coincida con las opciones seleccionadas.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected sessions.</source>
        <translation>Eliminar las sesiones seleccionadas.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/accounthandlers/html/ez</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Compañía</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Calle</translation>
    </message>
    <message>
        <source>Zip code</source>
        <translation>Código postal</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/basket</name>
    <message>
        <source>Items removed</source>
        <translation>Elementos eliminados</translation>
    </message>
    <message>
        <source>The following items were removed from your basket because the products have changed</source>
        <translation>Los siguientes elementos fueron eliminados de tu cesta porque los productos han cambiado</translation>
    </message>
    <message>
        <source>Shopping basket</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price (ex. VAT)</source>
        <translation>Precio (sin IVA)</translation>
    </message>
    <message>
        <source>Price (inc. VAT)</source>
        <translation>Precio (con IVA)</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Total (sin IVA)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Total (con IVA)</translation>
    </message>
    <message>
        <source>Select item for removal.</source>
        <translation>Elegir elemento para eliminar.</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones seleccionadas</translation>
    </message>
    <message>
        <source>Subtotal (ex. VAT)</source>
        <translation>Subtotal (sin IVA)</translation>
    </message>
    <message>
        <source>Subtotal (inc. VAT)</source>
        <translation>Subtotal (con IVA)</translation>
    </message>
    <message>
        <source>There are no items in your shopping basket.</source>
        <translation>No hay ningún elemento en tu cesta.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected items from the basket.</source>
        <translation>Eliminar los elementos seleccionados de la cesta.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to update the basket if you have modified any quantity and/or option fields.</source>
        <translation>Pulsa este botón para refrescar la cesta si has modificado alguna cantidad y/o opción.</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Continuar comprando</translation>
    </message>
    <message>
        <source>Leave the basket and continue shopping.</source>
        <translation>Dejar la cesta y seguir comprando.</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Caja</translation>
    </message>
    <message>
        <source>Proceed to checkout and purchase the items that are in the basket.</source>
        <translation>Realizar pago y comprar los elementos de la cesta.</translation>
    </message>
    <message>
        <source>You can not remove any items because there are no items in the basket.</source>
        <translation>No puedes eliminar ningún elemento porque no hay elementos en la cesta.</translation>
    </message>
    <message>
        <source>You can not store any changes because the basket is empty.</source>
        <translation>No puedes guardar ningún cambio porque la cesta está vacía.</translation>
    </message>
    <message>
        <source>You can not check out because the basket is empty.</source>
        <translation>No puedes realizar el pago porque tu cesta está vacía.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/browse_discountcustomer</name>
    <message>
        <source>Choose customers for discount group</source>
        <translation>Elegir los clientes para el grupo de descuento</translation>
    </message>
    <message>
        <source>Use the checkboxes to select users and user groups (customers) that you wish to add to the discount group.</source>
        <translation>Usa las casillas de verificación para elegir los usuarios y grupos de usuarios (clientes) que deseas añadir al grupo de descuento.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/browse_discountgroup</name>
    <message>
        <source>Choose products for discount group</source>
        <translation>Elige los producto para el grupo de descuento</translation>
    </message>
    <message>
        <source>Use the checkboxes to select products to be included in the discount group.</source>
        <translation>Usar las casillas de verificación para elegir los productos que se incluirán en el grupo de descuento.</translation>
    </message>
    <message>
        <source>Navigate using the available tabs (above), the tree menu (left) and the content list (middle).</source>
        <translation>Navega usando las pestañas disponibles (arriba), el menu (izquierda) y la lista de contenido (centro).</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/confirmorder</name>
    <message>
        <source>Order confirmation</source>
        <translation>Confirmación de pedido</translation>
    </message>
    <message>
        <source>Please confirm that the information below is correct. Click &quot;Confirm order&quot; to confirm the order.</source>
        <translation>Por favor confirma que la información de abajo es correcta. Pulsa el botón &quot;Confirmar pedido&quot; para confirmar el pedido.</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Items to be purchased</source>
        <translation>Elementos para comprar</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price (ex. VAT)</source>
        <translation>Precio (sin IVA)</translation>
    </message>
    <message>
        <source>Price (inc. VAT)</source>
        <translation>Precio (con IVA)</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total price (ex. VAT)</source>
        <translation>Precio total (sin IVA)</translation>
    </message>
    <message>
        <source>Total price (inc. VAT)</source>
        <translation>Precio total (con IVA)</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones seleccionadas</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sumario del pedido</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Subtotal de elementos</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total del pedido</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmar pedido</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/customerlist</name>
    <message>
        <source>Customers [%customers]</source>
        <translation>Clientes [%customers]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>Pedidos</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Total (ex. IVA)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Total (inc. IVA)</translation>
    </message>
    <message>
        <source>The customer list is empty.</source>
        <translation>La lista de clientes está vacía.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/customerorderview</name>
    <message>
        <source>Customer information</source>
        <translation>Información de cliente</translation>
    </message>
    <message>
        <source>Orders [%order_count]</source>
        <translation>Pedidos [%order_count]</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Total (sin IVA)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Total (con IVA)</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Purchased products [%product_count]</source>
        <translation>Productos adquiridos [%product_count]</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Cantidad</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroup</name>
    <message>
        <source>Discount groups [%discount_groups]</source>
        <translation>Grupos de descuento [%discount_groups]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Select discount group for removal.</source>
        <translation>Elegir grupo de descuento para eliminar.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%discountgroup_name&gt; discount group.</source>
        <translation>Editar el grupo de descuento &lt;%discountgroup_name&gt;.</translation>
    </message>
    <message>
        <source>There are no discount groups.</source>
        <translation>No hay grupos de descuento.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected discount groups.</source>
        <translation>Eliminar los grupos de descuento seleccionados.</translation>
    </message>
    <message>
        <source>New discount group</source>
        <translation>Nuevo grupo de descuento</translation>
    </message>
    <message>
        <source>Create a new discount group.</source>
        <translation>Crear nuevo grupo de descuento.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroupedit</name>
    <message>
        <source>Edit &lt;%discount_group&gt; [Discount group]</source>
        <translation>Editar &lt;%discount_group&gt;[Grupo de descuento]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroupmembershipview</name>
    <message>
        <source>%discount_group [Discount group]</source>
        <translation>%discount_group [Grupo de descuento]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this discount group.</source>
        <translation>Editar este grupo de descuento.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove this discount group.</source>
        <translation>Eliminar este grupo de descuento.</translation>
    </message>
    <message>
        <source>Discount rules [%rule_count]</source>
        <translation>Reglas de descuento [%rule_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Porcentaje</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Aplicar a </translation>
    </message>
    <message>
        <source>Select discount rule for removal.</source>
        <translation>Elegir regla de descuento para eliminar.</translation>
    </message>
    <message>
        <source>Edit the &lt;%discount_rule_name&gt; discount rule.</source>
        <translation>Editar la regla de descuento &lt;%discount_rule_name&gt;.</translation>
    </message>
    <message>
        <source>There are no discount rules in this group.</source>
        <translation>No hay reglas de descuento para este grupo.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected discount rules.</source>
        <translation>Eliminar las reglas de descuento seleccionadas.</translation>
    </message>
    <message>
        <source>New discount rule</source>
        <translation>Nueva regla de descuento</translation>
    </message>
    <message>
        <source>Create a new discount rule and add it to the &lt;%discount_group_name&gt; discount group.</source>
        <translation>Crear una nueva regla de descuento para el grupo de descuento &lt;%discount_group_name&gt; y editarla.</translation>
    </message>
    <message>
        <source>Customers (users and user groups) [%customer_count]</source>
        <translation>Clientes (usuarios y grupos de usuarios) [%customer_count]</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Select user or user group for removal.</source>
        <translation>Elegir usuario o grupo de usuario para eliminar.</translation>
    </message>
    <message>
        <source>There are no customers in this discount group.</source>
        <translation>No hay clientes en este grupo de descuento.</translation>
    </message>
    <message>
        <source>Remove selected users and/or user groups.</source>
        <translation>Eliminar los usuarios y/o grupos de usuarios seleccionados.</translation>
    </message>
    <message>
        <source>Add customers</source>
        <translation>Añadir clientes</translation>
    </message>
    <message>
        <source>Add users and/or user groups to the &lt;%discount_group_name&gt; discount group.</source>
        <translation>Añadir usuarios y/o grupos de usuarios al grupo de descuento &lt;%discount_group_name&gt;.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountruleedit</name>
    <message>
        <source>New discount rule</source>
        <translation>Nueva regla de descuento</translation>
    </message>
    <message>
        <source>Edit &lt;%rule_name&gt; [Discount rule]</source>
        <translation>Editar &lt;%rule_name&gt; [Regla de descuento]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Porcentaje de descuento</translation>
    </message>
    <message>
        <source>Product types</source>
        <translation>Tipos de productos</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>in sections</source>
        <translation>en secciones</translation>
    </message>
    <message>
        <source>Individual products</source>
        <translation>Productos individuales</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>The individual product list is empty.</source>
        <translation>La lista de productos individuales está vacía.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Add products</source>
        <translation>Añadir productos</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderlist</name>
    <message>
        <source>Orders [%count]</source>
        <translation>Pedidos[%count]</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Ascendente</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Descendente</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Total (sin IVA)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Total (con IVA)</translation>
    </message>
    <message>
        <source>Select order for removal.</source>
        <translation>Elegir pedido para eliminar.</translation>
    </message>
    <message>
        <source>The order list is empty.</source>
        <translation>La lista de pedidos está vacía.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected orders.</source>
        <translation>Eliminar pedidos seleccionados.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderstatistics</name>
    <message>
        <source>Product statistics [%count]</source>
        <translation>Estadísticas de producto [%count]</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation>Total (sin IVA)</translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation>Total (con IVA)</translation>
    </message>
    <message>
        <source>SUM</source>
        <translation>SUMA</translation>
    </message>
    <message>
        <source>The list is empty.</source>
        <translation>La lista está vacía.</translation>
    </message>
    <message>
        <source>Select the year for which you wish to view statistics.</source>
        <translation>Elige el año del cual quieres ver las estadísticas.</translation>
    </message>
    <message>
        <source>All years</source>
        <translation>Todos los años</translation>
    </message>
    <message>
        <source>Select the month for which you wish to view statistics.</source>
        <translation>Elige el mes del cual quieres ver las estadísticas.</translation>
    </message>
    <message>
        <source>All months</source>
        <translation>Todos los meses</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <source>Update the list using the values specified by the menus on the left.</source>
        <translation>Actualizar la lista usando los valores especificados en los menús de la izquierda.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderview</name>
    <message>
        <source>Order #%order_id</source>
        <translation>Pedido #%order_id</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Productos</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cuenta</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Precio sin IVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Precio con IVA</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Precio total sin IVA</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Precio total con IVA</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sumario del pedido</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Subtotal de elementos</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total del pedido</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove this order.</source>
        <translation>Eliminar este pedido.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/removeorder</name>
    <message>
        <source>Confirm order removal</source>
        <translation>Confirmar eliminación de pedido</translation>
    </message>
    <message>
        <source>Are you sure you want to remove order #%order_number?</source>
        <translation>¿Estás seguro de que quieres eliminar el pedido #%order_number? </translation>
    </message>
    <message>
        <source>Are you sure you want to remove the following orders?</source>
        <translation>¿Estás seguro de que quieres eliminar los siguientes pedidos? </translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/userregister</name>
    <message>
        <source>Required information is missing...</source>
        <translation>Falta información requerida...</translation>
    </message>
    <message>
        <source>Please please fill in the fields that are marked with a star.</source>
        <translation>Por favor rellena los campos marcados con un asterisco.</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Información de cuenta</translation>
    </message>
    <message>
        <source>Please fill in the necessary information. Required fields are marked with a star.</source>
        <translation>Por favor rellena la información necesaria. Los campos requeridos están marcados con un asterisco.</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Apellido</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Compañía</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Calle</translation>
    </message>
    <message>
        <source>ZIP code</source>
        <translation>Código postal</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Ciudad</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/vattype</name>
    <message>
        <source>VAT types [%vat_types]</source>
        <translation>Tipos de IVA [%vat_types]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Porcentaje</translation>
    </message>
    <message>
        <source>Select VAT type for removal.</source>
        <translation>Elegir tipo de IVA para eliminar.</translation>
    </message>
    <message>
        <source>There are no VAT types.</source>
        <translation>No hay ningún tipo de IVA.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected VAT types.</source>
        <translation>Eliminar los tipos de IVA seleccionados.</translation>
    </message>
    <message>
        <source>New VAT type</source>
        <translation>Nuevo tipo de IVA</translation>
    </message>
    <message>
        <source>Create a new VAT type.</source>
        <translation>Crear un nuevo tipo de IVA.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation>Pulsa este botón para guardar los cambios si has modificado alguno de los campos de arriba.</translation>
    </message>
</context>
<context>
    <name>design/admin/shop/wishlist</name>
    <message>
        <source>My wish list [%item_count]</source>
        <translation>Mi lista de deseados</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price (ex. VAT)</source>
        <translation>Precio (sin IVA)</translation>
    </message>
    <message>
        <source>Price (inc. VAT)</source>
        <translation>Precio (con IVA)</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuento</translation>
    </message>
    <message>
        <source>Total price (ex. VAT)</source>
        <translation>Precio total (sin IVA)</translation>
    </message>
    <message>
        <source>Total price (inc. VAT)</source>
        <translation>Precio total (con IVA)</translation>
    </message>
    <message>
        <source>Select item for removal.</source>
        <translation>Elegir elemento para eliminar.</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones seleccionadas</translation>
    </message>
    <message>
        <source>The wish list is empty.</source>
        <translation>La lista de deseados está vacía.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected items.</source>
        <translation>Eliminar los elementos seleccionados.</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified quantity and/or option values.</source>
        <translation>Pulsa este botón para guardar los cambios si has modificado la cantidad y/o el estado de las casillas de verificación.</translation>
    </message>
</context>
<context>
    <name>design/admin/trigger/list</name>
    <message>
        <source>Workflow triggers [%trigger_count]</source>
        <translation>Disparadores de flujo de trabajo [%trigger_count]</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Connection type</source>
        <translation>Tipo de conexión</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Flujo de trabajo</translation>
    </message>
    <message>
        <source>Select the workflow that should be triggered %type the %function function is executed within the %module module.</source>
        <translation>Elige el flujo de trabajo que debe ser ejecutado %type la función %function se ejecuta dentro del módulo %module.</translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>No hay flujo de trabajo</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation>Pulsa este botón para guardar los cambios si has modificado alguno de los campos de arriba.</translation>
    </message>
</context>
<context>
    <name>design/admin/url/edit</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Edit URL #%url_id</source>
        <translation>Editar URL #%url_id</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/url/list</name>
    <message>
        <source>Valid URLs [%url_list_count]</source>
        <translation>URLs válidas [%url_list_count]</translation>
    </message>
    <message>
        <source>Invalid URLs [%url_list_count]</source>
        <translation>URLs no válidas [%url_list_count]</translation>
    </message>
    <message>
        <source>All URLs [%url_list_count]</source>
        <translation>Todas las URLs [%url_list_count]</translation>
    </message>
    <message>
        <source>Show all URLs.</source>
        <translation>Mostrar todas las URLs.</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todas</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Válidas</translation>
    </message>
    <message>
        <source>Show only invalid URLs.</source>
        <translation>Mostrar sólo las URLs no válidas.</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Inválidas</translation>
    </message>
    <message>
        <source>Show only valid URLs.</source>
        <translation>Mostrar sólo las URLs válidas.</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Comprobado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>View information about URL.</source>
        <translation>Ver información sobre la URL.</translation>
    </message>
    <message>
        <source>Open URL in new window.</source>
        <translation>Abrir la URL en una nueva ventana.</translation>
    </message>
    <message>
        <source>open</source>
        <translation>abrir</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit URL.</source>
        <translation>Editar la URL.</translation>
    </message>
    <message>
        <source>The requested list is empty.</source>
        <translation>La lista solicitada está vacía.</translation>
    </message>
</context>
<context>
    <name>design/admin/url/view</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>URL #%url_id</source>
        <translation>URL #%url_id</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocida</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Válida</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Inválida</translation>
    </message>
    <message>
        <source>Last checked</source>
        <translation>Último chequeo</translation>
    </message>
    <message>
        <source>This URL has not been checked.</source>
        <translation>La URL no ha sido chequeada.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this URL.</source>
        <translation>Editar esta URL.</translation>
    </message>
    <message>
        <source>Objects using URL #%url_id [%url_count]</source>
        <translation>Objetos que usan la URL #%url_id [%url_count]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Edit &lt;%object_name&gt;.</source>
        <translation>Editar &lt;%object_name&gt;.</translation>
    </message>
    <message>
        <source>URL #%url_id is not in use by any objects.</source>
        <translation>La URL #%url_id no está siendo usada por ningún objeto.</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Pending</source>
        <translation>Pendiente</translation>
    </message>
    <message>
        <source>Archived</source>
        <translation>Archivado</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Rechazado</translation>
    </message>
    <message>
        <source> (in trash)</source>
        <translation> (en papelera)</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>View the contents of version #%version_number. Default translation: %default_translation.</source>
        <translation>Ver los contenidos de la versión #%version_number. Traducción predeterminada: %default_translation.</translation>
    </message>
</context>
<context>
    <name>design/admin/user</name>
    <message>
        <source>Activate account</source>
        <translation>Activar cuenta</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Tu cuenta está ahora activada.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Perdón, la clave enviada no es válida. La cuenta no ha sido activada.</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Usuario registrado</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Tu cuenta ha sido creada con éxito. Se enviará un correo a la dirección
de correo especificada. 
Necesitas seguir las instrucciones especificadas en ese correo para activar
tu cuenta.</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Tu cuenta se ha creado con éxito.</translation>
    </message>
</context>
<context>
    <name>design/admin/user/login</name>
    <message>
        <source>The system could not log you in.</source>
        <translation>El sistema no te dejó conectar.</translation>
    </message>
    <message>
        <source>Make sure that the username and password is correct.</source>
        <translation>Asegúrate de que el nombre de usuario y la contraseña sean correctas.</translation>
    </message>
    <message>
        <source>All letters must be typed in using the correct case.</source>
        <translation>Se debe escribir todas las letras, respetando minúscula/mayúscula.</translation>
    </message>
    <message>
        <source>Please try again or contact the site administrator.</source>
        <translation>Por favor prueba otra vez o contacta con el administrador de la web.</translation>
    </message>
    <message>
        <source>Access denied!</source>
        <translation>Acceso denegado!</translation>
    </message>
    <message>
        <source>You do not have permissions to access &lt;%siteaccess_name&gt;.</source>
        <translation>No tienes permisos para acceder a &lt;%siteaccess_name&gt;.</translation>
    </message>
    <message>
        <source>Please contact the site administrator.</source>
        <translation>Por favor contacta con el administrador de la web.</translation>
    </message>
    <message>
        <source>Log in to the administration interface of eZ publish</source>
        <translation>Conectar a la interfaz de administración de eZ publish</translation>
    </message>
    <message>
        <source>Please enter a valid username/password combination and click &quot;Log in&quot;.</source>
        <translation>Por favor escribe un nombre de usuario y una contraseña correcta y pulsa &quot;Conectar&quot;.</translation>
    </message>
    <message>
        <source>Use the &quot;Register&quot; button to create a new account.</source>
        <translation>Usa el botón &quot;Registrar&quot; para crear una nueva cuenta.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Enter a valid username into this field.</source>
        <translation>Escribe un nombre de usuario válido en este campo.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Enter a valid password into this field.</source>
        <translation>Escribe una contraseña válida en este campo.</translation>
    </message>
    <message>
        <source>Log in</source>
        <comment>Login button</comment>
        <translation>Conectar</translation>
    </message>
    <message>
        <source>Click here to log in using the username/password combination entered in the fields above.</source>
        <translation>Pulsa aquí para conectar usando el nombre de usuario y contraseña escritos arriba.</translation>
    </message>
    <message>
        <source>Register</source>
        <comment>Register button</comment>
        <translation>Registrar</translation>
    </message>
    <message>
        <source>Click here to create a new account.</source>
        <translation>Pulsa aquí para crear una nueva cuenta.</translation>
    </message>
</context>
<context>
    <name>design/admin/user/password</name>
    <message>
        <source>The password could not be changed.</source>
        <translation>No se pud cambiar la contraseña.</translation>
    </message>
    <message>
        <source>The old password was either missing or incorrect.</source>
        <translation>Falta la contraseña antigua o es incorrecta.</translation>
    </message>
    <message>
        <source>Please retype the old password and try again.</source>
        <translation>Por favor vuelve a escribir la contraseña antigua y prueba otra vez.</translation>
    </message>
    <message>
        <source>The new passwords did not match.</source>
        <translation>Las nuevas contraseñas no coinciden.</translation>
    </message>
    <message>
        <source>Please retype the new passwords and try again.</source>
        <translation>Por favor vuelve a escribir las nuevas contraseñas y prueba otra vez.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters long.</source>
        <translation>La contraseña debe contener por lo menos 3 carácteres.</translation>
    </message>
    <message>
        <source>The password was successfully changed.</source>
        <translation>La contraseña se cambió con éxito.</translation>
    </message>
    <message>
        <source>Change password for &lt;%username&gt;</source>
        <translation>Cambiar contraseña para &lt;%username&gt;</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Antigua contraseña</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Nueva contraseña</translation>
    </message>
    <message>
        <source>Confirm new password</source>
        <translation>Confirma la nueva contraseña</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/user/register</name>
    <message>
        <source>The information could not be stored...</source>
        <translation>No se pudo guardar la información...</translation>
    </message>
    <message>
        <source>The following information is either incorrect or missing</source>
        <translation>La siguiente información es o incorrecta o está mal escrita</translation>
    </message>
    <message>
        <source>Please correct the inputs (marked with red labels) and try again.</source>
        <translation>Por favor corrige tus datos (marcados con etiquetas rojas) y prueba otra vez.</translation>
    </message>
    <message>
        <source>Register new user</source>
        <translation>Registrar nuevo usuario</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Incapaz de registrar el nuevo usuario</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
</context>
<context>
    <name>design/admin/user/setting</name>
    <message>
        <source>User settings for &lt;%user_name&gt;</source>
        <translation>Preferencias de usuario de &lt;%user_name&gt;</translation>
    </message>
    <message>
        <source>Maximum concurrent logins</source>
        <translation>Máximo de conexiones simultaneas</translation>
    </message>
    <message>
        <source>This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]</source>
        <translation>Esta función no está disponible. [Usa este campo para especificar el número máximo de conexiones simultaneas permitidas.]</translation>
    </message>
    <message>
        <source>Enable user account</source>
        <translation>Activar cuenta de usuario</translation>
    </message>
    <message>
        <source>Use this checkbox to enable or disable the user account.</source>
        <translation>Usar esta casilla de verificación para activar o desactivar la cuenta de usuario.</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/user/success</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/menuconfig</name>
    <message>
        <source>Menu management</source>
        <translation>Gestión de menú</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Menu positioning</source>
        <translation>Posicionamiento del menú</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click here to store the changes if you have modified the menu settings above.</source>
        <translation>Pulsa aquí para guardar los cambios si has modificado las preferencias del menú de arriba.</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templatecreate</name>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>No puedes crear una plantilla. Permiso denegado.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Nombre no válido. Sólo puedes utilizar caracteres de la a a la z, números y _.</translation>
    </message>
    <message>
        <source>Create new template override for &lt;%template_name&gt;</source>
        <translation>Crear una nueva plantilla sobreescrita de &lt;%template_name&gt;</translation>
    </message>
    <message>
        <source>The newly created template file will be placed in</source>
        <translation>El archivo de plantilla recién creado se guardará en</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nombre del fichero</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Claves de sobreescritura</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Todas las clases</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Todas las secciones</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID del nudo</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Base de la plantilla en</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Archivo vacío</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Copia de plantilla por defecto</translation>
    </message>
    <message>
        <source>Container (with children)</source>
        <translation>Contenedor (con hijos)</translation>
    </message>
    <message>
        <source>View (without children)</source>
        <translation>Vista (sin hijos)</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objeto</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templateedit</name>
    <message>
        <source>Edit template: &lt;%template&gt;</source>
        <translation>Editar plantilla: &lt;%template&gt;</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to save the contents of the text field above to the template file.</source>
        <translation>Pulsa este botón para guardar los contenidos del campo de texto de arriba en el archivo de plantilla.</translation>
    </message>
    <message>
        <source>You do not have permissions to save the contents of the text field above to the template file.</source>
        <translation>No tienes permisos para guardar los contenidos del campo de texto de arriba en el archivo de plantilla.</translation>
    </message>
    <message>
        <source>Back to overrides</source>
        <translation>Volver a sobreescritos</translation>
    </message>
    <message>
        <source>Back to override overview.</source>
        <translation>Volver a vista general de sobreescritura.</translation>
    </message>
    <message>
        <source>The template can not be edited.</source>
        <translation>No se puede editar la plantilla.</translation>
    </message>
    <message>
        <source>The web server does not have write access to the requested template.</source>
        <translation>El servidor web no tiene acceso de escritura a la plantilla solicitada.</translation>
    </message>
    <message>
        <source>The web server does not have read access to the requested template.</source>
        <translation>El servidor web no tiene acceso de lectura a la plantilla solicitada.</translation>
    </message>
    <message>
        <source>The requested template does not exist or is not being used as an override.</source>
        <translation>La plantilla solicitada no existe o no está siendo usada como una plantilla sobreescrita.</translation>
    </message>
    <message>
        <source>Edit &lt;%template_name&gt; [Template]</source>
        <translation>Editar &lt;%template_name&gt; [Plantilla]</translation>
    </message>
    <message>
        <source>Requested template</source>
        <translation>Plantilla solicitada</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Overrides template</source>
        <translation>Plantillas sobreescritas</translation>
    </message>
    <message>
        <source>Open as read only</source>
        <translation>Abrir en modo lectura</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templatelist</name>
    <message>
        <source>Complete template list</source>
        <translation>Lista completa de plantillas</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Plantilla</translation>
    </message>
    <message>
        <source>Design resource</source>
        <translation>Recurso de diseño</translation>
    </message>
    <message>
        <source>Manage overrides for template.</source>
        <translation>Gestionar sobreescrituras de plantilla.</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Las plantillas más comunes</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/templateview</name>
    <message>
        <source>The overrides could not be removed.</source>
        <translation>Las sobreescrituras no se pudieron eliminar.</translation>
    </message>
    <message>
        <source>The following files and override rules could not be removed because of insufficient file permissions</source>
        <translation>Los siguientes archivos y reglas de sobreescritura no pudieron ser eliminadas porque no tienes permisos suficientes sobre los ficheros</translation>
    </message>
    <message>
        <source>The override.ini file could not be modified because of insufficient permissions.</source>
        <translation>El archivo override.ini no se pudo modificar porque no tienes permisos suficientes.</translation>
    </message>
    <message>
        <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
        <translation>Sobreescrituras de la plantilla &lt;%template_name&gt; en el acceso a sitio &lt;%current_siteaccess&gt; [%override_count]</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Recurso de plantilla por defecto</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Condiciones de coincidencia</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>No file matched</source>
        <translation>Ningún archivo coincidió</translation>
    </message>
    <message>
        <source>Edit override template.</source>
        <translation>Editar plantilla sobreescrita.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected template overrides.</source>
        <translation>Eliminar las plantillas sobreescritas seleccionadas.</translation>
    </message>
    <message>
        <source>New override</source>
        <translation>Nueva sobreescritura</translation>
    </message>
    <message>
        <source>Create a new template override.</source>
        <translation>Crear una nueva plantilla sobreescrita.</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Actualizar prioridades</translation>
    </message>
</context>
<context>
    <name>design/admin/visual/toolbar</name>
    <message>
        <source>Tool List for &lt;Toolbar_%toolbar_position&gt;</source>
        <translation>Lista de herramientas para &lt;Toolbar_%toolbar_position&gt;</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>There are currently no tools in this toolbar</source>
        <translation>No hay ninguna herramienta en esta barra de herramientas</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Actualizar prioridades</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Añadir herramienta</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified the parameters above.</source>
        <translation>Pulsa este botón para guardar los cambios si has modificado los parámetros de arriba.</translation>
    </message>
    <message>
        <source>Back to toolbars</source>
        <translation>Volver a barras de herramientas</translation>
    </message>
    <message>
        <source>Go back to the toolbar list.</source>
        <translation>Volver a la lista de barras de herramientas.</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Gestión de la barra de herramientas</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Acceso al sitio (SiteAccess) actual</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Elegir acceso al sitio (SiteAccess)</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Available toolbars for the &lt;%siteaccess&gt; siteaccess</source>
        <translation>Barras de herramientas disponibles para el acceso al sitio &lt;%siteaccess&gt;</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/edit</name>
    <message>
        <source>Input did not validate</source>
        <translation>Los datos no se validaron</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Los datos se deben arreglar</translation>
    </message>
    <message>
        <source>Edit &lt;%workflow_name&gt; [Workflow]</source>
        <translation>Editar &lt;%workflow_name&gt; [Flujo de trabajo]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Move down</source>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <source>Move up</source>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <source>Description / comments</source>
        <translation>Descripción / comentarios</translation>
    </message>
    <message>
        <source>There are no events within this workflow.</source>
        <translation>No hay eventos en este flujo de trabajo.</translation>
    </message>
    <message>
        <source>Remove selected events</source>
        <translation>Eliminar los eventos seleccionados</translation>
    </message>
    <message>
        <source>Add event</source>
        <translation>Añadir evento</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/eventtype/edit</name>
    <message>
        <source>Affected sections</source>
        <translation>Secciones afectadas</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Todas las secciones</translation>
    </message>
    <message>
        <source>User who approves content</source>
        <translation>Usuario que aprueba el contenido</translation>
    </message>
    <message>
        <source>Excluded users and groups</source>
        <translation>Usuarios y grupos excluidos</translation>
    </message>
    <message>
        <source>All users and groups</source>
        <translation>Todos los usuarios y grupos</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Clases por las cuales se aplica el flujo de trabajo</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Todas las clases</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Usuarios sin ID de flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Flujo de trabajo para funcionar</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Actualizar atributos</translation>
    </message>
    <message>
        <source>Attribute</source>
        <translation>Atributo</translation>
    </message>
    <message>
        <source>Select attribute</source>
        <translation>Elegir atributo</translation>
    </message>
    <message>
        <source>Class/attribute combinations [%count]</source>
        <translation>Combinaciones de clase/atributo [%count]</translation>
    </message>
    <message>
        <source>There are no combinations</source>
        <translation>No hat combinaciones</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Modify the objects&apos; publishing dates</source>
        <translation>Modificar las fechas de publicación de los objetos</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/groupedit</name>
    <message>
        <source>Edit &lt;%group_name&gt; [Workflow group]</source>
        <translation>Editar &lt;%group_name&gt; [Grupo de flujo de trabajo]</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/grouplist</name>
    <message>
        <source>Workflow groups [%groups_count]</source>
        <translation>Grupos de flujo de trabajo [%groups_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Select workflow group for removal.</source>
        <translation>Elegir grupo de flujo de trabajo para eliminar.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit the &lt;%workflow_group_name&gt; workflow group.</source>
        <translation>Editar el grupo de flujo de trabajo &lt;%workflow_group_name&gt;.</translation>
    </message>
    <message>
        <source>There are no workflow groups.</source>
        <translation>No hay grupos de flujo de trabajo.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected workflow groups.</source>
        <translation>Eliminar los grupos de flujos de trabajo seleccionados.</translation>
    </message>
    <message>
        <source>New workflow group</source>
        <translation>Nuevo grupo de flujo de trabajo</translation>
    </message>
    <message>
        <source>Create a new workflow group.</source>
        <translation>Crear un nuevo grupo de flujo de trabajo.</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/view</name>
    <message>
        <source>Input did not validate</source>
        <translation>Los datos no se validaron</translation>
    </message>
    <message>
        <source>%workflow_name [Workflow]</source>
        <translation>%workflow_name [Flujo de trabajo]</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Member of groups [%group_count]</source>
        <translation>Miembro de grupos [%group_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>Grupo</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Añadir al grupo</translation>
    </message>
    <message>
        <source>No group</source>
        <translation>No hay grupo</translation>
    </message>
    <message>
        <source>Events [%event_count]</source>
        <translation>Eventos [%event_count]</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Información adicional</translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/workflowlist</name>
    <message>
        <source>%group_name [Workflow group]</source>
        <translation>%group_name [Grupo de flujo de trabajo]</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Edit this workflow group.</source>
        <translation>Editar este grupo de flujo de trabajo.</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove this workflow group.</source>
        <translation>Eliminar este grupo de flujo de trabajo.</translation>
    </message>
    <message>
        <source>Back to workflow groups.</source>
        <translation>Volver a grupos de flujo de trabajo.</translation>
    </message>
    <message>
        <source>Workflows [%workflow_count]</source>
        <translation>Flujos de trabajo [%workflow_count]</translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation>Invertir la selección.</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Select workflow for removal.</source>
        <translation>Elegir flujo de trabajo para eliminar.</translation>
    </message>
    <message>
        <source>Edit the &lt;%workflow_name&gt; workflow.</source>
        <translation>Editar el flujo de trabajo &lt;%workflow_name&gt;.</translation>
    </message>
    <message>
        <source>There are no workflows in this group.</source>
        <translation>No hay flujos de trabajao en este grupo.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected workflows.</source>
        <translation>Eliminar los flujos de trabajo seleccionados.</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Nuevo flujo de trabajo</translation>
    </message>
    <message>
        <source>Create a new workflow.</source>
        <translation>Crear un nuevo flujo de trabajo.</translation>
    </message>
</context>
<context>
    <name>design/base</name>
    <message>
        <source>Back to poll</source>
        <translation>Volver a la encuesta</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Asunto</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Notifícame las actualizaciones</translation>
    </message>
    <message>
        <source>Sticky</source>
        <translation>Colgado (Sticky)</translation>
    </message>
    <message>
        <source>Create new weblog</source>
        <translation>Crear un nuevo weblog</translation>
    </message>
    <message>
        <source>Read more...</source>
        <translation>Leer más...</translation>
    </message>
    <message>
        <source>Contact information</source>
        <translation>Información de contacto</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Información adicional</translation>
    </message>
    <message>
        <source>Latest from:</source>
        <translation>Último de:</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Avisa a un amigo</translation>
    </message>
    <message>
        <source>Download PDF</source>
        <translation>Descargar PDF</translation>
    </message>
    <message>
        <source>Download PDF version of this page</source>
        <translation>Descargar una versión en PDF de esta página</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <source>New Comment</source>
        <translation>Nuevo comentario</translation>
    </message>
    <message>
        <source>You are not allowed to create comments.</source>
        <translation>No tienes permisos para crear comentarios.</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Contactos</translation>
    </message>
    <message>
        <source>Your E-mail address</source>
        <translation>Tu dirección de e-mail</translation>
    </message>
    <message>
        <source>Send form</source>
        <translation>Formulario de envio</translation>
    </message>
    <message>
        <source>New topic</source>
        <translation>Nuevo asunto</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Mantenme informado</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation>Tienes que estar conectado para acceder a los foros. Lo puedes hacer %login_link_start%aquí%login_link_end%</translation>
    </message>
    <message>
        <source>Topic</source>
        <translation>Asunto</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Respuestas</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Última respuesta</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Message preview</source>
        <translation>Previsualización del mensaje</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <source>Moderated by:</source>
        <translation>Moderado por:</translation>
    </message>
    <message>
        <source>Previous topic</source>
        <translation>Asunto anteriór</translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation>Asunto siguiente</translation>
    </message>
    <message>
        <source>New reply</source>
        <translation>Nueva respuesta</translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so</source>
        <translation>Tienes que estar conectado para tener acceso a los foros. Puedes hacerlo</translation>
    </message>
    <message>
        <source>here</source>
        <translation>aquí</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Localización</translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation>Moderado por</translation>
    </message>
    <message>
        <source>View as slideshow</source>
        <translation>Ver comó &quot;slideshow&quot;</translation>
    </message>
    <message>
        <source>Previous image</source>
        <translation>Imagen anteriór</translation>
    </message>
    <message>
        <source>Next image</source>
        <translation>Imagen siguiente</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Añadir a la cesta</translation>
    </message>
    <message>
        <source>Download this product sheet as PDF</source>
        <translation>Descargar una versión PDF de la descripción del producto</translation>
    </message>
    <message>
        <source>Product reviews</source>
        <translation>Analisis del producto</translation>
    </message>
    <message>
        <source>New review</source>
        <translation>Nuevo analisis</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Las personas que han comprado esto también han comprado</translation>
    </message>
    <message>
        <source>Previous entry</source>
        <translation>Entrada anteriór</translation>
    </message>
    <message>
        <source>Next entry</source>
        <translation>Entrada siguiente</translation>
    </message>
    <message>
        <source>New comment</source>
        <translation>Nuevo comentario</translation>
    </message>
    <message>
        <source>More...</source>
        <translation>Más...</translation>
    </message>
    <message>
        <source>View flash</source>
        <translation>Ver flash</translation>
    </message>
    <message>
        <source>View list</source>
        <translation>Lista de vista</translation>
    </message>
    <message>
        <source>Number of Topics:</source>
        <translation>Número de temas:</translation>
    </message>
    <message>
        <source>Number of Posts:</source>
        <translation>Número de envíos:</translation>
    </message>
    <message>
        <source>Enter forum</source>
        <translation>Entrar en el foro</translation>
    </message>
    <message>
        <source>Enter gallery</source>
        <translation>Entra en la galería</translation>
    </message>
    <message>
        <source>Vote</source>
        <translation>Voto</translation>
    </message>
    <message>
        <source>More information</source>
        <translation>Más información</translation>
    </message>
    <message>
        <source>View movie</source>
        <translation>Ver la video</translation>
    </message>
    <message>
        <source>in</source>
        <translation>En</translation>
    </message>
    <message>
        <source>View comments</source>
        <translation>Ver comentarios</translation>
    </message>
    <message>
        <source>Powered by %linkStartTag eZ publish&amp;reg;&amp;trade; open source content management system %linkEndTag and development framework.</source>
        <translation>Hecho con %linkStartTag eZ publish&amp;reg;&amp;trade; Sistema de gestión de contenido open source %linkEndTag y framework de desarrollo.</translation>
    </message>
    <message>
        <source>Top menu</source>
        <translation>Menu más alto</translation>
    </message>
    <message>
        <source>Sub menu</source>
        <translation>Submenu</translation>
    </message>
    <message>
        <source>Left menu</source>
        <translation>Menu de la izquierda</translation>
    </message>
    <message>
        <source>Left sub menu</source>
        <translation>Submenu de la izquierda</translation>
    </message>
    <message>
        <source>Powered by %linkStartTag eZ publish&amp;reg; open source content management system %linkEndTag and development framework.</source>
        <translation>Hecho con %linkStartTag eZ publish&amp;reg; Sistema de gestión de contenido open source %linkEndTag y framework de desarrollo.</translation>
    </message>
    <message>
        <source>Store quantities</source>
        <translation>Cantidades de la tienda</translation>
    </message>
    <message>
        <source>Details...</source>
        <translation>Detalles...</translation>
    </message>
</context>
<context>
    <name>design/base/shop</name>
    <message>
        <source>Quantity</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Precio</translation>
    </message>
    <message>
        <source>Total Price</source>
        <translation>Precio total</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation>Subtotal con IVA:</translation>
    </message>
</context>
<context>
    <name>design/content/datatype/edit</name>
    <message>
        <source>There are no rows in the matrix.</source>
        <translation>No hay ninguna fila en la matriz.</translation>
    </message>
</context>
<context>
    <name>design/intranet/layout</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
</context>
<context>
    <name>design/news/article</name>
    <message>
        <source>Author: </source>
        <translation>Autor:</translation>
    </message>
</context>
<context>
    <name>design/standar/content/datatype</name>
    <message>
        <source>There are no authors in the author list.</source>
        <translation>No hay ningún autor en la lista de autores.</translation>
    </message>
</context>
<context>
    <name>design/standard/class</name>
    <message>
        <source>Class is locked</source>
        <translation>La clase está bloqueada</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Inténtalo de nuevo</translation>
    </message>
</context>
<context>
    <name>design/standard/class/classlist</name>
    <message>
        <source>No classes in </source>
        <translation>No hay clases en</translation>
    </message>
    <message>
        <source>Click on the &apos;New&apos; button to create a class.</source>
        <translation>Pulsa el botón &quot;Nuevo&quot; para crear una clase.</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Clases incluidas en</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Object count</source>
        <translation>Número de objetos</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Nueva clase</translation>
    </message>
    <message>
        <source>Last modified classes</source>
        <translation>Últimas clases modificadas</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Empty</source>
        <translation>Vacío</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Hora actual</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Elección múltiple</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>Quick Time</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows media player</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Precio con IVA </translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Precio sin IVA</translation>
    </message>
    <message>
        <source>Max file size</source>
        <translation>Tamaño máximo del archivo</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Valor predeterminado</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Fecha actual</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Hora actual</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Valor mínimo del decimal</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Valor máximo del decimal</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Valor mínimo del entero</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Valor máximo del entero</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Tipo de reproductor media</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Nombre predeterminado</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Tipo de IVA</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Máxima longitud de la cadena</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Número de líneas preferido</translation>
    </message>
    <message>
        <source>Default number of rows</source>
        <translation>Número de líneas predeterminado</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Allowed classes</source>
        <translation>Clases permitidas</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Nueva opción</translation>
    </message>
    <message>
        <source>Pretext</source>
        <translation>Texto previo</translation>
    </message>
    <message>
        <source>Posttext</source>
        <translation>Texto posterior</translation>
    </message>
    <message>
        <source>Digits</source>
        <translation>Dígitos</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Valor de comienzo</translation>
    </message>
    <message>
        <source>Ini file</source>
        <translation>Archivo Ini</translation>
    </message>
    <message>
        <source>Ini Section</source>
        <translation>Sección Ini</translation>
    </message>
    <message>
        <source>Ini Parameter</source>
        <translation>Parámetro Ini</translation>
    </message>
    <message>
        <source>Ini file location</source>
        <translation>Ubicación del archivo Ini</translation>
    </message>
    <message>
        <source>Ini setting type</source>
        <translation>Tipo de configuración Ini</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Enable/Disable</source>
        <translation>Activasr/desactivar</translation>
    </message>
    <message>
        <source>True/False</source>
        <translation>Verdadero/Falso</translation>
    </message>
    <message>
        <source>Integer</source>
        <translation>Número entero</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Decimal</translation>
    </message>
    <message>
        <source>Array</source>
        <translation>Tabla</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Create or browse objects</source>
        <translation>Crear o explorar objetos</translation>
    </message>
    <message>
        <source>New and existing objects</source>
        <translation>Objetos nuevos y existentes</translation>
    </message>
    <message>
        <source>Only new objects</source>
        <translation>Sólo objetos nuevos</translation>
    </message>
    <message>
        <source>Only existing objects</source>
        <translation>Sólo objetos existentes</translation>
    </message>
    <message>
        <source>Package Type</source>
        <translation>Tipo de paquete</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Comprobado</translation>
    </message>
    <message>
        <source>Unchecked</source>
        <translation>No comprobado</translation>
    </message>
    <message>
        <source>Single choice</source>
        <translation>Opción sencilla</translation>
    </message>
    <message>
        <source>Warning, the ini file settings value and object value does not match.</source>
        <translation>Atención: el valor de la configuración del archivo Ini y el valor del objeto no coinciden.</translation>
    </message>
    <message>
        <source>The ini file has probably been modified manually since last time.</source>
        <translation>Probablemente, el archivo haya sido modificado manualmente desde la última vez.</translation>
    </message>
    <message>
        <source>Ini File : </source>
        <translation>Archivo Ini:</translation>
    </message>
    <message>
        <source>Ini Value: </source>
        <translation>Valor Ini:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Activado</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Select which classes user can create</source>
        <translation>Elige qué clases puede crear el usuario</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Make empty array</source>
        <translation>Hacer una tabla vacía</translation>
    </message>
    <message>
        <source>Adjusted current datetime</source>
        <translation>Hora actual actualizado</translation>
    </message>
    <message>
        <source>Selection method</source>
        <translation>Metodo de selección</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>Dropdown list</source>
        <translation>Lista desplegable</translation>
    </message>
    <message>
        <source>Dropdown tree</source>
        <translation>Arbol despleguable</translation>
    </message>
    <message>
        <source>Remove selection</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Allow fuzzy match</source>
        <translation>Permitir correspondencia borrosa</translation>
    </message>
    <message>
        <source>Current date and time adjusted by</source>
        <translation>Fecha y hora actual actualizada por</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Año</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mes</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Día</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minuto</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <source>Checkboxes / radiobuttons</source>
        <translation>Casillas de verificación / botones radio</translation>
    </message>
    <message>
        <source>Dropdown menu / multi menu</source>
        <translation>Menú desplegable / multi menú</translation>
    </message>
    <message>
        <source>Elements</source>
        <translation>Elementos</translation>
    </message>
    <message>
        <source>Element</source>
        <translation>Elemento</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>There are no elements in the list.</source>
        <translation>No hay ningún elemento en la lista.</translation>
    </message>
    <message>
        <source>Remove selected elements.</source>
        <translation>Eliminar los elementos seleccionados.</translation>
    </message>
    <message>
        <source>New element</source>
        <translation>Nuevo elemento</translation>
    </message>
    <message>
        <source>Add a new enum element.</source>
        <translation>Añadir un nuevo elemento de enumeración.</translation>
    </message>
    <message>
        <source>Columns</source>
        <translation>Columnas</translation>
    </message>
    <message>
        <source>Matrix column</source>
        <translation>Columna</translation>
    </message>
    <message>
        <source>The matrix does not have any columns.</source>
        <translation>La matriz no tiene ninguna columna.</translation>
    </message>
    <message>
        <source>Remove selected columns.</source>
        <translation>Eliminar las columnas seleccionadas.</translation>
    </message>
    <message>
        <source>New column</source>
        <translation>Nueva columna</translation>
    </message>
    <message>
        <source>Add a new column.</source>
        <translation>Añadir una nueva columna.</translation>
    </message>
    <message>
        <source>Default selection item</source>
        <translation>Elemento de selección predeterminado</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Unknown section</source>
        <translation>Sección desconocida</translation>
    </message>
    <message>
        <source>No item has been selected.</source>
        <translation>No has seleccionado ningún elemento.</translation>
    </message>
    <message>
        <source>Select item</source>
        <translation>Elegir elemento</translation>
    </message>
    <message>
        <source>Default location for objects</source>
        <translation>Ubicación predeterminada para los objetos</translation>
    </message>
    <message>
        <source>New objects will not be placed in the content tree.</source>
        <translation>Los objetos nuevos no se colocarán en el árbol de contenido.</translation>
    </message>
    <message>
        <source>Remove location</source>
        <translation>Eliminar ubicación</translation>
    </message>
    <message>
        <source>Select location</source>
        <translation>Elegir ubicación</translation>
    </message>
    <message>
        <source>Package type</source>
        <translation>Tipo de paquete</translation>
    </message>
    <message>
        <source>View mode</source>
        <translation>Tipo de vista</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Caja de selección</translation>
    </message>
    <message>
        <source>Icon view</source>
        <translation>Ver icono</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opción</translation>
    </message>
    <message>
        <source>Select option for removal.</source>
        <translation>Elegir opción para eliminar.</translation>
    </message>
    <message>
        <source>There are no options.</source>
        <translation>No hay opciones.</translation>
    </message>
    <message>
        <source>Remove selected options.</source>
        <translation>Eliminar las opciones seleccionadas.</translation>
    </message>
    <message>
        <source>Add a new option.</source>
        <translation>Añadir una nueva opción.</translation>
    </message>
    <message>
        <source>characters</source>
        <translation>carácteres</translation>
    </message>
    <message>
        <source>year(s)</source>
        <translation>año(s)</translation>
    </message>
    <message>
        <source>month(s)</source>
        <translation>mes(es)</translation>
    </message>
    <message>
        <source>day(s)</source>
        <translation>día(s)</translation>
    </message>
    <message>
        <source>hour(s)</source>
        <translation>hora(s)</translation>
    </message>
    <message>
        <source>minute(s)</source>
        <translation>minuto(s)</translation>
    </message>
    <message>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <source>Dropdown menu / multiselect</source>
        <translation>Menú desplegable / multi-selección</translation>
    </message>
    <message>
        <source>Radiobuttons / checkboxes</source>
        <translation>Botones radio / Casillas de verificación</translation>
    </message>
    <message>
        <source>Current value</source>
        <translation>Valor actual</translation>
    </message>
    <message>
        <source>Drop-down list</source>
        <translation>Lista desplegable</translation>
    </message>
    <message>
        <source>Drop-down tree</source>
        <translation>Árbol desplegable</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>View Mode</source>
        <translation>Tipo de vista</translation>
    </message>
    <message>
        <source>combobox</source>
        <translation>Caja de selección</translation>
    </message>
    <message>
        <source>icon view</source>
        <translation>Ver icono</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype </name>
    <message>
        <source>Max file size</source>
        <translation>Tamaño máximo del archivo</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Input did not validate</source>
        <translation>La entrada no fue validada</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>La entrada ha sido almacenada con éxito</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atributos</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Obligatorio</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Incluye en la búsqueda</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Recolector de información</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Bajar</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Descartar cambios</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>¿Estás seguro de que quieres eliminar estas clases?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>¡Eliminando la clase %1 eliminarás %2!</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>¿Estas seguro de que quieres eliminar estos grupos de clases?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>¡Eliminando el grupo de clases %1 eliminarás las clases %2!</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Patrón de nombre de objeto</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Miembro de los grupos</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Añadir al grupo</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Eliminar de los grupos</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Tipo de dato</translation>
    </message>
    <message>
        <source>Editing class - %1</source>
        <translation>Editando clase - %1</translation>
    </message>
    <message>
        <source>Editing class group - %1</source>
        <translation>Editando grupo de clase - %1</translation>
    </message>
    <message>
        <source>Last modified by %username on %time</source>
        <translation>Última modificación por %username el %time</translation>
    </message>
    <message>
        <source>Disable translation</source>
        <translation>Descativar la traducción</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Modificado por %username el %time</translation>
    </message>
    <message>
        <source>The class should have at least one attribute and nonempty &apos;Name&apos; attribute</source>
        <translation>La clase debería tener al menos un atributo y el atributo &apos;Nombre&apos; puesto</translation>
    </message>
    <message>
        <source>Use this menu to select the type of attribute you wish to create. Click the &quot;add attribute&quot; button. The attribute will be appended to the bottom of the list of attributes.</source>
        <translation>Usa este menú para elegir el tipo de atributo que deseas crear. Pulsa el botón &quot;añadir atributo&quot;. El atributo será añadido al final de la lista de atributos.</translation>
    </message>
    <message>
        <source>Is Container Class</source>
        <translation>Es una Clase Contenedora</translation>
    </message>
    <message>
        <source>The class %1 was already removed from the group but still exists in others.</source>
        <translation>La clase %1 ya se había eliminado del grupo pero aún existe en otros grupos.</translation>
    </message>
    <message>
        <source>The classes %1 were already removed from the group but still exist in others.</source>
        <translation>Las clases %1 ya se habían eliminado del grupo pero aún existen en otros grupos.</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Class groups</source>
        <translation>Grupos de clases</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Nuevo grupo</translation>
    </message>
    <message>
        <source>Last modified classes</source>
        <translation>Últimas clases modificadas</translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Menú de configuración</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Nueva clase</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Object count</source>
        <translation>Número de objetos</translation>
    </message>
    <message>
        <source>Class - %1</source>
        <translation>Clase - %1</translation>
    </message>
    <message>
        <source>Last modified by %username on %time</source>
        <translation>Última modificación por %username el %time</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Patrón de nombre de objeto</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Contenedor</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Miembro de los grupos</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atributos</translation>
    </message>
    <message>
        <source>Is required</source>
        <translation>Es requerido</translation>
    </message>
    <message>
        <source>Is not required</source>
        <translation>No es requerido</translation>
    </message>
    <message>
        <source>Is searchable</source>
        <translation>Es buscable</translation>
    </message>
    <message>
        <source>Is not searchable</source>
        <translation>No es buscable</translation>
    </message>
    <message>
        <source>Collects information</source>
        <translation>Recoge información</translation>
    </message>
    <message>
        <source>Does not collect information</source>
        <translation>No recoge información</translation>
    </message>
    <message>
        <source>Translation is disabled</source>
        <translation>La traducción está desactivada</translation>
    </message>
    <message>
        <source>Translation is enabled</source>
        <translation>La traducción está activada</translation>
    </message>
    <message>
        <source>Override templates</source>
        <translation>Plantillas sobrescritas</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Sobreescribir</translation>
    </message>
    <message>
        <source>Source template</source>
        <translation>Plantilla fuente</translation>
    </message>
    <message>
        <source>Override template</source>
        <translation>Plantilla sobreescrita</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Lista de grupos para &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>No hay elementos en el grupo.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Grupos</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Aprobación</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 espera aprobación del editor</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 fue aprobado para publicación</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 no fue aprobado para publicación</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 espera tu aprobación</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Asunto</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Leído</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>No leído</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactivo</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Enviado %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>No hay nuevos datos que tratar.</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>[more]</source>
        <translation>[más]</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Aprobación</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>El objeto de contenido %1 espera aprobación antes de poder ser publicado.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>¿Si quieres puedes enviar un mensaje a la persona que tiene que dar su aprobación?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>El objeto de contenido %1 necesita tu aprobación antes de poder ser publicado.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>¿Apruebas que el objeto de contenido sea publicado?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>El objeto de contenido %1 fue aprobado y será publicado cuando el flujo de trabajo de publicación continúe.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Añadir comentario</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Aprobar</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Denegar</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Participantes</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Mensajes</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Editar el objeto</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>El objeto de contenido %1 no fue aceptado pero está disponible de nuevo como borrador.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>El objeto de contenido %1 no fue aceptado pero estará disponible para el autor como borrador.</translation>
    </message>
    <message>
        <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
        <translation>[%sitename] la aprobación del &quot;%objectname&quot; requiere tu atención</translation>
    </message>
    <message>
        <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
        <translation>[%sitename] &quot;%objectname&quot; requiere aprobación</translation>
    </message>
    <message>
        <source>You may re-edit the draft and publish it, in which case an approval is required again.</source>
        <translation>Puedes volver a editar el borrador y publicarlo, en este caso se vuelve a requerir aprobación.</translation>
    </message>
    <message>
        <source>The author can re-edit the draft and publish it again, in which a new approval item is made.</source>
        <translation>El autor puede volver a editar el borrador y publicarlo otra vez, en ese caso el autor ha de esperar aprobación.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation>Este e-mail es para informarte que &quot;%objectname&quot; está pendiente de tu aprobación para %sitename.
El proceso de publicación está a la espera y has de decidir si continuar o no.
La aprobación se puede ver usando la URL  de abajo.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation>Este e-mail es para informarte que &quot;%objectname&quot; está pendiente de aprobación para %sitename antes de ser publicado.
Si deseas enviar comentarios a la persona encargada de aprobar el contenido o ver el estado usa la URL de abajo.</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>¿Estás seguro de que quieres eliminar esta traducción?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Cambiar traducción para contenido</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Escoje una de las traducciones de la lista para cambiarla o insertar una nueva en los campos de texto.</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Nueva traducción para contenido</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Escoje una de las traducciones de la lista para añadirla o insertar una nueva en los campos de texto.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Nueva</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Nombre de la traducción</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Locale</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Cambiar</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Traducción de contenidos</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Debajo encontrarás una serie de traducciones activas en las que el objeto de contenido puede ser traducido.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Removing &apos;%1&apos; will remove the translation itself and %2 translated versions!</source>
        <translation>¡Eliminando &apos;%1&apos; eliminarás la propia traducción y %2 versiones traducidas!</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>Traductor de URL</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
</context>
<context>
    <name>design/standard/content/browse</name>
    <message>
        <source>Create new</source>
        <translation>Crear nuevo</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Para seleccionar objetos, elige la opción más adecuada y haz clic en el botón &quot;Elegir&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Para seleccionar un objeto que es un hijo de uno de los objetos visualizados, pulsa sobre el nombre del objeto y obtendrás la lista de sus hijos.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>Subir un nivel</translation>
    </message>
    <message>
        <source>Top levels</source>
        <translation>Niveles más altos</translation>
    </message>
    <message>
        <source>Switch top levels by clicking one of these items.</source>
        <translation>Cambia los niveles más altos clicando uno de estos elementos.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Favoritos</translation>
    </message>
    <message>
        <source>Bookmark items are managed using %bookmarkname in the %personalname part.</source>
        <translation>Los elementos de favoritos se gestionan usando %bookmarkname en la parte %personalname.</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Mis favoritos</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personal</translation>
    </message>
    <message>
        <source>Recent items</source>
        <translation>Elementos recientes</translation>
    </message>
    <message>
        <source>Recent items are added on publishing.</source>
        <translation>Los elementos recientes son añadidos cuando publicas.</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copy all versions</source>
        <translation>Copiar todas las versiones</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Copiar la versión actual</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Copying %1</source>
        <translation>Copiando %1</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>El total de versiones es %1, y la versión actual es %2.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Crear nuevo</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>cancelar</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Remove Selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Eliminar imagen</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Alta</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Mejor</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Baja</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Engrandecimiento automático</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Empequeñecimiento automático</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Arranque automático</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Bucle</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Controlador</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Ventana de imagen</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Panel de control</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>Panel de información del volumen</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Panel de información</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Buscar objeto</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Precio:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Tu precio:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Ahorras:
</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Información de la cuenta del usuario</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nombre del fichero</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Año</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mes</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Día</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minuto</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Texto alternativo de imagen</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Anchura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Calidad</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Controles</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>No hay relación</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Valor de comienzo</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Valor de parada</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Valor de paso</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ID de usuari</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Confirmar contraseña</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Precio</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Eliminar objeto</translation>
    </message>
    <message>
        <source>New row</source>
        <translation>Nueva línea</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>No media file is available.</source>
        <translation>Ningun archivo de media disponible.</translation>
    </message>
    <message>
        <source>The file could not be found.</source>
        <translation>No se encontró el archivo.</translation>
    </message>
    <message>
        <source>There are no options.</source>
        <translation>No hay opciones.</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Select author row for removal.</source>
        <translation>Elegir fila de autor para eliminar.</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Remove selected rows from the author list.</source>
        <translation>Eliminar las filas seleccionadas de la lista de autores.</translation>
    </message>
    <message>
        <source>Add author</source>
        <translation>Añadir autor</translation>
    </message>
    <message>
        <source>Add a new row to the author list.</source>
        <translation>Añadir una nueva fila en la lista de autores.</translation>
    </message>
    <message>
        <source>Current file</source>
        <translation>Archivo actual</translation>
    </message>
    <message>
        <source>MIME type</source>
        <translation>Tipo MIME</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>There is no file.</source>
        <translation>No hay archivo.</translation>
    </message>
    <message>
        <source>Remove the file from this draft.</source>
        <translation>Eliminar el archivo de este borrador.</translation>
    </message>
    <message>
        <source>New file for upload</source>
        <translation>Nuevo archivo para subir</translation>
    </message>
    <message>
        <source>Current image</source>
        <translation>Imagen actual</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>There is no image file.</source>
        <translation>No hay archivo de imagen.</translation>
    </message>
    <message>
        <source>New image file for upload</source>
        <translation>Nuevo archivo de imagen para subir</translation>
    </message>
    <message>
        <source>Select row for removal.</source>
        <translation>Elegir fila para eliminar.</translation>
    </message>
    <message>
        <source>Remove selected rows from the matrix.</source>
        <translation>Eliminar las filas seleccionadas de la matriz.</translation>
    </message>
    <message>
        <source>Number of rows to add.</source>
        <translation>Número de filas a añadir.</translation>
    </message>
    <message>
        <source>Add rows</source>
        <translation>Añadir filas</translation>
    </message>
    <message>
        <source>Add new rows to the matrix.</source>
        <translation>Añadir nuevas filas a la matriz.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>Quick Time</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Reproductor Windows media</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Select multioption for removal.</source>
        <translation>Elegir multiopción para eliminar.</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opción</translation>
    </message>
    <message>
        <source>Additional price</source>
        <translation>Precio adicional</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <source>Use the radio buttons to set the default option.</source>
        <translation>Usar los botones radio para fijar la opción por defecto.</translation>
    </message>
    <message>
        <source>Remove selected options.</source>
        <translation>Eliminar las opciones seleccionadas.</translation>
    </message>
    <message>
        <source>Add option</source>
        <translation>Añadir opción</translation>
    </message>
    <message>
        <source>Add a new option.</source>
        <translation>Añadir una nueva opción.</translation>
    </message>
    <message>
        <source>There are no multioptions.</source>
        <translation>No hay multiopciones.</translation>
    </message>
    <message>
        <source>Remove selected multioptions.</source>
        <translation>Eliminar las multiopciones seleccionadas.</translation>
    </message>
    <message>
        <source>Add multioption</source>
        <translation>Añadir multiopción</translation>
    </message>
    <message>
        <source>Add a new multioption.</source>
        <translation>Añadir una nueva multiopción.</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>There are no related objects.</source>
        <translation>No hay objetos relacionados.</translation>
    </message>
    <message>
        <source>Edit selected</source>
        <translation>Editar seleccionado</translation>
    </message>
    <message>
        <source>Add existing objects</source>
        <translation>Añadir objetos existentes</translation>
    </message>
    <message>
        <source>Create new object</source>
        <translation>Crear nuevo objeto</translation>
    </message>
    <message>
        <source>Select option for removal.</source>
        <translation>Elegir opción para eliminar.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Your price</source>
        <translation>Tu precio</translation>
    </message>
    <message>
        <source>You save</source>
        <translation>Ahorras</translation>
    </message>
    <message>
        <source>Option set name</source>
        <translation>Nombre de la lista de opciones</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype </name>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype/</name>
    <message>
        <source>Configure user account settings</source>
        <translation>Configurar las preferencias de la cuenta de usuario</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>The following information was collected:</source>
        <translation>La información siguiente ha sido recogida:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Enviar para su publicación</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Localización</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Ordenado por</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Orden</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Profundidad</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Identificador de clase</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Nombre de clase</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Información del objeto</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Aún no publicado</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Actual</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Gestionar</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objetos relacionados</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>La entrada no fue validada</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>La entrada fue almacenada con éxito</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Información recogida de %1</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Almacenar borrador</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Añadir localizaciones</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versiones</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Editando</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (No hay información de &quot;locale&quot; disponible)</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>La validación ha fallado</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>La localización no ha sido validada</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Editar %1 - %2</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nuevo borrador</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>Envía</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Feedback from %1</source>
        <translation>Feedback de %1</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft %versionname?</source>
        <translation>¿Estas seguro que quieres descartar el borrador % versionname?</translation>
    </message>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>La versión publicada actualmente es %version y fue publicada el %time.</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>La última modificación fue el %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>El objeto es propiedad de %owner.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>El objeto ya está editado por alguien, además de ti.
Puedes editar uno de tus borradores o crear uno nuevo.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Este objeto ya está siendo editado por ti.
Puedes editar uno de tus borradores o crear uno nuevo.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
        <translation>Este objeto ya está siendo editado por algún otro.
Ponte en contacto con esta persona por el borrador o crea uno nuevo para editarlo personalmente. </translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Borradores actuales</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propietario</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Input was partially stored</source>
        <translation>La entrada se ha almacenado parcialmente</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publicar</translation>
    </message>
    <message>
        <source>Last Modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>The following feedback was collected</source>
        <translation>Los siguientes comentarios han sido recogidos</translation>
    </message>
    <message>
        <source>The following information was collected</source>
        <translation>La información siguiente ha sido recogida</translation>
    </message>
</context>
<context>
    <name>design/standard/content/ezoption</name>
    <message>
        <source>No value chosen</source>
        <translation>No se ha escogido ningún valor</translation>
    </message>
</context>
<context>
    <name>design/standard/content/feedback</name>
    <message>
        <source>Feedback for %feedbackname</source>
        <translation>Feedback para %feedbackname</translation>
    </message>
    <message>
        <source>Thanks for your feedback, the following information was collected.</source>
        <translation>Gracias por tu feedback. Se ha almacenado la siguiente información.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Volver al sitio</translation>
    </message>
    <message>
        <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
        <translation>Ya has enviado datos a este feedback. Los datos que se han enviado previamente son los siguientes.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Formulario %formname</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Volver al sitio</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Ya has enviado datos a este formulario. Los datos que se han enviado previamente son los siguientes.</translation>
    </message>
    <message>
        <source>Collected information</source>
        <translation>Información recogida</translation>
    </message>
</context>
<context>
    <name>design/standard/content/newcontent</name>
    <message>
        <source>New content since last visit</source>
        <translation>Nuevo contenido desde la última visita</translation>
    </message>
    <message>
        <source>Your last visit to this site was</source>
        <translation>Tu última visita a esta página fue</translation>
    </message>
    <message>
        <source>There is no new content since your last visit.</source>
        <translation>No hay contenido nuevo desde su última visita.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/pdf</name>
    <message>
        <source>eZ publish PDF export</source>
        <translation>Exportación PDF de eZpublish</translation>
    </message>
    <message>
        <source>#page of #total</source>
        <translation>#page de #total</translation>
    </message>
    <message>
        <source>#level1 - #level2</source>
        <translation>#level1 - #level2</translation>
    </message>
    <message>
        <source>#levelIndex1:#levelIndex2</source>
        <translation>#levelIndex1:#levelIndex2</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <source>Versionview not supported in PDF yet</source>
        <translation>La vista de versiones (versionview) no está aún soportada en PDF</translation>
    </message>
</context>
<context>
    <name>design/standard/content/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Encuesta %pollname</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Resultados</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>%count votos totales</translation>
    </message>
    <message>
        <source>Poll results</source>
        <translation>Resultados de la encuesta</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Los usuarios anónimos no pueden votar en esta encuesta. Regístrate antes, por favor.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Ya has votado en esta encuesta.</translation>
    </message>
    <message>
        <source>Votes:</source>
        <translation>Votos:</translation>
    </message>
    <message>
        <source>%count votes</source>
        <translation>%count votos</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Búsqueda avanzada</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Cualquier clase</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Actualizar atributos</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Cualquier sección</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Cualquier momento</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Último día</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Última semana</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Último mes</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Últimos tres meses</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Último año</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Buscar todas las palabras</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Buscar la frase exacta</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Buscar con al menos una de las palabras</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Atributo de clase</translation>
    </message>
    <message>
        <source>In</source>
        <translation>En</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publicado</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>No se han encontrado resultados al buscar por &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>La búsqueda por &quot;%1&quot; devolvió %2 coincidencias</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Las siguientes palabras fueron excluidas de la búsqueda:</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Vista por página</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 elementos</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 elementos</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 elementos</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 elementos</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 elementos</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Para obtener más opciones intenta la %1búsqueda avanzada%2</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Trucos de búsqueda</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Comprobar la ortografía de las palabras clave.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Intenta cambiar algunas palabras clave. Por ejemplo: coche en lugar de coches.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Intenta palabras clave más generales.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>Menos palabras clave ofrecen más resultados. Intenta reducir las palabras clave hasta que obtengas un resultado.</translation>
    </message>
    <message>
        <source>Any attribute</source>
        <translation>Cualquier atributo</translation>
    </message>
    <message>
        <source>The following words were excluded from the search</source>
        <translation>Las siguientes palabras fueron excluidas de la búsqueda</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Avisa a un amigo</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>El mensaje ha sido enviado.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Clica aquí para volver a la página principal.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>El mensaje no ha sido enviado.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>El mensaje no ha sido enviado debido a un error desconocido. Por favor, notifica este fallo al administrador del sitio.</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Tu nombre</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Tu dirección de e-mail</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Nombre del destinatario</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>Dirección de e-mail del destinatario</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Asunto</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Este mensaje te ha sido enviado porque &quot;%1 &lt;%2&gt;&quot; pensó que podrías encontrar la página &quot;%3&quot; en %4 interesante.</translation>
    </message>
    <message>
        <source>Please correct the following errors</source>
        <translation>Por favor corrige los siguientes errores</translation>
    </message>
    <message>
        <source>This is the link to the page</source>
        <translation>Este es el enlace a la página</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;</source>
        <translation>Comentario de &quot;%1 &lt;%2&gt;&quot;</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>(No locale information available)</source>
        <translation>(No hay información de &quot;locale&quot; disponible)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traducir</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 entrada ha sido almacenada con éxito</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>&quot;Locale&quot;</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation>Traducir a</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Translating &apos;%1&apos;</source>
        <translation>Traduciendo &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Remove the following translations from &apos;%1&apos;</source>
        <translation>Eliminar las siguientes traducciones de &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Los datos no se validaron</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>La papelera está vacía</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Versión actual</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Recuperar</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Desseleccionar todo</translation>
    </message>
    <message>
        <source>Empty Trash</source>
        <translation>Vaciar papelera</translation>
    </message>
</context>
<context>
    <name>design/standard/content/upload</name>
    <message>
        <source>Upload file</source>
        <translation>Subir archivo</translation>
    </message>
    <message>
        <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.</source>
        <translation>Elige un archivo de tu máquina y pulsa el botón &quot;Subir&quot;. Se creará un objeto de acuerdo con el tipo de fichero subido y se guardará en la ubicación elegida.</translation>
    </message>
    <message>
        <source>Some errors occurred</source>
        <translation>Ocurrieron algunos errores</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Click here to upload a file. The file will be placed within the location that is specified using the dropdown menu on the top.</source>
        <translation>Pulsa aquí para subir el archivo. El archivo se guardará en la ubicación especificada en el menú desplegable de arriba.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Version not a draft</source>
        <translation>Esta versión no es un borrador</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Para editar esta versión, crea una copia de ella.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>La versión no es tuya</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Copiar y editar</translation>
    </message>
    <message>
        <source>Versions for: %1</source>
        <translation>Versiones para: %1</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>La versión %1 no fue creada por ti. Solo tus propios borradores pueden ser editados.</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Incapaz para crear una nueva versión</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>El límite de historial de versiones ha sido excedido y las versiones no archivadas pueden ser eliminadas por el sistema.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Puedes modificar tu configuración de historial de versiones en content.ini. También puedes eliminar borradores de versión o editar los borradores existentes.</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing any more, only drafts can be edited.</source>
        <translation>La versión %1 ya no está disponible para editar, sólo los borradores se pueden editar.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creado por</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mis borradores</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>No tienes borradores</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objetos relacionados</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Cambiar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publicar</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versiones</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Versión actual</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Diseño del sitio</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Mis favoritos</translation>
    </message>
    <message>
        <source>Add bookmarks</source>
        <translation>Añadir favoritos</translation>
    </message>
    <message>
        <source>You have no bookmarks</source>
        <translation>No tienes favoritos</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>Choose initial placement</source>
        <translation>Elige la ubicación inicial</translation>
    </message>
    <message>
        <source>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Por favor, elige dónde quieres ubicar el nuevo %classname.

Selecciona la ubicación y clica el botón %buttonname.
Es posible usar los elementos de reciente y de favoritos para una ubicación rápida.
Clica en los nombres de ubicación para cambiar la lista de navegación. </translation>
    </message>
    <message>
        <source>Choose items to bookmark</source>
        <translation>Elige el elemento para añadir a favoritos</translation>
    </message>
    <message>
        <source>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</source>
        <translation>Por favor, escoge los elementos que quieres añadir a tu lista de favoritos.

Selecciona tus elementos y clica el botón %buttonname.
Es posible también usar los elementos de reciente o favoritos para una selección rápida.
Clica en los nombres de los elementos para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Choose new placement</source>
        <translation>Elige una nueva ubicación</translation>
    </message>
    <message>
        <source>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</source>
        <translation>Por favor, elige una nueva ubicación para %name.
La anterior ubicación estaba en %placementname.

Selecciona la ubicación y clica el botón %buttonname.
Es posible también usar los elementos de reciente o favoritos para una selección rápida.
Clica en los nombres de las ubicaciones para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Choose placements</source>
        <translation>Elige ubicaciones</translation>
    </message>
    <message>
        <source>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Por favor, elige dónde quieres ubicar %name.
Selecciona tus ubicaciones y clica el botón %buttonname.
Es posible también usar los elementos de reciente o favoritos para una selección rápida.
Clica en los nombres de las ubicaciones para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Choose related objects</source>
        <translation>Elige objetos relacionados</translation>
    </message>
    <message>
        <source>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Por favor, elige los objetos que quieres relacionar con %name.

Selecciona tus objetos y clica el botón %buttonname.
Es posible también usar los elementos de reciente o favoritos para una selección rápida.
Clica en los nombres de los objetos para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Desseleccionar todo</translation>
    </message>
    <message>
        <source>Empty Draft</source>
        <translation>Borrador vacío</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Mi lista de tareas pendientes</translation>
    </message>
    <message>
        <source>Your pending list is empty</source>
        <translation>Tu lista de tareas pendientes está vacía</translation>
    </message>
    <message>
        <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</source>
        <translation>Estos son los objetos que tu has marcado. Haz clic en el objeto para verlo; si tienes los suficientes privilegios, puedes editarlo haciendo clic en el botón de edición.
Si queires añadir más objetos a esta lista, haz clic en el botón %emphasize_startAñade favorito%emphasize_stop.

Si borras algún objeto, sólo lo borrarás de la lista.</translation>
    </message>
    <message>
        <source>Choose node for default selection</source>
        <translation>Eligir el nudo para la selección por defecto</translation>
    </message>
    <message>
        <source>Please choose where you want to the default selection of objectrelation to start from.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Por favor, elige dónde quiere que comienza la selección de relación de objeto por defecto.

    Elige el sitio y haz click en el botón %buttonname.
    Es también posible de hacer servir los recientes y los favoritos.
    Haz click en el nombre de un sitio para cambiar el listado de navegación.</translation>
    </message>
    <message>
        <source>Collected info</source>
        <translation>Información recogida</translation>
    </message>
    <message>
        <source>Choose new location for %objectname</source>
        <translation>Elige nueva ubicación para %objectname</translation>
    </message>
    <message>
        <source>Please choose where you want to place %objectname.

    Select the new location and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Por favor elige dónde quieres guardar %objectname.

Elige una nueva ubicación y pulsa el botón %buttonname.
Es posible usar los elementos recientes y los favoritos para ubicar rápidamente.
Pulsa en los nombres de ubicación para cambiar la lista de navegación. </translation>
    </message>
    <message>
        <source>Choose the exchanging node for %objectname</source>
        <translation>Elige el nudo de intercambio para %objectname</translation>
    </message>
    <message>
        <source>Please choose which node you want to exchange %objectname with.

    Select the node and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Por favor elige qué nudo quieres intercambiar con  %objectname.

Elige un nudo y pulsa el botón %buttonname.
Es posible usar los elementos recientes y los favoritos para ubicar rápidamente.
Pulsa en los nombres de ubicación para cambiar la lista de navegación. </translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them any more.</source>
        <translation>Estos són los objetos con los que estás trabajando. Los borradores són tuyos y sólo tú puedes verlos.
     Puedes editar los borradores o eliminarlos si no los necesitas más.</translation>
    </message>
    <message>
        <source>Upload file</source>
        <translation>Subir archivo</translation>
    </message>
    <message>
        <source>Choose a file from your locale machine and click the &quot;Upload&quot; button. An object will be created according to file type and placed in your chosen location.
</source>
        <translation>Elige un archivo de tu máquina y pulsa el botón &quot;Subir&quot;. Se creará un objeto de acuerdo con el tipo de fichero subido y se guardará en la ubicación elegida.
</translation>
    </message>
</context>
<context>
    <name>design/standard/contet/datatype</name>
    <message>
        <source>Select option for removal.</source>
        <translation>Elegir opción para eliminar.</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templateadmin</name>
    <message>
        <source>Template edit</source>
        <translation>Editar plantilla</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templatecreate</name>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>No puedes crear una plantilla. Permiso denegado.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Nombre no válido. Solo puedes utilizar caracteres de la a a la z, números y _.</translation>
    </message>
    <message>
        <source>Create new template override for &lt;%template_name&gt;</source>
        <translation>Crear una nueva plantilla sobreescrita de &lt;%template_name&gt;</translation>
    </message>
    <message>
        <source>The newly created template file will be placed in</source>
        <translation>El archivo de plantilla recién creado se guardará en</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nombre del fichero</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Claves de sobreescritura</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>All classes</source>
        <translation>Todas las clases</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>All sections</source>
        <translation>Todas las secciones</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID del nudo</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Base de la plantilla en</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Archivo vacío</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Copia de plantilla por defecto</translation>
    </message>
    <message>
        <source>Container (with children)</source>
        <translation>Contenedor (con hijos)</translation>
    </message>
    <message>
        <source>View (without children)</source>
        <translation>Vista (sin hijos)</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objeto</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templatelist</name>
    <message>
        <source>Complete template list</source>
        <translation>Lista completa de plantilla</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Plantilla</translation>
    </message>
    <message>
        <source>Design resource</source>
        <translation>Recurso de diseño</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>La plantillas más comunes</translation>
    </message>
</context>
<context>
    <name>design/standard/design/templateview</name>
    <message>
        <source>Overrides for &lt;%template_name&gt; template in &lt;%current_siteaccess&gt; siteaccess [%override_count]</source>
        <translation>Sobreescrituras para la plantilla &lt;%template_name&gt; en el acceso al sitio &lt;%current_siteaccess&gt; [%override_count]</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Recursos de la plantilla por defecto</translation>
    </message>
    <message>
        <source>Siteaccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Condiciones de coincidencia</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>New override</source>
        <translation>Nueva sobreescritura</translation>
    </message>
    <message>
        <source>Update priorities</source>
        <translation>Actualizar prioridades</translation>
    </message>
</context>
<context>
    <name>design/standard/design/toolbar</name>
    <message>
        <source>Tool List for Toolbar_%toolbar_position</source>
        <translation>Lista de herramientas para Barra de herramientas_%toolbar_position</translation>
    </message>
    <message>
        <source>Tool</source>
        <translation>Herramienta</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Update Placement</source>
        <translation>Actualizar la ubicación</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Añadir herramienta</translation>
    </message>
    <message>
        <source>Toolbar management</source>
        <translation>Gestión de la barra de herramientas</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Acceso al sitio (SiteAccess) actual</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Elige el acceso del sitio</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Available toolbars</source>
        <translation>Barras de herramientas disponibles</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Acceso denegado</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>No tienes permisos para acceder a este área.</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Clica el botón de Login para conectar.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>No encontrado</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Módulo no encontrado</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Vista no encontrada</translation>
    </message>
    <message>
        <source>View is disabled</source>
        <translation>La vista está desactivada</translation>
    </message>
    <message>
        <source>Module is disabled</source>
        <translation>El módulo está desactivado</translation>
    </message>
    <message>
        <source>Your current user does not have the proper privileges to access this page.</source>
        <translation>Tu usuario actual no tiene los privilegios apropiados para acceder a esta página.</translation>
    </message>
    <message>
        <source>The resource you requested was not found.</source>
        <translation>El recurso que has pedido no ha sido encontrado.</translation>
    </message>
    <message>
        <source>The the id or name of the resource was misspelled, try changing it.</source>
        <translation>La id o el nombre del recurso está mal escrito, inténta cambiarlo.</translation>
    </message>
    <message>
        <source>The requested module %module could not be found.</source>
        <translation>El módulo requerido %module no ha podido ser encontrado.</translation>
    </message>
    <message>
        <source>The module does not exist on this site.</source>
        <translation>El módulo no existe en este sitio.</translation>
    </message>
    <message>
        <source>The requested view %view could not be found in module %module</source>
        <translation>La vista requerida %view no pudo ser encontrada en el módulo %module</translation>
    </message>
    <message>
        <source>The view does not exist for the module %module.</source>
        <translation>La vista no existe para el módulo %module.</translation>
    </message>
    <message>
        <source>The view %module/%view is disabled and cannot be accessed.</source>
        <translation>La vista %module/%view está desactivada y no es accesible.</translation>
    </message>
    <message>
        <source>The module %module is disabled and cannot be accessed.</source>
        <translation>El módulo %module está desactivado y no es accesible.</translation>
    </message>
    <message>
        <source>Object is unavailable</source>
        <translation>El objeto no está disponible</translation>
    </message>
    <message>
        <source>The object you requested is not currently available.</source>
        <translation>El objeto pedido no está disponible actualmente.</translation>
    </message>
    <message>
        <source>The id or name of the object was misspelled, try changing it.</source>
        <translation>La id o el nombre del objeto está mal escrito, intenta cambiarlo.</translation>
    </message>
    <message>
        <source>The object is no longer available on the site.</source>
        <translation>El objeto no esta disponible más en este sitio.</translation>
    </message>
    <message>
        <source>Object moved</source>
        <translation>Objeto movido</translation>
    </message>
    <message>
        <source>The object is no longer available at this URL.</source>
        <translation>El objeto no esta disponible más en esta URL.</translation>
    </message>
    <message>
        <source>You should automatically be redirected to the new location. If not click %url.</source>
        <translation>Serás redireccionado automáticamente a una nueva ubicación. Si no, clica %url.</translation>
    </message>
    <message>
        <source>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</source>
        <translation>Actualmente no estás registrado en este sitio. Para obtener un acceso adecuado crea un nuevo usuario o conéctate con un usuario existente.</translation>
    </message>
    <message>
        <source>The resource no longer exists on the site.</source>
        <translation>El recurso no existe más en el sitio.</translation>
    </message>
    <message>
        <source>Permission required</source>
        <translation>Permisos requeridos</translation>
    </message>
    <message>
        <source>Module : </source>
        <translation>Modulo:</translation>
    </message>
    <message>
        <source>Function : </source>
        <translation>Función:</translation>
    </message>
    <message>
        <source>You misspelled some parts of your URL, try changing it.</source>
        <translation>Algunas partes de tu URL están mal escritas, prueba cambiándolas.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Conectar</translation>
    </message>
    <message>
        <source>The module name was misspelled, try changing the URL.</source>
        <translation>El nombre del módulo está mal escrio, prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>This site uses siteaccess matching in the URL and you didn&apos;t supply one, try inserting a siteaccess name before the module in the URL .</source>
        <translation>Este sitio usa los accesos al sitio en la URL y no aparece ningúno. Intenta poner el acceso al sitio antes del nombre del módulo en la URL.</translation>
    </message>
    <message>
        <source>The view name was misspelled, try changing the URL.</source>
        <translation>El nombre de la vista está mal escrito, prueba cambiando la URL.</translation>
    </message>
    <message>
        <source>Possible reasons for this are:</source>
        <translation>Las razones posibles para eso son:</translation>
    </message>
</context>
<context>
    <name>design/standard/form</name>
    <message>
        <source>Thank you for your feedback</source>
        <translation>
Gracias por tu feedback</translation>
    </message>
    <message>
        <source>Your information was successfully received.</source>
        <translation>Tu información ha sido recibida con éxito.</translation>
    </message>
</context>
<context>
    <name>design/standard/gui</name>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Printable version</source>
        <translation>Versión imprimible</translation>
    </message>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Bienvenido a  la administración de eZ publish </translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Para conectarte inserta un login válido y una contraseña.</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Búsqueda avanzada</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Página frontal</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Mapa del sitio</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Cambiar la contraseña</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Conectar</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Desconectar</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Redireccionar</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>La carga del módulo ha fallado</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Módulo indefinido:</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personal</translation>
    </message>
    <message>
        <source>%sitetitle front page</source>
        <translation>Página de inicio de %sitetitle</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Buscar %sitetitle</translation>
    </message>
    <message>
        <source>eZ publish redirection - %url</source>
        <translation>Redirección eZ publish - %url</translation>
    </message>
    <message>
        <source>Redirecting to %url</source>
        <translation>Redireccionando a %url</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
</context>
<context>
    <name>design/standard/location</name>
    <message>
        <source>Removal of locations</source>
        <translation>Eliminar ubicaciones</translation>
    </message>
    <message>
        <source>Some of the locations you tried to remove has children, are you really sure you want to remove those locations?
If you do all the children will be removed as well.</source>
        <translation>Algunas de las ubicacioines que intentas eliminar tienen hijos, ¿estás seguro de que quieres eliminar esas ubicaciones?
Si lo haces todos los hijos se eliminarán.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cuenta</translation>
    </message>
    <message>
        <source>Remove locations</source>
        <translation>Eliminar ubicaciones</translation>
    </message>
    <message>
        <source>Cancel removal</source>
        <translation>Cancelar eliminación</translation>
    </message>
</context>
<context>
    <name>design/standard/menuconfig</name>
    <message>
        <source>Menu management</source>
        <translation>Gestión de menu</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Acceso al sitio (SiteAccess) actual</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Elige el acceso del sitio</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Menu positioning</source>
        <translation>Posicionamiento del menú</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Anteriór</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>¿Estás seguro de que quieres eliminar %1 del nudo %2?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note:</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Los nudos eliminados pueden ser recuperados más tarde. Los podrás encontrar en la papelera.</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Los siguientes productos fueron eliminados de tu cesta porque los productos han sido cambiados</translation>
    </message>
    <message>
        <source>Removing node assignment of %1</source>
        <translation>Eliminando la asignación del nudo de %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>¿Estás seguro de que quieres eliminar estos ítems?</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Mover a la papelera</translation>
    </message>
    <message>
        <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
        <translation>Si %trashname ha pasado la comprobación, encontrarás los ítems borrados en la papelera más tarde.</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove its %1 children.</source>
        <translation>Eliminando esta asignación también eliminarás su(s) %1 hijo(s).</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename y su(s) %childcount hijo(s). %additionalwarning</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Mapa del sitio</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Grupo de usuarios</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Crear aquí</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Add to Bookmarks</source>
        <translation>Añadir a favoritos</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Notifícame las actualizaciones</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Desseleccionar todo</translation>
    </message>
    <message>
        <source>Click to create a custom template</source>
        <translation>Clica para crear una nueva plantilla</translation>
    </message>
    <message>
        <source>Default object view.</source>
        <translation>Vista del objeto predeterminada.</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID del nudo</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>ID del objeto</translation>
    </message>
    <message>
        <source>Missing or invalid input</source>
        <translation>La entrada falta o esta invalida</translation>
    </message>
    <message>
        <source>Placed in</source>
        <translation>Situado en</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Do you want to receive messages combined in digest</source>
        <translation>Quieres recibir los mensajes en forma de recopilación</translation>
    </message>
    <message>
        <source>Digest settings</source>
        <translation>Configuraciones de recopilación</translation>
    </message>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>Si no quieres seguir recibiendo estas notificaciones, 
cambia tus configuraciones en:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>%sitename notification system</source>
        <translation>Sistema de notificación de %sitename</translation>
    </message>
    <message>
        <source>[%sitename] New collaboration item</source>
        <translation>[%sitename] Nuevo elemento de colaboración</translation>
    </message>
    <message>
        <source>Receive all messages combined in one digest</source>
        <translation>Recibir todos los mensajes combinados en una recopilación</translation>
    </message>
    <message>
        <source>[%sitename] Digest for %date</source>
        <translation>[%sitename] Recopilación de %date</translation>
    </message>
    <message>
        <source>Day of the week</source>
        <translation>Día de la semana</translation>
    </message>
    <message>
        <source>Notification admin</source>
        <translation>Administrador de notificaciones</translation>
    </message>
    <message>
        <source>Time event was spawned</source>
        <translation>El evento de tiempo ha sido generado</translation>
    </message>
    <message>
        <source>Run notification filter</source>
        <translation>Arrancar filtro de notificación</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Arrancar</translation>
    </message>
    <message>
        <source>Spawn time event</source>
        <translation>Generar evento de tiempo</translation>
    </message>
    <message>
        <source>Spawn</source>
        <translation>Generar</translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation>Configuraciones de notificación</translation>
    </message>
    <message>
        <source>&quot;%name&quot; was updated</source>
        <translation>&quot;%name&quot; ha sido actualizado</translation>
    </message>
    <message>
        <source>The item can be viewed by using the URL below.</source>
        <translation>Este elemento se puede ver usando el enlace más abajo.</translation>
    </message>
    <message>
        <source>&quot;%name&quot; was published</source>
        <translation>&quot;%name&quot; ha sido publicado</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</source>
        <translation>Este e-mail es para informarte de que un nuevo elemento de colaboración está esperando tu aprobación en %sitename.
Puedes ver el elemento en la URL de abajo.</translation>
    </message>
    <message>
        <source>Time of day</source>
        <translation>Hora del día</translation>
    </message>
    <message>
        <source>Daily</source>
        <translation>A diario</translation>
    </message>
    <message>
        <source>Weekly, day of week</source>
        <translation>Semanalmente, día de la semana</translation>
    </message>
    <message>
        <source>Monthly, day of month</source>
        <translation>Mensualmente, día del mes</translation>
    </message>
    <message>
        <source>If the day of month number you have chosen is larger than the number of days in the current month, then the last day of the current month will be used instead.</source>
        <translation>Si el número del día del mes elegido es mayor que el total de días del mes, se usará el último día de mes.</translation>
    </message>
    <message>
        <source>This digest e-mail is to inform you on new items at %sitename.</source>
        <translation>Esta e-mail de recompilación es para informarte de nuevos elementos en %sitename.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you on news at %sitename.</source>
        <translation>Este e-mail es para informarte de las novedades en %sitename.</translation>
    </message>
    <message>
        <source>Node notification</source>
        <translation>Notificación de nudo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that an updated item has been published at %sitename.</source>
        <translation>Este e-mail es para informarte de que un elemento actualizado ha sido publicado en %sitename.</translation>
    </message>
    <message>
        <source>This e-mail is to inform you that a new item has been published at %sitename.</source>
        <translation>Este e-mail es para informarte de que un nuevo elemento ha sido aprobado en %sitename.</translation>
    </message>
    <message>
        <source>Notification filter processed all available notification events</source>
        <translation>El filtro de notificación procesó todos los eventos de notificación</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/collaboration</name>
    <message>
        <source>Collaboration notification</source>
        <translation>Notificación de colaboración</translation>
    </message>
    <message>
        <source>Choose which collaboration items you wish to get notifications for.</source>
        <translation>Elige a qué elementos de colaboración le enviarás notificación.</translation>
    </message>
</context>
<context>
    <name>design/standard/package</name>
    <message>
        <source>Packages</source>
        <translation>Paquetes</translation>
    </message>
    <message>
        <source>The following packages are available on this system</source>
        <translation>Los paquetes siguientes están disponibles en el sistema</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Upload package</source>
        <translation>Subir paquete</translation>
    </message>
    <message>
        <source>Select the file containing your package and click the upload button</source>
        <translation>Selecciona el archivo que contiene tu paquete y clica el botón de subida</translation>
    </message>
    <message>
        <source>Install package</source>
        <translation>Instalar paquete</translation>
    </message>
    <message>
        <source>Please provide information on the changes.</source>
        <translation>Por favor, suministra información sobre los cambios.</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Cambios</translation>
    </message>
    <message>
        <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</source>
        <translation>Comienza una entrada con un marcador (%emstart-%emend (guión) o %emstart*%emend (asterisco)) al inicio de la línea.
El cambio se mantendrá hasta el próximo marcador de cambio.</translation>
    </message>
    <message>
        <source>Please provide some basic information for your package.</source>
        <translation>Por favor, suministra alguna información básica sobre el paquete.</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Nombre del paquete</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Package host</source>
        <translation>Alojamiento del paquete</translation>
    </message>
    <message>
        <source>Packager</source>
        <translation>Empaquetador</translation>
    </message>
    <message>
        <source>Please provide information on the maintainer of the package.</source>
        <translation>Por favor, suministra información sobre el mantenedor del paquete.</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Maintainer name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Role</source>
        <comment>Maintainer role</comment>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</source>
        <translation>Por favor, selecciona algún fichero de miniatura para que sea incluido en el paquete.
Si no quieres tener ninguna miniatura, tan sólo has de hacer clic en Siguiente.</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Crear el paquete</translation>
    </message>
    <message>
        <source>Available wizards</source>
        <translation>Asistentes disponibles</translation>
    </message>
    <message>
        <source>Choose one of the following wizards for creating a package</source>
        <translation>Elige uno de los siguientes asistentes para crear un paquete</translation>
    </message>
    <message>
        <source>Please choose the content classes you wish to be included in the package.</source>
        <translation>Elige las clases de contenido que quieres incluir en el paquete.</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Lista de clases</translation>
    </message>
    <message>
        <source>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</source>
        <translation>Elige algún archivo de imagen para incluirlo en el paquete y haz clic en Siguiente.
Cuando hayas acabado de añadir imágenes, haz clic en Siguiente sin escoger una imagen.</translation>
    </message>
    <message>
        <source>Currently added image files</source>
        <translation>Archivos de imagen añadidos actualmente</translation>
    </message>
    <message>
        <source>Package wizard: %wizardname</source>
        <translation>Asistente de paquetes %wizardname</translation>
    </message>
    <message>
        <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
        <translation>El paquete se puede instalar en tu sistema. Con la instalación se copiarán archivos, se crearán clases de contenido, etc., dependiendo del paquete.
Si no quieres instalar ahora el paquete, lo puedes hacer más tarde en la página de vista para el paquete.</translation>
    </message>
    <message>
        <source>Install items</source>
        <translation>Instala los items</translation>
    </message>
    <message>
        <source>Skip installation</source>
        <translation>Saltar la instalación</translation>
    </message>
    <message>
        <source>Removal of packages</source>
        <translation>Eliminación de paquetes</translation>
    </message>
    <message>
        <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
        <translation>¿Estás seguro que quieres eliminar los siguientes paquetes?
Los paquetes se perderán para siempre.
Nota: los paquetes no serán desinstalados.</translation>
    </message>
    <message>
        <source>Confirm removal</source>
        <translation>Confirma la eliminación</translation>
    </message>
    <message>
        <source>Keep packages</source>
        <translation>Mantiene losm paquetes</translation>
    </message>
    <message>
        <source>Package removal was cancelled.</source>
        <translation>La eliminación del paquete ha sido cancelada.</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selección</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>No instalado</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Importado</translation>
    </message>
    <message>
        <source>Remove package</source>
        <translation>Eliminar paquete</translation>
    </message>
    <message>
        <source>Import package</source>
        <translation>Importa el paquete</translation>
    </message>
    <message>
        <source>Next %arrowright</source>
        <translation>Siguiente %arrowright</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Terminar</translation>
    </message>
    <message>
        <source>Uninstall package</source>
        <translation>Desinstalar paquete</translation>
    </message>
    <message>
        <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
        <translation>El paquete se puede desinstalar de tu sistema. Con la desinstalación se borrarán los archivos copiados, las clases de contenido, etc., dependiendo del paquete.
Si no quieres desinstalar ahora el paquete, lo puedes hacer más tarde desde la página de vista para el paquete.
También puedes borrar el paquete sin desinstalarlo de la lista de paquetes.</translation>
    </message>
    <message>
        <source>Uninstall items</source>
        <translation>Desinstalar ítems</translation>
    </message>
    <message>
        <source>Skip uninstallation</source>
        <translation>Saltar la desinstalación</translation>
    </message>
    <message>
        <source>Files [%collectionname]</source>
        <translation>Archivos [%colllectionname]</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Exporta a un archivo</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Maintainers</source>
        <translation>Mantenedores</translation>
    </message>
    <message>
        <source>Regarding eZ publish package &apos;%packagename&apos;</source>
        <translation>En relación al paquete eZpublish &apos;%packagename&apos;</translation>
    </message>
    <message>
        <source>Send E-Mail to the maintainer</source>
        <translation>Enviar un e-mail a la persona encargada de mantener el sitio</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Lista de archivos</translation>
    </message>
    <message>
        <source>Please choose objects you wish to include in the package.</source>
        <translation>Por favor, elige los objetos que quiere incluir en el paquete.</translation>
    </message>
    <message>
        <source>Selected nodes</source>
        <translation>Nudos selecionados</translation>
    </message>
    <message>
        <source>Please select the site CSS file to be included in the package.</source>
        <translation>Por favor, elige el archivo CSS del sitio que quiere incluir en el paquete.</translation>
    </message>
    <message>
        <source>Please select the classes CSS file to be included in the package.</source>
        <translation>Por favor, elige los archivos CSS de clases que quiere incluir en el paquete.</translation>
    </message>
    <message>
        <source>Package install wizard: %wizardname</source>
        <translation>Asistente de instalación de paquete: %wizardname</translation>
    </message>
    <message>
        <source>You must now choose which siteaccess the package contents should be installed to.
The chosen siteaccess determines where design files and settings are written to.
If unsure choose the siteaccess which reflects the user part of your site, i.e. not admin.</source>
        <translation>Ahora tiene que eligir en cual acceso de sitio (siteaccess) hay que instalar el contenido del paquete.
El acceso de sitio eligido determina donde los archivos de diseño y de configuración estan gravados.
Si no estas seguro, elige el acceso de sitio que representa la parte pública de su sitio, es decir no la de administración.</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Elige el acceso del sitio</translation>
    </message>
    <message>
        <source>Please select where you want to place the imported items.</source>
        <translation>Por favor, elige donde quiere poner los elementos importados.</translation>
    </message>
    <message>
        <source>If you wish to change the placement click the browse button.</source>
        <translation>Si quieres cambiar el sitio, haz click en el botón navegar.</translation>
    </message>
    <message>
        <source>Place %object_name in node %node_placement</source>
        <translation>Poner %object_name en el nudo %node_placement</translation>
    </message>
    <message>
        <source>Choose placement for %object_name</source>
        <translation>Elige el sitio para %object_name</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>Change repository</source>
        <translation>Cambia el repositorio</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nudo</translation>
    </message>
    <message>
        <source>Export type</source>
        <translation>Tipo de exportación</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Add subtree</source>
        <translation>Añadir subárbol</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>Añadir nudo</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Map %siteaccess_name to</source>
        <translation>Mapear %siteaccess_name a</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>Repositories</source>
        <translation>Repositorios</translation>
    </message>
    <message>
        <source>Send e-mail to the maintainer</source>
        <translation>Enviar e-mail a la persona encargada de mantener el sitio</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/standard/package/creators/ezcontentobject</name>
    <message>
        <source>Please choose the node(s) you wish to export.</source>
        <translation>Por favor, elige los nudos que quieres exportar.</translation>
    </message>
    <message>
        <source>Please choose the subtree(s) you wish to export.</source>
        <translation>Por favor, elige los subarboles que quieres exportar.</translation>
    </message>
    <message>
        <source>Choose node for export</source>
        <translation>Elige el nudo para exportar</translation>
    </message>
    <message>
        <source>Choose subtree for export</source>
        <translation>Elige el subárbol para exportar</translation>
    </message>
    <message>
        <source>Specify export properties. Default settings will most likely be suitable for your needs.</source>
        <translation>Especificar propiedades de exportación. La configuración predeterminada es seguramente suficiente para tus necesidades.</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Miscelaneos</translation>
    </message>
    <message>
        <source>Include class definitions.</source>
        <translation>Incluir definición de clases.</translation>
    </message>
    <message>
        <source>Include templates related exported objects.</source>
        <translation>Incluir plantillas relacionadas con los objetos exportados.</translation>
    </message>
    <message>
        <source>Select templates from the following siteaccesses</source>
        <translation>Eligir las plantillas de los siguientes accesos a sitios</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versiones</translation>
    </message>
    <message>
        <source>Published version</source>
        <translation>Versión publicada</translation>
    </message>
    <message>
        <source>All versions</source>
        <translation>Todas las versiones</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <source>Select languages to export</source>
        <translation>Eligir los idiomas para exportar</translation>
    </message>
    <message>
        <source>Node assignments</source>
        <translation>Asignaciones de nudo</translation>
    </message>
    <message>
        <source>Keep all in selected nodes</source>
        <translation>Mantener todo en los nudos seleccionados</translation>
    </message>
    <message>
        <source>Main only</source>
        <translation>Sólo el principal</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objetos relacionados</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
</context>
<context>
    <name>design/standard/package/installers/ezcontentobject</name>
    <message>
        <source>Choose parent node</source>
        <translation>Elige el nudo padre</translation>
    </message>
    <message>
        <source>Select parent node for new node.</source>
        <translation>Elige el nudo padre para los nuevos nudos.</translation>
    </message>
</context>
<context>
    <name>design/standard/pdf/list</name>
    <message>
        <source>PDF Exports</source>
        <translation>Exportaciones PDF</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Creado por</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Creado</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Nueva exportación</translation>
    </message>
</context>
<context>
    <name>design/standard/reference/ez</name>
    <message>
        <source>No generated documentation found</source>
        <translation>No se ha encontrado documentación generada</translation>
    </message>
    <message>
        <source>To create the reference documentation you must do the following step</source>
        <translation>Para crear la documentación de referencia debes dar el siguiente paso</translation>
    </message>
    <message>
        <source>Download and install doxygen</source>
        <translation>Descargar e instalar doxygen</translation>
    </message>
    <message>
        <source>Generate the documentation by running the following command</source>
        <translation>Generar la documentación arrancando el comando siguiente</translation>
    </message>
    <message>
        <source>Download doxygen from %doxygenurl.</source>
        <translation>Descargar doxygen de %doxygenurl.</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>Modules</source>
        <translation>Módulos</translation>
    </message>
    <message>
        <source>Class hierarchy</source>
        <translation>Jerarquía de clase</translation>
    </message>
    <message>
        <source>Compound list</source>
        <translation>Lista compuesta</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Lista de archivos</translation>
    </message>
    <message>
        <source>Compound members</source>
        <translation>Miembros compuestos</translation>
    </message>
    <message>
        <source>File members</source>
        <translation>Miembros de archivo</translation>
    </message>
    <message>
        <source>Related pages</source>
        <translation>Páginas relacionadas</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Introducción</translation>
    </message>
    <message>
        <source>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</source>
        <translation>La documentación de referencia para eZ publish consiste en múltiples secciones que
tienen una vista diferente de la documentación cada una. Las secciones son accesibles en
el menú superior.</translation>
    </message>
    <message>
        <source>The documentation will give an overview of the API of eZ publish.</source>
        <translation>La documentación ofrece un vistazo de la API de eZ publish.</translation>
    </message>
    <message>
        <source>All reference documentation has been made with %doxygenurl</source>
        <translation>Toda la documentación de referencia ha sido hecha con %doxygenurl</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Crear política para</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Paso 1</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Cada módulo</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Permiso total</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Permiso limitado</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Limitado</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Volver al paso 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>No estás habilitado para dar acceso a las funciones limitadas del módulo</translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>Porque la lista de funciones para él no está definida.</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Paso 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Especifica la función en el módulo</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Volver al paso 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Paso 3</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Lista de roles</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Vista de roles</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Políticas de roles</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Usuarios y grupos asignados a este rol</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Asignar</translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation>Dar acceso al módulo</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Módulo</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Acceso</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Función</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Políticas actuales</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Limitaciones</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Descartar cambios</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Limitación</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>Role edit %1</source>
        <translation>Edita el Rol %1</translation>
    </message>
    <message>
        <source>Edit policy</source>
        <translation>Editar política</translation>
    </message>
    <message>
        <source>Policy</source>
        <translation>Política</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nudo</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>No especificado.</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Subárbol</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualización</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Rol</translation>
    </message>
    <message>
        <source>Specify limitations for function %functionname in module %modulename. &apos;Any&apos; means no limitation by this parameter</source>
        <translation>Especificar limitaciones para la función %functionname en el módulo %modulename. &apos;Ninguna&apos; significa que no hay limitaciones para ese parámetro</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Remove selected policies</source>
        <translation>Eliminar las políticas seleccionadas</translation>
    </message>
    <message>
        <source>Edit role</source>
        <translation>Editar rol</translation>
    </message>
    <message>
        <source>Assign role to user or group</source>
        <translation>Asignar rol a un usuario o grupo</translation>
    </message>
    <message>
        <source>Remove selected roles</source>
        <translation>Eliminar los roles seleccionados</translation>
    </message>
    <message>
        <source>Edit current role</source>
        <translation>Editar el rol actual</translation>
    </message>
    <message>
        <source>Remove selected assignments</source>
        <translation>Eliminar las asignaciones seleccionadas</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Assign role to user or group to subtree</source>
        <translation>Asignar rol a un usuario o a un grupo a un subarbol</translation>
    </message>
    <message>
        <source>Assign limited</source>
        <translation>Asignación limitada</translation>
    </message>
</context>
<context>
    <name>design/standard/rss</name>
    <message>
        <source>Choose export node</source>
        <translation>Elige un nodo de exportación</translation>
    </message>
    <message>
        <source>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Elige desde dónde quieres exportar.

Selecciona tus ubicaciones y haz clic en el botón %buttonname.
También puedes usar las opciones Recientes y Favoritos para hacer ubicaciones de forma rápida.
Haz clic en los nombres de ubicación para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Choose import destination</source>
        <translation>Elige el destino de la importación</translation>
    </message>
    <message>
        <source>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Elige dónde quieres almacenar los ítems importados.

Selecciona tus ubicaciones y haz clic en el botón %buttonname.
También puedes usar las opciones Recientes y Favoritos para hacer ubicaciones de forma rápida.
Haz clic en los nombres de ubicación para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Choose RSS image</source>
        <translation>Elige la imagen RSS</translation>
    </message>
    <message>
        <source>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Elige la imagen que quieres utilizar en la exportación RSS.

Selecciona tus ubicaciones y haz clic en el botón %buttonname.
También puedes usar las opciones Recientes y Favoritos para hacer ubicaciones de forma rápida.
Haz clic en los nombres de ubicación para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Choose export source</source>
        <translation>Elige el origen de la exportación</translation>
    </message>
    <message>
        <source>Choose owner of imported objects</source>
        <translation>Elige el propietario de los objetos importados</translation>
    </message>
    <message>
        <source>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Elige el propietario de los objetos para importar.

Selecciona el usuario y haz clic en el botón %buttonname.
También puedes usar las opciones Recientes y Favoritos para hacer ubicaciones de forma rápida.
Haz clic en los nombres de ubicación para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>RSS export is locked</source>
        <translation>La exportación RSS está bloqueada</translation>
    </message>
    <message>
        <source>The RSS export %name is currently locked by %user and was last modified on %datetime.</source>
        <translation>La exportación RSS %name está bloqueada por %user y su última modificación fue el %datetime.</translation>
    </message>
    <message>
        <source>The RSS export will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
        <translation>La exportación RSS estará disponible para editar cuando sea guardada por el editor o cuando se desbloquee automaticamente el %datetime.</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Inténtalo de nuevo</translation>
    </message>
    <message>
        <source>RSS import is locked</source>
        <translation>La importación RSS está bloqueada</translation>
    </message>
    <message>
        <source>The RSS import %name is currently locked by %user and was last modified on %datetime.</source>
        <translation>La importación RSS está bloqueada por %user y su última modificación fue el %datetime.</translation>
    </message>
    <message>
        <source>The RSS import will be available for editing once it is stored by the modifier or when it is automatically unlocked on %datetime.</source>
        <translation>La importación RSS estará disponible para editar cuando sea guardada por el editor o cuando se desbloquee automaticamente el %datetime.</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/edit</name>
    <message>
        <source>Display frontpage</source>
        <translation>Mostrar portada</translation>
    </message>
    <message>
        <source>RSS Export</source>
        <translation>Exportación RSS</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Site URL</source>
        <translation>URL del sitio</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>Site Access</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>RSS version</source>
        <translation>Versión RSS</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Access URL</source>
        <translation>URL de acceso</translation>
    </message>
    <message>
        <source>Source path</source>
        <translation>Ruta de origen</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Add Source</source>
        <translation>Añadir origen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>RSS Import</source>
        <translation>Importación RSS</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Destination path</source>
        <translation>Ruta de destino</translation>
    </message>
    <message>
        <source>Imported objects owner</source>
        <translation>Propietario de los objetos importados</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorar</translation>
    </message>
    <message>
        <source>Remove Source</source>
        <translation>Eliminar fuente</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation>Exportación PDF</translation>
    </message>
    <message>
        <source>Intro text</source>
        <translation>Texto introductorio</translation>
    </message>
    <message>
        <source>Sub text</source>
        <translation>Texto secundario</translation>
    </message>
    <message>
        <source>Source node</source>
        <translation>Nudo de origen</translation>
    </message>
    <message>
        <source>Export structure</source>
        <translation>Exportar estructura</translation>
    </message>
    <message>
        <source>Tree</source>
        <translation>Árbol</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nudo</translation>
    </message>
    <message>
        <source>Export classes</source>
        <translation>Exportar las clases</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Acceso al sitio</translation>
    </message>
    <message>
        <source>Export destination</source>
        <translation>Exportar destino</translation>
    </message>
    <message>
        <source>Export to URL</source>
        <translation>Exportar a URL</translation>
    </message>
    <message>
        <source>Export for direct download</source>
        <translation>Exportar para una descarga directa</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/list</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>RSS Feeds</source>
        <translation>Suministros RSS</translation>
    </message>
    <message>
        <source>RSS Exports</source>
        <translation>Exportaciones RSS</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Nueva exportación</translation>
    </message>
    <message>
        <source>RSS Imports</source>
        <translation>Importaciones RSS</translation>
    </message>
    <message>
        <source>New Import</source>
        <translation>Nueva importación</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Buscar estadísticas</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Frases más frecuentemente buscadas</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Frase</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Número de frases</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Promedio de resultados devueltos</translation>
    </message>
    <message>
        <source>Reset statistics</source>
        <translation>Vaciar estadisticas</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section to node</source>
        <translation>Asignar sección al nudo</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>¿Estás seguro de que quieres eliminar estas secciones?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Eliminando estas secciones puedes corromper permisos, diseños del sitio y otros elementos del sistema. No lo hagas a menos que sepas exactamente lo que estás haciendo.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Editar sección</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Lista de secciones</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Zona de navegación</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>Sobre zonas de navegación</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>La administración de eZ publish está dividida en zonas de navegación. Este es un medio de agrupar diferentes áreas del sitio de administración. Selecciona la zona de navegación que debe estar activa cuando estés mirando esta página.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Asignar</translation>
    </message>
    <message>
        <source>Assign section - %section</source>
        <translation>Asignar sección - %section</translation>
    </message>
    <message>
        <source>Choose section assignment</source>
        <translation>Elige asignación de sección</translation>
    </message>
    <message>
        <source>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Por favor, elige dónde quieres comenzar la asignación de sección para la sección %sectionname.

Selecciona la ubicación y clica el botón %buttonname.
Es posible usar los elementos de reciente o favoritos para una ubicación rápida.
Clica en los nombres de ubicaciones para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Remove selected sections</source>
        <translation>Eliminar las secciones seleccionadas</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <source>Cache admin</source>
        <translation>Administrador de caché</translation>
    </message>
    <message>
        <source>Content view cache was cleared.</source>
        <translation>Se ha limpiado la caché de la vista de contenidos.</translation>
    </message>
    <message>
        <source>Ini file cache was cleared.</source>
        <translation>Se ha limpiado la caché del archivo Ini.</translation>
    </message>
    <message>
        <source>Template cache was cleared.</source>
        <translation>Se ha limpiado la caché de las plantillas.</translation>
    </message>
    <message>
        <source>View cache is enabled.</source>
        <translation>La vista de caché está activada.</translation>
    </message>
    <message>
        <source>View cache is disabled.</source>
        <translation>La vista de caché está desactivada.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Ini cache</source>
        <translation>Caché de los Ini</translation>
    </message>
    <message>
        <source>Ini cache is always enabled.</source>
        <translation>La caché del Ini está siempre activada.</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Caché de las plantillas</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Información del sistema</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>El modo salvado está encendido.</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>El modo salvado está apagado.</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>La restricción de basedir está encendida y fijada en %1.</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>La restricción de Basedir está apagada.</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>El registro de variable global está encendido.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>El registro de variable global está apagado.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>La actualización de archivo está activada.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>La actualización de archivo está apagado.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>El tamaño máximo del post data (texto y archivos] es %1.</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>El límite de la memoria script es %1.</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>El tiempo máximo de ejecución es %1 segundos.</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de datos</translation>
    </message>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Herramientas de Desarrollo de Aplicación Rápida</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
        <translation>Las herramientas de desarrollo de aplicación rápida (RAD) te ayudarán a un arranque más fácil creando una nueva fiuncionalidad para eZ publish.</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Asistente del operador de plantillas</translation>
    </message>
    <message>
        <source>Create new template override for</source>
        <translation>Crear una nueva plantilla sobreescrita para</translation>
    </message>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>No puedes crear una plantilla. Permiso denegado.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Nombre no válido. Solo puedes utilizar caracteres de la a a la z, números y _.</translation>
    </message>
    <message>
        <source>Template will be placed in</source>
        <translation>La plantilla será ubicada en</translation>
    </message>
    <message>
        <source>Template name</source>
        <translation>Nombre de la plantilla</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Claves de sobreescritura</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nudo</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Base de la plantilla en</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Archivo vacío</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Copia de plantilla defectuosa</translation>
    </message>
    <message>
        <source>Container ( with children )</source>
        <translation>Contenedor (con hijos)</translation>
    </message>
    <message>
        <source>View ( without children )</source>
        <translation>Vista (sin hijos)</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objeto</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Lista de plantilla</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>La plantillas más comunes</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Plantilla</translation>
    </message>
    <message>
        <source>Design Resource</source>
        <translation>Recurso de diseño</translation>
    </message>
    <message>
        <source>Complete template list</source>
        <translation>Lista completa de plantilla</translation>
    </message>
    <message>
        <source>Basic information</source>
        <translation>Información básica</translation>
    </message>
    <message>
        <source>Optional information</source>
        <translation>Información opcional</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Vista de plantilla</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Recursos de la plantilla por defecto</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Fijar</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Sobreescribir</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Condiciones de coincidencia</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Crear nuevo</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Asistente de tipo de dato</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Datatype start</comment>
        <translation>Empezar</translation>
    </message>
    <message>
        <source>Name of datatype</source>
        <comment>Datatype</comment>
        <translation>Nombre del tipo de dato</translation>
    </message>
    <message>
        <source>Descriptive name of datatype</source>
        <comment>Datatype</comment>
        <translation>Nombre descriptivo del tipo de dato</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Datatype</comment>
        <translation>Configuraciones</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <comment>Datatype</comment>
        <translation>Gestionar entradas en nivel de clase</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Datatype next</comment>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Datatype restart</comment>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Datatype</comment>
        <translation>Nombre de la clase</translation>
    </message>
    <message>
        <source>Constant name</source>
        <comment>Datatype</comment>
        <translation>Nombre de la constante</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <comment>Datatype</comment>
        <translation>El creador del tipo de dato</translation>
    </message>
    <message>
        <source>Description of your datatype</source>
        <comment>Datatype</comment>
        <translation>Descripción del tipo de dato</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Datatype</comment>
        <translation>La primera línea será usada como breve descripción y el resto es documentación del operador.</translation>
    </message>
    <message>
        <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
        <comment>Datatype default description</comment>
        <translation>Gestionar el tipo de dato %nombre del tipo de dato
Usando el %nombre de tipo de dato puedes...</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Datatype</comment>
        <translation>Una vez clicado el botón de descarga el código será generado y el browser preguntará si quieres almacenar el archivo generado.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Datatype download</comment>
        <translation>Descarga</translation>
    </message>
    <message>
        <source>Extension setup</source>
        <translation>Configuración extendida</translation>
    </message>
    <message>
        <source>Available extensions</source>
        <translation>Extensiones disponibles</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Sitio:</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>eZ publish version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <comment>eZ publish version</comment>
        <translation>SVN revisión</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>eZ publish extensions</comment>
        <translation>Extensiones</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>PHP extensions</comment>
        <translation>Extensiones</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP Accelerator version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>There is no known PHP accelerator active.</source>
        <translation>No se conoce ningúm acelerador PHP activo.</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>Database type</comment>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Charset</source>
        <comment>Database charset</comment>
        <translation>Juego de caracteres</translation>
    </message>
    <message>
        <source>&amp;percent% completed</source>
        <translation>&amp;porcentaje% completo</translation>
    </message>
    <message>
        <source>Tools</source>
        <comment>RAD Tools</comment>
        <translation>Herramientas</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Template operator start</comment>
        <translation>Empezar</translation>
    </message>
    <message>
        <source>Name of operator</source>
        <comment>Template operator</comment>
        <translation>Nombre del operador</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Template operator</comment>
        <translation>Configuraciones</translation>
    </message>
    <message>
        <source>One operator in class</source>
        <comment>Template operator</comment>
        <translation>Un operador en la clase</translation>
    </message>
    <message>
        <source>Handles operator input</source>
        <comment>Template operator</comment>
        <translation>Gestiona la entrada del operador</translation>
    </message>
    <message>
        <source>Generates operator output</source>
        <comment>Template operator</comment>
        <translation>Genera salida del operador</translation>
    </message>
    <message>
        <source>Parameter handling</source>
        <comment>Template operator</comment>
        <translation>Parametro gestionado</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Template operator next</comment>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Template operator restart</comment>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Template operator</comment>
        <translation>Nombre de la clase</translation>
    </message>
    <message>
        <source>The creator of the operator</source>
        <comment>Template operator</comment>
        <translation>El creador del operador</translation>
    </message>
    <message>
        <source>Description of your operator</source>
        <comment>Template operator</comment>
        <translation>Descripción de tu operador</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Template operator</comment>
        <translation>La primera línea será usada como breve descripción y el resto es documentación del operador.</translation>
    </message>
    <message>
        <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
        <comment>Template operator default description</comment>
        <translation>Gestiona el operador de plantillas %nombre del operador
Usando %nombre del operador puedes...</translation>
    </message>
    <message>
        <source>Example code</source>
        <comment>Template operator</comment>
        <translation>Código de ejemplo</translation>
    </message>
    <message>
        <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
        <comment>Template operator</comment>
        <translation>Si quieres puedes añadir algún código de ejemplo para explicar como puede funcionar tu operador.
El código por defecto ha sido hecho con los parámetros básicos que has elegido.</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Template operator</comment>
        <translation>Una vez clicado el botón de descarga el código será generado y el browser preguntará si quieres almacenar el archivo generado.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Template operator download</comment>
        <translation>Descarga</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>PHP Accelerator name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Could not detect version</source>
        <translation>No se ha podido detectar la versión</translation>
    </message>
    <message>
        <source>The PHP Accelerator is enabled.</source>
        <translation>El acelerador PHP está activo.</translation>
    </message>
    <message>
        <source>The PHP Accelerator is disabled.</source>
        <translation>El acelerador PHP está inactivo.</translation>
    </message>
    <message>
        <source>Server</source>
        <comment>Database server</comment>
        <translation>Servidor</translation>
    </message>
    <message>
        <source>Socket path</source>
        <comment>Database socket path</comment>
        <translation>Ruta de zócalo</translation>
    </message>
    <message>
        <source>Database</source>
        <comment>Database name</comment>
        <translation>Base de datos</translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <comment>Database retry count</comment>
        <translation>Contador de reintentos de conexión</translation>
    </message>
    <message>
        <source>Internal</source>
        <translation>Interno</translation>
    </message>
    <message>
        <source>Current read-only database (Slave)</source>
        <translation>Base de datos actualmente sólo de lectura (esclavo)</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>All caches were cleared.</source>
        <translation>Se ha limpiado todas las cachés.</translation>
    </message>
    <message>
        <source>Cache collections</source>
        <translation>Colecciónes de caché</translation>
    </message>
    <message>
        <source>Click a button to clear a collection of caches.</source>
        <translation>Haz click en un botón para limpiar una colección de caché.</translation>
    </message>
    <message>
        <source>All caches.</source>
        <translation>Todas las cachés.</translation>
    </message>
    <message>
        <source>All caches</source>
        <translation>Todas las caches</translation>
    </message>
    <message>
        <source>All caches are disabled</source>
        <translation>Todas las cachés estan desactivadas</translation>
    </message>
    <message>
        <source>Content views and template blocks.</source>
        <translation>Vistas de contenido y bloques de plantillas.</translation>
    </message>
    <message>
        <source>Content caches</source>
        <translation>Caché de contenido</translation>
    </message>
    <message>
        <source>Content caches is disabled</source>
        <translation>La caché de contenido esta desactivada</translation>
    </message>
    <message>
        <source>Template overrides and template compiling.</source>
        <translation>Plantillas sobreescritas y compilación de plantillas.</translation>
    </message>
    <message>
        <source>Template caches</source>
        <translation>Caché de plantilla</translation>
    </message>
    <message>
        <source>Template caches are disabled</source>
        <translation>La caché de plantilla esta desactivada</translation>
    </message>
    <message>
        <source>INI caches.</source>
        <translation>Caché de los INI.</translation>
    </message>
    <message>
        <source>INI caches</source>
        <translation>Caché de los INI</translation>
    </message>
    <message>
        <source>INI cache is disabled</source>
        <translation>La caché de los INI esta desactivada</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selección</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Desactivado</translation>
    </message>
    <message>
        <source>Clear selected</source>
        <translation>Limpiar la selección</translation>
    </message>
    <message>
        <source>Content view cache</source>
        <translation>Caché de vista de contenido</translation>
    </message>
    <message>
        <source>%name was cleared.</source>
        <translation>%name ha sido limpiado.</translation>
    </message>
    <message>
        <source>SiteAccess</source>
        <translation>Acceso del sitio</translation>
    </message>
    <message>
        <source>Current siteaccess</source>
        <translation>Acceso al sitio (SiteAccess) actual</translation>
    </message>
    <message>
        <source>Select siteaccess</source>
        <translation>Elige un acceso al sitio</translation>
    </message>
    <message>
        <source>System upgrade</source>
        <translation>Actualización del sistema</translation>
    </message>
    <message>
        <source>File consistency check OK</source>
        <translation>La comprobación de la consistencia de archivo esta OK</translation>
    </message>
    <message>
        <source>Database check OK</source>
        <translation>La comprobación de base de datos esta OK</translation>
    </message>
    <message>
        <source>Warning, your database is not consistent with the distribution database.</source>
        <translation>Cuidado, la base de datos no corresponde con la de la distribución.</translation>
    </message>
    <message>
        <source>Click a button to check file consistency.</source>
        <translation>Haz click en un botón para comprobar la consistencia de los archivos.</translation>
    </message>
    <message>
        <source>Check files</source>
        <translation>Comprobar archivos</translation>
    </message>
    <message>
        <source>warning, this might take a while</source>
        <translation>cuidado, esto puede necesitar mucho tiempo</translation>
    </message>
    <message>
        <source>Click a button to check database consistency.</source>
        <translation>Haz click en un botón para comprobar la consistencia de la base de datos.</translation>
    </message>
    <message>
        <source>Check database</source>
        <translation>Comprobar la base de datos</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <source>Tool List for Toolbar_%toolbar_position</source>
        <translation>Lista de herramientas para Barra_de_herramientas%toolbar_position</translation>
    </message>
    <message>
        <source>Add Tool</source>
        <translation>Añadir herramienta</translation>
    </message>
    <message>
        <source>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access specific extensions, modify these configuration files.</source>
        <translation>Aquí se puede activar y desactivar las extensiones. Solo las extensiones de sistema pueden ser activadas. Para extensiones específicas a un acceso de sitio, modificar sus archivos de configuración.</translation>
    </message>
    <message>
        <source>Webserver</source>
        <comment>Webserver title</comment>
        <translation>Servidor web</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Webserver name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>Webserver version</comment>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Modules</source>
        <comment>Webserver modules</comment>
        <translation>Módulos</translation>
    </message>
    <message>
        <source>Webserver modules could not be detected</source>
        <comment>Webserver modules</comment>
        <translation>No se pudieron detectar los módulos del servidor web</translation>
    </message>
    <message>
        <source>No known information on the webserver</source>
        <translation>No hay información conocida en el servidor web</translation>
    </message>
    <message>
        <source>Operating System</source>
        <translation>Sistema operativo</translation>
    </message>
    <message>
        <source>CPU</source>
        <comment>Database type</comment>
        <translation>CPU</translation>
    </message>
    <message>
        <source>Memory</source>
        <comment>Database server</comment>
        <translation>Memoria</translation>
    </message>
    <message>
        <source>No information on the operating system could be determined.</source>
        <translation>No se pudo determinar información del sistema operativo.</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Image system</source>
        <translation>Sistema de imagen</translation>
    </message>
    <message>
        <source>Mail</source>
        <translation>Mail</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Sitio</translation>
    </message>
    <message>
        <source>Warning, it is not safe to upgrade without checking the modifications done to the following files </source>
        <translation>Aviso, no es seguro actualizar sin comprobar las modificaciones hechas en los siguientes archivos</translation>
    </message>
    <message>
        <source>To revert your database to distribution setup, run the following SQL queries</source>
        <translation>Para revertir tu base de datos a la distribución de la instalación, ejecuta las siguientes consultas SQL</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/datatypecode</name>
    <message>
        <source>Constructor</source>
        <translation>Constructor</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Si tienes problemas con la conexión con tu base de datos tienes que mirar en</translation>
    </message>
    <message>
        <source>at</source>
        <translation>en</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Introducción</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL es un sistema de gestión de base de datos creado por MySQLAB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>Actualmente, es uno de las bases de datos más populares en las comunidades de código abierto.</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL es la base de datos de código abieerto más famosa del mundo, diseñada para ofercer velocidad, potencia y precisión en misiones críticas, y con mucha carga en su uso.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Se puede encontrar más información en</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL es una buena opción para manipular la mayoría de los lenguajes occidentales. Sin embargo, actualmente no lo es para Unicode o lenguajes no occidentales.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Instalación</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>A través del uso de </translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>la opción de configuración puedes permitir PHP para que acceda a las bases de datos de MySQL. Si utilizas esta opción sin especificar la ruta de MySQL, PHP usará las librerías de clientes propia de MySQL.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Se puede encontrar más información sobre la extensión MySQL en</translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL es un sistema de gestión de bases de datos desarrollado por la Universidad de California en el Departamento de Ciencias Informáticas de Berkeley.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>Es una base de datos muy popular en la comunidad de código abierto y aporta funcionalidades de base de datos altamente avanzadas.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>PostgreSQL es un sofisticado Object-Relational DBMS, que soporta casi todas las construcciones SQL, incluidas las subselecciones, transacciones i tipos i funciones definidas por el usuario. Es la base de datos de codigo abierto con prestaciones más avanzadas que puedes encontrar.</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL es uan buena opción para acomodar muchos lenguajes, incluido en Unicode, pero requiere algunas configuraciones para alcanzar una buena velocidad.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>Con tal de permitir el soporte de PostgreSQL</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>se requiere cuando compiles PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Se puede encontrar más información sobre la extensión PostgreSQL en</translation>
    </message>
    <message>
        <source>From their homepage</source>
        <translation>De su página principal</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>Install demo data?</source>
        <translation>¿Instalar demostración de datos?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>No se han podido instalar los datos de la demostración. No hay extensión zlib en tu instalación PHP.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation>no soporta la instalación de datos de demostración en este punto.</translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Error con los datos de demostración</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>No se puede desempaquetar la demostración de datos.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>Deberías tratar de instalar sin demostración de datos.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Inicialización fallida</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>La base de datos podría no estar cargada debidamente.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Alerta</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>Tu base de datos ya contiene información.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>La configuración puede continuar la inicialización pero prodría dañar los presentes datos.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>Qué quieres que haga la configuración?</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Continuar y eliminar los datos.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Dejarme elegir una nueva base de datos.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note:</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Opciones de idioma
</translation>
    </message>
    <message>
        <source>no</source>
        <translation>No</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Configurar</translation>
    </message>
    <message>
        <source>button.</source>
        <translation>botón.</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation>Tu sistema no requiere ajustes, puedes continuar clicando el</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>La comprobación del sistema ha encontrado algunas cuestiones que, una vez resueltas, podrían mejorar la ejecución o aportar más características. Mira en los resultados de abajo para obtener más información sobre lo que sei podría hacer. Cada tema te dará instrucciones para que sepas qué hacer para conseguir un ajuste más preciso.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>Una vez hayas solucionado los problemas, haz clic en</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Vuelve a hacer una comprobación del sistema</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>botón para volver a hacer una comprovación del sistema. Es recomendable que lo hagas después de hacer modificicaciones en el sistema para comprobar errores críticos. También puedes hacer clic al</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Vuelve a comprobar</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>botón para volver a comprobar los ajustes más precisos. No obstante, si quieres, puedes ir directamente al siguiente paso haciendo clic al</translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Cuestiones</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Fallo en la escritura</translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>La configuración no ha podido escribir en un fichero.</translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>La configuración no ha podido tener acceso de escritura al</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation>directorio. Esta es una tarea requerida para desactivar la inicialización. Siguiendo las instrucciones que se encuentran en</translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation>para habilitar el acceso de escritura y haz clic en el</translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Prueba de nuevo</translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Cambia la segunda línea desde </translation>
    </message>
    <message>
        <source>to</source>
        <translation>hasta</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation>La configuración no está desactivada, haz clic en</translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation>para volver al sitio.</translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>Puedes escoger entre cualquiera</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>Enviar mail</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation>Felicidades, eZ publish puede funcionar ahora en tu sistema.</translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>sitio web de eZ publish</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>aviso de fallos de eZ publish</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation>Es hora de elegir el lenguaje que ha de soportar este sitio.</translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation>Selecciona tu lenguaje y clica el</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sumario</translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation>botón, o el</translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation>Detalles de idioma</translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation>botón para seleccionar las variedades de lenguajes.</translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation>Es hora de elegir el mensaje que ha de soportar este sitio. Selecciona el lenguaje principal y activa algunos lenguajes adicionales.</translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation>Una vez hecho clica el</translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation>El lenguaje que escoja determinará la configuración de caracteres que usará el sitio.</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Nombre del idioma</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selección</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation>Ahora puedes seleccionar una variación del idioma que has escogido. Una variación hace pequeños ajustes en el idioma, como añadir el soporte al euro o los cambios en el formato de fecha. El uso de estas variaciones es opcional, así que puedes ahorrarte, si quieres, este paso. Una vez hecho, haz clic en el</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation>Ahora puedes seleccionar una variación del idioma que has escogido. Una variación hace pequeños ajustes en el idioma, como añadir el soporte al euro o los cambios en el formato de fecha. El uso de estas variaciones es opcional, así que puedes ahorrarte, si quieres, este paso. Una vez hecho, haz clic en el</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Enviar registro</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Saltarse el registro</translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation>¿Qué tipo de soporte de lenguaje ha de tener este sitio? El tipo de soporte determina la selección del lenguaje y los caracteres.</translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Monolingüe (un solo lenguaje)</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Multilingüe (muchos lenguajes con un solo tipo de carateres)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Multilingüe (Unicode, sin límites)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Opciones regionales</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation>Aquí verás un sumario con las preferencias básicas para ti sitio. Si estás satisfecho con ellas puedes clicar el</translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Configurar base de datos</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation>Sin embargo, si tu quieres cambiar tus preferencias clica el</translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation>Arrancar</translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation>botón que reiniciará la recogida de información (la configuración existente se mantendrá).</translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation>Preferencias de la base de datos</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de datos</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Controlador</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Soporte Unicode</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Preferencias de idioma</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Tipo de idioma</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Monolingüe</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Multilingüe</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>No se han encontrado problemas en tu sistema, puedes continuar clicando el</translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Sistema de ajuste preciso</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Por favor, mira los resultados de abajo para más información sobre qué problemas hay.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>Cada problema te dará las instrucciones para solucionarlo.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>The database is ready for initialization, click the %1 button when ready.</source>
        <translation>La base de datos está lista para la inicialización, clica el botón %1 cuando estés listo.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continúa</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation>La configuración no hace actualizaciones desde otras versiones antiguas de eZ publish (como 2.2.7) si se deja tal como está. Esto solo le importa a la gente que tiene datos existentes que no quiere perder. Si tienes datos de eZ publish 3.0 existentes (tales como una versión RC) has de saltarte la inicialización de la base de datos. No obstante, puedes hacer una actualización manual.</translation>
    </message>
    <message>
        <source>Continue but remove the data first.</source>
        <translation>Continúa pero elimina primero el dato.</translation>
    </message>
    <message>
        <source>Keep data and skip database initialization.</source>
        <translation>Mantén el dato y sáltate la inicialización de la base de datos.</translation>
    </message>
    <message>
        <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
        <translation>Puede que la inicialización de la base de datos tome algo de tiempo, así que por favor, se paciente y espera hasta que la nueva página haya finalizado.</translation>
    </message>
    <message>
        <source>Click the %1 button to start the configuration process.</source>
        <translation>Clica el botón %1 para comenzar el proceso de configuración.</translation>
    </message>
    <message>
        <source>which must be available on the server or</source>
        <translation>el cual está disponible en el servidor o</translation>
    </message>
    <message>
        <source>ez.no</source>
        <translation>ez.no</translation>
    </message>
    <message>
        <source>The default username for the administrator is %1 and the default password is %2.</source>
        <translation>El nombre para el administrador por defecto es %1 y la contraseña por defecto es %2.</translation>
    </message>
    <message>
        <source>Database choice</source>
        <translation>Opción de base de datos</translation>
    </message>
    <message>
        <source>The database would not accept the connection, please review your settings and try again.</source>
        <translation>La base de datos no acepta la conexión. Por favor, revisa tus configuraciones e inténtalo de nuevo.</translation>
    </message>
    <message>
        <source>Password entries did not match.</source>
        <translation>La contraseña introducida no coincide.</translation>
    </message>
    <message>
        <source>The selected database was not empty, please choose from the alternatives below.</source>
        <translation>La base de datos seleccinada no está vacía. Por favor, elige una de las alternativas de abajo.</translation>
    </message>
    <message>
        <source>The selected selected user has not got access to any databases. Change user or create a database for the user.</source>
        <translation>El &quot;usuario seleccionado&quot; que has seleccionado no tiene acceso a ninguna base de datos. Cambia el usuario o crea una base de datos para el usuario.</translation>
    </message>
    <message>
        <source>Database initalization</source>
        <translation>Inicialización de la base de datos</translation>
    </message>
    <message>
        <source>Email settings</source>
        <translation>Configuraciones de correo</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Ternimado</translation>
    </message>
    <message>
        <source>Language options</source>
        <translation>Opciones de idioma</translation>
    </message>
    <message>
        <source>Registration</source>
        <translation>Registro</translation>
    </message>
    <message>
        <source>Securing site</source>
        <translation>Asegurando el sitio</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Acceso del sitio</translation>
    </message>
    <message>
        <source>Site details</source>
        <translation>Detalles del sitio</translation>
    </message>
    <message>
        <source>No templates choosen.</source>
        <translation>No se han encontrado plantillas.</translation>
    </message>
    <message>
        <source>Site template selection</source>
        <translation>Selección de plantillas del sitio</translation>
    </message>
    <message>
        <source>System check</source>
        <translation>Chequeo del sistema</translation>
    </message>
    <message>
        <source>Welcome to eZ publish</source>
        <translation>Bienvenido a eZ publish</translation>
    </message>
    <message>
        <source>Choose database system</source>
        <translation>Elige sistema de base de datos</translation>
    </message>
    <message>
        <source>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</source>
        <translation>Para el soporte unicode en eZ publish se requiere una versión igual o mayor que PostgreSQL o MySQL 4.1.</translation>
    </message>
    <message>
        <source>More information about eZ publish and unicode support can be found %1.</source>
        <translation>Puedes encontrar más información sobre eZ publish y el soporte unicode en %1.</translation>
    </message>
    <message>
        <source>here</source>
        <comment>link to unicode info</comment>
        <translation>aquí</translation>
    </message>
    <message>
        <source>Database initialization</source>
        <translation>Inicialización de la base de datos</translation>
    </message>
    <message>
        <source>If you are using MySQL and do not know what to enter in the socket field, leave it blank</source>
        <translation>Si estás usando MySQL y no sabes como entrar en el campo de toma de corriente, dejalo en blanco</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</source>
        <translation>El cual transmitirá los correos. Si nos estás seguro de qué usar, pregunta a tu webhost. Algunos webhost no dan soporte</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>User site</source>
        <translation>Sitio de usuario</translation>
    </message>
    <message>
        <source>Admin site</source>
        <translation>Sitio de la administración</translation>
    </message>
    <message>
        <source>Make sure to visit the %1 and the %2 web site.</source>
        <translation>Asegúrate de visitar los web sites %1 y %2.</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <comment>eZ publish 3 link</comment>
        <translation>eZ publish</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation>Si necesitas ayuda con eZ publish, puedes ir a %enlace a ez y obtenerla en los foros.
Si encuentras algún error, por favor, ve a %enlace de error y repórtalo.
Con tu ayuda podemos solucionar los errores en eZ publish e implementar nuevas funcionalidades.</translation>
    </message>
    <message>
        <source>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</source>
        <translation>Clica en la URL para acceder a tu nuevo %enlace ez o clica en el botón %botón de hecho. ¡Disfruta de una de los más existosos sistemas web de gestión de contenidos!</translation>
    </message>
    <message>
        <source>Change the second line from %false to %true.</source>
        <translation>Cambia la segunda línea de %falso a %verdadero.</translation>
    </message>
    <message>
        <source>No Unicode support</source>
        <translation>No hay soporte unicode</translation>
    </message>
    <message>
        <source>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</source>
        <translation>El servidor de base de datos al que estás conectado no soporta Unicode, lo que significa que no puedes elegir las lenguas como querías.
Para solucionar estos problemas tienes que hacer algo de lo que sigue:</translation>
    </message>
    <message>
        <source>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won&apos;t work.</source>
        <translation>Elige tan solo lenguas que usen caracteres similares, por ejemplo: el inglés y el noruego pueden trabajar juntos donde el inglés y el ruso no pueden.</translation>
    </message>
    <message>
        <source>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</source>
        <translation>Asegúrate de que el servidor de base de datos está configurado para usar Unicode que tiene el último software que soporta Unicode.</translation>
    </message>
    <message>
        <source>Primary/Additional</source>
        <translation>Primario/Adicional</translation>
    </message>
    <message>
        <source>eZ publish supports multiple languages.</source>
        <translation>eZ publish soporta múltiples lenguajes.</translation>
    </message>
    <message>
        <source>These and other additional languages can also be installed later.</source>
        <translation>Este y otros lenguajes adicionales pueden también instalarse luego.</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>language information link</comment>
        <translation>Documentación</translation>
    </message>
    <message>
        <source>Back</source>
        <comment>back button in installation</comment>
        <translation>Atrás</translation>
    </message>
    <message>
        <source>Refresh</source>
        <comment>Refresh button in installation</comment>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>next button in installation</comment>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Site registration</source>
        <translation>Registro del sitio</translation>
    </message>
    <message>
        <source>By sending registration the following data will be sent to eZ systems</source>
        <translation>Enviando el registro los siguientes datos serán enviados a eZ systems</translation>
    </message>
    <message>
        <source>Site access configuration</source>
        <translation>Configuración del acceso al sitio</translation>
    </message>
    <message>
        <source>URL (recommended)</source>
        <translation>URL (recomendado)</translation>
    </message>
    <message>
        <source>Port. Note: Requires web server configuration </source>
        <translation>Puerto. Nota: requiere la configuración de un servidor web</translation>
    </message>
    <message>
        <source>Hostname. Note: Requires DNS setup.</source>
        <translation>Nombre de alojamineto (Hostname). Nota: requiere configuración DSN.</translation>
    </message>
    <message>
        <source>The path determines access.</source>
        <translation>La ruta determina el acceso.</translation>
    </message>
    <message>
        <source>e.g. %adminsite and %usersite</source>
        <translation>p. ej.: %sitio del administrador y %sitio del usuario</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <source>The port number determines access.*</source>
        <translation>El número de puerto determina el acceso.*</translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Nombre de alojamiento (hostname)</translation>
    </message>
    <message>
        <source>The hostname determines access.*</source>
        <translation>El nombre de alojamiento (hostname) determina el acceso.*</translation>
    </message>
    <message>
        <source>online documentation</source>
        <comment>site access documentation link</comment>
        <translation>Documentación on line</translation>
    </message>
    <message>
        <source>You have chosen the same database for two or more site templates. Please change where indicated by *</source>
        <translation>Has elegido la misma base de datos para dos o más plantillas. Por favor, cámbialas donde esté indicado con *</translation>
    </message>
    <message>
        <source>Site url</source>
        <translation>Url del sitio</translation>
    </message>
    <message>
        <source>Leave the data and add new</source>
        <translation>Dejar los datos y añade nuevos</translation>
    </message>
    <message>
        <source>Remove existing data</source>
        <translation>Eliminar los datos existentes</translation>
    </message>
    <message>
        <source>Leave the data and do nothing</source>
        <translation>Dejar los datos y no hacer nada</translation>
    </message>
    <message>
        <source>I&apos;ve chosen a new database</source>
        <translation>Escogeré una nueva base de datos</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>site access documentation link</comment>
        <translation>documentación</translation>
    </message>
    <message>
        <source>Select which sites you would like to install on your system.</source>
        <translation>Selecciona qué sitios te gustaría instalar en tu sistema.</translation>
    </message>
    <message>
        <source>The system check found some issues that need to be resolved before the setup can continue.</source>
        <translation>El chequeo de sistema encontró algunos temas que deben ser resueltos antes de que la configuración pueda continuar.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</source>
        <translation>Una vez resuelvas los problemas clica el botón %1 para volver a arrancar el chequeo de sistema. También puedes ignorar los test específicos clicando las check boxes.</translation>
    </message>
    <message>
        <source>Ignore this test</source>
        <translation>Ignorar este test</translation>
    </message>
    <message>
        <source>Welcome to eZ publish %1</source>
        <translation>Bienvenido a eZ publish %1</translation>
    </message>
    <message>
        <source>This section will contain information/help about each step in the setup wizard.</source>
        <translation>Esta sección contendrá informaión/ayuda sobre cada paso en el asistente de configuración.</translation>
    </message>
    <message>
        <source>The summary section below will contain information about configured settings.</source>
        <translation>La sección sumario de abajo contendrá información sobre las opciones de configuración.</translation>
    </message>
    <message>
        <source>Information about how to set up eZ publish manually is available %1.</source>
        <translation>La información sobre como configurar manualmente eZ publish está disponible en %1.</translation>
    </message>
    <message>
        <source>here</source>
        <comment>manual installation link</comment>
        <translation>aquí</translation>
    </message>
    <message>
        <source>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</source>
        <translation>Se ha detectado soporte a MySQL y PostgreSQL en tu sistema. Elige que base de datos quieres utilizar.</translation>
    </message>
    <message>
        <source>eZ publish supports both MySQL and PostgreSQL.</source>
        <translation>eZ publish tiene soporte para MySQL y para PostgreSQL.</translation>
    </message>
    <message>
        <source>Please input database access information in the form below.</source>
        <translation>Introduce la información de acceso a la base de datos en el formulario de abajo.</translation>
    </message>
    <message>
        <source>If you don&apos;t have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you&apos;re unsure about how to create a database.</source>
        <translation>Si no tienes acceso a la base de datos, lo puedes obtener ahora. eZ publish es capaz de hacer funcionar diferentes sitios. Cada sitio necesita su propia base de datos, lo que quiere decir que tienes que crear diversas bases de datos si quieres arrancar diferentes sitios. Consulta el manual de usuario de la base de datos si no estás seguro de cómo se crea una base de datos.</translation>
    </message>
    <message>
        <source>Outgoing E-mail</source>
        <translation>Correo saliendo</translation>
    </message>
    <message>
        <source>This section is used to configure how eZ publish delivers its outgoing E-mail.</source>
        <translation>Esta sección sirve para configurar cómo eZ publish entrega el correo saliente.</translation>
    </message>
    <message>
        <source>There are two options:&lt;br&gt;- Direct delivery through sendmail (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
        <translation>Hay dos opciones: &lt;br&gt;- Entrega directamente a través del &quot;sendmail&quot; (ha de estar disponible en el servidor).&lt;br&gt;- La entrega indirecta utiliza el servidor retardado SMTP.</translation>
    </message>
    <message>
        <source>SMTP is recommended for MS Windows users.</source>
        <translation>Para usuarios de Windows es recomendable el uso de SMTP.</translation>
    </message>
    <message>
        <source>E-mail delivery</source>
        <translation>Entrega de la lista de correo</translation>
    </message>
    <message>
        <source>Server name: </source>
        <translation>Nombre del servidor:</translation>
    </message>
    <message>
        <source>Username (optional): </source>
        <translation>Nombre del usuario (opcional):</translation>
    </message>
    <message>
        <source>Password (optional): </source>
        <translation>Contraseña (opcional):</translation>
    </message>
    <message>
        <source>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</source>
        <translation>eZ publish utiliza el correo para enviar información importante, tal como el registro de usuario y la aprobación de los contenidos.Sobre Linux/Unix,: prueba usuando el &quot;sendmail&quot;. Sobre Windows: usa  el servidor SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Sendmail:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the sendmail transfer agent. The sendmail binary is usually available on most Linux/UNIX systems. If sendmail is not available then SMTP should be used.</source>
        <translation>&lt;b&gt;Sendmail:&lt;/b&gt;&lt;br&gt;El correo se envía directamente usando el agente de transferencia &quot;sendmail&quot;. El &quot;sendmail&quot; binario normalmente está disponible en la mayoría de sistemas Linux/UNIX. Si no tienes disponible el &quot;sendmail&quot;,  se usará el SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</source>
        <translation>&lt;b&gt;SMTP&lt;/b&gt;&lt;br&gt;El correo se sirve a través de un servidor SMTP. Hay que especificar, al menos, el nombre del servidor SMTP. Una pista: comprueba la configuración STMP en tu aplicación de correo electrónico.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval.</source>
        <translation>El correo electrónico se usa para transmitir noticias importantes, tales como el registro y la aprovación de contenidos.</translation>
    </message>
    <message>
        <source>Most Unix systems support sendmail, while windows users must choose SMTP.</source>
        <translation>La mayoría de los sistemas UNIX tienen soporte para el &quot;sendmail&quot;. En cambio, los usuarios de Windows tienen que elegir el SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP&lt;/b&gt;: If you&apos;re unsure what to enter, take a look at the settings in your e-mail application.</source>
        <translation>&lt;b&gt;SMTP&lt;/b&gt;: Si no estás seguro de lo que has de introducir, echa un vistazo a la configuración de tu aplicación de correo.</translation>
    </message>
    <message>
        <source>eZ publish has been installed with the following sites. You will find the username and password mentioned for each site.</source>
        <translation>eZ publish se ha instalado también con los siguientes sitios. Encontrarás el nombre de usuario y la contraseña mencionados para cada sitio.</translation>
    </message>
    <message>
        <source>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</source>
        <translation>Consejo: almacena esta página como fichero HTML haciendo clic en la opción &quot;Guardar como&quot; (Save as) del menú de tu navegador.</translation>
    </message>
    <message>
        <source>forums</source>
        <comment>forum link</comment>
        <translation>foros</translation>
    </message>
    <message>
        <source>Language support</source>
        <translation>Soporte de idioma</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the primary language, and the checkboxes to choose additional languages. You may choose more than one additional language.</source>
        <translation>Utiliza las checkboxes para seleccionar el idioma principal, y los cuadros de configuración para escoger idiomas adicionales. Puedes escoger más de un idioma adicional.</translation>
    </message>
    <message>
        <source>The selected languages are used to determine character sets, date / number formats, etc.</source>
        <translation>Los idiomas seleccionados son usados para determinar el juego de caracteres, formato de datos o números, etc.</translation>
    </message>
    <message>
        <source>For more information about language customization, please refer to the %1.</source>
        <translation>Si quieres más información sobre la personalización del idioma, dirígete a %1.</translation>
    </message>
    <message>
        <source>If you wish, you can also add some comments, which will be included in the registration E-mail.</source>
        <translation>Si quieres, también puedes añadir comentarios, que se incluirán en el correo de registro.</translation>
    </message>
    <message>
        <source>Send registration</source>
        <translation>Enviar registro</translation>
    </message>
    <message>
        <source>System details (OS type, etc)</source>
        <translation>Detalles de sistema (sistema operativo, etc.)</translation>
    </message>
    <message>
        <source>The test results</source>
        <translation>Los últimos resultados</translation>
    </message>
    <message>
        <source>The database type</source>
        <translation>El tipo de base de datos</translation>
    </message>
    <message>
        <source>The site name</source>
        <translation>El nombre del sitio</translation>
    </message>
    <message>
        <source>The url of the site</source>
        <translation>La url del sitio</translation>
    </message>
    <message>
        <source>Languages chosen</source>
        <translation>Idiomas elegidos</translation>
    </message>
    <message>
        <source>This data will help to improve future releases of eZ publish.</source>
        <translation>Esta información nos ayudará a mejorar nuevas versiones de eZ publish.</translation>
    </message>
    <message>
        <source>Site security</source>
        <translation>Seguridad del sitio</translation>
    </message>
    <message>
        <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</source>
        <translation>Tu sitio no está funcionando en modo de servidor virtual. Este es unn modo inseguro. Es recomendable hacer funcionar eZ publish en un modo de servidor virtual. Si no tienes la posibilidad de usar este modo, sigue las instrucciones de abajo para sabre cómo instalar un fichero .htacces. Un fichero .htacces pide al servidor web que restrinja el acceso a determinados ficheros.</translation>
    </message>
    <message>
        <source>If you have shell access, you can run the following commmands.</source>
        <translation>Si tienes acceso al intérprete de órdenes, puedes hacer funcionar los comandos siguientes.</translation>
    </message>
    <message>
        <source>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</source>
        <translation>Si no tienes acceso al intérprete de órdenes, tendrás que copiar el fichero usando un cliente de FTP o pedir a tu proveedor de espacio web que lo haga por ti.</translation>
    </message>
    <message>
        <source>This security tweak takes care of protecting configuration files and other important files.</source>
        <translation>Este pequeño cambio de seguridad se encarga de proteger ficheros de configuración y otros ficheros importantes.</translation>
    </message>
    <message>
        <source>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
        <translation>Elige el método de acceso quieres usar para tu sitio. Este método determina como se accederá al sitio desde un navegador web. Si no estás seguro, elige URL.</translation>
    </message>
    <message>
        <source>Port*</source>
        <translation>Puerto*</translation>
    </message>
    <message>
        <source>* Requires web server setup.</source>
        <translation>* Es necesario que configures el servidor web.</translation>
    </message>
    <message>
        <source>Hostname*</source>
        <translation>Nombre del servidor*</translation>
    </message>
    <message>
        <source>* Requires DNS setup.</source>
        <translation>* Es necesario que configures el DNS.</translation>
    </message>
    <message>
        <source>For more detailed information on site access, please refer to the %1</source>
        <translation>Si quieres más información sobre el acceso al sitio, dirígete a %1</translation>
    </message>
    <message>
        <source>User path</source>
        <translation>Ruta del usuario</translation>
    </message>
    <message>
        <source>User port</source>
        <translation>Puerto del usuario</translation>
    </message>
    <message>
        <source>User hostname</source>
        <translation>Nombre del servidor de usuario</translation>
    </message>
    <message>
        <source>Admin path</source>
        <translation>Ruta de la administración</translation>
    </message>
    <message>
        <source>Admin port</source>
        <translation>Puerto de la administración</translation>
    </message>
    <message>
        <source>Admin hostname</source>
        <translation>Nombre del servidor de la administración</translation>
    </message>
    <message>
        <source>You may modify the details for each site.</source>
        <translation>Puedes modificar los detalles para cada sitio.</translation>
    </message>
    <message>
        <source>For more information about how to configure site access, please refer to the %1</source>
        <translation>Si quieres más información sobre cómo configurar el acceso al sitio, dirígete a %1</translation>
    </message>
    <message>
        <source>Use the refresh button to update the database listing.</source>
        <translation>Utiliza el botón de refresco para actualizar la lista de la base de datos.</translation>
    </message>
    <message>
        <source>Next &amp;gt;</source>
        <translation>Siguiente &amp;gt;</translation>
    </message>
    <message>
        <source>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Hay algunas cuestiones importantes que han de resolverse. La lista se presenta abajo. Cada sección tiene una descripción y una solución recomendada o sugerida.</translation>
    </message>
    <message>
        <source>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</source>
        <translation>Una vez que los problemas / cuestiones se hayan solucionado, puedes hacer clic en el botón &lt;i&gt;Siguiente&lt;/i&gt; para continuar. La comprobación de sistema arrancará de nuevo. Si todo es correcto, la configuración continuará hasta el estadio siguiente. Ante cualquier problema volverá a aparecer la página de comprobación del sistema.</translation>
    </message>
    <message>
        <source>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</source>
        <translation>Algunas cuestiones pueden ser ignoradas al marcar la(s) casilla(s) &lt;i&gt;ignora esta prueba&lt;/i&gt;; aún así, no es recomendable.</translation>
    </message>
    <message>
        <source>The system check page is being displayed. This means that there are some problems/issues present.</source>
        <translation>Se está mostrando las página del comprobador del sistema. Esto quiere decir que hay algunos problemas o cuestiones.</translation>
    </message>
    <message>
        <source>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</source>
        <translation>Estos temas se han de resolver o solucionar. Si no, eZ publish no funcionará correctamente.</translation>
    </message>
    <message>
        <source>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</source>
        <translation>Los problemas están habitualmente relacionados con el sistema de archivos y se pueden solucionar con un corta y pega los comandos sugeridos en el sistema de intérprete de comandos.</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</source>
        <translation>Bienvenido/a al sistema de contenidos y marco de desarrollo eZ publish. Este asistente te ayudará a configurar eZ publish. &lt;br&gt;Haz clic en &lt;i&gt;Siguiente&lt;/i&gt; para continuar.</translation>
    </message>
    <message>
        <source>No data will be stored in the database until the final step of the setup.</source>
        <translation>No se almacenará ningun dato en la base de datos hasta el último paso de la configuración.</translation>
    </message>
    <message>
        <source>Site packages</source>
        <translation>Paquetes del sitio</translation>
    </message>
    <message>
        <source>Each package will create a unique web site.</source>
        <translation>Cada paquete creará un único sitio web.</translation>
    </message>
    <message>
        <source>Since each web site is unique, each package requires a unique database.</source>
        <translation>Como cada sitio web es único, cada paquete requiere una única base de datos.</translation>
    </message>
    <message>
        <source>System finetuning</source>
        <translation>Ajuste preciso del sistema</translation>
    </message>
    <message>
        <source>Finetune</source>
        <comment>Finetune button in installation</comment>
        <translation>Ajuste preciso</translation>
    </message>
    <message>
        <source>It is also possible to do some finetuning of your system, click &lt;i&gt;Finetune&lt;/i&gt; instead &lt;i&gt;Next&lt;/i&gt; if you want to see the finetuning hints.</source>
        <translation>También se puede ajustar el sistema de forma precisa, haz click en &lt;i&gt;Ajuste preciso&lt;/i&gt; en lugar de &lt;i&gt;Siguiente&lt;/i&gt; si quiere ver las opciones de ajuste preciso.</translation>
    </message>
    <message>
        <source>There are some issues that should be resolved to get maximum performance and features. A list of issues is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Hay algunas cuestiones que deberían estar arregladas para tener un rendimiento óptimo. Una lista esta presentada abajo. Cada sección contiene una descripción y una solución sugerida.</translation>
    </message>
    <message>
        <source>Once the issues are handled, you may click the &lt;i&gt;Finetune&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If the issues are not solved the system finetune page will reappear.</source>
        <translation>Una vez que esos temas estan arreglados, puede hacer click en el botón &lt;i&gt;Ajuste preciso&lt;/i&gt; para continuar. Se volverá a ejecutar la comprobación del sistema. Si todo esta correcto, el configurador pasará al paso siguiente. Si los temas no estan arreglados la página de ajuste preciso del sistema volverá a aparecer.</translation>
    </message>
    <message>
        <source>If you do not want to fix these issues just click &lt;i&gt;Next&lt;/i&gt;.</source>
        <translation>Si no quiere arreglar esos temas haz click en &lt;i&gt;Next&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>The system finetune page is being displayed. This means that there are some issues which can be solved to improve the performance or features.</source>
        <translation>Se esta visualizando la página de ajuste preciso del sistema. Significa que unos temas podrían estar arreglado para mejorar el rendimiento o las funcionalidades.</translation>
    </message>
    <message>
        <source>These issues do not need to be resolved/fixed. eZ publish will function properly without them.</source>
        <translation>Esos temas no necesitan estar arreglados. eZ publish funcionará correctamente sin ellos.</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Your system is not optimal, if you wish you can click the &lt;i&gt;Finetune&lt;/i&gt; button. This will present hints on how to fix these issues.&lt;br/&gt; Click &lt;i&gt;Next&lt;/i&gt; to continue without finetuning.</source>
        <translation>Bienvenido en el sistema de gestión de contenio y en el framework de desarrollo eZ publish. Este asitante le va a ayudar a configurar eZ publish.&lt;br&gt;Su sistema no es óptimo, si quiere puede hacer click en el botón &lt;i&gt;Ajuste preciso&lt;/i&gt;. Le enseñará unos trucos para arreglar esos temas.&lt;br/&gt; Haz click en &lt;i&gt;Siguiente&lt;/i&gt; para seguir sin el ajuste preciso. </translation>
    </message>
    <message>
        <source>Site administrator</source>
        <translation>Administrador del sitio</translation>
    </message>
    <message>
        <source>No packages choosen.</source>
        <translation>Ningún paquete eligido.</translation>
    </message>
    <message>
        <source>Site functionality</source>
        <translation>Funcionalidades del sitio</translation>
    </message>
    <message>
        <source>No site choosen.</source>
        <translation>Ningún sitio eligido.</translation>
    </message>
    <message>
        <source>Site selection</source>
        <translation>Selección de sitio</translation>
    </message>
    <message>
        <source>The first time the user or admin site is accessed it will take some time (30 to 60 seconds). This is because eZ publish prepares the site for your machine.</source>
        <translation>La primera vez que se accede a la parte pública o de administración del sitio, se va a necesitar mucho tiempo (de 30 hasta 60 segundos). Esto occure porqué eZ publish prepara el sito para tu máquina.</translation>
    </message>
    <message>
        <source>This page lets you modify the administrator for your site. This ensures that your site is secure and has proper name and E-mail set.</source>
        <translation>Esta página permite cambiar el administrador del sitio. Esto asegura que el sitio sea seguro y que tenga su propio nombre y su dirección de correo puesta.</translation>
    </message>
    <message>
        <source>You need to fill in the first name.</source>
        <translation>Tienes que introducir el nombre.</translation>
    </message>
    <message>
        <source>You need to fill in the last name.</source>
        <translation>Tienes que introducir el apellido.</translation>
    </message>
    <message>
        <source>You need to fill in an e-mail address.</source>
        <translation>Tienes que poner la dirección de correo electronico.</translation>
    </message>
    <message>
        <source>You need to fill in a valid e-mail address.</source>
        <translation>Tienes que poner una dirección de correo electronico valida.</translation>
    </message>
    <message>
        <source>Your passwords do not match.</source>
        <translation>Las contraseñas no coinciden.</translation>
    </message>
    <message>
        <source>You need to fill in a password.</source>
        <translation>Tienes que introducir una contraseña.</translation>
    </message>
    <message>
        <source>Administrator settings</source>
        <translation>Configuración del administrador</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Apellido</translation>
    </message>
    <message>
        <source>E-mail address</source>
        <translation>Dirección de correo electronico</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Confirmar contraseña</translation>
    </message>
    <message>
        <source>The login name is fixed and cannot be changed.
After the setup is done you can login with %admin_login and your password.</source>
        <translation>El nombre de usuario es fijo y no se puede cambiar.
Una vez la configuración acabada, puedes conectarte con %admin_login y tu contraseña.</translation>
    </message>
    <message>
        <source>This page lets you modify information about the site you&apos;ve chosen to install. In addition, it also lets you choose a database for the site.</source>
        <translation>Esta página permite cambiar la información del sitio que se ha eligido para instalar. Además, permite eligir la base de datos para este sitio.</translation>
    </message>
    <message>
        <source>Host names should not include underscores (&apos;_&apos;), as this violates the DNS RFC and will cause problems with Internet Explorer. They have been converted to dashes (&apos;-&apos;).</source>
        <translation>Los nombre de sitios no pueden tener sobrayados (&quot;underscores&quot;: &apos;_&apos;), porqué esto viola la norma de DNS (DNS RFC) y puede poner problemas con Internet Explorar. Han sido cambiados por guillones (&apos;-&apos;).</translation>
    </message>
    <message>
        <source>The access values must not be named &apos;admin&apos; or &apos;user&apos; and each values must be unique. Please change invalid values on site indicated by *</source>
        <translation>El nombre del acceso no puede ser &apos;admin&apos; ni &apos;user&apos; y cada nombre tiene que ser único. Por favor, cambia los nombre invalidos indicados por *</translation>
    </message>
    <message>
        <source>Your database already contain data.
The setup can continue with the initialization but may damage the present data.</source>
        <translation>La base de datos ya contiene datos.
El configurador puede seguir la initialización pero puede dañar los datos presentes.</translation>
    </message>
    <message>
        <source>Select what to do from the drop-down box.</source>
        <translation>Elige que hacer con la caja desplegable.</translation>
    </message>
    <message>
        <source>Action: </source>
        <translation>Acción:</translation>
    </message>
    <message>
        <source>Current site functionality</source>
        <translation>Funcionalidades actuales del sitio</translation>
    </message>
    <message>
        <source>Please select additional functionality</source>
        <translation>Por favor, elige más funcionalidades</translation>
    </message>
    <message>
        <source>Each site comes with a predefined set of functionality, however it is possible to add extra functionality.
This functionality is also available at a later time from the administration interface.</source>
        <translation>Cada sitio viene con un conjunto de funcionalidades predeterminado, pero es posible de añadir una funcionalidades extra.
Esta funcionalidad queda también disponible más adelante desde la interfaz de administración.</translation>
    </message>
    <message>
        <source>Site type</source>
        <translation>Tipo de sitio</translation>
    </message>
    <message>
        <source>The type of site will choose some basic settings for toolbars, menus, color and functionality.
It is possible to change these settings at a later time.</source>
        <translation>El tipo de sitio va a eligir unas configuraciones básicas para la barra de herramientas, los menus, las colores y las funcionalidades.
Queda la posibilidad de cambiar esas configuraciones más adelante.</translation>
    </message>
    <message>
        <source>Creating sites</source>
        <translation>Creando sitios</translation>
    </message>
    <message>
        <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the PHP documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that PostgreSQL 7.2 is not supported.</source>
        <translation>Por favor asegúrate de que el nombre de usuario y la contraseña son correctos. Verifica que tu base de datos PostgreSQL está configurada correctamente.&lt;br&gt;Revisa la documentación PHP para obtener más información sobre esto.&lt;br&gt;Recuerda de arrancar postmaster con la opción -i.&lt;br&gt;Recuerda que PostgreSQL 7.2 no está soportado.</translation>
    </message>
    <message>
        <source>The &apos;digest&apos; procedure is not available in your database, you cannot run eZ publish without this. Visit the FAQ for more information.</source>
        <translation>El procedimiento &apos;digest&apos; no esta disponible en su base de datos. No se puede usar eZ publish sin esta funcionalidad. Mirar las FAQ para obtener más información.</translation>
    </message>
    <message>
        <source>Your database version %version does not fit the minimum requirement which is %req_version.</source>
        <translation>La versión de tu base de datos no cumple los siguientes requerimientos mínimos %req_version.</translation>
    </message>
    <message>
        <source>The setup wizard was not able to complete the creation of your selected sites.</source>
        <translation>El asistente de instalación no pudo completar la creación de tus sitios seleccionados.</translation>
    </message>
    <message>
        <source>The following errors were detected:</source>
        <translation>Se detectaron los siguientes errores:</translation>
    </message>
    <message>
        <source>If you think you have fixed the errors you can try and click the &quot;Retry&quot; button.</source>
        <translation>Si crees que has corregido los errores puedes pulsar el botón &quot;Inténtalo de nuevo&quot;.</translation>
    </message>
    <message>
        <source>The setup wizard failed to create the sites.</source>
        <translation>El asistente de instalación falló al crear los sitios.</translation>
    </message>
    <message>
        <source>If possible try to fix these errors and click &quot;Retry&quot;.</source>
        <translation>Si es posible intenta corregir estos errores y pulsa el botón &quot;Inténtalo de nuevo&quot;.</translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilities of eZ publish</source>
        <translation>Si quieres puedes dejar que la instalación añada datos de prueba en tu base de datos, estos datos son una demostración de las capacidades de eZ publish</translation>
    </message>
    <message>
        <source>First time users are advised to install the demo data.</source>
        <translation>Se recomienda a los usuarios que usan eZ por primera vez que usen los datos de prueba.</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>The database was sucessfully initialized. You are now ready for some post configuration of the site.</source>
        <translation>La base de datos se inicializó correctamente. Ahora estás listo para configurar el sitio.</translation>
    </message>
    <message>
        <source>Servername</source>
        <translation>Nombre del servidor</translation>
    </message>
    <message>
        <source>Socket (optional)</source>
        <translation>Socket (opcional)</translation>
    </message>
    <message>
        <source>PostgreSQL username and password is not tested until database names are selected.</source>
        <translation>El nombre de usuario y la contraseña de PostgreSQL no se comprueban hasta haber seleccionado una base de datos.</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says</source>
        <translation>Opcionalmente puedes desabilitar esto manualmente, edita el archivo &lt;i&gt;settings/site.ini&lt;/i&gt; y busca la línea</translation>
    </message>
    <message>
        <source>Sending e-mail failed</source>
        <translation>Fallo al enviar el e-mail</translation>
    </message>
    <message>
        <source>Failed to send the registration email using</source>
        <translation>Fallo al enviar el email de registro usando</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file %filename and look for a line that says</source>
        <translation>Si quieres volver a reiniciar la instalación, edita el archivo %filename y busca la línea</translation>
    </message>
    <message>
        <source>Retry</source>
        <comment>Retry button in installation</comment>
        <translation>Inténtalo de nuevo</translation>
    </message>
    <message>
        <source>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited e-mails.</source>
        <translation>Si lo deseas, puedes registrar esta instalación enviando información a eZ systems. No se transmitirán datos confidenciales y eZ systems no usará o venderá tus detalles para recibir correos no deseados.  </translation>
    </message>
    <message>
        <source>The registration e-mail</source>
        <translation>El e-mail de registro</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <source>Sending out the e-mail and generating your site will take about 10 to 30 seconds depending on your machine. Please wait until the next page loads. Clicking the button again will only send out duplicate e-mails, and may corrupt the installation.</source>
        <translation>Enviar el e-mail y generar el sitio tardará de 10 a 30 segundos dependiendo de tu máquina. Por favor, espera hasta que la siguiente página cargue. Pulsando el botón otra vez sólo enviarás e-mails duplicados, e incluso puedes corromper la instalación. </translation>
    </message>
    <message>
        <source>The database %database_name cannot be used, it uses the character set %charset which is different from the requested charset %req_charset.</source>
        <translation>La base de datos %database_name no puede ser utilizada. Esta base de datos utiliza el juego de caracteros %charset que es diferente del eligido: %req_charset.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Ejemplo</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Constructor, no hace nada por defecto.</translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>\retornar una tabla con el nombre de operador de plantillas.</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Ejecuta la función PHP para la limpieza del operador y modifica \a $operatorValue.</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Código de ejemplo. Este código debe ser modificado para hacer lo que el operador debe hacer. Actualmente solo limpia texto.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/session</name>
    <message>
        <source>Session admin</source>
        <translation>Sesión de administración</translation>
    </message>
    <message>
        <source>The sessions were successfully removed.</source>
        <translation>Las sesiones han sido eliminadas correctamente.</translation>
    </message>
    <message>
        <source>Sessions</source>
        <translation>Sesiones</translation>
    </message>
    <message>
        <source>Use the buttons below to delete the session entries that are present in the database.</source>
        <translation>Haz click en el botón más abajo para eliminar las sesiones presentes en la base de datos.</translation>
    </message>
    <message>
        <source>WARNING! When removing sessions, users that are logged in will be thrown out from the system.</source>
        <translation>¡CUIDADO! Cuando se eliminan las sesiones, los usuarios que estan conectados van a estar desconectados del sistema.</translation>
    </message>
    <message>
        <source>Remove all sessions</source>
        <translation>Eliminar todas las sesiones</translation>
    </message>
    <message>
        <source>Remove timed out / old sessions</source>
        <translation>Eliminar las sesiones caducadas y antiguas</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Full name</source>
        <translation>Nombre y apellido</translation>
    </message>
    <message>
        <source>Idle time</source>
        <translation>Tiempo de inactividad</translation>
    </message>
    <message>
        <source>Idle since</source>
        <translation>Inactivo desde</translation>
    </message>
    <message>
        <source>Time skew detected</source>
        <translation>Tiempo raro detectado</translation>
    </message>
    <message>
        <source>Total number of sessions</source>
        <translation>Total de sesiones</translation>
    </message>
    <message>
        <source>Displaying sessions for %username</source>
        <translation>Mostrando las sesiones de %username</translation>
    </message>
    <message>
        <source>Show from all users</source>
        <translation>Mostrar de todos los usuarios</translation>
    </message>
    <message>
        <source>Filter sessions</source>
        <translation>Filtrar sesiones</translation>
    </message>
    <message>
        <source>Everyone</source>
        <translation>Todos</translation>
    </message>
    <message>
        <source>Registered users</source>
        <translation>Usuarios registrados</translation>
    </message>
    <message>
        <source>Anonymous users</source>
        <translation>Usuarios anónimos</translation>
    </message>
    <message>
        <source>Include inactive users</source>
        <translation>Incluir usuarios inactivos</translation>
    </message>
    <message>
        <source>Update list</source>
        <translation>Actualizar lista</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cuenta</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/session </name>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Se han perdido los procesadores de la base de datos</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Tu PHP no tiene soporte para todas las bases de datos que soporta eZ publish.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>También algunas bases de datos tienen  más características avanzadas, tales como caracteres, entre otros.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Para obtener mayor soporte de base de datos necesitas recompilar PHP, el extracto de opciones de recompilación esta especificado debajo.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Se ha perdido el procesador de la base de datos</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>No se encontraron los procesadores de las base de datos soportada. eZ publish requiere una base de datos para almacenar sus datos, sin la cula el sistema fallará.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Para obtener soporte de la base de datos necesitas recompilar PHP, el extracto de las opciones de recompolación está especificado debaje.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Permisos de directorio insuficientes</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish no puede escribir algunos directorios importantes, sin ellos, la configuración no puede finalizarse y partes del eZ publish podrían fallar.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>Es recomendable que lo soluciones con los comandos de abajo.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Comandos de Shell</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>La carga de ficheros está deshabilitada</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>La carga de ficheros no está habilitada, por lo que eZ publish no puede manipularla. El resto de partes de eZ publish funcionará correctamente, pero es recomendable que actives la carga de ficheros.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>La activación de la carga de ficheros se hace mediante %1 al php.ini. Consulta el manual de PHP para saber cómo hacer cambios en la configuración</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Puedes encontrar más información sobre la activación de la aplicación leyendo %1 y %2</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>El soporte a la conversión de imágenes está ausente</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>No se han detectado capacidades de conversión de imágenes, lo que significa que eZ publish no puede escalarlas o detectar su tipo. Esta es una funcionalidad vital en eZ publish y debe de ser soportada.</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>El operador de la plantilla no estará disponible.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Nota:</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>Las próximas versiones de eZ publish tendrán más soporte avanzado para imágenes con el uso de la extensión de imágenes GD.</translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Programa ImageMagik perdido</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>El programa ImageMagick no está disponible en eZ publish. Sin ella, eZ publish no podrá convertir imágenes hasta que la extensión de imágenes GD esté disponible.</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>Si sabes dónde está instalado el programa (el ejecutable se llama</translation>
    </message>
    <message>
        <source>or</source>
        <translation>o</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>), introduce entonces el directorio en el campo de entrada inferior y vuelve a hacer una comprobación (separa directorios múltiples con un</translation>
    </message>
    <message>
        <source>colon</source>
        <translation>dos puntos</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>punto y coma</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Instalación</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>ImageMagick puede ser descargado desde</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>Extensión MBString perdida</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>eZ publish incluye una buena lista de codificación de caracteres soportados. Aún así, pueden ser un poco lentos, ya que están hechos en PHP puro. Afortunadamente, eZ publish soporta la extensión MBStrings para manipular alguna de las codificaciones de caracteres.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>Activando la extensión MBString, eZ publish tendrá acceso a más codificación de caracteres y también podrá procesar algunos de ellos más rápidamente, como el Unicode o el ISO-8859·* Esto está recomendado para sitios multiidiomas y sitios con codificaciones más exóticas.</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>La instalación de las extensiones mbstring está hecha a través de la compilación PHP con el</translation>
    </message>
    <message>
        <source>option.</source>
        <translation>opción.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>Puedes encontrar más información sobre la activación de la extensión en</translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>No actives la sobrecarga de la extensión MBString. eZ publish solo utilizará la extensión cuando la necesite.</translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>Opción PHP</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>está permitida</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish trabajará con esta opción activada. Aún así, comportará un menor rendimiento hasta que todas las variables de entrada necesiten volver a convertirse en</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Versión PHP insuficiente</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Tu versión PHP, tal cuál está,</translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>,no reune los requerimientos mínimos</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>Puedes descargarte una versión PHP más nueva en</translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>Debes actualizar al menos la versión</translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish no puede escribir en el</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>directorio. Sin esto la configuración no podrá desactivarse por ella misma.</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>La extensión zlib está ausente</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>La extensión alib no está disponible en eZ publish. Sin esta extensión eZ publish no podrá instalar los datos de demostración. Sin embargo, si tu no quieres estos datos de demostración, puedes ignorar tranquilamente este hecho.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>Para activar zlib, hace falta que vuelvas a compilar PHP con soporte para esta extensión. Necesitarás configurar PHP con</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>Hay más información disponible sobre este objeto en</translation>
    </message>
    <message>
        <source>More information on the subject can be found at %1.</source>
        <translation>Más información sobre el sujeto puede encontrarse en %1.</translation>
    </message>
    <message>
        <source>PHP option %1 is enabled</source>
        <translation>La opción PHP %1 está habilitada</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
        <translation>eZ publish puede trabajar con esta opción encendida, sin embargo te comportará una reproducción inferior hasta que todas las variables de entrada se conviertan en generales para cada ejecución de script.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
        <translation>Se recomienda que la opción esté apagada. Para apagarla edita tu configuración %1 y fija %2 a %3.</translation>
    </message>
    <message>
        <source>PHP safe mode is enabled</source>
        <translation>El modo seguro PHP está activado</translation>
    </message>
    <message>
        <source>Insufficient execution time allowed to install eZ publish</source>
        <translation>Tiempo permitido insuficiente para instalar eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a execution time limit of %1.</source>
        <translation>eZ publish no funcionará correctamente con un tiempo límite de ejecución de %1.</translation>
    </message>
    <message>
        <source>It&apos;s highly recommended that you fix this.</source>
        <translation>Es muy recomendable que soluciones esto.</translation>
    </message>
    <message>
        <source>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</source>
        <translation>Localiza el archivo php.ini para tu instalación PHP. En los sistemas UNIX, normalmente está en /etc/php.ini; en Windows, comprueba la ruta de instalación de PHP.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</source>
        <translation>Abre el archivo php.ini y cambia el valor del tiempo máximo de ejecución (max_execution_time) a un mínimo de %1, y clica en %2</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</source>
        <translation>Si estás haciendo funcionar eZ publish en un entorno compartido, ponte en contacto con tu ISP para efectuar cambios</translation>
    </message>
    <message>
        <source>Insufficient memory allocated to install eZ publish</source>
        <translation>Memoria asignada insuficiente para instalar eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a memory limit of %1.</source>
        <translation>eZ publish no funcionará correctamente con un límite de memoria de %1.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the memory_limit value to at least %1, and press %2</source>
        <translation>Abre el archivo php.ini y cambia el valor del límite de memoria (memory_limit) a un mínimo de %1, y clica en %2</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</source>
        <translation>Es recomendable que la opción esté deshabilitada. Para hacerlo, edita la configuración %phpini y pon %magic_quotes_gpc y %magic_quotes_runtime en %offtext.</translation>
    </message>
    <message>
        <source>eZ publish will not work properly with this option on.</source>
        <translation>eZ publish no funcionará correctamente con la opción habilitada.</translation>
    </message>
    <message>
        <source>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</source>
        <translation>para deshabilitarla, edita la configuración %phpini y pon %magic_quotes_runtime en %offtext.</translation>
    </message>
    <message>
        <source>Unstable PHP version</source>
        <translation>Versión PHP inestable</translation>
    </message>
    <message>
        <source>, is known to be unstable</source>
        <translation>, es conocida por ser inestable</translation>
    </message>
    <message>
        <source>Another version of PHP can be download at</source>
        <translation>Puedes descargar otra versión de PHP en</translation>
    </message>
    <message>
        <source>AcceptPathInfo disabled or running in CGI mode</source>
        <translation>AcceptPathInfo esta desactivado o corriendo en modo CGI</translation>
    </message>
    <message>
        <source>enter the following into your httpd.conf file.</source>
        <translation>Poner lo siguiente en el archivo httpd.conf.</translation>
    </message>
    <message>
        <source>Remember to restart your web server afterwards.</source>
        <translation>No olvide de reiniciar el servidor web despues.</translation>
    </message>
    <message>
        <source>Missing imagegd2 extension</source>
        <translation>La extensión imagegd2 está ausente</translation>
    </message>
    <message>
        <source>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>La extensión imagegd2 no esta disponible. Sin ella, eZ publish solo podrá hacer las converciones utilizando ImageMagick y el</translation>
    </message>
    <message>
        <source>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>Para activar imagegd2 es necesario recompilar PHP con imagegd2 activado, más informaciones sobre este tema esta disponible en</translation>
    </message>
    <message>
        <source>Missing text creation functions</source>
        <translation>Las funciones de creación de texto estan ausentes</translation>
    </message>
    <message>
        <source>The PHP functions ImageTTFText and ImageTTFBBox is missing. Without these functions it is not possible to use the texttoimage template operator.</source>
        <translation>Las funciones PHP ImageTTFText y ImageTTFBBox estan ausente. Sin esas funciones no se puede usar el operador de plantilla texttoimage.</translation>
    </message>
    <message>
        <source>To enable these functions you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>Para activar esas funciones es necesario recompilar PHP, más informaciones sobre este tema esta disponible en</translation>
    </message>
    <message>
        <source>Missing Session Extension</source>
        <translation>Falta la extensión de sesión</translation>
    </message>
    <message>
        <source>Your PHP module does not have session support, without this eZ publish will not work properly.</source>
        <translation>El modulo PHP no tiene soporte para las sesiones, sin eso eZ publish no puede funcionar correctamente.</translation>
    </message>
    <message>
        <source>To enable session support you will have recompile your PHP module without the %session_disable switch.</source>
        <translation>Para activar el soporte de sesiones, se tiene que volver a compilar el modulo PHP sin la opción %session_disable.</translation>
    </message>
    <message>
        <source>If your site is on shared-hosting you must contact the system administrator of the hosting company.</source>
        <translation>Si el sitio web esta en un alojamiento compartido, hay que tomar contacto con el administrador de sistema de la empresa de alojamiento.</translation>
    </message>
    <message>
        <source>, but the latest released PHP 4.3.x version is highly recommended.</source>
        <translation>, pero la última versión disponible PHP 4.3.x esta muy recomendada.</translation>
    </message>
    <message>
        <source>Although eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>Aunque eZ publish funcionará sin ella, seguramente quieres soporte para esta base de datos.</translation>
    </message>
    <message>
        <source>The affected directories are: %dir_list</source>
        <translation>Los directorios afectados son: %dir_list</translation>
    </message>
    <message>
        <source>These shell commands will give proper permission to the webserver.</source>
        <translation>Estos comandos de consola darán los permisos necesarios al servidor web.</translation>
    </message>
    <message>
        <source>Alternative shell commands</source>
        <translation>Comandos de consola alternativos</translation>
    </message>
    <message>
        <source>If you don&apos;t have permissions to change the ownership you can try these commands.</source>
        <translation>Si no tienes permisos para cambiar la propiedad puedes probar estos comandos.</translation>
    </message>
    <message>
        <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it&apos;s recommended to change the ownership of the files to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
        <translation>eZ publish no pudo detectar el usuario o grupo del servidor web.
Si sabes el usuario y grupo del servidor web es recomendable que cambies la propiedad de los ficheros para que coincidan con este usuario y grupo.
Para hacer esto tienes que cambiar los comandos %chown en Comandos de consola alternativos.</translation>
    </message>
    <message>
        <source>These commands will setup the permission more correctly, but require knowledge about the running webserver.</source>
        <translation>Estos comandos configurarán los permisos correctamente, pero se requiere conocimiento sobre el servidor web que está funcionando.</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>The %user_expr must be changed to your webserver username and groupname.</source>
        <translation>El %user_expr tiene que ser cambiado por el nombre de usuario y el nombre de grupo del servidor web.</translation>
    </message>
    <message>
        <source>File uploading is not possible</source>
        <translation>No es posible subir archivos</translation>
    </message>
    <message>
        <source>The PHP upload directory %upload_dir does not exists or is not accessible, without this you will not be able to upload files or images to eZ publish.</source>
        <translation>El directorio PHP para subir %upload_dir no existe o no es accesible, sin este directorio no podrás subir archivos o imágenes a eZ publish.</translation>
    </message>
    <message>
        <source>Create the directory %upload_dir on your system. If you do not have the possibility to create this yourself ask the administrator to create it for you.</source>
        <translation>Crear el directorio %upload_dir en tu sistema. Si no tienes la posibilidad de crear este directorio, pregunta al administrador para que lo cree por ti.</translation>
    </message>
    <message>
        <source>The upload directory is currently placed in the directory of the root user.
This is a security problem and should be changed to another global temporary directory</source>
        <translation>El directorio de subida está en el directorio del usuario root.
Esto supone un problema de seguridad y debe ser cambiado a otro directorio temporal global</translation>
    </message>
    <message>
        <source>This shell command will create the upload directory.</source>
        <translation>Este comando de consola creará el directorio para subir.</translation>
    </message>
    <message>
        <source>The PHP upload directory %upload_dir is not writeable. This means that it will be impossible to upload files or images to eZ publish.</source>
        <translation>No se puede escribir en el directorio PHP para subir %upload_dir. Esto quiere decir que será imposible subir archivos o imágenes a eZ publish.</translation>
    </message>
    <message>
        <source>You must change the permission on the directory %upload_dir. If you do not have the possibility to create this yourself ask the administrator to do this for you.</source>
        <translation>Debes cambiar los permisos en el directorio %upload_dir. Si no tienes la posibilidad de hacerlo, pregunta al administrador para que lo cree por ti.</translation>
    </message>
    <message>
        <source>These shell commands will give proper permission to the upload directory.</source>
        <translation>Estos comandos de consola darán los permisos necesarios al directorio de subida.</translation>
    </message>
    <message>
        <source>If you don&apos;t have permissions to change the ownership you can try this command.</source>
        <translation>Si no tienes permisos para cambiar la propiedad puedes probar este comando.</translation>
    </message>
    <message>
        <source>eZ publish could not detect the user and group of the webserver.
If you know the user and group of the webserver it&apos;s recommended to change the ownership of the upload directory to match this user and group.
To do this you need to change the %chown commands under Alternative shell commands.</source>
        <translation>eZ publish no pudo detectar el usuario y grupo del servidor web.
Si sabes el usuario y grupo del servidor web, es recomendable que cambies la propiedad del directorio de subida para que coincida con este usuario y grupo.
Para hacer esto necesitas cambiar los comandos %chown en comandos de consola alternativa.</translation>
    </message>
    <message>
        <source>This shell command will give proper permission to the upload directory.</source>
        <translation>Esto comando de consola dará los permisos necesarios al directorio de subida.</translation>
    </message>
    <message>
        <source>If you know the user and group of the webserver you can try this command. Replace apache:apache with the user and group.</source>
        <translation>Si sabes el usuario y grupo del servidor web puedes probar este comando. Cambia apache:apache por el usuario y grupo.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are</source>
        <translation>La lista completa de juegos de carácteres soportados por mbstring es</translation>
    </message>
    <message>
        <source>php.ini example</source>
        <translation>ejemplo php.ini</translation>
    </message>
    <message>
        <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following</source>
        <translation>También puedes crear un archivo llamado %1 en el directorio raiz de eZ publish y añadir lo siguiente</translation>
    </message>
    <message>
        <source>.htaccess example</source>
        <translation>ejemplo .htaccess</translation>
    </message>
    <message>
        <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are</source>
        <translation>eZ publish puede funcionar con modo seguro activado, non obstante puede ser que haya varias funcionalidades que no van a estar disponibles. Algunas de las cosas que pueden ocurrir son</translation>
    </message>
    <message>
        <source>You need to enable AcceptPathInfo in your Apache config file, if you&apos;re using apache 2.x.</source>
        <translation>Necesitas activar AcceptPathInfo en tu archivo de configuración de Apache, si usas apache 2.x.</translation>
    </message>
    <message>
        <source>If you&apos;re running apache 1.3, eZ publish will not run in CGI mode.</source>
        <translation>Si estás usando apache 1.3, eZ publish no funcionará en modo CGI.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/toolbar</name>
    <message>
        <source>Tool</source>
        <translation>Herramienta</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Update Placement</source>
        <translation>Actualizar la ubicación</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Continuar comprando</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Caja</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>No tienes productos en tu cesta</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmar el pedido</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Productos</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Vista de grupo</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Porcentaje</translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Añadir regla</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Eliminar regla</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Clientes</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Añadir clientes</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Eliminar clientes</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Editando regla</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Lista de pedidos</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Total sin IVA</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Total con IVA</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Pedido</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Tipos de iva</translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Lista de deseos</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Lista de deseos vacía</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Cuenta</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>IVA</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Precio sin IVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Precio con IVA</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Descuentos</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Precio total sin IVA</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Precio total con IVA</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Grupos de descuento</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Editar grupos de descuento - %1</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Nombre de grupo</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Reglas definidas</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Aplicar a </translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Porcentaje de descuento</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Subtotal de entradas</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>La lista de la compra está vacía</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total del pedido</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Registrar información de cuenta</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>La entrada no ha sido validada, rellenar todos los campos</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Porcentaje</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atributos</translation>
    </message>
    <message>
        <source>Rule settings</source>
        <translation>Configuraciones de regla</translation>
    </message>
    <message>
        <source>Choose which classes, sections or objects ( products ) applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Elige qué clases, secciones u objetos (productos) a los que hay que aplicar esta sub regla. &apos;Ninguna&apos; significa que la regla será aplicada a todos.</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objeto</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>No especificado.</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Ordenar</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Apellido</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Payment was cancelled for an unknown reason. Please try to buy again.</source>
        <translation>El pago fué cancelado por una razón desconocida. Por favor, intenta comprar de nuevo.</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Sumario del pedido</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Customer name</comment>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Sort Result by</source>
        <translation>Ordenar los resultados por</translation>
    </message>
    <message>
        <source>Order Time</source>
        <translation>Fecha del pedido</translation>
    </message>
    <message>
        <source>User Name</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation>ID del pedido</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Ascendente</translation>
    </message>
    <message>
        <source>Sort ascending</source>
        <translation>Orden ascendente</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Descendente</translation>
    </message>
    <message>
        <source>Sort descending</source>
        <translation>Orden descendente</translation>
    </message>
    <message>
        <source>Order %1</source>
        <translation>Pedido %1</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Eliminar items</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Opciones eligidas</translation>
    </message>
    <message>
        <source>Customer list</source>
        <translation>Lista de clientes</translation>
    </message>
    <message>
        <source>Number of orders</source>
        <translation>Número de pedidos</translation>
    </message>
    <message>
        <source>The customer list is empty</source>
        <translation>La lista de cliente esta vacía</translation>
    </message>
    <message>
        <source>Customer Information</source>
        <translation>Información de cliente</translation>
    </message>
    <message>
        <source>Purchase list</source>
        <translation>Lista de compras</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Importe</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Estadisticas</translation>
    </message>
    <message>
        <source>All Year</source>
        <translation>Todo el año</translation>
    </message>
    <message>
        <source>All Month</source>
        <translation>Todo el mes</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <source>Are you sure you want to remove order: </source>
        <translation>Esta seguro de querer eliminar el pedido:</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Tu información de cuenta</translation>
    </message>
    <message>
        <source>Input did not validate, all fields marked with * must be filled in</source>
        <translation>La entrada no es valida, todos los campos indicados con * tienen que estar rellenados</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Todos los campos indicados con * tienen que estar rellenados.</translation>
    </message>
    <message>
        <source>Customer information</source>
        <translation>Información de cliente</translation>
    </message>
    <message>
        <source>Shipping address</source>
        <translation>Dirección de entrega</translation>
    </message>
    <message>
        <source>Company</source>
        <translation>Compañía</translation>
    </message>
    <message>
        <source>Street</source>
        <translation>Calle</translation>
    </message>
    <message>
        <source>Zip</source>
        <translation>Código</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Los siguientes elementos fueron eliminados de tu cesta porque los productos han sido cambiados</translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation>Intentó añadir un objeto sin precio a la cesta.</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT</source>
        <translation>Subtotal sin IVA</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT</source>
        <translation>Subtotal con IVA</translation>
    </message>
    <message>
        <source>SUM</source>
        <translation>SUMA</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
</context>
<context>
    <name>design/standard/shop/view</name>
    <message>
        <source>Choose customers</source>
        <translation>Elegir clientes</translation>
    </message>
    <message>
        <source>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Por favor, elige los clientes que quieras añadir al grupo de descuento %groupname.

Selecciona los clientes y clica el botón %buttonname.
También es posible usar los elementos de reciente o favoritos para una selección rápida.
Clica en nombres de objeto para cambiar la lista de navegación.</translation>
    </message>
    <message>
        <source>Choose product for discount</source>
        <translation>Elige producto para descuento</translation>
    </message>
    <message>
        <source>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</source>
        <translation>Por favor, elige los productos que quieras añadir a la regla de descuento %discountname en el grupo de descuento %groupname.

Selecciona los productos y clica el botón %buttonname.
También es posible usar los elementos de reciente o favoritos para una selección rápida.
Clica en nombres de producto para cambiar la lista de navegación.</translation>
    </message>
</context>
<context>
    <name>design/standard/toolbar</name>
    <message>
        <source>Toolbar management</source>
        <translation>Gestión de la barra de herramientas</translation>
    </message>
    <message>
        <source>There are %logged_in_count registered and %anonymous_count anonymous users online.</source>
        <translation>Hay $logged_in_count usuarios registrados y %anonymous_count usuarios anónimos conectados.</translation>
    </message>
    <message>
        <source>Available toolbars</source>
        <translation>Barra de herramientas disponibles</translation>
    </message>
    <message>
        <source>Shopping basket</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>View all details</source>
        <translation>Ver los detalles</translation>
    </message>
    <message>
        <source>Your basket is empty</source>
        <translation>Tu cesta está vacía</translation>
    </message>
    <message>
        <source>Best sellers</source>
        <translation>Los más vendidos</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Calendario</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mis borradores</translation>
    </message>
    <message>
        <source>Account</source>
        <translation>Cuenta</translation>
    </message>
    <message>
        <source>Not logged in</source>
        <translation>No conectado</translation>
    </message>
    <message>
        <source>Logged in as: %username</source>
        <translation>Conectado como: %username</translation>
    </message>
    <message>
        <source>Edit account</source>
        <translation>Editar la cuenta</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Desconectar</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Not registered?</source>
        <translation>¿No esta registrado?</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Contraseña olvidada?</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Notificación</translation>
    </message>
    <message>
        <source>My Notifications</source>
        <translation>Mis notificaciones</translation>
    </message>
    <message>
        <source>User information</source>
        <translation>Información de usuario</translation>
    </message>
    <message>
        <source>View basket</source>
        <translation>Ver la cesta</translation>
    </message>
    <message>
        <source>Online: %logged_in_count:%anonymous_count</source>
        <comment>Short user information</comment>
        <translation>Conectados: %logged_in_count:%anonymous_count</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
</context>
<context>
    <name>design/standard/toolbar/search</name>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>Global</translation>
    </message>
    <message>
        <source>From here</source>
        <translation>Desde aquí</translation>
    </message>
    <message>
        <source>Search: </source>
        <translation>Buscar:</translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>No workflow</source>
        <translation>No hay flujo de trabajo</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Trigger list</source>
        <translation>Lista de disparadores</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Flujo de trabajo</translation>
    </message>
    <message>
        <source>Module name</source>
        <translation>Nombre de módulo</translation>
    </message>
    <message>
        <source>Function name</source>
        <translation>Nombre de función</translation>
    </message>
    <message>
        <source>Connect type</source>
        <translation>Tipo de conexión</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Válido</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Inválido</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>La URL apunta a %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Última modificación en %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>La URL no tiene fecha de modificación</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Último chequeo en %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>La URL no ha sido chequeado</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtrar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Last checked</source>
        <translation>Último chequeo</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>Popup</source>
        <translation>Popup</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>All URLs</source>
        <translation>Todas las URL</translation>
    </message>
    <message>
        <source>Invalid URLs</source>
        <translation>URL inválidas</translation>
    </message>
    <message>
        <source>Valid URLs</source>
        <translation>URL válidas</translation>
    </message>
    <message>
        <source>Information on URL</source>
        <translation>Información en la URL</translation>
    </message>
    <message>
        <source>Objects which use this link</source>
        <translation>Objetos que usan este enlace</translation>
    </message>
    <message>
        <source>No object available</source>
        <translation>No hay objeto disponible</translation>
    </message>
    <message>
        <source>version</source>
        <translation>versión</translation>
    </message>
    <message>
        <source>The URL is not considered valid any more.</source>
        <translation>Esta URL ya no se considera válida.</translation>
    </message>
    <message>
        <source>This means that the URL is no longer available or has been moved.</source>
        <translation>Esto significa que la URL ya no está disponible o ha sido movida.</translation>
    </message>
</context>
<context>
    <name>design/standard/url/edit</name>
    <message>
        <source>Editing URL - %1</source>
        <translation>Editar URL - %1</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Activate account</source>
        <translation>Activar cuenta</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>No se puede conectar</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Para conectar se requiere un nombre de usuario válido y una contraseña.</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Cambiar contraseña para el usuario</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Registrar usuario</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>La entrada no fue validada</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>La entrada se almacenó con éxito</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrarse</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Preferencias del usuario</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Login máximo</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Está activado</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Usuario registrado</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Tu cuenta se ha creado con éxito.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Acceso no permitido</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>No tienes permisos para acceder a %1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>User profile</source>
        <translation>Usar perfil</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Please retype your old password.</source>
        <translation>Por favor, reescribe tu antigua contraseña.</translation>
    </message>
    <message>
        <source>Password didn&apos;t match, please retype your new password.</source>
        <translation>La contraseña no coincidió. Por favor, reescribe tu nueva contraseña.</translation>
    </message>
    <message>
        <source>Password successfully updated.</source>
        <translation>La contraseña se actualizó con éxito.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Login</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation>
Inscribir</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Editar perfil</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>Change setting</source>
        <translation>Cambiar configuración</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Antigua contraseña</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Nueva contraseña</translation>
    </message>
    <message>
        <source>Retype password</source>
        <translation>Escribir la contraseña de nuevo</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Tu cuenta ha sido creada con éxito. Se enviará un correo a la especificada
dirección de correo. Necesitas seguir las instrucciones especificadas en ese correo para activar
tu cuenta.</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Tu cuenta ha sido activada.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Perdón, la clave enviada no es válida. La cuenta no ha sido activada.</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation>Contraseña olvidada?</translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation>Incapaz de registrar el nuevo usuario</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
</context>
<context>
    <name>design/standard/user/forgotpassword</name>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>No hay ningún usuario registrado con esta dirección de correo.</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>¿Has olvidado tu contraseña?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Si has olvidado tu contraseña podemos generar otra para ti. Todo lo que tienes que hacer es introducir tu dirección de correo electrónico y se creará una nueva contraseña para ti.</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Generar una nueva contraseña</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Tu información de cuenta</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>La contraseña ha sido generada con éxito y enviada a: %1</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>La clave no es válida o ya ha sido usada.</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>%siteurl new password</source>
        <translation>Nueva contraseña de %siteurl</translation>
    </message>
    <message>
        <source>Click here to get new password</source>
        <translation>Clica aquí para obtener una nueva contraseña</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Nueva contraseña</translation>
    </message>
    <message>
        <source>A mail has been sent to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Se ha enviado un e-mail a la siguiente dirección: %1. Este e-mail contiene el enlace que necesitas para confirmar que es el usuario correcto quien recibe la nueva contraseña.</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>%1 registration info</source>
        <translation>%1 Información del registro</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Click the following URL to confirm your account</source>
        <translation>Clica la siguiente URL para confirmar tu cuenta</translation>
    </message>
    <message>
        <source>New user registered at %siteurl</source>
        <translation>Nuevo usuario registrado en %siteurl</translation>
    </message>
    <message>
        <source>A new user has registered.</source>
        <translation>Se ha registrado un nuevo usuario.</translation>
    </message>
    <message>
        <source>Account information.</source>
        <translation>Información de la cuenta.</translation>
    </message>
    <message>
        <source>Link to user information</source>
        <translation>Enlace a la información de usuario</translation>
    </message>
    <message>
        <source>Thank you for registering at %siteurl.</source>
        <translation>Gracias por registrarte en %siteurl.</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Tu información de cuenta</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Username</source>
        <comment>Login name</comment>
        <translation>Nombre de usuario</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Editing workflow</source>
        <translation>Editando flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>Flujo de trabajo almacenado</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Los datos se deben arreglar</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Grupos</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>Eventos</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Almacenar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>on</source>
        <translation>en</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Modificado por</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>Proceso de flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>El proceso de flujos de trabajo fue creado en</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>y modificado en</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Flujo de trabajo</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>Usando flujo de trabajo</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>por procesar.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>Este flujo de trabajo está funcionando para el usuario</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>Objeto de contenido</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>El flujo de trabajo fue creado para contenido</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>usando la versión</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>en padre</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>Evento de flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>El flujo de trabajo no ha sido empezado aún, el número de eventos en el flujo de trabajo es</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>La posición del evento actual es</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>El evento que arrancará es</translation>
    </message>
    <message>
        <source>event</source>
        <translation>Evento</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>El último evento ha devuelto el estado</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>Lista de eventos de flujo de trabajo</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Próximo paso</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>Log del evento de flujo de trabajo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>Pos</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>Grupos de flujos de trabajo</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Nuevo grupo</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificador</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modificado</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Nuevo flujo de trabajo</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Añadir grupo</translation>
    </message>
    <message>
        <source>Editing workflow group - %1</source>
        <translation>Editando grupo de flujo de trabajo - %1</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Modificado por %username en %time</translation>
    </message>
    <message>
        <source>Edit workflow</source>
        <translation>Editar flujo de trabajo</translation>
    </message>
    <message>
        <source>Remove selected workflows</source>
        <translation>Eliminar los flujos de trabajo seleccionados</translation>
    </message>
    <message>
        <source>Workflow process was created at %creation and modified at %modification.</source>
        <translation>El flujo de trabajo fue creado en %creation y modificado en %modification.</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <comment>%1 is workflow group</comment>
        <translation>Flujos de trabajo en %1</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Los datos no se validaron</translation>
    </message>
    <message>
        <source>Select gateway</source>
        <translation>Elegir la puerta de enlace</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Additional information</source>
        <translation>Información adicional</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Secciones</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Usuarios sin aprovación</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Usuarios sin flujo de trabajo de IDs</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Clases por las cuales se aplica el flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Flujo de trabajo para funcionar</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Eliminar la selección</translation>
    </message>
    <message>
        <source>Load attributes</source>
        <translation>Cargar atributos</translation>
    </message>
    <message>
        <source>Modify publish date</source>
        <translation>Modificar la fecha de publicación</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>Añadir entrada</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Class Attributes</source>
        <translation>Atributos de clase</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/view</name>
    <message>
        <source>Editor</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Secciones</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Usuarios sin aprobación</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Clases por las cuales se aplica el flujo de trabajo</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Usuarios sin IDs de flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Flujo de trabajo para funcionar</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Publish date will be modified.</source>
        <translation>La fecha de publicación será modificada.</translation>
    </message>
    <message>
        <source>Publish date will not be modified.</source>
        <translation>La fecha de publicación no será modificada.</translation>
    </message>
</context>
<context>
    <name>kernel/cache</name>
    <message>
        <source>Content view cache</source>
        <translation>Caché de vista de contenido</translation>
    </message>
    <message>
        <source>Global INI cache</source>
        <translation>Caché de INI global</translation>
    </message>
    <message>
        <source>INI cache</source>
        <translation>Caché de INI</translation>
    </message>
    <message>
        <source>Codepage cache</source>
        <translation>Caché de código de página</translation>
    </message>
    <message>
        <source>Expiry cache</source>
        <translation>Caché de expiración</translation>
    </message>
    <message>
        <source>Class identifier cache</source>
        <translation>Caché de identificador de clase</translation>
    </message>
    <message>
        <source>Sort key cache</source>
        <translation>Caché de claves de ordenación</translation>
    </message>
    <message>
        <source>URL alias cache</source>
        <translation>Caché de alias de URL</translation>
    </message>
    <message>
        <source>Character transformation cache</source>
        <translation>Caché de transformación de carácteres</translation>
    </message>
    <message>
        <source>Image alias</source>
        <translation>Alias de imagen</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Caché de plantillas</translation>
    </message>
    <message>
        <source>Template block cache</source>
        <translation>Caché de bloque de plantilla</translation>
    </message>
    <message>
        <source>Template override cache</source>
        <translation>Caché de plantillas sobreescritas</translation>
    </message>
    <message>
        <source>RSS cache</source>
        <translation>Caché de RSS</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Lista de clase de grupo</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Lista de grupo de clase</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Lista de clase</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(No hay clases)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Eliminar grupo de clase</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Eliminar clase</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Editar clase</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Clases</translation>
    </message>
    <message>
        <source>You have to have at least one group that the class belongs to!</source>
        <translation>¡Debes tener al menos un grupo al cual pertenezca la clase!</translation>
    </message>
    <message>
        <source>Remove classes %class_id</source>
        <translation>Eliminar clases %class_id</translation>
    </message>
    <message>
        <source>Copy of %class_name</source>
        <translation>Copia de %class_name</translation>
    </message>
    <message>
        <source>The class should have nonempty &apos;Name&apos; attribute.</source>
        <translation>La clase debe tener el atributo &apos;Nombre&apos; puesto.</translation>
    </message>
    <message>
        <source>The class should have at least one attribute.</source>
        <translation>La clase debe tener al menos un atributo.</translation>
    </message>
    <message>
        <source>There is a class already having the same identifier.</source>
        <translation>Ya existe una clase con el mismo identificador.</translation>
    </message>
</context>
<context>
    <name>kernel/class/edit</name>
    <message>
        <source>New Class</source>
        <translation>Nueva clase</translation>
    </message>
    <message>
        <source>new attribute</source>
        <translation>nuevo atributo</translation>
    </message>
</context>
<context>
    <name>kernel/class/groupedit</name>
    <message>
        <source>New Group</source>
        <translation>Nuevo Grupo</translation>
    </message>
</context>
<context>
    <name>kernel/classe/datatypes/ezbinaryfile</name>
    <message>
        <source>Failed to store file %filename. Please contact the site administrator.</source>
        <translation>Fallo al guardar el archivo %filename. Por favor, contacta con el administrador de la web.</translation>
    </message>
</context>
<context>
    <name>kernel/classe/datatypes/ezimage</name>
    <message>
        <source>Failed to fetch Image Handler. Please contact the site administrator.</source>
        <translation>Fallo al recoger el gestor de imágenes. Por favor, contactar el administrador del sistema.</translation>
    </message>
</context>
<context>
    <name>kernel/classe/datatypes/ezmedia</name>
    <message>
        <source>Failed to store media file %filename. Please contact the site administrator.</source>
        <translation>Fallo al guardar el archivo multimedia %filename. Por favor, contacta con el administrador de la web.</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Aprobación</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standar</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Observador</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propietario</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Aprobador</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Bandeja de entrada</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Sin estado aún</translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>Flujo de trabajo funcionando</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>Flujo de trabajo hecho</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>El flujo de trabajo ha fallado un evento</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>Evento del flujo de trabajo ha sido prorrogado a una tarea programada (cron job)</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>El flujo de trabajo ha sido cancelado</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>El flujo de trabajo ha sido reiniciado para su reutilización</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Evento aceptado</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Evento rechazado</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>Evento prorrogado a cron job</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>Evento prorrogado a cron job. El evento volverá a ser ejecutado</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>El evento ejecuta un subevento</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Cancelado todo el flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow fetches template</source>
        <translation>El flujo de trabajo recoge una plantilla</translation>
    </message>
    <message>
        <source>Workflow redirects user view</source>
        <translation>El flujo de trabajo redirecciona la vista de usuario</translation>
    </message>
    <message>
        <source>New RSS Export</source>
        <translation>Nueva exportación RSS</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Missing date input.</source>
        <translation>Falta entrada de fecha.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Falta entrada de hora.</translation>
    </message>
    <message>
        <source>Author</source>
        <comment>Datatype name</comment>
        <translation>Autor</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <translation>Se requiere al menos un autor.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <translation>Se requiere un fichero válido.</translation>
    </message>
    <message>
        <source>Checkbox</source>
        <comment>Datatype name</comment>
        <translation>Checkbox</translation>
    </message>
    <message>
        <source>Date field</source>
        <comment>Datatype name</comment>
        <translation>Campo de fecha</translation>
    </message>
    <message>
        <source>Datetime field</source>
        <comment>Datatype name</comment>
        <translation>Campo de hora y fecha</translation>
    </message>
    <message>
        <source>Email</source>
        <comment>Datatype name</comment>
        <translation>Email</translation>
    </message>
    <message>
        <source>Enum</source>
        <comment>Datatype name</comment>
        <translation>Enumeración</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <translation>Al menos hay que elegir un campo.</translation>
    </message>
    <message>
        <source>Float</source>
        <comment>Datatype name</comment>
        <translation>Decimal</translation>
    </message>
    <message>
        <source>Image</source>
        <comment>Datatype name</comment>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Integer</source>
        <comment>Datatype name</comment>
        <translation>Número entero</translation>
    </message>
    <message>
        <source>ISBN</source>
        <comment>Datatype name</comment>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>Keyword</source>
        <comment>Datatype name</comment>
        <translation>Palabra clave</translation>
    </message>
    <message>
        <source>Matrix</source>
        <comment>Datatype name</comment>
        <translation>Matriz</translation>
    </message>
    <message>
        <source>Media</source>
        <comment>Datatype name</comment>
        <translation>Media</translation>
    </message>
    <message>
        <source>Object relation</source>
        <comment>Datatype name</comment>
        <translation>Relación de objeto</translation>
    </message>
    <message>
        <source>Object relation list</source>
        <comment>Datatype name</comment>
        <translation>Lista de relaciones de objeto</translation>
    </message>
    <message>
        <source>Option</source>
        <comment>Datatype name</comment>
        <translation>Opción</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <translation>Al menos se requiere una opción.</translation>
    </message>
    <message>
        <source>Price</source>
        <comment>Datatype name</comment>
        <translation>Precio</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Añadir a la cesta</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Añadir a la lista de deseos</translation>
    </message>
    <message>
        <source>Range option</source>
        <comment>Datatype name</comment>
        <translation>Opción de rango</translation>
    </message>
    <message>
        <source>Selection</source>
        <comment>Datatype name</comment>
        <translation>Selección</translation>
    </message>
    <message>
        <source>Text line</source>
        <comment>Datatype name</comment>
        <translation>Línea de texto</translation>
    </message>
    <message>
        <source>Subtree subscription</source>
        <comment>Datatype name</comment>
        <translation>Suscripción de subárbol</translation>
    </message>
    <message>
        <source>Text field</source>
        <comment>Datatype name</comment>
        <translation>Campo de texto</translation>
    </message>
    <message>
        <source>URL</source>
        <comment>Datatype name</comment>
        <translation>URL</translation>
    </message>
    <message>
        <source>User account</source>
        <comment>Datatype name</comment>
        <translation>Cuenta de usuario</translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <translation>Ya existe un usuario con este e-mail.</translation>
    </message>
    <message>
        <source>XML Text field</source>
        <comment>Datatype name</comment>
        <translation>Campo de texto XML</translation>
    </message>
    <message>
        <source>Object %1 does not exist.</source>
        <translation>El objeto %1 no existe.</translation>
    </message>
    <message>
        <source>Link %1 does not exist.</source>
        <translation>El enlace %1 no existe.</translation>
    </message>
    <message>
        <source>Identifier</source>
        <comment>Datatype name</comment>
        <translation>Identificador</translation>
    </message>
    <message>
        <source>image</source>
        <comment>Default image name</comment>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Ini Setting</source>
        <comment>Datatype name</comment>
        <translation>Configuración Ini</translation>
    </message>
    <message>
        <source>Package</source>
        <comment>Datatype name</comment>
        <translation>Paquete</translation>
    </message>
    <message>
        <source>Send</source>
        <comment>Datatype information collector action</comment>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Missing objectrelation input.</source>
        <translation>Falta entrada de relación de objeto.</translation>
    </message>
    <message>
        <source>The author name must be provided.</source>
        <translation>El nombre de autor es obligatorio.</translation>
    </message>
    <message>
        <source>The email address is not valid.</source>
        <translation>La dirección de email no es válida.</translation>
    </message>
    <message>
        <source>Binary file</source>
        <comment>Datatype name</comment>
        <translation>Archivo binario</translation>
    </message>
    <message>
        <source>File uploading is not enabled. Please contact the site administrator to enable it.</source>
        <translation>La subida de archivos no está activada. Por favor, contacta con el administrador de la web para activarla.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set by the upload_max_filesize directive in php.ini.</source>
        <translation>El tamaño del archivo subido excede el límite fijado por la directiva upload_max_filesize en php.ini.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the maximum upload size: %1 bytes.</source>
        <translation>El tamaño del archivo subido excede el máximo permitido: %1 bytes.</translation>
    </message>
    <message>
        <source>The email address is empty.</source>
        <translation>La dirección email está vacía.</translation>
    </message>
    <message>
        <source>The given input is not a floating point number.</source>
        <translation>El dato no es un número de coma flotante.</translation>
    </message>
    <message>
        <source>The input must be greater than %1</source>
        <translation>El dato debe ser mayor que %1</translation>
    </message>
    <message>
        <source>The input must be less than %1</source>
        <translation>El dato debe ser menor que %1</translation>
    </message>
    <message>
        <source>The input is not in defined range %1 - %2</source>
        <translation>El dato no está dentro del rango %1 - %2</translation>
    </message>
    <message>
        <source>A valid image file is required.</source>
        <translation>Es obligatorio un archivo de imagen válido.</translation>
    </message>
    <message>
        <source>The size of the uploaded image exceeds limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
        <translation>El tamaño del archivo imagen subido excede el límite fijado por la directiva upload_max_filesize en php.ini. Por favor, contacta con el administrador de la web.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set for this site: %1 bytes.</source>
        <translation>El tamaño del archivo subido excede el límite fijado de esta web: %1 bytes.</translation>
    </message>
    <message>
        <source>Could not locate the ini file.</source>
        <translation>No se pudo encontrar el archivo ini.</translation>
    </message>
    <message>
        <source>The input is not a valid integer.</source>
        <translation>El dato no es un número entero válido.</translation>
    </message>
    <message>
        <source>The number must be greater than %1</source>
        <translation>El número debe ser mayor que %1</translation>
    </message>
    <message>
        <source>The number must be less than %1</source>
        <translation>El número debe ser menor que %1</translation>
    </message>
    <message>
        <source>The number is not within the required range %1 - %2</source>
        <translation>El número no está en el rango requerido %1 - %2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please check the input for mistakes.</source>
        <translation>El número ISBN no es correcto. Por favor comprueba los datos.</translation>
    </message>
    <message>
        <source>A valid media file is required.</source>
        <translation>Se requiere un fichero multimedia válido.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds the limit set by upload_max_filesize directive in php.ini. Please contact the site administrator.</source>
        <translation>El tamaño del archivo subido excede el límite fijado por la directiva upload_max_filesize en php.ini. Por favor, contacta con el administrador de la web.</translation>
    </message>
    <message>
        <source>The size of the uploaded file exceeds site maximum: %1 bytes.</source>
        <translation>El tamaño del archivo subido excede el límite de esta web: %1 bytes.</translation>
    </message>
    <message>
        <source>Multi-option</source>
        <comment>Datatype name</comment>
        <translation>Multi-opción</translation>
    </message>
    <message>
        <source>The option value must be provided.</source>
        <translation>Debes rellenar el valor de la opción.</translation>
    </message>
    <message>
        <source>The additional price for the multioption value is not valid.</source>
        <translation>El precio adicional para el valor de la opción multiple no es válido.</translation>
    </message>
    <message>
        <source>The Additional price value is not valid.</source>
        <translation>El valor del precio adicional no es válido.</translation>
    </message>
    <message>
        <source>Input required.</source>
        <translation>Entrada obligatoria.</translation>
    </message>
    <message>
        <source>The input text is too long. The maximum number of characters allowed is %1.</source>
        <translation>El texto entrado es demasiado largo. El número maximo de caracteros permitidos es %1.</translation>
    </message>
    <message>
        <source>Time input required.</source>
        <translation>Hora de entrada obligatoria.</translation>
    </message>
    <message>
        <source>Invalid time.</source>
        <translation>Hora incorrecta.</translation>
    </message>
    <message>
        <source>The username must be specified.</source>
        <translation>Se debe especificar el nombre de usuario.</translation>
    </message>
    <message>
        <source>The username already exists, please choose another one.</source>
        <translation>El nombre de usuario ya existe, por favor elige otro.</translation>
    </message>
    <message>
        <source>The passwords do not match.</source>
        <comment>eZUserType</comment>
        <translation>Las contraseñas no coindiden.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters long.</source>
        <translation>La contraseña debe contener por lo menos 3 carácteres.</translation>
    </message>
    <message>
        <source>Cannot remove the account:</source>
        <translation>No se puede eliminar la cuenta:</translation>
    </message>
    <message>
        <source>The account owner is currently logged in.</source>
        <translation>El propietario de la cuenta está conectado.</translation>
    </message>
    <message>
        <source>The account is currently used by the anonymous user.</source>
        <translation>La cuenta está siendo usada por el usuario anónimo.</translation>
    </message>
    <message>
        <source>The account is currenty used the administrator user.</source>
        <translation>La cuenta está siendo usada por el usuario administrador.</translation>
    </message>
    <message>
        <source>You can not remove the last class holding user accounts.</source>
        <translation>No se puede eliminar la última clase gestionando las cuentas de usuario.</translation>
    </message>
    <message>
        <source>The link %1 does not exist.</source>
        <translation>El enlace %1 no existe.</translation>
    </message>
    <message>
        <source>Input required</source>
        <translation>Entrada obligatoria</translation>
    </message>
    <message>
        <source>Object %1 can not be embeded to itself.</source>
        <translation>El objeto %1 no puede ser encajado en el mismo.</translation>
    </message>
    <message>
        <source>Date is not valid.</source>
        <translation>La fecha no es válida.</translation>
    </message>
    <message>
        <source>Time</source>
        <comment>Datatype name</comment>
        <translation>Hora</translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Acción de colaboración personalizada</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Colaboración</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Remove object</source>
        <translation>Eliminar objeto</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzada</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>No hay seleccionado ningún nudo principal. por favor, seleccione uno.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mis borradores</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Eliminar la versión editada</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Volcar desde %1: %2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>La dirección de e-mail del emisor no es válida</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>La dirección de e-mail del receptor no es válida</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Avisa a un amigo</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traducir</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Traducciones de contenidos</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versiones</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Mis favoritos</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Mi lista de tareas pendientes</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>Traductor de URL</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Palabras clave</translation>
    </message>
    <message>
        <source>Media</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <source>New content</source>
        <translation>Nuevo contenido</translation>
    </message>
    <message>
        <source>You are not allowed to place this object under: %1</source>
        <translation>No puedes colocar este objeto en: %1</translation>
    </message>
    <message>
        <source>Remove location</source>
        <translation>Eliminar ubicación</translation>
    </message>
    <message>
        <source>Top Level Nodes</source>
        <translation>El destinario ya ha recibido demasiado &quot;avisa a un amigo&quot; durante el último par de horas</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Oculto</translation>
    </message>
    <message>
        <source>Hidden by superior</source>
        <translation>Oculto por superior</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Visible</translation>
    </message>
    <message>
        <source>The receiver has already received the maximimum number of tipafriend mails the last hours</source>
        <translation>El destinario ya ha recibido el maximo número de avisos a un amigo en las últimas horas</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>Hijo</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>Hijos</translation>
    </message>
</context>
<context>
    <name>kernel/content/upload</name>
    <message>
        <source>The file %filename does not exist, cannot insert file.</source>
        <translation>El archivo %filename no existe, no se puede insertar el archivo.</translation>
    </message>
    <message>
        <source>No matching class identifier found.</source>
        <translation>No se ha encontrado ninguna clase que coincide con el identificador.</translation>
    </message>
    <message>
        <source>The class %class_identifier does not exist.</source>
        <translation>La clase %class_identifier no existe.</translation>
    </message>
    <message>
        <source>Was not able to figure out placement of object.</source>
        <translation>No se pudo determinar la ubicación del objeto.</translation>
    </message>
    <message>
        <source>No configuration group in upload.ini for class identifier %class_identifier.</source>
        <translation>No hay grupo de configuración en upload.ini para el identificador de clase %class_identifier.</translation>
    </message>
    <message>
        <source>No matching file attribute found, cannot create content object without this.</source>
        <translation>No se ha encontrado un archivo que coincide con el atributo. No se puede crear el objeto de contenido sin eso.</translation>
    </message>
    <message>
        <source>No matching name attribute found, cannot create content object without this.</source>
        <translation>No se ha encontrado un nombre que coincide con el atributo. No se puede crear un objeto de contenido sin eso.</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <source>The attribute %class_identifier does not support regular file storage.</source>
        <translation>El atributo %class_identifier no soporta el almacenamiento de archivos.</translation>
    </message>
    <message>
        <source>The attribute %class_identifier does not support simple string storage.</source>
        <translation>El atributo %class_identifier no soporta almacenamiento de cadenas simples.</translation>
    </message>
    <message>
        <source>No HTTP file found, cannot fetch uploaded file.</source>
        <translation>No se ha encontrado un archivo HTTP, no se puede recoger el archivo subido.</translation>
    </message>
    <message>
        <source>The attribute %class_identifier does not support HTTP file storage.</source>
        <translation>El atributo %class_identifier no soporta el almacenamiento de archivos HTTP.</translation>
    </message>
    <message>
        <source>Publishing of content object was halted.</source>
        <translation>Se detuvo la publicación del objeto de contenido.</translation>
    </message>
    <message>
        <source>Publish process was cancelled.</source>
        <translation>El proceso de publicación ha sido cancelado.</translation>
    </message>
    <message>
        <source>A file is required for upload, no file were found.</source>
        <translation>Se requiere subir un archivo, no se encontró ningún archivo.</translation>
    </message>
    <message>
        <source>Expected a eZHTTPFile object but got nothing.</source>
        <translation>Se esperaba un objeto eZHTTPFile pero no se encontró nada.</translation>
    </message>
</context>
<context>
    <name>kernel/contentclass</name>
    <message>
        <source>New %1</source>
        <translation>Nuevo %1</translation>
    </message>
    <message>
        <source>Cannot remove class &apos;%class_name&apos;:</source>
        <translation>No se puede eliminar la clase &apos;%class_name&apos;:</translation>
    </message>
    <message>
        <source>The class is used by a top-level node and cannot be removed.</source>
        <translation>Un nodo de nivel superior está usando esta clase y no se puede eliminar.</translation>
    </message>
</context>
<context>
    <name>kernel/design</name>
    <message>
        <source>Template list</source>
        <translation>Lista de plantilla</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Vista de plantilla</translation>
    </message>
    <message>
        <source>Create new template</source>
        <translation>Crear nueva plantilla</translation>
    </message>
    <message>
        <source>Template edit</source>
        <translation>Editar plantilla</translation>
    </message>
    <message>
        <source>Toolbar list</source>
        <translation>Lista de barras de herramientas</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
</context>
<context>
    <name>kernel/form</name>
    <message>
        <source>Form processing</source>
        <translation>Procesando el formulario</translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Content structure</source>
        <comment>Navigation part</comment>
        <translation>Estructura de contenido</translation>
    </message>
    <message>
        <source>Media library</source>
        <comment>Navigation part</comment>
        <translation>Biblioteca multimedia</translation>
    </message>
    <message>
        <source>User accounts</source>
        <comment>Navigation part</comment>
        <translation>Cuentas de usuario</translation>
    </message>
    <message>
        <source>Webshop</source>
        <comment>Navigation part</comment>
        <translation>Tienda virtual</translation>
    </message>
    <message>
        <source>Design</source>
        <comment>Navigation part</comment>
        <translation>Diseño</translation>
    </message>
    <message>
        <source>Setup</source>
        <comment>Navigation part</comment>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>My account</source>
        <comment>Navigation part</comment>
        <translation>Mi cuenta</translation>
    </message>
</context>
<context>
    <name>kernel/notification</name>
    <message>
        <source>Notification settings</source>
        <translation>Configuraciones de notificación</translation>
    </message>
</context>
<context>
    <name>kernel/package</name>
    <message>
        <source>Packages</source>
        <translation>Paquetes</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Package information</source>
        <translation>Información del paquete</translation>
    </message>
    <message>
        <source>Package maintainer</source>
        <translation>Mantenedor del paquete</translation>
    </message>
    <message>
        <source>Package changelog</source>
        <translation>Registro de cambios del paquete</translation>
    </message>
    <message>
        <source>Package thumbnail</source>
        <translation>Miniatura del paquete</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Nombre del paquete</translation>
    </message>
    <message>
        <source>Package name is missing</source>
        <translation>No se encuentra el nombre del paquete</translation>
    </message>
    <message>
        <source>A package named %packagename already exists, please give another name</source>
        <translation>Ya existe un paquete llamado %packagename. Por favor, dale otro nombre</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Resumen</translation>
    </message>
    <message>
        <source>Summary is missing</source>
        <translation>No se ha encontrado el resumen</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>You must enter a name for the changelog</source>
        <translation>Hay que introducir un nombre para el registro de cambios</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>You must enter an e-mail for the changelog</source>
        <translation>Hay que introducir un correo para el registro de cambios</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <source>You must supply some text for the changelog entry</source>
        <translation>Hay que poner algún texto para la entrada del registro de cambios</translation>
    </message>
    <message>
        <source>You must enter a name of the maintainer</source>
        <translation>Hay que introducir un nombre de mantenedor</translation>
    </message>
    <message>
        <source>You must enter an e-mail address of the maintainer</source>
        <translation>Hay que introducir la dirección de correo del mantenedor</translation>
    </message>
    <message>
        <source>Content classes to include</source>
        <translation>Clases de contenido para incluir</translation>
    </message>
    <message>
        <source>Content class export</source>
        <translation>Exportación de clases de contenido</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Lista de clase</translation>
    </message>
    <message>
        <source>You must select at least one class for inclusion</source>
        <translation>Hay que seleccionar al menos una clase para incluir</translation>
    </message>
    <message>
        <source>CSS file</source>
        <translation>Archivo CSS</translation>
    </message>
    <message>
        <source>Image files</source>
        <translation>Archivos de imagen</translation>
    </message>
    <message>
        <source>Site style</source>
        <translation>Estilo del sitio</translation>
    </message>
    <message>
        <source>File did not have a .css suffix, this is most likely not a CSS file</source>
        <translation>El archivo no tiene un sufijo .css. Probablemente no es un archivo CSS</translation>
    </message>
    <message>
        <source>Content class %classname (%classidentifier)</source>
        <translation>Clase de contenido %classname (%classidentifier)</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Crear el paquete</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <source>Package %packagename already exists, cannot import the package</source>
        <translation>El paquete %packagename ya existe, no se puede importar el paquete</translation>
    </message>
    <message>
        <source>Local</source>
        <translation>Local</translation>
    </message>
    <message>
        <source>Styles</source>
        <translation>Estilos</translation>
    </message>
    <message>
        <source>Addons</source>
        <translation>Modulos añadidos</translation>
    </message>
    <message>
        <source>The version must only contain numbers (optionally followed by text) and must be delimited by dots (.), e.g. 1.0, 3.4.0beta1</source>
        <translation>La versión tiene que contener solo números (eventualmente seguidos con un texto) y tiene que ser delimitada por puntos (.), por ejemplo 1.0, 3.4.0beta1</translation>
    </message>
    <message>
        <source>Content objects to include</source>
        <translation>Objetos de contenido para incluir</translation>
    </message>
    <message>
        <source>Content object limits</source>
        <translation>Limites de objeto de contenido</translation>
    </message>
    <message>
        <source>Content object export</source>
        <translation>Exportación de objetos de contenido</translation>
    </message>
    <message>
        <source>Selected nodes</source>
        <translation>Nudos selecionados</translation>
    </message>
    <message>
        <source>You must select one or more node(s)/subtree(s) for export.</source>
        <translation>Se tiene que eligir uno o más nudos/subarboles para exportar.</translation>
    </message>
    <message>
        <source>You must choose one or more languages.</source>
        <translation>Se tiene que eligir uno o más idiomas.</translation>
    </message>
    <message>
        <source>You must choose one or more site access.</source>
        <translation>Se tiene que eligir uno o más accesos de sitio.</translation>
    </message>
    <message>
        <source>CSS files</source>
        <translation>Archivos CSS</translation>
    </message>
    <message>
        <source>You must upload both CSS files</source>
        <translation>Se tiene que subir ambos archivos CSS</translation>
    </message>
    <message>
        <source>Content object %objectname</source>
        <translation>Objeto de contenido %objectname</translation>
    </message>
    <message>
        <source>Site access mapping</source>
        <translation>Mapping de accesos a los sitios</translation>
    </message>
    <message>
        <source>Top node placements</source>
        <translation>Ubicación de los nudos más altos</translation>
    </message>
    <message>
        <source>Content object import</source>
        <translation>Importación de objetos de contenido</translation>
    </message>
    <message>
        <source>Select parent nodes</source>
        <translation>Elige los nudos padres</translation>
    </message>
    <message>
        <source>You must assign all nodes to new parent nodes.</source>
        <translation>Se tiene que asignar todos los nudos a los nuevos nudos padres.</translation>
    </message>
    <message>
        <source>Lead</source>
        <translation>Introducción</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Desarrollador</translation>
    </message>
    <message>
        <source>Designer</source>
        <translation>Diseñador</translation>
    </message>
    <message>
        <source>Contributor</source>
        <translation>Contributor</translation>
    </message>
    <message>
        <source>Tester</source>
        <translation>Comprobador</translation>
    </message>
    <message>
        <source>The package name %packagename is not valid, it can only contain characters in the range a-z, 0-9 and underscore.</source>
        <translation>El nombre de paquete %packagename no es valido. Solo puede contener caracteros a-z, 0-9 y subrayado.</translation>
    </message>
</context>
<context>
    <name>kernel/pdf</name>
    <message>
        <source>PDF Export</source>
        <translation>Exportación PDF</translation>
    </message>
</context>
<context>
    <name>kernel/pdfexport</name>
    <message>
        <source>New PDF Export</source>
        <translation>Nueva exportación PDF</translation>
    </message>
</context>
<context>
    <name>kernel/reference</name>
    <message>
        <source>Reference documentation</source>
        <translation>Documentación de referencia</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Role list</source>
        <translation>Lista de roles</translation>
    </message>
    <message>
        <source>Editing policy</source>
        <translation>Editando política</translation>
    </message>
    <message>
        <source>Limit on section</source>
        <translation>Limitación a nivel de sección</translation>
    </message>
    <message>
        <source>Create new policy, step 2: select function</source>
        <translation>Crear nueva política, paso 2: elegir función</translation>
    </message>
    <message>
        <source>Create new policy, step three: set function limitations</source>
        <translation>Crear nueva política, paso tres: fijar limitaciones de función</translation>
    </message>
    <message>
        <source>Create new policy, step two: select function</source>
        <translation>Crear nueva política, paso dos: elegir función</translation>
    </message>
    <message>
        <source>Create new policy, step one: select module</source>
        <translation>Crear nueva política, paso uno: elegir módulo</translation>
    </message>
</context>
<context>
    <name>kernel/role/edit</name>
    <message>
        <source>New role</source>
        <translation>Nuevo rol</translation>
    </message>
</context>
<context>
    <name>kernel/rss</name>
    <message>
        <source>Really Simple Syndication</source>
        <translation>Really Simple Syndication (RSS)</translation>
    </message>
    <message>
        <source>New RSS Export</source>
        <translation>Nueva exportación RSS</translation>
    </message>
    <message>
        <source>New RSS Import</source>
        <translation>Nueva importación RSS</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Estadísticas de la búsqueda</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Editar Sección</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Secciones</translation>
    </message>
    <message>
        <source>New section</source>
        <translation>Nueva sección</translation>
    </message>
    <message>
        <source>View section</source>
        <translation>Ver sección</translation>
    </message>
</context>
<context>
    <name>kernel/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Administrador de Caché</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Información de sistema</translation>
    </message>
    <message>
        <source>Rapid Application Development</source>
        <translation>Desarrollo de Aplicación Rápida (RAD)</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Asistente de operador de plantilla</translation>
    </message>
    <message>
        <source>Extension configuration</source>
        <translation>Configuración de extensión</translation>
    </message>
    <message>
        <source>Activate extensions</source>
        <translation>Activar extensiones</translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Menú de configuración</translation>
    </message>
    <message>
        <source>Session admin</source>
        <translation>Sesión de administración</translation>
    </message>
    <message>
        <source>File %1 does not exist. You should copy it from the recent eZ Publish distribution.</source>
        <translation>El archivo %1 no existe. Hay que copiarle desde una distribución reciente de eZ Publish.</translation>
    </message>
    <message>
        <source>System Upgrade</source>
        <translation>Actualización del sistema</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Asistente de tipo de datos</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Cesta</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Realizar pago</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmar pedido</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Grupo de descuento</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>Vista de grupo de la regla de descuento</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Editando regla</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Lista de pedido</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation>Vista del pedido</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Insertar información de cuenta</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Tipos de IVA</translation>
    </message>
    <message>
        <source>Customer list</source>
        <translation>Lista de clientes</translation>
    </message>
    <message>
        <source> Customer order view</source>
        <translation>Vista de pedidos de clientes</translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation>Estadisticas</translation>
    </message>
    <message>
        <source>Remove order</source>
        <translation>Eliminar pedido</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Tipo de IVA</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Clases</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Cualquier clase</translation>
    </message>
    <message>
        <source>in sections</source>
        <translation>en secciones</translation>
    </message>
    <message>
        <source>in any section</source>
        <translation>en cualquier sección</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Productos</translation>
    </message>
    <message>
        <source>Any product</source>
        <translation>Cualquier producto</translation>
    </message>
    <message>
        <source>The confirm order operation was canceled. Try to checkout again.</source>
        <translation>La confirmación de la operación de pedido ha sido cancelada. Prueba de realizar el pago otra vez.</translation>
    </message>
</context>
<context>
    <name>kernel/shop/discountgroup</name>
    <message>
        <source>New discount group</source>
        <translation>Nuevo grupo de descuento</translation>
    </message>
    <message>
        <source>New Discount Rule</source>
        <translation>Nueva regla de descuento</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Disparador</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <source>URL edit</source>
        <translation>Editar URL</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Registrar</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Cambiar contraseña</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Contraseña olvidada</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Información de registro</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Nuevo usuario registrado</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Editar flujo de trabajo</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Flujo de trabajo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar </translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Editar grupo de flujo de trabajo</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Editar grupo</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Lista de grupos de flujo de trabajo</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>Lista de grupos</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Lista de flujos de trabajo de un grupo</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Lista de flujo de trabajo</translation>
    </message>
    <message>
        <source>You have to have at least one group that the workflow belongs to!</source>
        <translation>Debes tener al menos un grupo al que pertenezca el flujo de trabajo!</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/edit</name>
    <message>
        <source>New Workflow</source>
        <translation>Nuevo Flujo de trabajo</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Event</source>
        <translation>Evento</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Aprobar</translation>
    </message>
    <message>
        <source>Multiplexer</source>
        <translation>Multiplexador</translation>
    </message>
    <message>
        <source>Simple shipping</source>
        <translation>Compra sencilla</translation>
    </message>
    <message>
        <source>Wait until date</source>
        <translation>Espera hasta fecha</translation>
    </message>
    <message>
        <source>Payment Gateway</source>
        <translation>Pasarela de pago</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/group</name>
    <message>
        <source>Group</source>
        <translation>Grupo</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/groupedit</name>
    <message>
        <source>New WorkflowGroup</source>
        <translation>Nuevo Grupo de flujos de trabajo</translation>
    </message>
</context>
<context>
    <name>lib/ezpdf/classes</name>
    <message>
        <source>Contents</source>
        <comment>Table of contents</comment>
        <translation>Contenidos</translation>
    </message>
    <message>
        <source>Index</source>
        <comment>Keyword index name</comment>
        <translation>Índice</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Han ocurrido algunos errores de plantilla. Para más información, mirar el depurador.</translation>
    </message>
</context>
<context>
    <name>pdf/edit</name>
    <message>
        <source>PDF Export</source>
        <translation>Exportación PDF</translation>
    </message>
</context>
<context>
    <name>settings/edit</name>
    <message>
        <source>Settings</source>
        <translation>Configuraciones</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
</context>
<context>
    <name>settings/view</name>
    <message>
        <source>Settings</source>
        <translation>Configuraciones</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
</context>
<context>
    <name>setup/templateadmin</name>
    <message>
        <source>Template edit</source>
        <translation>Editar plantilla</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>shop</name>
    <message>
        <source>Remove orders</source>
        <translation>Eliminar pedidos</translation>
    </message>
</context>
</TS>
