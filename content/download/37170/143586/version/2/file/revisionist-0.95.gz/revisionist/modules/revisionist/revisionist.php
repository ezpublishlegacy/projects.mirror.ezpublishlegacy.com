<?php
//
// Created on: <20-09-2006> pike@labforculture.org
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//


	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( 'kernel/common/template.php' );


	$Module = $Params['Module'];

	$tpl = templateInit();

	$request= array();
	$result = array();

	$http		= eZHTTPTool::instance();
	$node_id	= $http->variable('node_id');
	if ($http->hasVariable('action')) {


		$node	= eZContentObjectTreeNode::fetch($node_id);
		if ($node) {
			$object_id 				= $node->attribute("contentobject_id");
			$object 				= eZContentObject::fetch($object_id);
			$initial				= $object->version(1); // 1 ?
			$initial_id				= ($initial)?$initial->attribute("id"):false;
			$current				= $object->currentVersion();
			$current_id				= $current->attribute("id");

			/*
				the mapping below is ezpublish voodoo
			*/

			// node.creator==node.object.current.creator
			$set_currentcreatorid	= $http->variable('creator');

			//node.object.owner==node.object.versions[0].creator
			$set_objectownerid 		= $http->variable('owner');
			$set_initialcreatorid	= $http->variable('owner');

			//node.object.modified = node.object.current/modified
			$set_objectmodified 	= strtotime($http->variable('modified'));
			$set_currentmodified	= strtotime($http->variable('modified'));

			//node.object.published=node.object.versions[0].published
			$set_objectpublished 	= strtotime($http->variable('published'));
			$set_initialmodified	= strtotime($http->variable('published'));


			// and these arent 'actively' used in ezp, apparently
			//$set_initialcreated	= $http->variable('set_initialcreated');
			//$set_currentcreated	= $http->variable('set_currentcreated');

			// if there is only one version, creator must be owner
			if ($initial_id==$current_id) {
				if ($set_currentcreatorid) {
					$set_objectownerid = $set_currentcreatorid;
					$set_initialcreatorid = $set_currentcreatorid;
				}
			}
			$db = eZDB::instance();


			if ($set_objectownerid) {
				ezDebug::writeDebug("set_objectownerid $set_objectownerid","revisionist.php");
				$db->query( "UPDATE ezcontentobject SET owner_id='$set_objectownerid' WHERE id='$object_id'" );
			}
			if ($set_objectmodified) {
				ezDebug::writeDebug("set_objectmodified $set_objectmodified","revisionist.php");
				$db->query( "UPDATE ezcontentobject SET modified='$set_objectmodified' WHERE id='$object_id'" );
			}
			if ($set_objectpublished) {
				ezDebug::writeDebug("set_objectpublished $set_objectpublished","revisionist.php");
				$db->query( "UPDATE ezcontentobject SET published='$set_objectpublished' WHERE id='$object_id'" );
			}
			if ($initial) {
				if ($set_initialcreatorid) {
					ezDebug::writeDebug("set_initialcreatorid $set_initialcreatorid","revisionist.php");
					$db->query( "UPDATE ezcontentobject_version SET creator_id='$set_initialcreatorid' WHERE id='$initial_id'" );
				}
				if ($set_initialcreated) {
					ezDebug::writeDebug("set_initialcreated $set_initialcreated","revisionist.php");
					$db->query( "UPDATE ezcontentobject_version SET created='$set_initialcreated' WHERE id='$initial_id'" );
				}
				if ($set_initialmodified) {
					ezDebug::writeDebug("set_initialmodified $set_initialmodified","revisionist.php");
					$db->query( "UPDATE ezcontentobject_version SET modified='$set_initialmodified' WHERE id='$initial_id'" );
				}
			}
			if ($set_currentcreatorid) {
				ezDebug::writeDebug("set_currentcreatorid $set_currentcreatorid","revisionist.php");
				$db->query( "UPDATE ezcontentobject_version SET creator_id='$set_currentcreatorid' WHERE id='$current_id'" );
			}
			if ($set_currentcreated) {
				ezDebug::writeDebug("set_currentcreated $set_currentcreated","revisionist.php");
				$db->query( "UPDATE ezcontentobject_version SET created='$set_currentcreated' WHERE id='$current_id'" );
			}
			if ($set_currentmodified) {
				ezDebug::writeDebug("set_currentmodified $set_currentmodified","revisionist.php");
				$db->query( "UPDATE ezcontentobject_version SET modified='$set_currentmodified' WHERE id='$current_id'" );
			}
			// no commit, nothing ..
			$success=true;
		} else {
			$success = false;
			$feedback = "cant find node ";
		}
	}

	$request = compact(array('node_id','set_objectownerid','set_objectmodified','set_objectpublished','set_initialcreatorid','set_initialcreated','set_initialmodified','set_currentcreatorid','set_currentcreated','set_currentmodified'));
	$result = compact(array("result","feedback","object_id","initial_id","current_id"));


	$tpl->setVariable( 'request', $request );
	$tpl->setVariable( 'result', $result );


	$Result = array();
	$Result['content'] 	= $tpl->fetch( 'design:revisionist/revisionist.tpl' );
	$Result['path'] 	= array(
		array( 'url' => false, 'text' => 'Revisionist' )
	);

?>
