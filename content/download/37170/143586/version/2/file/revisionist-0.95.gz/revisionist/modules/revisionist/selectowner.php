<?php
//
// Created on: <20-09-2006> pike@labforculture.org
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//


	include_once( "lib/ezutils/classes/ezhttptool.php" );
	include_once( 'kernel/common/template.php' );
	
	
	$Module = $Params['Module'];
	
	$tpl = templateInit();
	
	$request= array();
	$result = array();
	
	$http		= eZHTTPTool::instance();
	$node_id	= $http->variable('node_id');
	$creator 	= $http->variable('creator');
	$owner 		= $http->variable('owner');
	$modified	= $http->variable('modified');
	$published	= $http->variable('published');
	
	// fecth all userids and names. this performs
	// beter when done from php.
	$params = array();
	$params['AsObject']			= false;
	$params['LoadDataMap'] 		= false;
	$params['MainNodeOnly']	  	= true;						// dont fecth dupes
	$params['IgnoreVisibility']	= true;						// ignore hidden
	$params['ClassFilterType'] 	= "include";				// "include" or "exclude"
	$params['ClassFilterArray'] = array("user");			// array of class_identifiers
	$params['SortBy'] 			= array(array("name",true));
	
	$usersnode = eZContentObjectTreeNode::fetch(5);
	$usersdata = $usersnode->subTree($params);

	//var_dump($usersdata);
	
	
	$request = compact(array(
		'node_id','creator','owner','modified','published'
	));
	$result = compact(array(
		'usersdata'
	));
		
	
	$tpl->setVariable( 'request', $request );
	$tpl->setVariable( 'result', $result );
	
	
	$Result = array();
	$Result['content'] 	= $tpl->fetch( 'design:revisionist/selectowner.tpl' );
	$Result['path'] 	= array( 
		array( 'url' => '/revisionist/revisionist?node_id='.$node_id, 'text' => 'Revisionist' ),
		array( 'url' => false, 'text' => 'Select owner' )
	);

?>
