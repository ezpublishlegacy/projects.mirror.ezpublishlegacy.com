<?php

	$Module = array( "name" => "revisionist" );
	
	$ViewList = array();
	
	$ViewList["revisionist"] = array("script" => "revisionist.php");
	$ViewList["selectcreator"] = array("script" => "selectcreator.php");
	$ViewList["selectowner"] = array("script" => "selectowner.php");



?>
