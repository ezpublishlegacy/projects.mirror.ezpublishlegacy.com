
[AdditionalMenuSettings]
ContextMenuTemplateArray[]=revisionist/contextmenu.tpl
SubitemsContextMenuTemplateArray[]=revisionist/subitemscontextmenu.tpl

