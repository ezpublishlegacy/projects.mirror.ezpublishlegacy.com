<?php
/*
[ExtensionSettings]
DesignExtensions[]=revisionist
*/
?>
