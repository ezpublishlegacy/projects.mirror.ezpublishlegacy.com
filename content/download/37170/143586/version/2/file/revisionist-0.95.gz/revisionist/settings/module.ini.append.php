[ModuleSettings]
ExtensionRepositories[]=revisionist
ModuleList[]=revisionist