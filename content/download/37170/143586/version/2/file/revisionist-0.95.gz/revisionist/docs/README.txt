=============
ezRevisionist - some addons for the admin interface
=============
Release: 0.95
Created: <2009/07> pike@labforculture.org
Commissioned by LabforCulture

This extension adds one entry
to the contextsenstive menu: revisionist.
It takes you to a page where you are
allowed to set creator, set owner, set modified
and set published properties of the selected node.


- set creator
  allows you to set $node.creator 
  (effectively sets $node.object.current.creator)

- set owner
  allows you to set $node.object.owner 
  also sets $node.object.versions[0].creator if possible
  	
- set modified
  allows you to set $node.object.modified 
  also sets $node.object.current.modified
 
- set published
  allows you to set $node.object.published
  also sets  $node.object.versions[0].created if possible
  
All these sets are done through SQL on the contentobject
and contentobject_version tables.

------------
Dependencies: 

- ezp4.0

------------
Known issues: 

- None

-------------
Status:  

 - beta. tested on my own 4.0.3 installation





