<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=arraysortoperator

*/?>