<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/arraysortoperator/classes/arraysortoperator.php',
                                    'class' => 'ArraySortOperator',
                                    'operator_names' => array( 'sort', 'rsort', 'asort', 'arsort', 'ksort', 'krsort', 'natsort', 'natcasesort' ) );
?>