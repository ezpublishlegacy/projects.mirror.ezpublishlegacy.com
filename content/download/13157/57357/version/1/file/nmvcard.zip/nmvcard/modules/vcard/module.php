<?php

$Module = array( "name" => "vCard" );

$ViewList["download"] 	= array('functions' => array( 'download' ),
								"script" 	=> "download.php",
								"params" 	=> array( "NodeID" ));

$FunctionList['download'] = array( );

?>

