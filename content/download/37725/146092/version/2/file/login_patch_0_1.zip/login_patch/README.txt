Concurrent logins patch

Written by Moshkovich Genrih ( genri[at]i-b[dot]com[dot]ua )

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

 Features
****************************

When you preview some user through eZ admin interface there is a link "Configure user account settings" that can lead you to user settings. There you can find a text field called "Maximum concurrent logins" but it is disabled. This patch makes these functionality work...

This patch was made as an unswer for these forum topics:
http://ez.no/community/forum/setup_design/activating_concurrent_logins
http://ez.no/community/forum/setup_design/maximum_concurrent_logins
http://ez.no/community/forum/setup_design/restricting_multiple_concurrent_logon_login
http://issues.ez.no/2238

 Installation instructions
****************************

To install this patch on eZ 3.9.2 update files provided in kernel and design folders.

To install this patch on other versions you can do the following instructions
(this is because /kernel/user/login.php and /kernel/classes/datatypes/ezuser/ezuser.php 
are different for different versions of eZ):

1. In /kernel/user/login.php

$tpl->setVariable( 'warning', array( 'bad_login' => $loginWarning ), 'User' );

Replace with:

if ($user!="max_failed") 
{$tpl->setVariable( 'warning', array( 'bad_login' => $loginWarning ), 'User' );}
else {$tpl->setVariable( 'warning', array( 'max_login' => $loginWarning ), 'User' );}
-------------------------------------------------------------------

In /kernel/classes/datatypes/ezuser/ezuser.php added:

        function fetchMUserCount( $userID )
    {
        if ( isset( $GLOBALS['eZSiteBasics']['no-cache-adviced'] ) and
             !$GLOBALS['eZSiteBasics']['no-cache-adviced'] and
             isset( $GLOBALS['eZMUserCount'] ) )
            return $GLOBALS['eZMUserCount'];
        $db =& eZDB::instance();
        $time = mktime();
        $ini =& eZINI::instance();
        $activityTimeout = $ini->variable( 'Session', 'ActivityTimeout' );
        $sessionTimeout = $ini->variable( 'Session', 'SessionTimeout' );
        $time = $time + $sessionTimeout - $activityTimeout;

        $sql = "SELECT count( session_key ) as count
FROM ezsession
WHERE user_id = '" . $userID . "' AND
      expiration_time > '$time'";
        $rows = $db->arrayQuery( $sql );
        $count = ( count( $rows ) > 0 ) ? $rows[0]['count'] : 0;
        $GLOBALS['eZMUserCount'] = $count;
        
        return $count;
    }
-------------------------------------------------------------------

2. In /kernel/classes/datatypes/ezuser/ezuser.php in function &loginUser(...) 

        if ( $exists and $isEnabled and $canLogin )
        {
        	$oldUserID = $contentObjectID = $http->sessionVariable( "eZUserLoggedInID" );
            eZDebugSetting::writeDebug( 'kernel-user', $userRow, 'user row' );
            $user = new eZUser( $userRow );
            eZDebugSetting::writeDebug( 'kernel-user', $user, 'user' );
            $userID = $user->attribute( 'contentobject_id' );

            // if audit is enabled logins should be looged
            eZAudit::writeAudit( 'user-login', array( 'User id' => $userID, 'User login' => $user->attribute( 'login' ) ) );

            eZUser::updateLastVisit( $userID );
            eZUser::setCurrentlyLoggedInUser( $user, $userID );

            // Reset number of failed login attempts
            eZUser::setFailedLoginAttempts( $userID, 0 );
		
            return $user; 
        }
        else
        {
            // Failed login attempts should be looged
            $userIDAudit = isset( $userID ) ? $userID : 'null';
            eZAudit::writeAudit( 'user-failed-login', array( 'User id' => $userIDAudit, 'User login' => $loginEscaped,
                                                             'Comment' => 'Failed login attempt: eZUser::loginUser()' ) );

            // Increase number of failed login attempts.
            if ( isset( $userID ) )
                eZUser::setFailedLoginAttempts( $userID );

            $user = false;
            return $user;
        }

Replace with:

        if ( $exists and $isEnabled and $canLogin )
        {
		include_once( "kernel/classes/datatypes/ezuser/ezusersetting.php" );
		$userSetting = eZUserSetting::fetch( $userID );
		$maxLogin = $userSetting->attribute( "max_login" );
		$count = eZUser::fetchMUserCount( $userID );
          if (($count < $maxLogin) or ($maxLogin==0)) {
            $oldUserID = $contentObjectID = $http->sessionVariable( "eZUserLoggedInID" );
            eZDebugSetting::writeDebug( 'kernel-user', $userRow, 'user row' );
            $user = new eZUser( $userRow );
            eZDebugSetting::writeDebug( 'kernel-user', $user, 'user' );
            $userID = $user->attribute( 'contentobject_id' );

            // if audit is enabled logins should be looged
            eZAudit::writeAudit( 'user-login', array( 'User id' => $userID, 'User login' => $user->attribute( 'login' ) ) );

            eZUser::updateLastVisit( $userID );
            eZUser::setCurrentlyLoggedInUser( $user, $userID );

            // Reset number of failed login attempts
            eZUser::setFailedLoginAttempts( $userID, 0 );
		
            return $user; }
		// Failed max concurent login attempts
          else {
            $user = "max_failed";
            return $user;}
        }
        else
        {
            // Failed login attempts should be looged
            $userIDAudit = isset( $userID ) ? $userID : 'null';
            eZAudit::writeAudit( 'user-failed-login', array( 'User id' => $userIDAudit, 'User login' => $loginEscaped, 'Comment' => 'Failed login attempt: eZUser::loginUser()' ) );

            // Increase number of failed login attempts.
            if ( isset( $userID ) )
                eZUser::setFailedLoginAttempts( $userID );

            $user = false;
            return $user;
        }
-------------------------------------------------------------------

Next instructions can be made by updating files from design folder or you can also perform them manually:

3. In design/standard/templates/user/login.tpl 

After:
{section show=$User:warning.bad_login}
....
{section-else}

Add:

{section show=$User:warning.max_login}
<div class="warning">
<h2>{"Could not login"|i18n("design/standard/user")}</h2>
<ul>
    <li>{"Your login limit is overflow."|i18n("design/standard/user")}</li>
</ul>
</div>
{section-else}
-------------------------------------------------------------------

4. If you use ezwebin extension you will also need to update /extension/ezwebin/design/ezwebin/templates/user/login.tpl

Add:
{elseif $User:warning.max_login}
<div class="warning">
<h2>{"Could not login"|i18n("design/standard/user")}</h2>
<ul>
    <li>{"Your login limit is overflow."|i18n("design/standard/user")}</li>
</ul>
</div>

Between
{if $User:warning.bad_login}
<div class="warning">
...
</div>
And
{else}

-------------------------------------------------------------------

5. In /design/admin/templates/user/setting.tpl

<input type="text" name="max_login" size="11" value="{$userSetting.max_login}" title="{'This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]'|i18n( 'design/admin/user/setting' )}" disabled="disabled" />

Replace with:
<input type="text" name="max_login" size="11" value="{$userSetting.max_login}" title="{'This functionality is not currently not available. [Use this field to specify the maximum allowed number of concurrent logins.]'|i18n( 'design/admin/user/setting' )}"  />

