<?php
//
// Definition of ymcCountryType class
//
// Created on: <16-Jan-2006 12:20:00 ymc-dabe>
//
// Copyright (C) 2006 Young Media Concepts GmbH. All rights reserved.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// If you wish to use this extension under conditions others than the
// GPL you need to contact Young MediaConcepts first (licence@ymc.ch).
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//
// Contact licence@ymc.ch if any conditions of this licencing isn't clear to
// you.
//

/*!
  \class ymcCountryType ymccountrytype.php
  \ingroup eZDatatype
  \brief A content datatype which handles countries

  It allows thesuer to select a country from a list predefined
  in ymccountry.ini.

  It uses the field data_text in a content object attribute for storing
  the attribute data with its ISO 3166-3 code.

*/

include_once( 'kernel/classes/ezdatatype.php' );
include_once( 'kernel/common/i18n.php' );

define( 'YMC_DATATYPECOUNTRY_STRING', 'ymccountry' );


class ymcCountryType extends eZDataType
{
    /*!
     Initializes with a string id and a description.
    */
    function ymcCountryType()
    {
        $this->eZDataType( YMC_DATATYPECOUNTRY_STRING, ezi18n( 'kernel/classes/datatypes', 'Country', 'Datatype name' ),
                           array( 'serialize_supported' => true,
                                  'object_serialize_map' => array( 'data_text' => 'text' ) ) );
        $this->MappingISO = array();
        $this->Countries = array();

        $this->initialiseForCurrentLanguage();
    }
    
    function initialiseForCurrentLanguage()
    {
        $countryList = array();
        $countryINI =& eZINI::instance( 'ymccountry.ini');

        $this->MappingISO = $countryINI->variable( 'Default', 'ISOmapping' );

        foreach ( $countryINI->variable( 'Default', 'Countries' ) as $key => $value )
        {
            $countryList[$key] = ezi18n( 'kernel/content/datatypes/ymccountry', $value );
        }
        natcasesort($countryList);
        $this->Countries = $countryList;
    }

    /*!
     Sets the default value.
    */
    function initializeObjectAttribute( &$contentObjectAttribute, $currentVersion, &$originalContentObjectAttribute )
    {
        if ( $currentVersion != false )
        {
            $dataText = $originalContentObjectAttribute->attribute( "data_text" );
            $contentObjectAttribute->setAttribute( "data_text", $dataText );
        }
        else
        {
            $CountryINI =& eZINI::instance( 'ymccountry.ini');
            $default = $CountryINI->variable( 'Default', 'DefaultCountry' );
            if ( $default !== "" and $default != "false" )
            {
                $contentObjectAttribute->setAttribute( "data_text", $default );
            }
        }
    }

    /*!
     \reimp
    */
    function validateObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_ymccountry_iso_3166_3_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data =& $http->postVariable( $base . '_ymccountry_iso_3166_3_' . $contentObjectAttribute->attribute( 'id' ) );
            if ( $contentObjectAttribute->validateIsRequired() )
            {
                if ( $data == "" )
                {
                    $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                         'Input required.' ) );
                    return EZ_INPUT_VALIDATOR_STATE_INVALID;
                }
            }
            if ( in_array($data, array_keys($this->Countries)) )
                return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
            $contentObjectAttribute->setValidationError( ezi18n( 'kernel/classes/datatypes',
                                                                 'Input required.' ) );
        }
        else
        {
            return EZ_INPUT_VALIDATOR_STATE_ACCEPTED;
        }
        return EZ_INPUT_VALIDATOR_STATE_INVALID;
    }

    /*!
     Fetches the http post var string input and stores it in the data instance.
    */
    function fetchObjectAttributeHTTPInput( &$http, $base, &$contentObjectAttribute )
    {
        if ( $http->hasPostVariable( $base . '_ymccountry_iso_3166_3_' . $contentObjectAttribute->attribute( 'id' ) ) )
        {
            $data =& $http->postVariable( $base . '_ymccountry_iso_3166_3_' . $contentObjectAttribute->attribute( 'id' ) );
            $contentObjectAttribute->setAttribute( 'data_text', $data );
            return true;
        }
        return false;
    }

    /*!
     Does nothing since it uses the data_text field in the content object attribute.
     See fetchObjectAttributeHTTPInput for the actual storing.
    */
    function storeObjectAttribute( &$attribute )
    {
    }

    function storeClassAttribute( &$attribute, $version )
    {
    }

    function storeDefinedClassAttribute( &$attribute )
    {
    }

    /*!
     Builds an array with the ISO 3166-3 code and a human readable translation of it
    */
    function &countryInformation( &$contentObjectAttribute )
    {
        $countries = $this->Countries;
        $ISOmapping = $this->MappingISO;
        $iso_3166_3 = $contentObjectAttribute->attribute( 'data_text' );
        $return = array( 'iso-3166-3' => $iso_3166_3,
                         'iso-3166-2' => $ISOmapping[$iso_3166_3],
                         'name' => $countries[$iso_3166_3],
                         'available_countries' => $countries );
        return $return;
    }

    /*!
     Returns the content.
    */
    function &objectAttributeContent( &$contentObjectAttribute )
    {
        return $this->countryInformation( $contentObjectAttribute );
    }

    /*!
     Returns the meta data used for storing search indeces.
    */
    function metaData( &$contentObjectAttribute )
    {
        $data =& $this->countryInformation( $contentObjectAttribute );
        return $data['name'];
    }

    /*!
     Returns the content of the string for use as a title
    */
    function title( &$contentObjectAttribute )
    {
        $data =& $this->countryInformation( $contentObjectAttribute );
        return $data['name'];
    }

    function hasObjectAttributeContent( &$contentObjectAttribute )
    {
        $data =& $this->countryInformation( $contentObjectAttribute );
        return trim( $data['name'] ) != '';
    }

    /*!
     \reimp
    */
    function isIndexable()
    {
        return true;
    }

    /*!
     \reimp
    */
    function &sortKey( &$contentObjectAttribute )
    {
        include_once( 'lib/ezi18n/classes/ezchartransform.php' );
        $trans =& eZCharTransform::instance();
        $data =& $this->countryInformation( $contentObjectAttribute );
        return $trans->transformByGroup( $data['name'], 'lowercase' );
    }

    /*!
     \reimp
    */
    function &sortKeyType()
    {
        return 'string';
    }

    /// \privatesection
    /// The list of avalible countries
    var $Countries;
}

eZDataType::register( YMC_DATATYPECOUNTRY_STRING, 'ymccountrytype' );

?>
