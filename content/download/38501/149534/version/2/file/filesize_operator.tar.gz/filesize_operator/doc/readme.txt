filesize operator extension.

Provides the function uffilesize.

USAGE:
<integer>|uffilesize

EXAMPLE:
{$node.name|wash} ({$node.data_map.image.content.original.filesize|uffilesize()})

returns: "My Image (1,2 MB)"
