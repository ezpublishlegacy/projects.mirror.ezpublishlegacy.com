<?php /* #?ini charset="utf-8"?

[ApiProvider]
# Register API provider for example.org/api/ssr/...
ProviderClass[ssr]=svrPostApiProvider

*/ ?>