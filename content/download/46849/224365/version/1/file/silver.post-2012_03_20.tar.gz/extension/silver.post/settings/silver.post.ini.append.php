<?php /* #?ini charset="utf-8"?

[NodeSettings]
# configure allowed nodes to post in
PostAllowed[174]=Business track
PostAllowed[175]=Community track
PostAllowed[196]=Lisboa

*/ ?>