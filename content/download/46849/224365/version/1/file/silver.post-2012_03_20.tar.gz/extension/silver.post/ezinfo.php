<?php

class svrPostInfo {

    static function info() {
        return array(
            'Name'      => '<a href="http://projects.ez.no/silver-post/">silver.post</a> extension',
            'Version'   => '2012-03-09',
            'Author'    => '<a href="http://www.silversolutions.de/">silver.solutions GmbH</a>',
            'Info_url'  => 'http://projects.ez.no/silver-post/',
            'Copyright' => 'Copyright (c) 2012 silver.solutions GmbH',
            'Credits'   => '',
            'License'   => 'GNU General Public License v2.0',
        );
    }
}

?>