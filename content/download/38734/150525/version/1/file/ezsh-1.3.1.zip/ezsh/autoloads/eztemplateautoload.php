<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezsh/autoloads/ezsh.php',
                                    'class' => 'eZSH',
                                    'operator_names' => array( 'ezsh' ) );
?>