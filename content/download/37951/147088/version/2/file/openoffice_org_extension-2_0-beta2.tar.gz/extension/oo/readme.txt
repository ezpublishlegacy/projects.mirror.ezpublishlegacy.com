eZ publish OpenOffice.org extension
===================================
This extension enables import and export of OpenOffice.org Writer documents within 
eZ publish. It comes with a general OpenOffice.org Writer document generation library 
as well, if you have custom modules that needs to generate OpenOffice.org Writer 
documents.

For documentation look under doc/