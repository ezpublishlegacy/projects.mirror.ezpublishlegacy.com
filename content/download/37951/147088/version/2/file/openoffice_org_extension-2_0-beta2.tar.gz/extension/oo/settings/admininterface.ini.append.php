
[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/oocontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/oosubitemscontextmenu.tpl

