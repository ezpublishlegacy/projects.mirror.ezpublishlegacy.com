
[ModuleSettings]
ExtensionRepositories[]=oo
