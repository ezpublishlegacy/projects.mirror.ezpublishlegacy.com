
[CreateSettings]

# Upload handler setting for stock 3.6
MimeUploadHandlerMap[application/octet-stream]=ezopenofficeuploadhandler
MimeUploadHandlerMap[application/vnd.oasis.opendocument.text]=ezopenofficeuploadhandler

MimeUploadHandlerMap[application/msword]=ezopenofficeuploadhandler
MimeUploadHandlerMap[application/rtf]=ezopenofficeuploadhandler

