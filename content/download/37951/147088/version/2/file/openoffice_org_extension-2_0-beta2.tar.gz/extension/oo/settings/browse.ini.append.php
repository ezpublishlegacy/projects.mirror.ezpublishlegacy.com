
[OOPlace]
StartNode=content
SelectionType=single
ReturnType=NodeID
