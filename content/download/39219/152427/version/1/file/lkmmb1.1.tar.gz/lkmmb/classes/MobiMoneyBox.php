<?php 

class MobiMoneyBox
{
	public static function check( $code = null, $itemID, $method )
	{
		$eZMMBIni = eZINI::instance('lkmmb.ini.append.php');

		if($code)
		{
			// connection to socket
			$fp = fsockopen('ssl://'.$eZMMBIni->variable('Settings', 'MMBSSLHost'), $eZMMBIni->variable('Settings', 'SSLPort'), $errno, $errstr, $eZMMBIni->variable('Settings','TimeOut'));

			if($fp)
			{
				$buffer = '';
				fwrite($fp, "Helo#".$eZMMBIni->variable('Settings', 'ClientID')."#".$itemID."#".$code."#".$method."#\n\r\n");
				$buffer = fread($fp, 2046);
			
				while( !preg_match('/\r?\n\r?\n/', $buffer) )
				{
					$buffer .= fread($fp, 2046);
					break;
				}

				if(substr($buffer,0,3) == '+OK')
					return true;
				else 
					return false;
			}
			else
			{
				return false;
			}
		
			fclose($fp);
		}
		else
		{
			return false;
		}
	}
}

?>
