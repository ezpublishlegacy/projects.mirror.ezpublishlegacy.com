<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="eng_GB">
<context>
	<name>extension/lkmmb</name>
	<message>
		<source>Buy</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>If you have the key, write here:</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>If you want to see more, just</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>ok</source>
		<translation type="unfinished"></translation>
	</message>
</context>
</TS>
