<?php /* #?ini charset="utf-8"?

[Settings]
SSLPort=443
TimeOut=30
MMBSSLHost=178.33.48.198
MMBHost=mobimoneybox.com
ClientID=
TitleSimpleButton=Buy
TitleExtendedButton=Buy
mC=m&#8353

*/ ?>
