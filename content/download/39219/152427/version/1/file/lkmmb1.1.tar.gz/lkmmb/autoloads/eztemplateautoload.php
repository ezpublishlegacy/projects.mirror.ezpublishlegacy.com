<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/lkmmb/autoloads/operatorMMB.php',
                                    'class' => 'operatorMMB',
                                    'operator_names' => array( 'lkcheckmmb', 'lkaddsimplebutton', 'lkaddextendedbutton', 'current_url' ) );

?>
