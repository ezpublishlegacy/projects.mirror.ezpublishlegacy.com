<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pol_PL" sourcelanguage="eng_GB">
<context>
	<name>extension/lkmmb</name>
	<message>
		<source>Buy</source>
		<translation>Kup</translation>
	</message>
	<message>
		<source>If you have the key, write here:</source>
		<translation>Jeśli posiadasz klucz, wpisz tutaj:</translation>
	</message>
	<message>
		<source>If you want to see more, just</source>
		<translation>Jeśli chcesz zobaczyć więcej, po prostu</translation>
	</message>
	<message>
		<source>ok</source>
		<translation>ok</translation>
	</message>
</context>
</TS>
