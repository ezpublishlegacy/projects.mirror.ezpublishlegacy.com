<?php 
class operatorMMB
{
	function __construct()
	{
		
	}
	
	function operatorList()
	{
		return array( 'lkcheckmmb', 'lkaddsimplebutton', 'lkaddextendedbutton', 'current_url' );
	}
	
	function namedParameterPerOperator()
    {
        return true;
    }
    
    function namedParameterList()
    {
    	return array( 'lkcheckmmb' => array(    'params' => array( 'type' => 'array',
						                        'required' => true,
						                        'default' => array() ) ),
    				  'lkaddsimplebutton' => array(    'params' => array( 'type' => 'array',
						                        'required' => true,
						                        'default' => array() ) ),
    				  'lkaddextendedbutton' => array(    'params' => array( 'type' => 'array',
						                        'required' => true,
						                        'default' => array() ) ),
    				  'current_url'			=> array()
    				);
    }
    
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters )
    {
		$ret = '';
		
		$params = $namedParameters['params'];
		switch ( $operatorName )
        {
            case 'lkcheckmmb':
                {                    
                    $ret = MobiMoneyBox::check($params['code'],$params['itemID'],$params['method']);        
                } break;
            case 'lkaddsimplebutton':
            	{
            		$ret = operatorMMB::CreateSimpleButton($params['itemID'],$params['method']);                    
            	} break;
            case 'lkaddextendedbutton':
            	{
            		$ret = operatorMMB::CreateExtendedButton($params['itemID'],$params['method'],$params['price']);                    
            	} break;
            case 'current_url':
            	{
            		$ret = 'http://'.$_SERVER['SERVER_NAME'].''.$_SERVER['REQUEST_URI'];                    
            	} break;
        }
        $operatorValue = $ret;
    }
    
    function CreateSimpleButton($itemID, $method)
    {
    	$eZMMBIni = eZINI::instance('lkmmb.ini.append.php');
    	$MMBHost = $eZMMBIni->variable('Settings', 'MMBHost');
    	$CliendID = $eZMMBIni->variable('Settings', 'ClientID');
    	$url = 'http://'.$_SERVER['SERVER_NAME'].''.$_SERVER['REQUEST_URI'];
    	$TitleSimpleButton = $eZMMBIni->variable('Settings', 'TitleSimpleButton');
    	
    	$script = '
    	<div class="SimpleMMBButton">
    	<form action="https://'.$MMBHost.'/app/item/buy" method="post">
    		<input type="hidden" name="clientId" value="'.$CliendID.'" />
    		<input type="hidden" name="itemId" value="'.$itemID.'" />
    		<input type="hidden" name="method" value="'.$method.'" />
    		<input type="hidden" name="url" value="'.$url.'" />
    		<input type="submit" value="'.ezi18n( 'extension/lkmmb', $TitleSimpleButton ).'" name="secureFormSubmit" />
    	</form>
    	</div>
    	';
    	
    	return $script;
    }
    
    function CreateExtendedButton($itemID, $method, $price)
    {
    	$eZMMBIni = eZINI::instance('ezmmb.ini.append.php');
    	$MMBHost = $eZMMBIni->variable('Settings', 'MMBHost');
    	$CliendID = $eZMMBIni->variable('Settings', 'ClientID');
    	$url = 'http://'.$_SERVER['SERVER_NAME'].''.$_SERVER['REQUEST_URI'];
    	$TitleExtendedButton = $eZMMBIni->variable('Settings', 'TitleExtendedButton');
    	$mC = $eZMMBIni->variable('Settings', 'mC');
    	
    	$script = '
    	<div class="ExtendedMMBButton">
    	<form action="https://'.$MMBHost.'/app/item/buy" method="post">
    		<input type="hidden" name="clientId" value="'.$CliendID.'" />
    		<input type="hidden" name="itemId" value="'.$itemID.'" />
    		<input type="hidden" name="method" value="'.$method.'" />
    		<input type="hidden" name="url" value="'.$url.'" />
    		<input type="submit" value="'.ezi18n( 'extension/ezmmb', $TitleExtendedButton ).'" name="secureFormSubmit" />
    	</form>
    	<div class="mC">'.$price.$mC.'</div>
    	</div>
    	';
    	
    	return $script;
    }
}
?>
