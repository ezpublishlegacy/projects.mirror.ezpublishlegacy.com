<?php /* #?ini charset="utf-8"?

[CustomTagSettings]
AvailableCustomTags[]=CheckMMBArea

[CheckMMBArea]
CustomAttributes[]=itemID
CustomAttributes[]=method
CustomAttributes[]=price
CustomAttributes[]=button
CustomAttributesDefaults[itemID]=YOUR ID ITEM
CustomAttributesDefaults[method]=YOUR METHOD ID
CustomAttributesDefaults[price]=YOUR mC PRICE
CustomAttributesDefaults[button]=simple

*/ ?>