<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=lkmmb

[RegionalSettings]
TranslationExtensions[]=lkmmb

*/ ?>
