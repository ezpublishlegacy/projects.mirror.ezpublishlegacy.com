------------------------------------------------------------------------------
--- FetchUrlAlias  1.0                                                     ---
------------------------------------------------------------------------------
/*
    FetchUrlAlias for eZ publish 3.x
    Copyright (C) 2007  Tobias Vogel, Zieltraffic AG

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/


1. Introduction
---------------

This operator allows to fetch the full path of a content node in ezpublish
for a given locale. This extension is only intended to be a temporary
workaround for the multilingual url alias system in eZ publish 3.10.x,
until a similiar functionality makes it into the next stable release of eZ
publish.


2. Problem Description 
----------------------

In version 3.10, eZ publish brought a new URL alias system, that allowed for
translated URL aliases (which is especially good for SEO). The only drawback
was, that all sorts of language switchers were left broken. The reason for
this is, that in version 3.10, there's no way to retrieve the URL alias of a 
node in another than the currently used locale (no operator, no fetch).

The only possibility to safely link other languages was by using the Node-ID:
/content/view/full/$node.node_id  


4. Solution
-----------

I wrote a custom operator, that fetches the full node path in a desired locale.
As requested by Xavier Dutoit, this now comes in an extension, to make it more
usable (global activation, one package).


5. How to use ?
---------------

The operator 'fetch_url_alias' fetches the complete path of a node in a given
locale. The node is identified by its ID and the locale as a string (e.g. 'eng-US').
Both parameters are required and cannot be ommited.

Example usage for a language switcher:
<a href={fetch_url_alias($node.node_id, 'ger-DE')|ezurl()}>Read it in german</a>
<a href={fetch_url_alias($node.node_id, 'eng-US')|ezurl()}>Read it in english</a> 


6. Known bugs and limitations
-----------------------------

The operator will only be able to generate a fully localized URL, if all nodes on 
the path have an URL-alias in the desired locale, else it will return an URL with
mixed locales (like you see them in the admin backend template for URL aliases).

Example comparison:
1. /imprint/copyright (eng-US only, correct)
2. /pie_de_imprenta/derechos_de_propiedad_intelectual (esl-ES only, correct)
1. /imprint/derechos_de_propiedad_intelectual (eng-US and esl-ES mixed)

ATTENTION: If you have different SiteAccesses for each language, and only one
language allowed for each, these mixed locale URLs will break ("Module not found"
errors). 

If you find any additonal bugs, drop an email to tobias.vogel(at)zieltraffic.de


7. Thanks
---------

Having fiddled with the problem for a whole day without a usable solution, a comment
from Luis Muñoz regarding 'urlalias.tpl' brought me on the right track
(http://ez.no/developer/forum/setup_design/language_switcher_in_3_10#msg153517)
