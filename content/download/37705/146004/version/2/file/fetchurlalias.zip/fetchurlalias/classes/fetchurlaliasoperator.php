<?php
include_once( 'kernel/classes/ezurlaliasquery.php' );

/*!
  \class   FetchUrlAliasOperator fetchurlaliasoperator.php
  \ingroup eZTemplateOperators
  \brief   Fetches the URL alias of a node (defined by its id) for a certain locale. 
  \version 1.0
  \date    Monday November 26 2007 02:51:15 pm
  \author  Tobias Vogel, Zieltraffic AG


  Example:
\code
<a href={fetch_url_alias($node.node_id, 'ger-DE')|ezurl()}>Read it in german</a>
<a href={fetch_url_alias($node.node_id, 'eng-US')|ezurl()}>Read it in english</a>
\endcode
*/
class FetchUrlAliasOperator
{
    /*!
      Constructor, does nothing by default.
    */
    function FetchUrlAliasOperator()
    {
    }
  
    /*!
      Returns an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'fetch_url_alias' );
    }
    /*!
      Return true to tell the template engine that the parameter list exists per operator type,
      this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }
    
    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array ( 
            'fetch_url_alias' => array(
                'node_id' => array( 'type' => 'integer',
                                    'required' => true,
                                    'default' => 0 ),
                'locale_code' => array( 'type' => 'string',
                                        'required' => true,
                                        'default' => '')
            ) 
        );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    {
        $nodeId = $namedParameters['node_id'];
        $localeCode = $namedParameters['locale_code'];

        switch ( $operatorName )
        {
            case 'fetch_url_alias':
            {
                // fetch the language mask of the locale code
                $prefLangMask = eZContentLanguage::maskByLocale($localeCode);
              
                // Fetch generated url aliases of the node
                $filter = new eZURLAliasQuery();
                $filter->actions = array( 'eznode:' . $nodeId );
                $filter->type = 'name';
                $filter->limit = false;    // fetch all aliases
                $filter->languages = false;  // fetch aliases in any language
                $elements = $filter->fetchAll();
                
                // search through all elements for the preferred locale
                foreach ($elements as $element) {
                  
                    // if preferred locale: return the fully localized node path
                    if (($element->LangMask & $prefLangMask) > 0) {
                        $operatorValue = $this->getPath($element, $prefLangMask);
                    }
                }
            }
            break;
        }
    }
    
    
    
    //======================================================================
    // Patched functions derived from the eZ object model (see comments)
    //======================================================================
            
    /**
     * Gets the path of an element with the correct locale
     * in all node tree levels (not just at the leaf).
     *
     * @param $element The element to calculate the path for
     * @param $prefLangMask The preferred language set as a single bit
     * @return A fully localized URL-alias path to the node
     * 
     * @see eZPathElement::getPath()
     */
    function getPath($element, $prefLangMask)
    {
        if ( $element->Path !== null )
            return $element->Path;

        // Fetch path 'text' elements of correct parent path
        $path = array( $element->Text );
        $id = (int)$element->Parent;
        $db = eZDB::instance();
        while ( $id != 0 )
        {
            $query = "SELECT parent, lang_mask, text FROM ezurlalias_ml WHERE id={$id}";
            $rows = $db->arrayQuery( $query );
            if ( count( $rows ) == 0 )
            {
                break;
            }
            
            // The original line below will always return the alias for the current
            // locale and thus possibly break the URL-alias path (mixed locales in path). 
            // Replaced with a custom function based on a preferred locale.
            //$result = eZURLAliasML::choosePrioritizedRow( $rows );
                
            $result = $this->choosePrioritizedRow($rows, $prefLangMask);
            if ( !$result )
            {
                $result = $rows[0];
            }
            $id = (int)$result['parent'];
            array_unshift( $path, $result['text'] );
        }
        $element->Path = implode( '/', $path );
        return $element->Path;
    }
    
    /**
     * Chooses the prioritized row, based on a preferred locale
     *
     * @param $rows Database result set with all matching rows
     * @param $prefLangMask bitmask with the preferred language bit set
     * @return The row with the alias part in the preferred language
     * 
     * @see eZURLAliasML::choosePrioritizedRow()
     */
    function choosePrioritizedRow($rows, $prefLangMask) {
        foreach ($rows as $row) {
            if (($row['lang_mask'] & $prefLangMask) > 0) {
                return $row;
            }
        }
    }
}

?>
