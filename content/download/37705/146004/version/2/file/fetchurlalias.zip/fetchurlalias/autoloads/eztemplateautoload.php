<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =
    array(
        'script'         => 'extension/fetchurlalias/classes/fetchurlaliasoperator.php',
        'class'          => 'FetchUrlAliasOperator',
        'operator_names' => array( 'fetch_url_alias' ) 
    );
?>