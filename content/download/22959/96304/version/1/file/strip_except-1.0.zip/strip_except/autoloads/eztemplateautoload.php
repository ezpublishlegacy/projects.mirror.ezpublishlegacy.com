<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
	array( 'script' => 'extension/strip_except/stripexceptoperator.php',
                            'class' => 'StripexceptOperator',
                            'operator_names' => array( 'strip_except' ) );
?>
