<?php /* #?ini charset="utf-8"?

[box_browser]
Source=ezoe/box_browse.tpl
MatchFile=ezoe/box_browse.tpl
Subdir=templates

[upload_objects]
Source=ezoe/upload_objects.tpl
MatchFile=ezoe/upload_objects.tpl
Subdir=templates

[ezp_cmis_object_content]
Source=content/view/full.tpl
MatchFile=content/view/cmis.tpl
Subdir=templates
Match[class_identifier]=cmis_object

[ezp_cmis_object_content_embed]
Source=content/view/embed.tpl
MatchFile=content/view/embed.tpl
Subdir=templates
Match[class_identifier]=cmis_object

*/ ?>