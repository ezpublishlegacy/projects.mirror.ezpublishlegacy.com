<?php
class ezdebugInfo
{
    static function info()
    {
        return array(
            'Name' => "eZ Debug extension",
            'Version' => "0.2",
            'Copyright' => "Copyright (C) 2008 G. Giunta",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
