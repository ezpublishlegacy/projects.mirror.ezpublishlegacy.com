<?php

/**

    PDF catalogue extension for eZ Publish - Class abPDFCatalogue

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

require_once( 'autoload.php' );
require_once( 'kernel/common/template.php' );

function abpdfcatalogue_ContentActionHandler( $module, $http, $objectID )
{

    $abPDFCatalogue = abPDFCatalogue::instance();

    if ( !$abPDFCatalogue instanceof abPDFCatalogue )
    {
        return false;
    }

    if ( $http->hasPostVariable( 'PDFCatalogueGeneratePDFByNodeID' ) &&
         $http->hasPostVariable( 'PDFCatalogueItemNodeID' ) &&
         $http->hasPostVariable( 'PDFCatalogueGeneratePDFTranslation' )
       )
    {
        $nodeID = (int)$http->postVariable( 'PDFCatalogueItemNodeID' );
        $languageCode = $http->postVariable( 'PDFCatalogueGeneratePDFTranslation' );
        $abPDFCatalogue->generatePDFByNodeID( $nodeID, $languageCode );

        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
        eZExecution::setCleanExit();
        return true;
    }

    if ( $http->hasPostVariable( 'PDFCatalogueSetItemListBotton' ) &&
         $http->hasPostVariable( 'PDFCatalogueItemNodeIDString' ) &&
         $http->hasPostVariable( 'PDFCatalogueGetItemListTranslation' )
       )
    {
        $nodeIDList = json_decode( $http->postVariable( 'PDFCatalogueItemNodeIDString' ), true );
        if ( isset( $nodeIDList['node_id_list'] ) && is_array( $nodeIDList['node_id_list'] ) )
        {
            $abPDFCatalogue->setCommonCatalogueItemList( $nodeIDList['node_id_list'] );
        }

        $result = $abPDFCatalogue->getCommonCatalogueItemList( trim( $http->postVariable( 'PDFCatalogueGetItemListTranslation' ) ) );

        echo $result;

        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
        eZExecution::setCleanExit();
        return false;
    }

    if ( $http->hasPostVariable( 'PDFCatalogueGenerateCommonBotton' ) &&
         $http->hasPostVariable( 'PDFCatalogueItemNodeIDString' ) &&
         $http->hasPostVariable( 'PDFCatalogueGetItemListTranslation' )
       )
    {
        $nodeIDList = json_decode( $http->postVariable( 'PDFCatalogueItemNodeIDString' ), true );
        if ( isset( $nodeIDList['node_id_list'] ) && is_array( $nodeIDList['node_id_list'] ) )
        {
            $abPDFCatalogue->generateCommonCatalogue( $nodeIDList['node_id_list'],
                                                      trim( $http->postVariable( 'PDFCatalogueGetItemListTranslation' ) ),
                                                      'live', false
                                                    );
        }

        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
        eZExecution::setCleanExit();
        return true;
    }

    if ( $http->hasPostVariable( 'PDFCatalogueRemoveItemBotton' ) &&
         $http->hasPostVariable( 'PDFCatalogueItemNodeID' ) &&
         $http->hasPostVariable( 'PDFCatalogueGetItemListTranslation' )
       )
    {
        $abPDFCatalogue->removeCommonCatalogueItemID( $http->postVariable( 'PDFCatalogueItemNodeID' ) );

        $result = $abPDFCatalogue->getCommonCatalogueItemList( trim( $http->postVariable( 'PDFCatalogueGetItemListTranslation' ) ) );

        echo $result;

        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
        eZExecution::setCleanExit();
        return true;
    }

    if ( $http->hasPostVariable( 'PDFCatalogueGetItemListButton' ) &&
         $http->hasPostVariable( 'PDFCatalogueGetItemListTranslation' )
       )
    {
        $result = $abPDFCatalogue->getCommonCatalogueItemList( trim( $http->postVariable( 'PDFCatalogueGetItemListTranslation' ) ) );

        echo $result;

        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
        eZExecution::setCleanExit();
        return true;
    }

}

?>