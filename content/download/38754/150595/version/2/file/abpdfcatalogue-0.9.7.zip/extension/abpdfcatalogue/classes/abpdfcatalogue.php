<?php

/**

    PDF catalogue extension for eZ Publish - Class abPDFCatalogue

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

class abPDFCatalogue
{

    const INTRODUCTION_FILE_ATTRIBUTE_NAME = 'introduction',
              APPENDIX_FILE_ATTRIBUTE_NAME = 'appendix',
           TARGET_FILE_NAME_ATTRIBUTE_NAME = 'targetfilename',
                 TOC_MARGINS_ATTRIBUE_NAME = 'toc_margins',
                  TOC_TITLE_ATTRIBUTE_NAME = 'toc_title',
             TOC_BACKGROUND_ATTRIBUTE_NAME = 'toc_background',
            TOC_MAX_ENTRIES_ATTRIBUTE_NAME = 'toc_max_entries',
           CUSTOM_TOC_TITLE_ATTRIBUTE_NAME = 'custom_toc_title',
                PDF_SUBJECT_ATTRIBUTE_NAME = 'pdf_subject',
                  PDF_TITLE_ATTRIBUTE_NAME = 'pdf_title',
                 PDF_AUTHOR_ATTRIBUTE_NAME = 'pdf_author',
               PDF_KEYWORDS_ATTRIBUTE_NAME = 'pdf_keywords',
            PDF_COMPRESSION_ATTRIBUTE_NAME = 'pdf_compression',
                  DEFAULT_TARGET_FILE_NAME = 'catalogue.pdf',
          PDF_DOCUMENT_FILE_ATTRIBUTE_NAME = 'pdf',
            FILE_CLASS_FILE_ATTRIBUTE_NAME = 'file',
                         CACHE_SUBDIR_NAME = 'pdfcatalogue',
                      TOC_MARGIN_SEPARATOR = ';',
             COMMON_TARGET_SESSION_ID_LIST = 'abPDFCatalogueCommonTargetItemNodeIDList';

    private static $instance = null;

    private       $liveMode = false,
                      $mode = 'cache',
              $documentList = array(),
               $pdfMetaData = array(),
                       $pdf = null,
            $targetFileName = '',
                 $startTime = 0,
               $resultArray = array();

    public static function instance()
    {
        if ( self::$instance === null )
        {
            self::$instance = new abPDFCatalogue();
        }
        return self::$instance;
    }

    public static function getRelationTargetFromAttribute( $attributeObject, $classIdentifier,
                                                           $asObject = false, $asList = false
                                                         )
    {
        $result = false;
        if ( $asList )
        {
            $result = array();
        }
        if ( $attributeObject->hasContent() )
        {
            $attributeContent = $attributeObject->attribute( 'content' );
            if ( array_key_exists( 'relation_list', $attributeContent ) && is_array( $attributeContent['relation_list'] ) )
            {
                foreach ( $attributeContent['relation_list'] as $relatedObjectInformation )
                {
                    if ( array_key_exists( 'contentclass_identifier', $relatedObjectInformation ) &&
                         $relatedObjectInformation['contentclass_identifier'] == $classIdentifier
                       )
                    {
                        if ( array_key_exists( 'contentobject_id', $relatedObjectInformation ) )
                        {
                            if ( $asObject )
                            {
                                $targetObject = eZContentObject::fetch( $relatedObjectInformation['contentobject_id'] );
                                if ( is_object( $targetObject ) )
                                {
                                    if ( $asList )
                                    {
                                        $result[] = $targetObject;
                                    }
                                    else
                                    {
                                        $result = $targetObject;
                                    }
                                    break;
                                }
                                else
                                {
                                    eZDebug::writeWarning( 'Failed to fetch target object with ID ' . $relatedObjectInformation['contentobject_id'], __METHOD__ );
                                }
                            }
                            else
                            {
                                if ( $asList )
                                {
                                    $result[] = (int)$relatedObjectInformation['contentobject_id'];
                                }
                                else
                                {
                                    $result = (int)$relatedObjectInformation['contentobject_id'];
                                }
                                break;
                            }
                        }
                        else
                        {
                            eZDebug::writeWarning( 'The appendix attribute of the PDF Catalogue content object has no content object id in the relation list', __METHOD__ );
                        }
                    }
                    else
                    {
                        eZDebug::writeDebug( 'Skipping related object of class ' . $relatedObjectInformation['contentclass_identifier'], __METHOD__ );
                        continue;
                    }
                }
            }
            else
            {
                eZDebug::writeWarning( 'The appendix attribute of the PDF Catalogue content object has no relation list', __METHOD__ );
            }
        }
        return $result;
    }

    public function clearCache()
    {
        $cacheDirectory = $this->cacheDirectory();

        if ( $cacheDirectory !== false )
        {
            eZDebug::writeDebug( 'Clearing cache in ' . $cacheDirectory, __METHOD__ );
            eZDir::recursiveDelete( $cacheDirectory );
            return true;
        }
        else
        {
            eZDebug::writeWarning( 'Failed to remove cache directory.', __METHOD__ );
        }
        return false;
    }

    public function removeCommonCatalogueItemID( $itemID )
    {
        $http        = eZHTTPTool::instance();
        $nodeIDArray = array();
        $itemID      = (int)trim( $itemID );
        if ( $http->hasSessionVariable( self::COMMON_TARGET_SESSION_ID_LIST ) )
        {
            $currentNodeIDArray = $http->sessionVariable( self::COMMON_TARGET_SESSION_ID_LIST );
            foreach ( $currentNodeIDArray as $currentNodeID )
            {
                if ( $currentNodeID != $itemID )
                {
                    $nodeIDArray[] = $currentNodeID;
                }
            }
        }
        $nodeIDArray = array_unique( $nodeIDArray );
        $http->setSessionVariable( self::COMMON_TARGET_SESSION_ID_LIST, $nodeIDArray );
    }

    public function setCommonCatalogueItemList( $itemList )
    {
        $http        = eZHTTPTool::instance();
        $nodeIDArray = array();
        $itemList    = array_unique( $itemList );
        foreach ( $itemList as $key => $nodeID )
        {
            $nodeIDArray[] = (int)$nodeID;
        }
        $http->setSessionVariable( self::COMMON_TARGET_SESSION_ID_LIST, $nodeIDArray );
    }

    public function addCommonCatalogueItemID( $itemID )
    {
        $http        = eZHTTPTool::instance();
        $nodeIDArray = array();
        $itemID      = (int)trim( $itemID );
        if ( $http->hasSessionVariable( self::COMMON_TARGET_SESSION_ID_LIST ) )
        {
            $nodeIDArray = $http->sessionVariable( self::COMMON_TARGET_SESSION_ID_LIST );
        }
        $nodeIDArray[] = $itemID;
        $nodeIDArray   = array_unique( $nodeIDArray );
        $http->setSessionVariable( self::COMMON_TARGET_SESSION_ID_LIST, $nodeIDArray );
    }

    public function generatePDFByNodeID( $nodeID, $languageCode )
    {
        $fileNamePrefix = $this->getFileNamePrefix( $nodeID, $languageCode );
        if ( !$fileNamePrefix )
        {
            return false;
        }
        $pdfFileName        = $fileNamePrefix . '.pdf';
        $htmlFileName       = $fileNamePrefix . '.html';
        $contentObjectArray = eZContentObject::fetchByNodeID( $nodeID, false );
        if ( !is_array( $contentObjectArray ) || !array_key_exists( 'modified', $contentObjectArray ) )
        {
            eZDebug::writeWarning( 'Failed to fetch content object of node ID ' . $nodeID . '.', __METHOD__ );
            return false;
        }
        $objectModificationTimeStamp  = $contentObjectArray['modified'];
        $pdfFileModificationTimeStamp = is_readable( $pdfFileName ) ? filemtime( $pdfFileName ) : 0;
        if ( $pdfFileModificationTimeStamp !== false && $pdfFileModificationTimeStamp > $objectModificationTimeStamp )
        {
            eZDebug::writeDebug( 'Using cached PDF file for node ID ' . $nodeID . '.', __METHOD__ );
            return true;
        }
        $htmlFileModificationTimeStamp = is_readable( $htmlFileName ) ? filemtime( $htmlFileName ) : 0;
        if ( $htmlFileModificationTimeStamp === false || $htmlFileModificationTimeStamp < $objectModificationTimeStamp )
        {
            $fullURI = '/content/view/full/' . $nodeID;

            eZURI::transformURI( $fullURI, false, 'full' );

            $pageContent = file_get_contents( $fullURI );
            if ( $pageContent !== false )
            {
                $levelCount = count( explode( eZDir::separator( eZDir::SEPARATOR_LOCAL ), $htmlFileName ) ) - 1;
                $finalHTML  = $this->correctRelativeLinksInHTML( $pageContent, $levelCount );
                if ( file_put_contents( $htmlFileName, $finalHTML ) === false )
                {
                    eZDebug::writeWarning( 'Failed to store HTML file on disk at ' . $htmlFileName . '.', __METHOD__ );
                }
            }
            else
            {
                eZDebug::writeWarning( 'Failed to fetch web page from ' . $fullURI . '.', __METHOD__ );
            }
        }
        else
        {
            eZDebug::writeDebug( 'Using cached HTML file for node ID ' . $nodeID . '.', __METHOD__ );
        }
        if ( !is_readable( $htmlFileName ) )
        {
            eZDebug::writeWarning( 'File ' . $htmlFileName . ' does not exist or is not readable.', __METHOD__ );
            return false;
        }
        $htmlFileSize = filesize( $htmlFileName );
        if ( $htmlFileSize < 1 )
        {
            unlink( $htmlFileName );
            eZDebug::writeWarning( 'File ' . $htmlFileName . ' is empty.', __METHOD__ );
            return false;
        }

        if ( !$this->convertHTMLToPDF( $htmlFileName, $pdfFileName ) )
        {
            return false;
        }
        return true;
    }

    public function convertNodeToPDF( $nodeID, $locale )
    {
        if ( $this->generatePDFByNodeID( $nodeID, $locale ) )
        {
            $fileNamePrefix = $this->getFileNamePrefix( $nodeID, $locale );
            if ( !$fileNamePrefix )
            {
                return false;
            }
            $pdfFileName = $fileNamePrefix . '.pdf';
            $name = 'webpage.pdf';
            $contentNode = eZContentObjectTreeNode::fetch( $nodeID );
            if ( is_object( $contentNode ) )
            {
                $name = $contentNode->attribute( 'name' ) . '.pdf';
            }
            $this->downloadPDF( false, $name, $pdfFileName );
        }
    }

    public function getCommonCatalogueItemList( $locale )
    {
        $http         = eZHTTPTool::instance();
        $result       = '';
        $languageCode = trim( $locale );
        $nodeIDArray  = array();
        $queryResult  = array();

        if ( $http->hasSessionVariable( self::COMMON_TARGET_SESSION_ID_LIST ) )
        {
            $nodeIDArray = $http->sessionVariable( self::COMMON_TARGET_SESSION_ID_LIST );
        }

        $finalResult = array();
        if ( is_array( $nodeIDArray ) && count( $nodeIDArray ) > 0 && $languageCode != '' )
        {
            $db = eZDB::instance();
            if ( is_object( $db ) )
            {
                $inPart    = 'ezcontentobject_tree.node_id=-1';
                $query = '
SELECT ezcontentobject_tree.node_id, ezcontentobject_name.name
FROM ezcontentobject_name, ezcontentobject_tree
WHERE ezcontentobject_name.contentobject_id=ezcontentobject_tree.contentobject_id AND
      ezcontentobject_name.content_version=ezcontentobject_tree.contentobject_version AND
      ezcontentobject_name.content_translation="' . $db->escapeString( $languageCode ) . '" AND
      ' . $db->generateSQLINStatement( $nodeIDArray, 'ezcontentobject_tree.node_id' );
                $queryResult = $db->arrayQuery( $query );
                foreach ( $nodeIDArray as $key => $nodeID )
                {
                    foreach ( $queryResult as $key => $itemInformation )
                    {
                        if ( $itemInformation['node_id'] == $nodeID )
                        {
                            $finalResult[] = $itemInformation;
                            break;
                        }
                    }
                }
            }
        }

        $tpl = templateInit();
        if ( is_object( $tpl ) )
        {
            $tpl->setVariable( 'nodeNameList', $finalResult );
            $result = $tpl->fetch( 'design:pdfcatalogue/commontargetlist.tpl' );
        }
        return $result;
    }

    private function convertHTMLToPDF( $htmlFileName, $pdfFileName )
    {
        $pdfCatalogueIni = eZINI::instance( 'pdfcatalogue.ini' );
        if ( !$pdfCatalogueIni instanceof eZINI )
        {
            return false;
        }
        $commandList = array();
        if ( !$pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'JavaExecutablePath' ) )
        {
            return false;
        }
        $commandList[] = escapeshellcmd( trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'JavaExecutablePath' ) ) );
        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'JavaExtraParameters' ) )
        {
            $extraParameterList = $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'JavaExtraParameters' );
            if ( is_array( $extraParameterList ) )
            {
                foreach ( $extraParameterList as $extraParameter )
                {
                    $commandList[] = escapeshellarg( trim( $extraParameter ) );
                }
            }
        }
        if ( !$pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'JarFilePath' ) )
        {
            return false;
        }
        $commandList[] = '-jar';
        $commandList[] = escapeshellarg( trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'JarFilePath' ) ) );
        $commandList[] = escapeshellarg( $htmlFileName );
        $commandList[] = escapeshellarg( $pdfFileName );
        $output     = '';
        $returnCode = 0;

        $result     = exec( implode( ' ', $commandList ), $output, $returnCode );
        if ( !is_readable( $pdfFileName ) )
        {
            return false;
        }
        $pdfFileSize = filesize( $pdfFileName );
        if ( $pdfFileSize < 1 )
        {
            unlink( $pdfFileName );
            return false;
        }
        return $pdfFileSize;
    }

    private function fetchObjectIDFromRelationAttribute( $attributeObject )
    {
        $pdfDocumentObject = abPDFCatalogue::getRelationTargetFromAttribute( $attributeObject, 'ab_pdf_catalogue_document', true );
        if ( is_object( $pdfDocumentObject ) )
        {
            $dataMap = $pdfDocumentObject->attribute( 'data_map' );
            if ( array_key_exists( 'pdf_file', $dataMap ) )
            {
                return abPDFCatalogue::getRelationTargetFromAttribute( $dataMap['pdf_file'], 'file' );
            }
        }
        return false;
    }

    private function getFileNamePrefix( $nodeID, $languageCode )
    {
        $user = eZUser::currentUser();
        if ( is_object( $user ) )
        {
            $cacheFileNameList = array( $user->attribute( 'contentobject_id' ), $languageCode );
            $cacheDirectory    = $this->cacheDirectory( $cacheFileNameList );
            if ( $cacheDirectory !== false )
            {
                $cacheFileArray = eZNodeviewfunctions::generateViewCacheFile( $user, $nodeID, 0, false,
                                                                              $languageCode, 'full',
                                                                              array(), false
                                                                            );
                if ( array_key_exists( 'cache_file', $cacheFileArray ) )
                {
                    return $cacheDirectory . eZDir::separator( eZDir::SEPARATOR_LOCAL ) . $cacheFileArray['cache_file'];
                }
                else
                {
                    eZDebug::writeWarning( 'Cache file name creation failed.', __METHOD__ );
                }
            }
        }
        else
        {
            eZDebug::writeWarning( 'Failed to fetch current user.', __METHOD__ );
        }
        return false;
    }

    private function checkCacheDirectory( $directoryName )
    {
        if ( !file_exists( $directoryName ) )
        {
            eZDebug::writeDebug( 'Creating cache directory for PDF catalogue files: ' . $directoryName, __METHOD__ );
            eZDir::mkdir( $directoryName, false, true );
        }
        if ( file_exists( $directoryName ) )
        {
            if ( is_dir( $directoryName ) )
            {
                if ( is_writable( $directoryName ) )
                {
                    return true;
                }
                else
                {
                    eZDebug::writeDebug( 'Directoy ' . $directoryName . ' is not writeable.', __METHOD__ );
                }
            }
            else
            {
                eZDebug::writeDebug( 'Directoy ' . $directoryName . ' is not a directory.', __METHOD__ );
            }
        }
        else
        {
            eZDebug::writeDebug( 'Directoy ' . $directoryName . ' does not exist.', __METHOD__ );
        }
        return false;
    }

    private function cacheDirectory( $subDirectories = false )
    {
        $cacheDir        = false;
        $pdfCatalogueIni = eZINI::instance( 'pdfcatalogue.ini' );
        $separator       = eZDir::separator( eZDir::SEPARATOR_LOCAL );
        if ( $pdfCatalogueIni->hasVariable( 'CommonSettings', 'PDFCacheDirectory' ) )
        {
            $cacheDirList   = array();
            $cacheDirList[] = eZSys::cacheDirectory();
            $cacheDirList[] = trim( $pdfCatalogueIni->variable( 'CommonSettings', 'PDFCacheDirectory' ) );
            if ( is_array( $subDirectories ) && count( $subDirectories ) > 0 )
            {
                $cacheDirList = array_merge( $cacheDirList, $subDirectories );
            }
            $cacheDir = eZDir::path( $cacheDirList, false, eZDir::SEPARATOR_LOCAL );
            eZDebug::writeDebug( 'Checking custom cache directory ' . $cacheDir, __METHOD__  );
            if ( !$this->checkCacheDirectory( $cacheDir ) )
            {
                $cacheDir = false;
            }
        }
        else
        {
            eZDebug::writeDebug( 'No custom cache directory configured. Using default.', __METHOD__  );
        }
        if ( $cacheDir === false )
        {
            $cacheDirList   = array();
            $cacheDirList[] = 'var';
            $cacheDirList[] = 'cache';
            $cacheDirList[] = abPDFCatalogue::CACHE_SUBDIR_NAME;
            if ( is_array( $subDirectories ) && count( $subDirectories ) > 0 )
            {
                $cacheDirList = array_merge( $cacheDirList, $subDirectories );
            }
            $cacheDir = eZDir::path( $cacheDirList, false, eZDir::SEPARATOR_LOCAL );
            eZDebug::writeDebug( 'Checking cache directory ' . $cacheDir, __METHOD__  );
            if ( !$this->checkCacheDirectory( $cacheDir ) )
            {
                $cacheDir = false;
            }
        }
        if ( $cacheDir === false )
        {
            eZDebug::writeWarning( 'Failed to create cache directory for PDF catalogue file.', __METHOD__  );
        }
        return $cacheDir;
    }

    private function cacheFilename( $hash )
    {
        $cacheDir = $this->cacheDirectory();
        if ( $cacheDir !== false )
        {
            return $cacheDir . eZDir::separator( eZDir::SEPARATOR_LOCAL ) . $hash . '.pdf';
        }
        return false;
    }

    public function verifyEmail( $jsonData )
    {
        $dataObject = json_decode( $jsonData, true );
        $email      = array_key_exists( 'email',  $dataObject ) ? $dataObject[ 'email' ]  : '';

        if ( trim( $email ) != '' && eZMail::validate( $email ) )
        {
            echo '1';
        }
        else
        {
            echo '0';
        }

        $this->eZPublishExit();
    }

    public function deCompress( $data )
    {
        if ( function_exists( 'lzf_decompress' ) )
        {
            eZDebug::writeDebug( 'Using decompression', __METHOD__ );
            return lzf_decompress( $data );
        }
        return $data;
    }

    public function compress( $data )
    {
        if ( function_exists( 'lzf_compress' ) )
        {
            eZDebug::writeDebug( 'Using compression', __METHOD__ );
            return lzf_compress( $data );
        }
        return $data;
    }

    public function sendEmail( $jsonData )
    {
        $dataObject    = json_decode( $jsonData, true );
        $senderEmail   = array_key_exists( 'sender',  $dataObject ) ? $dataObject[ 'sender' ]  : '';
        $subject       = array_key_exists( 'subject',  $dataObject ) ? $dataObject[ 'subject' ]  : '';
        $receiverEmail = array_key_exists( 'receiver',  $dataObject ) ? $dataObject[ 'receiver' ]  : '';
        $body          = array_key_exists( 'body',  $dataObject ) ? $dataObject[ 'body' ]  : '';
        $link          = array_key_exists( 'link',  $dataObject ) ? $dataObject[ 'link' ]  : '';
        $idlist        = array_key_exists( 'idlist',  $dataObject ) ? $dataObject[ 'idlist' ]  : '';
        $idlist        = $this->compress( $idlist );

        $body .= "\n\n" . $link . '/(idlist)/' . urlencode( $idlist );

        $mail = new eZMail();

        $mail->setSender( $senderEmail );
        $mail->setSubject( $subject );
        $mail->setReceiver( $receiverEmail );
        $mail->setBody( $body );

        $mailResult = eZMailTransport::send( $mail );

        echo $mailResult;

        $this->eZPublishExit();
    }

    public function generatePDF( $jsonData, $mode, $filename )
    {
        $this->startTime   = microtime( true );
        $this->resultArray = array( 'success' => false );

        if ( $mode != 'cache' && $mode != 'live' )
        {
            $this->resultArray[ 'error' ] = 'Invalid mode: ' . $mode;
            return $this->exitJSON();
        }

        $this->mode     = $mode;
        $this->liveMode = ( strtolower( $mode ) == 'live' ) ? true : false;

        if ( $jsonData == '' )
        {
            $this->resultArray[ 'error' ] = 'No JSON input data';
            return $this->exitJSON();
        }

        $documentIDList = array();
        $dataObject     = json_decode( $jsonData, true );
        $itemList       = array_key_exists( 'list',  $dataObject ) ? $dataObject[ 'list' ]  : array();
        $catalogueID    = array_key_exists( 'catid', $dataObject ) ? $dataObject[ 'catid' ] : false;

        if ( !is_array( $itemList ) || count( $itemList ) == 0 )
        {
            $this->resultArray[ 'error' ] = 'No files selected';
            return $this->exitJSON();
        }

        foreach ( $itemList as $item )
        {
            $documentIDList[$item['document_id']] = $item['pdf_id'];
        }

        if ( !$catalogueID )
        {
            $this->resultArray[ 'error' ] = 'No catalogue ID set';
            return $this->exitJSON();
        }

        $catalogueContentObject = eZContentObject::fetch( (int)$catalogueID );

        if ( !$catalogueContentObject instanceof eZContentObject )
        {
            $this->resultArray[ 'error' ] = 'Invalid Catalog ID: ' . $catalogueID;
            return $this->exitJSON();
        }

        $catalogueDataMap = $catalogueContentObject->dataMap();

        $this->targetFileName = abPDFCatalogue::DEFAULT_TARGET_FILE_NAME;

        $filename = trim( $filename );
        if ( $filename != '' )
        {
            $this->targetFileName = $filename;
        }

        $this->documentList = array();
        $this->pdfMetaData  = array();

        $tocMargins = array();
        if ( array_key_exists( self::TOC_MARGINS_ATTRIBUE_NAME, $catalogueDataMap ) &&
             is_object( $catalogueDataMap[self::TOC_MARGINS_ATTRIBUE_NAME] )
           )
        {
            $explodedString = explode( self::TOC_MARGIN_SEPARATOR,
                                       $catalogueDataMap[self::TOC_MARGINS_ATTRIBUE_NAME]->attribute( 'content' )
                                     );
            if ( count( $explodedString ) == 3 )
            {
                $tocMargins = $explodedString;
            }
        }

        $tocMaxEntries = 20;
        if ( array_key_exists( self::TOC_MAX_ENTRIES_ATTRIBUTE_NAME, $catalogueDataMap ) &&
             is_object( $catalogueDataMap[self::TOC_MAX_ENTRIES_ATTRIBUTE_NAME] )
           )
        {
            $tocMaxEntries = (int)$catalogueDataMap[self::TOC_MAX_ENTRIES_ATTRIBUTE_NAME]->attribute( 'data_int' );
        }

        $pdfCompression = false;
        if ( array_key_exists( self::PDF_COMPRESSION_ATTRIBUTE_NAME, $catalogueDataMap ) &&
             is_object( $catalogueDataMap[self::PDF_COMPRESSION_ATTRIBUTE_NAME] )
           )
        {
            if ( $catalogueDataMap[self::PDF_COMPRESSION_ATTRIBUTE_NAME]->attribute( 'content' ) == '1' )
            {
                $pdfCompression = true;
            }
        }

        $this->pdf = new abPDFCatalogueAssembler();

        $this->pdf->setTableOfContentsMargins( $tocMargins );
        $this->pdf->setTableOfContentsMaxEntries( $tocMaxEntries );
        $this->pdf->usePDFCompression( $pdfCompression );
        $this->preparePDFMetaData( $catalogueDataMap );
        $this->prepareDocumentList( $catalogueDataMap, $documentIDList );
        $this->mergePDFFiles();
    }

    public function generateCommonCatalogue( $itemList, $languageCode, $mode, $filename )
    {
        $pdfCatalogueIni = eZINI::instance( 'pdfcatalogue.ini' );
        if ( !$pdfCatalogueIni instanceof eZINI )
        {
            return false;
        }

        $this->startTime   = microtime( true );
        $this->resultArray = array( 'success' => false );

        if ( $mode != 'cache' && $mode != 'live' )
        {
            $this->resultArray[ 'error' ] = 'Invalid mode: ' . $mode;
            return $this->exitJSON();
        }

        $this->mode     = $mode;
        $this->liveMode = ( strtolower( $mode ) == 'live' ) ? true : false;

        if ( count( $itemList ) == 0 )
        {
            $this->resultArray[ 'error' ] = 'No documents selected';
            return $this->exitJSON();
        }

        $this->targetFileName = abPDFCatalogue::DEFAULT_TARGET_FILE_NAME;

        $filename = trim( $filename );
        if ( $filename != '' )
        {
            $this->targetFileName = $filename;
        }

        $this->documentList = array();
        $this->pdfMetaData  = array();

        $tocMargins = array();
        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'TOCMargins' ) )
        {
            $explodedString = explode( self::TOC_MARGIN_SEPARATOR,
                                       trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'TOCMargins' ) )
                                     );
            if ( count( $explodedString ) == 3 )
            {
                $tocMargins = $explodedString;
            }
        }

        $pdfCompression = false;
        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'PDFCompression' ) &&
             trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'PDFCompression' ) ) == 'enabled'
           )
        {
            $pdfCompression = true;
        }

        $successItemIDList = array();

        foreach ( $itemList as $itemID )
        {
            if ( $this->generatePDFByNodeID( $itemID, $languageCode ) !== false )
            {
                $successItemIDList[] = $itemID;
            }
        }

        $this->pdf = new abPDFCatalogueAssembler();

        $this->pdf->setTableOfContentsMargins( $tocMargins );
        $this->pdf->usePDFCompression( $pdfCompression );
        $this->prepareCommonPDFMetaData( $pdfCatalogueIni );
        $this->prepareCommonDocumentList( $pdfCatalogueIni, $successItemIDList, $languageCode );
        $this->mergePDFFiles();
    }

    private function preparePDFMetaData( $dataMap )
    {
        $attributeNameList = array(    'toc_title' => abPDFCatalogue::TOC_TITLE_ATTRIBUTE_NAME,
                                     'pdf_subject' => abPDFCatalogue::PDF_SUBJECT_ATTRIBUTE_NAME,
                                       'pdf_title' => abPDFCatalogue::PDF_TITLE_ATTRIBUTE_NAME,
                                      'pdf_author' => abPDFCatalogue::PDF_AUTHOR_ATTRIBUTE_NAME,
                                    'pdf_keywords' => abPDFCatalogue::PDF_KEYWORDS_ATTRIBUTE_NAME
                                  );
        foreach ( $attributeNameList as $fieldName => $attributeName )
        {
            $this->pdfMetaData[$fieldName] = false;
            if ( array_key_exists( $attributeName, $dataMap ) && is_object( $dataMap[$attributeName] ) )
            {
                $attributeObject = $dataMap[$attributeName];
                if ( $attributeObject->hasContent() )
                {
                    $content = trim( $attributeObject->attribute( 'content' ) );
                    if ( $content != '' )
                    {
                        $this->pdfMetaData[$fieldName] = $content;
                    }
                    else
                    {
                        eZDebug::writeDebug( 'Empty attribute in PDF catalogue object: ' . $attributeName, __METHOD__ );
                    }
                }
                else
                {
                    eZDebug::writeDebug( 'No content in attribute of PDF catalogue object: ' . $attributeName, __METHOD__ );
                }
            }
            else
            {
                eZDebug::writeDebug( 'No such attribute in PDF catalogue object: ' . $attributeName, __METHOD__ );
            }
        }
        $this->pdf->setMetaData( $this->pdfMetaData );
    }

    private function prepareCommonPDFMetaData( $pdfCatalogueIni )
    {
        $settingsNameList = array(    'toc_title' => 'TOCTitle',
                                    'pdf_subject' => 'PDFSubject',
                                      'pdf_title' => 'PDFTitle',
                                     'pdf_author' => 'PDFAuthor',
                                   'pdf_keywords' => 'PDFKeywords'
                                 );
        foreach ( $settingsNameList as $fieldName => $settingsName )
        {
            $this->pdfMetaData[$fieldName] = false;
            if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', $settingsName ) )
            {
                $this->pdfMetaData[$fieldName] = trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', $settingsName ) );
            }
            else
            {
                eZDebug::writeDebug( 'No such setting below CommonCatalogueSettings: ' . $settingsName, __METHOD__ );
            }
        }
        $this->pdf->setMetaData( $this->pdfMetaData );
    }

    private function prepareDocumentList( $dataMap, $documentIDList )
    {
        $requiredAttributeNames = array( abPDFCatalogue::INTRODUCTION_FILE_ATTRIBUTE_NAME,
                                         abPDFCatalogue::APPENDIX_FILE_ATTRIBUTE_NAME,
                                         abPDFCatalogue::TARGET_FILE_NAME_ATTRIBUTE_NAME
                                       );

        foreach ( $requiredAttributeNames as $requiredAttributeName )
        {
            if ( !array_key_exists( $requiredAttributeName, $dataMap ) ||
                 !is_object( $dataMap[$requiredAttributeName] )
               )
            {
                $this->resultArray[ 'error' ] = 'No such attribute in catalogue content object: ' . $requiredAttributeName;
                return $this->exitJSON();
            }
        }

        if ( $dataMap[abPDFCatalogue::TARGET_FILE_NAME_ATTRIBUTE_NAME]->hasContent() )
        {
            $this->targetFileName = $dataMap[abPDFCatalogue::TARGET_FILE_NAME_ATTRIBUTE_NAME]->attribute( 'content' );
        }

        $contentObjectId = $this->fetchObjectIDFromRelationAttribute( $dataMap[abPDFCatalogue::INTRODUCTION_FILE_ATTRIBUTE_NAME] );
        if ( is_int( $contentObjectId ) )
        {
            $this->documentList[] = array( 'type'   => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'pdf_id' => $contentObjectId,
                                           'toc'    => false
                                         );
        }

        $tocBackgroundFile = false;
        if ( array_key_exists( self::TOC_BACKGROUND_ATTRIBUTE_NAME, $dataMap ) &&
             is_object( $dataMap[self::TOC_BACKGROUND_ATTRIBUTE_NAME] )
           )
        {
            if ( $dataMap[self::TOC_BACKGROUND_ATTRIBUTE_NAME]->hasContent() )
            {
                $fileObject        = $dataMap[self::TOC_BACKGROUND_ATTRIBUTE_NAME]->attribute( 'content' );
                $tocBackgroundFile = eZSys::siteDir() . $fileObject->filePath();
                if ( !is_readable( $tocBackgroundFile ) )
                {
                    $tocBackgroundFile = false;
                    eZDebug::writeWarning( 'PDF catalogue table of contents file ' . $tocBackgroundFile . ' is not readable', __METHOD__ );
                }
                elseif ( $fileObject->attribute( 'mime_type' ) != 'application/pdf' )
                {
                    $tocBackgroundFile = false;
                    eZDebug::writeWarning( 'PDF catalogue table of contents file is not a PDF document. Ignoring.', __METHOD__ );
                }
            }
        }

        $this->documentList[] = array( 'type'  => abPDFAssembler::DOCUMENT_TYPE_TOC ,
                                       'title' => false,
                                       'toc'   => false,
                                       'bg'    => $tocBackgroundFile
                                     );

        foreach ( $documentIDList as $documentID => $pdfID )
        {
            $this->documentList[] = array( 'type'        => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'document_id' => $documentID,
                                           'pdf_id'      => $pdfID,
                                           'toc'         => true
                                         );
        }

        $contentObjectId = $this->fetchObjectIDFromRelationAttribute( $dataMap[abPDFCatalogue::APPENDIX_FILE_ATTRIBUTE_NAME] );
        if ( is_int( $contentObjectId ) )
        {
            $this->documentList[] = array( 'type'   => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'pdf_id' => $contentObjectId,
                                           'toc'    => false
                                         );
        }
    }

    private function prepareCommonDocumentList( $pdfCatalogueIni, $itemIDList, $languageCode )
    {
        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'TargetFileName' ) )
        {
            $this->targetFileName = trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'TargetFileName' ) );
        }

        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'IntroductionFileName' ) )
        {
            $introductionFileName = trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'IntroductionFileName' ) );
            if ( $introductionFileName != '' && is_readable( $introductionFileName ) )
            {
                $this->documentList[] = array( 'type'   => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                               'pdf_id' => false,
                                               'title'  => false,
                                               'file'   => $introductionFileName,
                                               'toc'    => false
                                             );
            }
        }

        $tocBackgroundFile = false;
        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'TOCBackgroundFileName' ) )
        {
            $backgroundFileName = trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'TOCBackgroundFileName' ) );
            if ( $backgroundFileName != '' && is_readable( $backgroundFileName ) )
            {
                $tocBackgroundFile = $backgroundFileName;
            }
        }

        $this->documentList[] = array( 'type'  => abPDFAssembler::DOCUMENT_TYPE_TOC ,
                                       'title' => false,
                                       'toc'   => false,
                                       'bg'    => $tocBackgroundFile
                                     );

        foreach ( $itemIDList as $itemID )
        {
            $fileNamePrefix     = $this->getFileNamePrefix( $itemID, $languageCode );
            $contentObjectArray = eZContentObject::fetchByNodeID( $itemID, false );

            $this->documentList[] = array( 'type'   => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                           'pdf_id' => false,
                                           'toc'    => true,
                                           'title'  => $contentObjectArray['name'],
                                           'file'   => $fileNamePrefix . '.pdf'
                                         );
        }

        if ( $pdfCatalogueIni->hasVariable( 'CommonCatalogueSettings', 'AppendixFileName' ) )
        {
            $appendixFileName = trim( $pdfCatalogueIni->variable( 'CommonCatalogueSettings', 'AppendixFileName' ) );
            if ( $appendixFileName != '' && is_readable( $appendixFileName ) )
            {
                $this->documentList[] = array( 'type'   => abPDFAssembler::DOCUMENT_TYPE_FILE,
                                               'pdf_id' => false,
                                               'title'  => false,
                                               'file'   => $appendixFileName,
                                               'toc'    => false
                                             );
            }
        }
    }

    private function mergePDFFiles()
    {
        $fileHash      = md5( serialize( $this->documentList ) );
        $cachefile     = $this->cacheFilename( $fileHash );
        $missingFiles  = array();
        $existingFiles = array();

        $this->resultArray[ 'hash' ]      = $fileHash;
        $this->resultArray[ 'cachefile' ] = $cachefile;
        $this->resultArray[ 'filename' ]  = $this->targetFileName;

        if ( $cachefile !== false && file_exists( $cachefile ) )
        {
            $this->resultArray[ 'cached' ]  = true;
            $this->resultArray[ 'success' ] = true;
        }
        else
        {
            foreach ( $this->documentList as $key => $doc )
            {
                if ( $doc['type'] != abPDFAssembler::DOCUMENT_TYPE_FILE )
                {
                    continue;
                }

                if ( $doc['pdf_id'] === false )
                {
                    continue;
                }

                $documentTitle    = false;

                if ( array_key_exists( 'document_id', $doc ) )
                {
                    $documentObjectID      = (int)$doc['document_id'];
                    $documentContentObject = eZContentObject::fetch( $documentObjectID );
                    if ( is_object( $documentContentObject ) )
                    {
                        $documentDataMap = $documentContentObject->dataMap();
                        if ( array_key_exists( abPDFCatalogue::CUSTOM_TOC_TITLE_ATTRIBUTE_NAME, $documentDataMap ) &&
                             is_object( $documentDataMap[abPDFCatalogue::CUSTOM_TOC_TITLE_ATTRIBUTE_NAME] ) &&
                             $documentDataMap[abPDFCatalogue::CUSTOM_TOC_TITLE_ATTRIBUTE_NAME]->hasContent()
                           )
                        {
                            $documentTitle = $documentDataMap[abPDFCatalogue::CUSTOM_TOC_TITLE_ATTRIBUTE_NAME]->content();
                        }
                        if ( $documentTitle === false )
                        {
                            $documentTitle = $documentContentObject->name();
                        }
                        unset( $documentDataMap );
                    }
                    else
                    {
                        eZDebug::writeWarning( 'Failed to fetch document content object with ID ' . $documentObjectID, __METHOD__ );
                    }
                    unset( $documentContentObject );
                }

                $pdfObjectID      = (int)$doc['pdf_id'];
                $pdfContentObject = eZContentObject::fetch( $pdfObjectID );

                if ( is_object( $pdfContentObject ) )
                {
                    $pdfDataMap    = $pdfContentObject->dataMap();

                    if ( $documentTitle === false )
                    {
                        $documentTitle = $pdfContentObject->name();
                    }

                    if ( array_key_exists( abPDFCatalogue::FILE_CLASS_FILE_ATTRIBUTE_NAME, $pdfDataMap ) &&
                         is_object( $pdfDataMap[abPDFCatalogue::FILE_CLASS_FILE_ATTRIBUTE_NAME] )
                       )
                    {
                        $attribute = $pdfDataMap[abPDFCatalogue::FILE_CLASS_FILE_ATTRIBUTE_NAME]->attribute( 'content' );
                        $filepath  = eZSys::siteDir() . $attribute->filePath();
                        if ( file_exists( $filepath ) )
                        {
                            $this->documentList[$key]['file']  = $filepath;
                            $this->documentList[$key]['title'] = $documentTitle;

                            $existingFiles[] = $pdfObjectID;
                        }
                        else
                        {
                            eZDebug::writeWarning( 'The file ' . $filepath . ' of content object ID ' . $pdfObjectID . ' and can not be merged into PDF catalogue.', __METHOD__ );
                            $missingFiles[] = $pdfObjectID;
                        }
                    }
                    else
                    {
                        eZDebug::writeWarning( 'Content object with ID ' . $pdfObjectID . ' does not seem to be a valid PDF Catalogue document.', __METHOD__ );
                        $missingFiles[] = $pdfObjectID;
                    }
                }
                else
                {
                    eZDebug::writeWarning( 'Document ID ' . $pdfObjectID . ' to merge into PDF catalogue is not a valid content object.', __METHOD__ );
                    $filepath = false;
                }

            }

            $this->pdf->setDocumentList( $this->documentList );
            $this->pdf->mergeDocuments();

            if  ( $cachefile !== false )
            {
                $this->pdf->Output( $cachefile, 'F' );
                if ( !file_exists( $cachefile ) )
                {
                    $cachefile = false;
                }
            }

            $this->resultArray[ 'existingfiles' ] = $existingFiles;
            $this->resultArray[ 'missingfiles' ]  = $missingFiles;
        }

        switch( $this->mode )
        {
            case 'live':
            {
                if ( $cachefile !== false )
                {
                    $this->downloadPDF( $fileHash, $this->targetFileName, $cachefile );
                }
                else
                {
                    $this->pdf->Output( $this->targetFileName, 'I' );
                }

                $this->resultArray[ 'success' ] = false;
                $this->resultArray[ 'error' ]   = "PDF download failure";

                return $this->exitJSON();
            }
            break;

            case 'cache':
            default:
            {
                if  ( $cachefile !== false )
                {
                    $this->resultArray[ 'success' ] = true;
                    $this->resultArray[ 'time' ]    = microtime( true ) - $this->startTime;
                    return $this->exitJSON();
                }
                else
                {
                    $this->resultArray[ 'success' ] = false;
                    $this->resultArray[ 'error' ]   = 'File can not be stored in ' . $cachefile;
                    return $this->exitJSON();
                }
            }
        }
    }

    public function downloadPDF( $hash, $fileName, $cacheFilename = false )
    {
        $sourceFile = '';
        if ( $cacheFilename !== false )
        {
            $sourceFile = $cacheFilename;
        }
        else
        {
            $sourceFile = $this->cacheFilename( $hash );
        }

        if ( $sourceFile !== false && file_exists( $sourceFile ) )
        {
            ini_set('zlib.output_compression','0');
            header( 'Cache-Control: public' );
            header( 'Content-Description: File Transfer' );
            //header( 'Content-Disposition: inline; filename="' . $fileName . '' );
            header( 'Content-Disposition: attachment; filename="' . $fileName . '"' );
            header( 'Content-type: application/pdf' );
            header( 'Content-Transfer-Encoding: binary');
            header( 'Content-Length: '. filesize( $sourceFile ) );
            $bytesWritten = readfile( $sourceFile );
            if ( $bytesWritten === false )
            {
                eZDebug::writeWarning( 'An error occured reading file ' . $sourceFilem, __METHOD__ );
            }
            else
            {
                eZDebug::writeDebug( 'Send ' . $bytesWritten . ' bytes for PDF download', __METHOD__ );
            }

            $this->eZPublishExit();
        }
    }

    public function exitJSON()
    {
        if ( $this->liveMode )
        {
            echo "<h1>Error</h1>";
            echo "<pre>", json_encode( $this->resultArray ), "</pre>";
        }
        else
        {
            header( 'Content-type: application/json' );
            header( 'Content-Disposition: attachment; filename=response.json' );
            echo json_encode( $this->resultArray );
        }

        $this->eZPublishExit();
    }

    private function correctRelativeLinksInHTML( $html, $levelCount )
    {
        $upDirectoryList = array();
        for ( $i = 0; $i < $levelCount; ++$i )
        {
            $upDirectoryList[] = '..';
        }
        $correctedHTML = preg_replace( '#(href|src)\s*=\s*["\'](?!https?|mailto)(\/?)(.*)["\']#Ui', '$1="' . implode( eZDir::separator( eZDir::SEPARATOR_LOCAL ), $upDirectoryList ) . '$3"', $html );
        $correctedHTML = preg_replace( '#(@import[\ \t]+url\()[\ \t"\']*(.*)[\ \t"\']*\)#Ui', '$1 "' . implode( eZDir::separator( eZDir::SEPARATOR_LOCAL ), $upDirectoryList ) . '$2" )', $correctedHTML );
        return $correctedHTML;
    }

    private function eZPublishExit()
    {
        eZDB::checkTransactionCounter();
        eZExecution::cleanExit();
    }

}

?>