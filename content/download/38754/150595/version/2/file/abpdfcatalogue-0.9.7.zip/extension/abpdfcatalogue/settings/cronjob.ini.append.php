<?php /*

[CronjobSettings]
ExtensionDirectories[]=abpdfcatalogue

[CronjobPart-infrequent]
Scripts[]=clearpdfcataloguecache.php

[CronjobPart-clearpdfcataloguecache]
Scripts[]
Scripts[]=clearpdfcataloguecache.php

*/ ?>
