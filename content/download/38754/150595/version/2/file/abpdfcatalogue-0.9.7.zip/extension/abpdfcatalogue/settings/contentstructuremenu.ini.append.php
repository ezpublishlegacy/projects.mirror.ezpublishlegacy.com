<?php /* #?ini charset="utf-8"?

[TreeMenu]
ShowClasses[]=ab_pdf_catalogue
ShowClasses[]=ab_pdf_catalogue_chapter

*/ ?>
