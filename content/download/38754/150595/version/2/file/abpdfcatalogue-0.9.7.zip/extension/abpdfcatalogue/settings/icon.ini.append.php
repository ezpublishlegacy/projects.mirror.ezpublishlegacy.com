<?php /* #?ini charset="utf-8"?

#[ClassIcons]
#ClassMap[ab_pdf_catalogue]=apps/abpdfcatalogue.png
#ClassMap[ab_pdf_catalogue_chapter]=apps/abpdfcataloguechapter.png
#ClassMap[ab_pdf_catalogue_document]=apps/abpdfcataloguedocument.png

*/ ?>
