<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=pdfcataloguethumbnail
AliasList[]=pdfcataloguebackground

[pdfcataloguethumbnail]
Filters[]
Filters[]=geometry/scaledownonly=56;71

[pdfcataloguebackground]
Filters[]
Filters[]=geometry/scaledownonly=140;

*/ ?>
