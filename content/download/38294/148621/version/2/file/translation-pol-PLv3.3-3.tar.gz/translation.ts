<!DOCTYPE TS><TS>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>Spis</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Sklep</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Użytkownicy</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Moje szkice</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Front</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Mapa</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Kosz</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Zmień hasło</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Zamówienia</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Typy VAT</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Rabaty</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Role</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Współpraca</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Klasy</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sekcje</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Przepływy</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Procedury</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Tłumaczenia</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>Statystyka szukania</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Własne</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Powiadamianie</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Preferowane</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Szablony</translation>
    </message>
    <message>
        <source>RAD</source>
        <translation type="obsolete">RAD</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Pliki tymczasowe</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Powiadamianie</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>O systemie</translation>
    </message>
    <message>
        <source>URL List</source>
        <translation type="obsolete">Lista URL</translation>
    </message>
    <message>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Preferowane</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Oczekujące</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL translator</translation>
    </message>
    <message>
        <source>URL management</source>
        <translation>Zarządzanie URL</translation>
    </message>
    <message>
        <source>Extension setup</source>
        <translation>Rozszerzenia</translation>
    </message>
    <message>
        <source>Packages</source>
        <translation>Pakiety</translation>
    </message>
    <message>
        <source>RSS</source>
        <translation type="obsolete">RSS</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Zaawansowane</translation>
    </message>
    <message>
        <source>PDF export</source>
        <translation type="obsolete">PDF eksport</translation>
    </message>
    <message>
        <source>RSS</source>
        <comment>Really Simple Syndication</comment>
        <translation>RSS</translation>
    </message>
    <message>
        <source>PDF export</source>
        <comment>PDF export</comment>
        <translation>PDF eksport</translation>
    </message>
    <message>
        <source>RAD</source>
        <comment>Rapid Application Development</comment>
        <translation>RAD</translation>
    </message>
    <message>
        <source>Ini settings</source>
        <translation>Ustawienia Ini</translation>
    </message>
    <message>
        <source>System upgrade</source>
        <translation>Upgreade systemu</translation>
    </message>
</context>
<context>
    <name>design/admin/node/view</name>
    <message>
        <source>Article</source>
        <translation>Artykuł</translation>
    </message>
    <message>
        <source>Placed in</source>
        <translation>Położony w</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentarz</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Folder</translation>
    </message>
    <message>
        <source>Forum</source>
        <translation>Forum</translation>
    </message>
    <message>
        <source>Forum message</source>
        <translation>Wiadomość na forum</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <source>Info page</source>
        <translation>Strona Informacyjna</translation>
    </message>
    <message>
        <source>Default object view</source>
        <translation type="obsolete">Bieżący widok obiektu</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produkt</translation>
    </message>
    <message>
        <source>Product review</source>
        <translation>Podgląd produktu</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <source>Also part of these groups</source>
        <translation>Także częścią tych grup</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Grupa użytkowników</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Link</translation>
    </message>
</context>
<context>
    <name>design/blog/layout</name>
    <message>
        <source>Log entries</source>
        <translation>Wpisy w Logu</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Opis:</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <source>Latest blogs</source>
        <translation>Ostatnie blogi</translation>
    </message>
    <message>
        <source>Log Archive by Entry</source>
        <translation>Wpisy w Logu</translation>
    </message>
    <message>
        <source>Comments disabled</source>
        <translation>Komentarze wyłączone</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Rezultat</translation>
    </message>
    <message>
        <source>Poll</source>
        <translation>Ankieta</translation>
    </message>
    <message>
        <source>Recent links</source>
        <translation>Ostatnie linki</translation>
    </message>
    <message>
        <source>Create new blog entry</source>
        <translation>Utwórz nowy wpis blog</translation>
    </message>
</context>
<context>
    <name>design/corporate/layout</name>
    <message>
        <source>Read more</source>
        <translation>Czytaj więcej</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Wyślij</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Ostatnie nowinki</translation>
    </message>
</context>
<context>
    <name>design/forum/layout</name>
    <message>
        <source>Read more</source>
        <translation>Czytaj więcej</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Wiadomość</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>List</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Replies</source>
        <translation>Odpowiedzi</translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation>Ostatnia odpowiedź</translation>
    </message>
    <message>
        <source>Number of Topics:</source>
        <translation>Liczba wątków:</translation>
    </message>
    <message>
        <source>Number of Posts:</source>
        <translation>Liczba listów:</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Powiadamianie</translation>
    </message>
    <message>
        <source>Edit account</source>
        <translation>Edycja konta</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <source>Latest posts</source>
        <translation>Ostatnie listy</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Ostatnie nowinki</translation>
    </message>
</context>
<context>
    <name>design/gallery/layout</name>
    <message>
        <source>Read more</source>
        <translation>Czytaj więcej</translation>
    </message>
    <message>
        <source>Galleries</source>
        <translation>Galerie</translation>
    </message>
    <message>
        <source>Latest images</source>
        <translation>Ostatnie obrazy</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Ostatnie nowinki</translation>
    </message>
    <message>
        <source>Latest comments</source>
        <translation>Ostatnie komentarze</translation>
    </message>
    <message>
        <source>Edit gallery</source>
        <translation>Edytuj galerię</translation>
    </message>
    <message>
        <source>Create a new gallery</source>
        <translation>Utwórz nową galerię</translation>
    </message>
    <message>
        <source>Name of your album</source>
        <translation>Nazwa Twego albumu</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Number of columns</source>
        <translation>Liczba kolumn</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation>Albumy</translation>
    </message>
    <message>
        <source>Gallery list</source>
        <translation>Lista galerii</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
</context>
<context>
    <name>design/intranet/layout</name>
    <message>
        <source>Comment this article!</source>
        <translation>Komentuj ten artykuł!</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Czytaj więcej</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Ostatnie nowinki</translation>
    </message>
    <message>
        <source>Contact information</source>
        <translation>Informacje kontaktowe</translation>
    </message>
</context>
<context>
    <name>design/news/content/poll</name>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Anonimowy użytkownik nie może głosować w tej ankiecie, proszę zalogować się.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Twój głos został już uwzględniony w tej ankiecie.</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Rezultaty</translation>
    </message>
</context>
<context>
    <name>design/news/layout</name>
    <message>
        <source>Related stories</source>
        <translation>Powiązane nowinki</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Poradź znajomemu</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Komentarze</translation>
    </message>
    <message>
        <source>Comment this article!</source>
        <translation>Komentuj ten artykuł!</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Czytaj więcej</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Ostatnie nowinki</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Rezultat</translation>
    </message>
    <message>
        <source>View all polls</source>
        <translation>Pokaż wszystkie ankiety</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Nowinki</translation>
    </message>
    <message>
        <source>Most popular</source>
        <translation>Najbardziej popularne</translation>
    </message>
    <message>
        <source>Poll</source>
        <translation>Ankieta</translation>
    </message>
</context>
<context>
    <name>design/shop/layout</name>
    <message>
        <source>login</source>
        <translation>login</translation>
    </message>
    <message>
        <source>logout</source>
        <translation>logout</translation>
    </message>
    <message>
        <source>Read more</source>
        <translation>Czytaj więcej</translation>
    </message>
    <message>
        <source>Write your own review</source>
        <translation>Napisz własną recenzję</translation>
    </message>
    <message>
        <source>Write a review and share your opinion. Please make sure your comments are devoted to the product.</source>
        <translation>Napisz recenzję i podziel się swą opinią. Prosimy upewnij  się jednak, że Twój komentarz jest powiązany z właściwym produktem.</translation>
    </message>
    <message>
        <source>How do you rate the product?</source>
        <translation>Jak oceniasz ten produkt?</translation>
    </message>
    <message>
        <source>Title of your review:</source>
        <translation>Tytuł Twej recenzji:</translation>
    </message>
    <message>
        <source>Your review:</source>
        <translation>Twa recenzja:</translation>
    </message>
    <message>
        <source>Related products</source>
        <translation>Powiązane produkty</translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation>Klienci kupujący ten produkt kupowali też zwykle</translation>
    </message>
    <message>
        <source>Reviews</source>
        <translation>Recenzje</translation>
    </message>
    <message>
        <source>Write a review</source>
        <translation>Napisz recenzję</translation>
    </message>
    <message>
        <source>No rating</source>
        <translation>Brak ocen</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Produkty</translation>
    </message>
    <message>
        <source>Latest products</source>
        <translation>Nowości</translation>
    </message>
    <message>
        <source>Your basket is empty</source>
        <translation>Twój koszyk jest pusty</translation>
    </message>
    <message>
        <source>Best sellers</source>
        <translation>Bestsellery</translation>
    </message>
    <message>
        <source>Latest news</source>
        <translation>Ostatnie nowinki</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Do koszyka</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Śledź aktualizacje</translation>
    </message>
    <message>
        <source>Printerfriendly version</source>
        <translation>Wersja drukowalna</translation>
    </message>
    <message>
        <source>Main menu</source>
        <translation>Menu główne</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Powiadamianie</translation>
    </message>
    <message>
        <source>Edit account</source>
        <translation>Edycja konta</translation>
    </message>
    <message>
        <source>View basket</source>
        <translation>Widok koszyka</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <source>Register new customer</source>
        <translation>Rejestruj nowego klienta</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Shopping basket</source>
        <translation>Koszyk</translation>
    </message>
    <message>
        <source>View all details</source>
        <translation>Pokaż szczegóły</translation>
    </message>
</context>
<context>
    <name>design/standard/class</name>
    <message>
        <source>Class is locked</source>
        <translation>Klasa jest zablokowana</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size:</source>
        <translation type="obsolete">Maks. rozmiar pliku:</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Wielokrotny wybór</translation>
    </message>
    <message>
        <source>Option style</source>
        <translation>Styl opcji</translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation>Styl pól zaznaczenia </translation>
    </message>
    <message>
        <source>Enum Element:</source>
        <translation type="obsolete">Element policzalny:</translation>
    </message>
    <message>
        <source>Enum Value:</source>
        <translation type="obsolete">Wartość policzalna:</translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation>Nowy Element Policzalny</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Usuń Zaznaczenie</translation>
    </message>
    <message>
        <source>Default value:</source>
        <translation type="obsolete">Wartość domyślna:</translation>
    </message>
    <message>
        <source>Min float value:</source>
        <translation type="obsolete">Min zakładana wartość:</translation>
    </message>
    <message>
        <source>Max float value:</source>
        <translation type="obsolete">Max zakładana wartość:</translation>
    </message>
    <message>
        <source>Min integer value:</source>
        <translation type="obsolete">Min wartość całkowita:</translation>
    </message>
    <message>
        <source>Max integer value:</source>
        <translation type="obsolete">Max wartość całkowita:</translation>
    </message>
    <message>
        <source>Media player type:</source>
        <translation type="obsolete">Rodzaj Media playera:</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>Quick Time</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real Player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows media player</translation>
    </message>
    <message>
        <source>VAT type:</source>
        <translation type="obsolete">Rodzaj VAT-u:</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Cena zawierająca VAT</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Cena bez VAT</translation>
    </message>
    <message>
        <source>Max string length:</source>
        <translation type="obsolete">Maks. długość napisu:</translation>
    </message>
    <message>
        <source>Prefered columns</source>
        <translation type="obsolete">Preferowane kolumny</translation>
    </message>
    <message>
        <source>Prefered columns:</source>
        <translation type="obsolete">Preferowane kolumny:</translation>
    </message>
    <message>
        <source>Max file size</source>
        <translation>Maks. wielkość pliku</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Wartość domyślna</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Pusty</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Bieżąca data</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Bieżący czas i data</translation>
    </message>
    <message>
        <source>Enum Element</source>
        <translation>Element policzalny</translation>
    </message>
    <message>
        <source>Enum Value</source>
        <translation>Wartość policzalna</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Min wartość liczby ogólnej</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Max wartość liczby ogólnej</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Min wartość liczby całkowitej</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Max wartość liczby całkowitej</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Typ media player</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Domyślna nazwa</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Typ VAT</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Max długość napisu</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Preferowana liczba wierszy</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Bieżący czas</translation>
    </message>
    <message>
        <source>Default number of rows</source>
        <translation>Standardowa liczba wierszy</translation>
    </message>
    <message>
        <source>Matrix Column</source>
        <translation>Kolumna macierzy</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identyfikator</translation>
    </message>
    <message>
        <source>New Column</source>
        <translation>Nowa kolumna</translation>
    </message>
    <message>
        <source>Allowed classes</source>
        <translation>Dozwolone klasy</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Dowolna</translation>
    </message>
    <message>
        <source>Default placement for objects</source>
        <translation>Domyślne położenie obiektów</translation>
    </message>
    <message>
        <source>New objects will not be placed in the content tree</source>
        <translation>Nowy obiekt nie może być ulokowany w strukturze drzewa</translation>
    </message>
    <message>
        <source>Select placement</source>
        <translation>Wybierz położenie</translation>
    </message>
    <message>
        <source>Disable placement</source>
        <translation>Wyłącz położenie</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Nowa opcja</translation>
    </message>
    <message>
        <source>Pretext</source>
        <translation>Tekst przed</translation>
    </message>
    <message>
        <source>Posttext</source>
        <translation>Tekst po</translation>
    </message>
    <message>
        <source>Current value: </source>
        <translation>Bieżąca wartość:</translation>
    </message>
    <message>
        <source> (This value are the current identifier)</source>
        <translation>(Ta wartość jest aktualnym identyfikatorem)</translation>
    </message>
    <message>
        <source>Current temporary value: </source>
        <translation>Bieżąca wartość tymczasowa:</translation>
    </message>
    <message>
        <source> (This value is a copy of the original identifier)</source>
        <translation>(Ta wartość jest kopią aktualnego identyfikatora)</translation>
    </message>
    <message>
        <source>Digits</source>
        <translation>Cyfry</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Wartość początkowa</translation>
    </message>
    <message>
        <source>Update identifier</source>
        <translation>Uaktualnij identyfikator</translation>
    </message>
    <message>
        <source>Ini file</source>
        <translation>Plik Ini</translation>
    </message>
    <message>
        <source>Ini Section</source>
        <translation>Sekcja Ini</translation>
    </message>
    <message>
        <source>Ini Parameter</source>
        <translation>Parametr Ini</translation>
    </message>
    <message>
        <source>Ini file location</source>
        <translation>Położenie pliku Ini</translation>
    </message>
    <message>
        <source>Ini setting type</source>
        <translation>Typ ustawień Ini</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>Enable/Disable</source>
        <translation>Włącz/Wyłącz</translation>
    </message>
    <message>
        <source>True/False</source>
        <translation>Prawda/Fałsz</translation>
    </message>
    <message>
        <source>Integer</source>
        <translation>Integer</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Float</translation>
    </message>
    <message>
        <source>Array</source>
        <translation>Array</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Create or browse objects</source>
        <translation>Twórz lub przeglądaj obiekty</translation>
    </message>
    <message>
        <source>New and existing objects</source>
        <translation>Nowe i istniejące obiekty</translation>
    </message>
    <message>
        <source>Only new objects</source>
        <translation>Tylko nowe obiekty</translation>
    </message>
    <message>
        <source>Only existing objects</source>
        <translation>Tylko istniejące obiekty</translation>
    </message>
    <message>
        <source>Select which class user can create</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Package Type</source>
        <translation>Typ pakietu</translation>
    </message>
    <message>
        <source>Single choice</source>
        <translation>Pojedyńczy wybór</translation>
    </message>
    <message>
        <source>Warning, the ini file settings value and object value does not match.</source>
        <translation>Uwaga, ustawienia pliku ini i obiektu są nieodpowiednie.</translation>
    </message>
    <message>
        <source>The ini file has probably been modified manually since last time.</source>
        <translation>Plik ini prawdopodobnie był ostatnio modyfikowany ręcznie.</translation>
    </message>
    <message>
        <source>Ini File : </source>
        <translation>Plik Ini:</translation>
    </message>
    <message>
        <source>Ini Value: </source>
        <translation>Wartość Ini:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Włączone</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Wyłączone</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Prawda</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Fałsz</translation>
    </message>
    <message>
        <source>Select which classes user can create</source>
        <translation>Wybierz które klasy użytkownik może tworzyć</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Zaznaczone</translation>
    </message>
    <message>
        <source>Unchecked</source>
        <translation>Nie zaznaczone</translation>
    </message>
    <message>
        <source>New objects will be placed in %nodename</source>
        <translation>Nowe obiekty będą lokowane w %nodename</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Editing class type</source>
        <translation type="obsolete">Edycja typu klas</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation type="obsolete">Utworzone przez</translation>
    </message>
    <message>
        <source>on</source>
        <translation type="obsolete">wł</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation type="obsolete">Zmodyfikowane przez</translation>
    </message>
    <message>
        <source>Object name:</source>
        <translation type="obsolete">Nazwa objektu:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation type="obsolete">Identyfikator:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>In group:</source>
        <translation type="obsolete">W grupie:</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation type="obsolete">Dodaj grupę</translation>
    </message>
    <message>
        <source>Remove group</source>
        <translation type="obsolete">Usuń grupę</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Zmiany nie zatwierdzone</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Zmiany zapisane pomyślnie</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atrybuty</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Typ:</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Wymagane</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Przeszukiwalne</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Odbiorca informacji</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Dół</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Góra</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Editing class group</source>
        <translation type="obsolete">Edycja grupy klas</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) class(es)?</source>
        <translation type="obsolete">Czy jesteś pewien, że chcesz usunąć tą(te) kalsę(y)?</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation type="obsolete">Usuń klasę</translation>
    </message>
    <message>
        <source>will remove</source>
        <translation type="obsolete">usunie</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) group(s)?</source>
        <translation type="obsolete">Czy jesteś pewien, że chcesz usunąć tą(te) grupę(y)?</translation>
    </message>
    <message>
        <source>Editing class - %1</source>
        <translation>Edycja klasy - %1</translation>
    </message>
    <message>
        <source>Last modified by</source>
        <translation type="obsolete">Ostatnio zmodyfikowane przez</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identyfikator</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Identyfikator ścieżki</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Członek grup</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Dodaj do grupy</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Usuń z grupy</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Typ danych</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Wycofaj Zmiany</translation>
    </message>
    <message>
        <source>Editing class group - %1</source>
        <translation>Edycja grupy klas - %1</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Czy na pewno chcesz usunąć te klasy?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Usunięcie klasy %1 spowoduje usunięcie %2!</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Czy na pewno chcesz usunąć tę grupę klas?</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Usunięcie grupy klas %1 spowoduje usunięcie klas %2!</translation>
    </message>
    <message>
        <source>Disable translation</source>
        <translation>Wyłącz tłumaczenia</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Last modified by %username on %time</source>
        <translation>Ostatnia zmodyfikowano przez %username o %time</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Zmodyfikowano przez %username o %time</translation>
    </message>
    <message>
        <source>Class - %1</source>
        <translation>Klasa - %1</translation>
    </message>
    <message>
        <source>Is required</source>
        <translation>Wymagane</translation>
    </message>
    <message>
        <source>Is not required</source>
        <translation>Nie wymagane</translation>
    </message>
    <message>
        <source>Is searchable</source>
        <translation>Przeszukiwalne</translation>
    </message>
    <message>
        <source>Is not searchable</source>
        <translation>Nie przeszukiwalne</translation>
    </message>
    <message>
        <source>Collects information</source>
        <translation>Zbiera informacje</translation>
    </message>
    <message>
        <source>Does not collect information</source>
        <translation>Nie zbiera informacji</translation>
    </message>
    <message>
        <source>Translation is disabled</source>
        <translation>Tłumaczenia wyłączone</translation>
    </message>
    <message>
        <source>Translation is enabled</source>
        <translation>Tłumaczenia włączone</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Powtórz</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Defined class groups</source>
        <translation type="obsolete">Zdefiniowane grupy klas</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Modyfikator:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Zmodyfikowany:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>help</source>
        <translation type="obsolete">pomoc</translation>
    </message>
    <message>
        <source>Class groups</source>
        <translation>Grupy klas</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modyfikujący</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Zmodyfikowane</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Nowa grupa</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Pomoc</translation>
    </message>
    <message>
        <source>Last modified classes</source>
        <translation>Ostatnio modyfikowane klasy</translation>
    </message>
    <message>
        <source>PDF Exports</source>
        <translation>PDF eksport</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Nowy eksport</translation>
    </message>
    <message>
        <source>RSS Feeds</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>RSS Exports</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>RSS Imports</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>New Import</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Setup menu</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>No classes have been defined for </source>
        <translation type="obsolete">Nie zdefiniowano klas dla</translation>
    </message>
    <message>
        <source>Defined class types for</source>
        <translation type="obsolete">Zdefiniowane typy klas dla</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Identifier:</source>
        <translation type="obsolete">Identyfikator:</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Modyfikator:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Zmodyfikowany:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>No classes in </source>
        <translation>Brak klas w</translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Klasy w</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Nr</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identyfikator</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modyfikujący</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Zmodyfikowane</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Nowa klasa</translation>
    </message>
    <message>
        <source>Click on the &apos;New&apos; button to create a class.</source>
        <translation>Kliknij na klawisz &quot;Nowa&quot; aby stworzyć nową klasę.</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Lista dla grupy &quot;%1&quot;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>Brak pozycji w grupie.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Grupy</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Aprobata</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 oczekuje aprobaty edytora</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 zaaprobowano do publikacji</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 nie zaaprobowane do publikacji</translation>
    </message>
    <message>
        <source>%1 was deferred for reediting</source>
        <translation type="obsolete">%1 wycofane do reedycji</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%%1 oczekuje Twej aprobaty</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Czytaj</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Nie czytano</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Nieaktywny</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Wysłano: %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Brak nowych pozycji do obróbki.</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Zestawienie</translation>
    </message>
    <message>
        <source>more</source>
        <translation type="obsolete">więcej</translation>
    </message>
    <message>
        <source>[more]</source>
        <translation>[więcej]</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Aprobata</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>Zawartość obiektu %1 oczekuje aprobaty publikacji.</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Jeśli chcesz, to możesz wysłać wiadomość do osoby zatwierdzającej?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>Zawartość obiektu %1 wymaga Twej aprobaty przed publikacją.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Czy aprobujesz zawartość obiektu do publikacji?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>Obiekt %1 był zaakceptowany i będzie opublikowany.</translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived. If you wish you may publish a new version of the object by clicking the edit link.</source>
        <translation type="obsolete">Objekt %1 nie został zaakceptowany i będzie zarchiwowany. Jeżeli sobie życzysz to możesz opublikować nową wersje obiektu wciskając odnośnik edycji.</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Edycja obiektu</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
        <translation>Objekt %1 nie był zaakceptowany ale będzie widoczny jako szkic u autora.</translation>
    </message>
    <message>
        <source>You must reedit the draft and publish it again for the approval to continue.</source>
        <translation type="obsolete">Powinieneś jeszcze raz poprawić objekt i opublikować go dla zatwierdzenia.</translation>
    </message>
    <message>
        <source>If the approver finds the new changes satisfying the object will be accepted.</source>
        <translation type="obsolete">Jeżeli osoba zatwierdzająca poprze zmiany objekt zostanie zaakceptowany.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>Objekt %1 nie był zaakceptowany ale będzie widoczny jako szkic u autora.</translation>
    </message>
    <message>
        <source>The author must reedit the draft and publish it again for the approval to continue.</source>
        <translation type="obsolete">Autor powinien jeszcze raz poprawić szkic i opublikować dla zatwierdzenia.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentarz</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Dodaj komentarz</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Aprobuj</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Pushback</source>
        <translation type="obsolete">Odeślij</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Uczestnicy</translation>
    </message>
    <message>
        <source>Content object class - %1</source>
        <translation type="obsolete">Zawartość obiektu klasy - %1</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Wiadomości</translation>
    </message>
    <message>
        <source>You may reedit the draft and publish it, in which case an approval is required again.</source>
        <translation>Możesz ponownie edytować szkic i go publikować, wtedy niezbędna jest ponowna aprobata.</translation>
    </message>
    <message>
        <source>The author can reedit the draft and publish it again, in which a new approval item is made.</source>
        <translation>Autor może ponownie edytować szkic i go publikować, wtedy tworzona  jest nowa pozycja do aprobaty.</translation>
    </message>
    <message>
        <source>This email is to inform you that &quot;%objectname&quot; awaits your attention at %sitename.
The publishing process has been halted and it is up to you to decide if it should continue or stop.
The approval can viewed by using the URL below.</source>
        <translation>Ten email informuje Cię, że &quot;%objectname&quot; wymaga Twej uwagi na %sitename.
Proces publikacji został zatrzymany i należy podjąc decyzję czy go kontynuować czy też zatrzymać.
Aprobaty dokonać można używając poniższego adresu URL.</translation>
    </message>
    <message>
        <source>This email is to inform you that &quot;%objectname&quot; awaits approval at %sitename before it is published.
If you wish to send comments to the approver or view the status use the URL below.</source>
        <translation>Ten email informuje Cię, że &quot;%objectname&quot; oczekuje aprobaty na %sitename przed jego publikacją.
Jeśli życzysz sobie wysłać komentarz do aprobującego lub wyświetlić obecny status użyj poniższego adresu URL.</translation>
    </message>
    <message>
        <source>[%sitename] Approval of &quot;%objectname&quot; awaits your attention</source>
        <translation>[%sitename] Twej aprobaty wymaga &quot;%objectname&quot;, polecamy go Twej uwadze </translation>
    </message>
    <message>
        <source>[%sitename] &quot;%objectname&quot; awaits approval</source>
        <translation>[%sitename] &quot;%objectname&quot; oczekuje aprobaty</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Czy na pewno chcesz usunąć to tłumaczenie?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Zmień tłumaczenie zawartości</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Wybież gotowe tłumaczenie z listy albo wpisz własne w polu tekstowym.</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Nowe tłumaczenie zawartości</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Wybierz gotowe tłumaczenie z listy albo wpisz własne w polu tekstowym.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Tłumaczenie</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Własny</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Nazwa tłumaczenia</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Regionalne</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Zmień</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Utwórz</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Tłumaczenia zawartości</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Poniżej znajdziesz listę języków na które może zostać przetłumaczony dany obiekt.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Kraj</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Skasuj</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL translator</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation>PDF eksport</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tytuł</translation>
    </message>
    <message>
        <source>Intro text</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Sub text</source>
        <translation>Opis szczegółowy</translation>
    </message>
    <message>
        <source>Source node</source>
        <translation>Węzeł źródłowy</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Przejrzyj</translation>
    </message>
    <message>
        <source>Export structure</source>
        <translation>Eksportuj strukturę</translation>
    </message>
    <message>
        <source>Tree</source>
        <translation>Drzewo</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Węzeł</translation>
    </message>
    <message>
        <source>Export classes</source>
        <translation>Eksportuj klasy</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Dostęp do stron</translation>
    </message>
    <message>
        <source>Export destination</source>
        <translation>Miejsce docelowe eksportu</translation>
    </message>
    <message>
        <source>Export to URL</source>
        <translation>Eksport do URL</translation>
    </message>
    <message>
        <source>Export for direct download</source>
        <translation>Eksport dla bezpośredniego pobierania</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Eksport</translation>
    </message>
    <message>
        <source>Removing &apos;%1&apos; will remove the translation itself and %2 translated versions!</source>
        <translation>Usunięcie &apos;%1&apos; spowoduje usunięcie tłumaczeń i %2 wersji przetłumaczonych!</translation>
    </message>
</context>
<context>
    <name>design/standard/content/browse</name>
    <message>
        <source>Create new</source>
        <translation>Utwórz nowy</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation>Kopiuj %1</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>Liczba wersji %1, bieżąca wersja %2.</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Kopiuj wszystkie wersje</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Kopiuj bieżącą versję</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Utwórz nowy</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwisko:</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation type="obsolete">E-mail:</translation>
    </message>
    <message>
        <source>New author</source>
        <translation>Nowy autor</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Usuń zaznaczone</translation>
    </message>
    <message>
        <source>Filename:</source>
        <translation type="obsolete">Nazwa pliku:</translation>
    </message>
    <message>
        <source>Existing filename:</source>
        <translation type="obsolete">Istniejąca nazwa pliku:</translation>
    </message>
    <message>
        <source>Existing orignal filename:</source>
        <translation type="obsolete">Istniejąca pierwotna nazwa pliku:</translation>
    </message>
    <message>
        <source>Existing mime/type:</source>
        <translation type="obsolete">Istniejący typ mime:</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Skasuj</translation>
    </message>
    <message>
        <source>Year:</source>
        <translation type="obsolete">Rok:</translation>
    </message>
    <message>
        <source>Month:</source>
        <translation type="obsolete">Miesiąc:</translation>
    </message>
    <message>
        <source>Day:</source>
        <translation type="obsolete">Dzień:</translation>
    </message>
    <message>
        <source>Hour:</source>
        <translation type="obsolete">Godzina:</translation>
    </message>
    <message>
        <source>Minute:</source>
        <translation type="obsolete">Minuta:</translation>
    </message>
    <message>
        <source>Image filename:</source>
        <translation type="obsolete">Nazwa pliku graficznego:</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Usuń obraz</translation>
    </message>
    <message>
        <source>ISBN:</source>
        <translation type="obsolete">ISBN:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="obsolete">Szerokość:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation type="obsolete">Wysokość:</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="obsolete">Jakość:</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Wybitna</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Najlepsza</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Niska</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Wysoka (auto)</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Niska (auto)</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Autoplay</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Pętla</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Kontroler</translation>
    </message>
    <message>
        <source>Controls:</source>
        <translation type="obsolete">Kontrolki:</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Okno Obrazu</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Wszystko</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Panel Sterowania</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>Panel Informacyjny Rozmiaru</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Panel Informacyjny</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Znajdź obiekt</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation type="obsolete">Opcje:</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Nowa opcja</translation>
    </message>
    <message>
        <source>URL:</source>
        <translation type="obsolete">URL:</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation type="obsolete">tekst:</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation type="obsolete">Nazwa użytkownika:</translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation type="obsolete">e-mail:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete">Hasło:</translation>
    </message>
    <message>
        <source>Password confirmation:</source>
        <translation type="obsolete">Potwierdź hasło:</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Cena:</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Twoja cena:</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Oszczędzasz:</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Informacje o koncie użytkownika</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation type="obsolete">Email:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nazwa pliku</translation>
    </message>
    <message>
        <source>MIME Type</source>
        <translation type="obsolete">Typ MIME</translation>
    </message>
    <message>
        <source>Filesize</source>
        <translation>Wielkość pliku</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Rok</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Miesiąc</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Dzień</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Godzina</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minuta</translation>
    </message>
    <message>
        <source>Image filename</source>
        <translation type="obsolete">Nazwa pliku obrazu</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Tekst alternatywny dla obrazu</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Jakość</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Kontrola</translation>
    </message>
    <message>
        <source>Existing filename</source>
        <translation>Istniejąca nazwa pliku</translation>
    </message>
    <message>
        <source>Existing orignal filename</source>
        <translation type="obsolete">Istniejąca oryginalna nazwa pliku</translation>
    </message>
    <message>
        <source>Existing mime/type</source>
        <translation>Instniejące mime/type</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Brak relacji</translation>
    </message>
    <message>
        <source>Replace object</source>
        <translation>Wymiana obiektu</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Usuń obiekt</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Wartość początkowa</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Wartość końcowa</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Krok</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>Nr użytkownika</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Potwierdzenie hasła</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Cena</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>New row</source>
        <translation>Nowy wiersz</translation>
    </message>
    <message>
        <source>Create new %classname</source>
        <translation type="obsolete">Utwórz nowy  %classname</translation>
    </message>
    <message>
        <source>Add %classname</source>
        <translation type="obsolete">Dodaj %classname</translation>
    </message>
    <message>
        <source>Edit objects</source>
        <translation type="obsolete">Edytuj obiekty</translation>
    </message>
    <message>
        <source>Remove objects</source>
        <translation>Usuń obiekty</translation>
    </message>
    <message>
        <source>MIME-Type</source>
        <translation>Typ MIME</translation>
    </message>
    <message>
        <source>View Mode</source>
        <translation>Typ widoku</translation>
    </message>
    <message>
        <source>Local image file for upload</source>
        <translation>Lokalny plik z obrazem do załadowania</translation>
    </message>
    <message>
        <source>Image preview</source>
        <translation>Podgląd obrazu</translation>
    </message>
    <message>
        <source>Original filename for image</source>
        <translation>Oryginalna nazwa pliku obrazu</translation>
    </message>
    <message>
        <source>Browse objects</source>
        <translation type="obsolete">Przegląd obiektów</translation>
    </message>
    <message>
        <source>Existing original filename</source>
        <translation>Istniejąca oryginalna nazwa pliku</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Open objects for edit</source>
        <translation>Otwórz obiekt do edycji</translation>
    </message>
    <message>
        <source>Browse for objects</source>
        <translation>Przeglądaj obiekty</translation>
    </message>
    <message>
        <source>Value (optional)</source>
        <translation>Wartość (opcjonalnie)</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from:</source>
        <translation type="obsolete">Informacje zebrane z:</translation>
    </message>
    <message>
        <source>The following information was collected:</source>
        <translation>Następujące informacje zostały zebrane:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Zmiany nie zatwierdzone</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Zmiany zapisane pomyślnie</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Lokalizacja</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Sortuj wg</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Porządek</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Główny</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Przesuń</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="obsolete">Ścieżka</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Opublikowane</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Zmodyfikowane</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcja</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Głębokość</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Identyfikator klasy</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Nazwa Klasy</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>Add location(s)</source>
        <translation type="obsolete">Dodaj lokalizację(e)</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <source>Store Draft</source>
        <translation type="obsolete">Zapamiętaj szkic</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Opublikuj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Informacje o obiekcie</translation>
    </message>
    <message>
        <source>Created:</source>
        <translation type="obsolete">Utworzony:</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Jeszcze nie opublikowany</translation>
    </message>
    <message>
        <source>Version info</source>
        <translation type="obsolete">Info o wersji</translation>
    </message>
    <message>
        <source>Editing:</source>
        <translation type="obsolete">Edycja:</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Obecny</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Zarządzaj</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Tłumaczenia</translation>
    </message>
    <message>
        <source>Related products:</source>
        <translation type="obsolete">Produkty pokrewne</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Znajdź</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Collected information from %1</source>
        <translation>Zebrane informacje z %1</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Edycja %1 - %2</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Zapisz szkic</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Dodaj lokalizację</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Utworzono</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Wersje</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (informacje regionalne niedostępne)</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>Badanie poprawności niepomyślne</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Localizacja nie została potwierdzona</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nowy szkic</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Powiązane obiekty</translation>
    </message>
    <message>
        <source>The currently published version is</source>
        <translation type="obsolete">Obecnie opublikowaną wersją jest</translation>
    </message>
    <message>
        <source>and was published at</source>
        <translation type="obsolete">opublikowana</translation>
    </message>
    <message>
        <source>The last modification was done</source>
        <translation type="obsolete">Ostatnią modyfikację zakończono</translation>
    </message>
    <message>
        <source>The object is owned by</source>
        <translation type="obsolete">Właścicielem obiektu jest</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else including you.
    You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Ten obiekt jest obecnie edytowany przez kogoś lub przez samego Ciebie.
  Możesz kontynuować jego edycję lub utworzyć nowy szkic.</translation>
    </message>
    <message>
        <source>This object is already being edited by you.
        You can either continue editing one of your drafts or you can create a new draft.</source>
        <translation>Edycja tego obiektu jest już rozpoczęta przez Ciebie.
  Możesz kontynuować jego edycję lub utworzyć nowy szkic.</translation>
    </message>
    <message>
        <source>This object is already being edited by someone else.
        You should either contact the person about the draft or create a new draft for personal editing.</source>
        <translation>Ten obiekt jest aktualnie edytowany przez kogoś.
 Skontaktuj się raczej z tą osobą w tej sprawie lub utwórz nowy szkic do własnej edycji.</translation>
    </message>
    <message>
        <source>Current drafts</source>
        <translation>Bieżące szkice</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Właściciel</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Ostatnia modyfikacja</translation>
    </message>
    <message>
        <source>Post</source>
        <translation>List</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Feedback from %1</source>
        <translation>Odpowiedź of %1</translation>
    </message>
    <message>
        <source>The following feedback was collected:</source>
        <translation>Zebrano następujące odpowiedzi:</translation>
    </message>
    <message>
        <source>The currently published version is %version and was published at %time.</source>
        <translation>Obecnie opublikowaną wersją jest %version została ona opublikowana %time</translation>
    </message>
    <message>
        <source>The last modification was done at %modified.</source>
        <translation>Ostatnią modyfikację zakończono %modified.</translation>
    </message>
    <message>
        <source>The object is owned by %owner.</source>
        <translation>Właścicielem obiektu jest %owner.</translation>
    </message>
    <message>
        <source>Input was partially stored</source>
        <translation>Zapisano częściowo </translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft %versionname?</source>
        <translation>Czy na pewno chcesz usunąć szkic %versionname?</translation>
    </message>
</context>
<context>
    <name>design/standard/content/ezoption</name>
    <message>
        <source>No value chosen</source>
        <translation>Nie wybrano wartości</translation>
    </message>
</context>
<context>
    <name>design/standard/content/feedback</name>
    <message>
        <source>Feedback for %feedbackname</source>
        <translation>Odpowiedź dla %feedbackname</translation>
    </message>
    <message>
        <source>Thanks for your feedback, the following information was collected.</source>
        <translation>Dziękujemy za Twą odpowiedź, otrzymaliśmy następujące informacje.</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Powrót do strony</translation>
    </message>
    <message>
        <source>You have already submitted data to this feedback. The previously submitted data was the following.</source>
        <translation>Masz już wysłane dane dla tej odpowiedzi. Poprzednio wysłane dane były następujące.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/form</name>
    <message>
        <source>Form %formname</source>
        <translation>Formularz %formname</translation>
    </message>
    <message>
        <source>Return to site</source>
        <translation>Powrót do strony</translation>
    </message>
    <message>
        <source>You have already submitted data to this form. The previously submitted data was the following.</source>
        <translation>Masz już wysłane dane w tym formularzu. Poprzednio wysłane dane były następujące.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/pdf</name>
    <message>
        <source>Content</source>
        <translation>Zawartość</translation>
    </message>
    <message>
        <source>Versionview not supported in PDF yet</source>
        <translation>Wersje nie są obsługiwane obecnie przez PDF</translation>
    </message>
    <message>
        <source>eZ publish PDF export</source>
        <translation>eZ publish PDF eksport</translation>
    </message>
    <message>
        <source>#page of #total</source>
        <translation>#page z #total</translation>
    </message>
    <message>
        <source>#level1 - #level2</source>
        <translation>#level1 - #level2</translation>
    </message>
    <message>
        <source>#levelIndex1:#levelIndex2</source>
        <translation>#levelIndex1:#levelIndex2</translation>
    </message>
</context>
<context>
    <name>design/standard/content/poll</name>
    <message>
        <source>Poll %pollname</source>
        <translation>Ankieta %pollname</translation>
    </message>
    <message>
        <source>Anonymous users are not allowed to vote on this poll, please login.</source>
        <translation>Anonimowy użytkownik nie może głosować w tej ankiecie, proszę zalogować się.</translation>
    </message>
    <message>
        <source>You have already voted for this poll.</source>
        <translation>Twój głos został już uwzględniony w tej ankiecie.</translation>
    </message>
    <message>
        <source>Poll results</source>
        <translation>Wyniki ankiety</translation>
    </message>
    <message>
        <source>%count total votes</source>
        <translation>%count wszystkich głosów</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>Wyniki</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Advanced search</source>
        <translation>Szukanie zaawansowane</translation>
    </message>
    <message>
        <source>No results were found when searching for:</source>
        <translation type="obsolete">Nic nie znaleziono podczas szukania:</translation>
    </message>
    <message>
        <source>Search for:</source>
        <translation type="obsolete">Szukaj:</translation>
    </message>
    <message>
        <source>returned</source>
        <translation type="obsolete">zwrócone</translation>
    </message>
    <message>
        <source>matches</source>
        <translation type="obsolete">trafienia</translation>
    </message>
    <message>
        <source>Search all the words:</source>
        <translation type="obsolete">Szukaj wszystkich słów:</translation>
    </message>
    <message>
        <source>Search the exact phrase:</source>
        <translation type="obsolete">Szukaj dokładnego wyrażenia:</translation>
    </message>
    <message>
        <source>Search with at least one of the words:</source>
        <translation type="obsolete">Szukaj z którymkolwiek ze słów:</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete">Klasa:</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>Dowolna klasa</translation>
    </message>
    <message>
        <source>Class attribute:</source>
        <translation type="obsolete">Atrybut klasy:</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Uaktualnij atrybuty</translation>
    </message>
    <message>
        <source>In:</source>
        <translation type="obsolete">W:</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>Dowolna sekcja</translation>
    </message>
    <message>
        <source>Published:</source>
        <translation type="obsolete">Opublikowane:</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>Dowolny czas</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Ostatni dzień</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Ostatni tydzień</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Ostatni miesiąc</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Ostatnie trzy miesiące</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Ostatni rok</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>No results were found for searching:</source>
        <translation type="obsolete">Nie znaleziono rezultatów szukania:</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Szukaj wszystkich słów</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Szukaj wymaganej frazy</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Szukaj przynajmniej jednego słowa</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Atrybuty klasy</translation>
    </message>
    <message>
        <source>In</source>
        <translation>W</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Opublikowane</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Brak rezultatu szukania &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>Poszukiwanie &quot;%1&quot; zwróciło %2 wystąpień</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <translation type="obsolete">Więcej możliwości uzyskasz wybierając %1Szukanie zaawansowane%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Następujące słowa wykluczono z poszukiwania:</translation>
    </message>
    <message>
        <source>Search tips</source>
        <translation>Sugestie</translation>
    </message>
    <message>
        <source>Check spelling of keywords.</source>
        <translation>Spawdź poprawność pisowni.</translation>
    </message>
    <message>
        <source>Try changing some keywords eg. car instead of cars.</source>
        <translation>Zmień sposób użycia niektórych słów np. napisz pies zamiast psy.</translation>
    </message>
    <message>
        <source>Try more general keywords.</source>
        <translation>Wpisz więcej słów.</translation>
    </message>
    <message>
        <source>Fewer keywords gives more results, try reducing keywords until you get a result.</source>
        <translation>Jeśli kilka słów daje wiele rezultatów, wtedy zredukuj liczbę słów.</translation>
    </message>
    <message>
        <source>Display per page</source>
        <translation>Wyświetl na stronie</translation>
    </message>
    <message>
        <source>5 items</source>
        <translation>5 pozycji</translation>
    </message>
    <message>
        <source>10 items</source>
        <translation>10 pozycji</translation>
    </message>
    <message>
        <source>20 items</source>
        <translation>20 pozycji</translation>
    </message>
    <message>
        <source>30 items</source>
        <translation>30 pozycji</translation>
    </message>
    <message>
        <source>50 items</source>
        <translation>50 pozycji</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <comment>The parameters are link start and end tags.</comment>
        <translation>Więcej możliwości uzyskasz wybierając %1Szukanie zaawansowane%2</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Poradź znajomemu</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Widomość wysłano.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Kliknij tu by wrócić do strony oryginalnej.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Wiadmości nie wysłano.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Wiadomość nie została wysłana z powodu nieznanego błędu. Prosimy, abyś bezzwłocznie powiadomił o tym administratora.</translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>Proszę poprawić następujące błędy:     </translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Twoja nazwa</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Twój adres email</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Nazwa adresata</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>Adres email adresata</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentarz</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Wyślij</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Ta wiadomość została wysłana do Ciebie bo &quot;%1 &lt;%2&gt;&quot; pomyślał, że strona &quot;%3&quot; na &quot;%4&quot; może Cię zainteresować.</translation>
    </message>
    <message>
        <source>This is the link to the page:</source>
        <translation>To jest link do strony:</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;:</source>
        <translation>Skomentowane przez: &quot;%1 &lt;%2&gt;&quot;:</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>Translating</source>
        <translation type="obsolete">Tłumaczenie</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="obsolete">Zmiany nie zatwierdzone</translation>
    </message>
    <message>
        <source>input was stored successfully</source>
        <translation type="obsolete">Zmiany zapamiętane pomyślnie</translation>
    </message>
    <message>
        <source>Remove the following translations from</source>
        <translation type="obsolete">Usuń następujące tłumaczenie z</translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation type="obsolete">Lokalizacja:</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="obsolete">Język:</translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation>(Brak informacji o lokalizacji)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Translate into:</source>
        <translation type="obsolete">Przetłumacz na:</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Tłumaczenia</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Przetłumacz</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="obsolete">Usuń</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Edit Object</source>
        <translation type="obsolete">Edytuj obiekt</translation>
    </message>
    <message>
        <source>Translating &apos;%1&apos;</source>
        <translation>Tłumaczenie &apos;%1&apos;</translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 zapisano pomyślnie</translation>
    </message>
    <message>
        <source>Remove the following translations from &apos;%1&apos;</source>
        <translation>Usuń następujące tłumaczenia z &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Region</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <source>Translate into</source>
        <translation>Tłumacz na</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Kosz</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcja</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Bieżąca wersja</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Odzyskaj</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>Kosz jest pusty</translation>
    </message>
    <message>
        <source>Empty Trash</source>
        <translation>Opróżnij kosz</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Zaznacz wszystkie</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Odznacz wszystkie</translation>
    </message>
    <message>
        <source>Draft is empty</source>
        <translation>Szkice (błedy) są puste</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Versions for:</source>
        <translation type="obsolete">Wersje dla:</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Wersje (nie szkice)</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="obsolete">Wersja</translation>
    </message>
    <message>
        <source>is not available for editing anymore, only drafts can be edited.</source>
        <translation type="obsolete">jest niedostępna do edycji, tylko szkice mogą być edytowane.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Aby edytować tą wersję, utwórz jej kopię.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Wersja nie należy do Ciebie</translation>
    </message>
    <message>
        <source>was not created by you, only your own drafts can be edited.</source>
        <translation type="obsolete">nie była stworzona przez Ciebie, edytować możesz tylko Swoje własne szkice.</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Wersja:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Tłumaczenia:</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Autor:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Zmodyfikowane:</translation>
    </message>
    <message>
        <source>Object Edit</source>
        <translation type="obsolete">Edycja Obiektu</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiuj</translation>
    </message>
    <message>
        <source>Versions for: %1</source>
        <translation>Wersja dla: %1</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>Wersja %1 nie jest dłużej dostępna do edycji. Tylko szkice mogą być poprawiane.</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>Versja %1 nie została stworzona przez ciebie. Możesz edytować tylko własne szkice.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Kopiuj i edytuj</translation>
    </message>
    <message>
        <source>Unable to create new version</source>
        <translation>Nie możliwe utworzenie nowej wersji</translation>
    </message>
    <message>
        <source>Version history limit has been exceeded and no archived version can be removed by the system.</source>
        <translation>Przekroczono limit wersji historycznych a wersji a wersji archiwlanej nie daje się usunąć z systemu.</translation>
    </message>
    <message>
        <source>You can change your version history settings in content.ini, remove draft versions or edit existing drafts.</source>
        <translation>Możesz zmienić ustawienia historii w content.ini, usunąć szkic lub edytować już istniejący szkic.</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>Browse</source>
        <translation>Przejrzyj</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Select:</source>
        <translation type="obsolete">Wybierz:</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Wybierz</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Moje szkice</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="obsolete">Wersja:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Edycja:</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Nie masz żadnych szkiców</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation type="obsolete">Obecna wersja:</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Powiązane obiekty</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Żadne</translation>
    </message>
    <message>
        <source>Translation:</source>
        <translation type="obsolete">Tłumaczenie:</translation>
    </message>
    <message>
        <source>Placement:</source>
        <translation type="obsolete">Umiejscowienie:</translation>
    </message>
    <message>
        <source>Site Design:</source>
        <translation type="obsolete">Projekt Strony:</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Zmień</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publikuj</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Wersje</translation>
    </message>
    <message>
        <source>To select objects, choose the appriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Aby wybrać obiekt zaznacz odpowiednie pole i kliknij na &quot;Wybierz&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Aby wybrać obiekt który jest pochodny od jednego z wyświetlonych obiektów, kliknij na nazwę obiektu a otrzymasz listę obiektów pochodnych od danego.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcja</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Bieżąca wersja</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Tłumaczenie</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Usytuowanie</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Design strony</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Preferowane</translation>
    </message>
    <message>
        <source>Add bookmarks</source>
        <translation>Do Preferowanych</translation>
    </message>
    <message>
        <source>You have no bookmarks</source>
        <translation>Nie masz Preferowanych</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>W górę o jeden poziom</translation>
    </message>
    <message>
        <source>Top levels</source>
        <translation>Poziomy najwyższe</translation>
    </message>
    <message>
        <source>Switch top levels by clicking one of these items.</source>
        <translation>Przełączaj poziomy najwyższe klikając na jednej z tych pozycji.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Do Preferowanych</translation>
    </message>
    <message>
        <source>Recent items</source>
        <translation>Ostatnie obiekty</translation>
    </message>
    <message>
        <source>Recent items are added on publishing.</source>
        <translation>Ostatnie obiekty zostały dodane do opublikowania.</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them anymore.</source>
        <translation>Istnieją objekty nad którymi właśnie pracujesz. Jesteś właścicielem szkiców i wyłącznie ty możesz je podglądać.
Możesz nawet poprawiać szkice, albo je wykasować, o ile nie są one więcej przydatne.</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Ostatnia modyfikacja</translation>
    </message>
    <message>
        <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %addbutton button.

      Removing objects will only remove them from this list.</source>
        <translation type="obsolete">To są obiekty zaznaczone jako Preferowane. Kliknij na obiekt aby go obejrzeć lub, jeśli masz odpowiednie uprawnienia, aby go edytować kliknij na Edytuj.
Jeśli życzysz sobie dodać więcej obiektów kliknij na %addbutton

Usunięcie obiektu powoduje jedynie usunięcie go z tej listy.

</translation>
    </message>
    <message>
        <source>Empty Draft</source>
        <translation>Opróżnij szkice</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Oczekujące</translation>
    </message>
    <message>
        <source>Your pending list is empty</source>
        <translation>Lista oczekujących jest pusta</translation>
    </message>
    <message>
        <source>Choose related objects</source>
        <translation>Wybierz połączone obiekty</translation>
    </message>
    <message>
        <source>Please choose objects which you want to relate to %name.

    Select your objects and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Wybierz obiekt, który ma być powiązany z %name.

Wybierz obiekt i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszej selekcji, o ile to możliwe. 
Klikaj na nazwie obiektu w celu zmiany wyświetlanej listy obiektów.</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Zaznacz wszystkie</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Odznacz wszystkie</translation>
    </message>
    <message>
        <source>Bookmark items are managed using %bookmarkname in the %personalname part.</source>
        <translation>Zarządzaj Ulubionymi używając %bookmarkname w części %personalname. </translation>
    </message>
    <message>
        <source>Choose placements</source>
        <translation>Wybierz położenie</translation>
    </message>
    <message>
        <source>Please choose where you want to place %name.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać położenie dla %name.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
    <message>
        <source>Choose new placement</source>
        <translation>Wybierz nowe położenie</translation>
    </message>
    <message>
        <source>Please choose the new placement for %name.
      The previous placement was in %placementname.

      Select the placement and click the %buttonname button.
      Using the recent and bookmark items for quick placement is also possible.
      Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać nowe położenie dla %name.
   Poprzednim położeniem było %placementname.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Utworzył</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Utworzono</translation>
    </message>
    <message>
        <source>Regenerate</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>To select objects, choose the appropriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Aby wybrać obiekt, zaznacz odpowiednią(e) pozycję(e) i kliknij na klawisz &quot;Wybierz&quot;.</translation>
    </message>
    <message>
        <source>Choose initial placement</source>
        <translation>Wypierz położenie początkowe</translation>
    </message>
    <message>
        <source>Please choose where you want to place the new %classname.

    Select the placement and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać położenie dla nowej %classname.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
    <message>
        <source>These are the objects you have bookmarked. Click on an object to view it or if you have sufficient permission you can to edit the object by clicking the edit button.
      If you want to add more objects to this list click the %emphasize_startAdd bookmarks%emphasize_stop button.

      Removing objects will only remove them from this list.</source>
        <translation>To są obiekty zaznaczone jako Preferowane. Kliknij na obiekt aby go obejrzeć lub, jeśli masz odpowiednie uprawnienia, aby go edytować kliknij na Edytuj.
Jeśli życzysz sobie dodać więcej obiektów kliknij na klawisz %emphasize_startDo Preferowanych%emphasize_stop

Usunięcie obiektu powoduje jedynie usunięcie go z tej listy.

</translation>
    </message>
    <message>
        <source>Choose items to bookmark</source>
        <translation>Wybierz Preferowane pozycje</translation>
    </message>
    <message>
        <source>Please choose the items you want to add to your bookmark list.

    Select your items and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on item names to change the browse listing.</source>
        <translation>Wybierz pozycje które chcesz dodać do Twej listy Preferowanych.

Wybierz pozycje i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszej selekcji, o ile to możliwe. 
Klikaj na nazwie obiektu w celu zmiany wyświetlanej listy obiektów.</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Dostęp zabroniony</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>Nie masz wystarczających uprawnień do tego obszaru.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Nie znaleziono</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Moduł nie znaleziony</translation>
    </message>
    <message>
        <source>The requested module</source>
        <translation type="obsolete">Żądany moduł</translation>
    </message>
    <message>
        <source>could not be found.</source>
        <translation type="obsolete">nie może zostać znaleziony.</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Widok nie znaleziony</translation>
    </message>
    <message>
        <source>The requested view</source>
        <translation type="obsolete">Żądany widok</translation>
    </message>
    <message>
        <source>could not be found in module:</source>
        <translation type="obsolete">nie może zostać znaleziony w module:</translation>
    </message>
    <message>
        <source>Unavailable</source>
        <translation type="obsolete">Nieosiągalny</translation>
    </message>
    <message>
        <source>The object is not available.</source>
        <translation type="obsolete">Obiekt nie jest dostępny.</translation>
    </message>
    <message>
        <source>Login to get proper permissions.</source>
        <translation type="obsolete">Zaloguj się w celu uzyskania uprawnień.</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Kliknij na klawisz Login w celu zalogowania.</translation>
    </message>
    <message>
        <source>The requested module &apos;%1&apos; could not be found.</source>
        <translation type="obsolete">Żądanego modułu &apos;%1&quot; nie odnaleziono.</translation>
    </message>
    <message>
        <source>The requested view &apos;%1&apos; could not be found in module: &apos;%2&apos;</source>
        <translation type="obsolete">Żądanego widoku &apos;%1&quot;  nie odnaleziono w module: &apos;%2&apos;</translation>
    </message>
    <message>
        <source>View is disabled</source>
        <translation>Widok jest wyłączony</translation>
    </message>
    <message>
        <source>The view %2/%1 is disabled and cannot be accessed.</source>
        <translation type="obsolete">Widok %2/%1 jest wyłaczony i jest niedostępny.</translation>
    </message>
    <message>
        <source>Module is disabled</source>
        <translation>Moduł jest wyłączony</translation>
    </message>
    <message>
        <source>The module %1 is disabled and cannot be accessed.</source>
        <translation type="obsolete">Moduł %1 jest wyłączony i nie jest dostępny.</translation>
    </message>
    <message>
        <source>Possible reasons for this is.</source>
        <translation>Możliwe powody to.</translation>
    </message>
    <message>
        <source>Your current user does not have the proper privileges to access this page.</source>
        <translation>Nie masz prawa dostępu do tej strony.</translation>
    </message>
    <message>
        <source>You&apos;re currently not logged in on the site, to get proper access create a new user or login with an existing user.</source>
        <translation type="obsolete">Nie jesteś zalogowany, aby uzyskać dostęp dokonaj rejestracji nowego użytkownika lub zaloguj się jako istniejący już użytkownik.</translation>
    </message>
    <message>
        <source>You misspelled some parts of your url, try changing it.</source>
        <translation>Popełniłeś błąd w adresie strony, należy go porawić.</translation>
    </message>
    <message>
        <source>The resource you requested was not found.</source>
        <translation>Zasób którego żądasz nie istnieje.</translation>
    </message>
    <message>
        <source>The the id or name of the resource was misspelled, try changing it.</source>
        <translation>ID lub nazwa zasobu błędnie napisana, popraw.</translation>
    </message>
    <message>
        <source>The resource longer exists on the site.</source>
        <translation>Zasób nie jest już dostępny na stronach.</translation>
    </message>
    <message>
        <source>The module name was misspelled, try changing the url.</source>
        <translation>Nazwa modułu błędnie napisana, popraw.</translation>
    </message>
    <message>
        <source>The module does not exist on this site.</source>
        <translation>Ten moduł nie istnieje  na stronach.</translation>
    </message>
    <message>
        <source>This site uses siteaccess matching in the url and you didn&apos;t supply one, try inserting a siteaccess name before the module in the url .</source>
        <translation>System używa przedrostka siteacces w adresie url, wpisz go przed nazwą modułu w adresie url.</translation>
    </message>
    <message>
        <source>The view name was misspelled, try changing the url.</source>
        <translation>Nazwa widoku błędnie napisana, popraw adres URL.</translation>
    </message>
    <message>
        <source>The view does not exist for the module &apos;%1&apos;.</source>
        <translation type="obsolete">Ten widok nie istnieje dla modułu &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Object is unavailable</source>
        <translation>Obiekt niedostępny</translation>
    </message>
    <message>
        <source>The object you requested is not currently available.</source>
        <translation>Żądany obiekt nie jest aktualnie dostępny.</translation>
    </message>
    <message>
        <source>The id or name of the object was misspelled, try changing it.</source>
        <translation>ID lub nazwa obiektu błędnie napisana, popraw.</translation>
    </message>
    <message>
        <source>The object is no longer available on the site.</source>
        <translation>Obiekt nie jest już dostępny na stronach.</translation>
    </message>
    <message>
        <source>Object moved</source>
        <translation>Obiekt przeniesiony</translation>
    </message>
    <message>
        <source>The object is no longer available at this URL.</source>
        <translation>ObObiekt nie jest już dostępny pod tym adresem URL.</translation>
    </message>
    <message>
        <source>You should automatically be redirected to the new location. If not click %1here%2.</source>
        <translation type="obsolete">Nastąpi automatyczne przekierowanie do nowego adresu. Jeśli nie chcesz, kliknij %1tu%2.</translation>
    </message>
    <message>
        <source>The requested module %module could not be found.</source>
        <translation>Żądany moduł %module nie istnieje.</translation>
    </message>
    <message>
        <source>The requested view %view could not be found in module %module</source>
        <translation>Żądanego widoku %view nie znaleziono w module %module</translation>
    </message>
    <message>
        <source>The view does not exist for the module %module.</source>
        <translation>Ten widok nie istnieje w module %module.</translation>
    </message>
    <message>
        <source>The view %module/%view is disabled and cannot be accessed.</source>
        <translation>Widok %module/%view jest wyłączony i niedostępny.</translation>
    </message>
    <message>
        <source>The module %module is disabled and cannot be accessed.</source>
        <translation>Moduł %module jest wyłączony i niedostępny.</translation>
    </message>
    <message>
        <source>You should automatically be redirected to the new location. If not click %url.</source>
        <translation>Nastąpi automatyczne przekierowanie pod nowy adres. Jeśli nie chcesz kliknij %url.</translation>
    </message>
    <message>
        <source>You are currently not logged in to the site, to get proper access create a new user or login with an existing user.</source>
        <translation>Nie jesteś obecnie zalogowanym użytkownikiem, aby uzyskać szerszy dostęp utwórz nowego użytkownika lub zaloguj się jako już istniejący użytkownik.</translation>
    </message>
</context>
<context>
    <name>design/standard/form</name>
    <message>
        <source>Thank you for your feedback</source>
        <translation>Dziękujemy za Twą informację zwrotną</translation>
    </message>
    <message>
        <source>Your information was successfully received.</source>
        <translation>Twoją informację otrzymaliśmy.  </translation>
    </message>
</context>
<context>
    <name>design/standard/gui</name>
    <message>
        <source>Delete</source>
        <translation>Skasuj</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Printable version</source>
        <translation>Wersja drukowalna</translation>
    </message>
    <message>
        <source>%1 front page</source>
        <translation type="obsolete">%1 strona główna</translation>
    </message>
    <message>
        <source>Search %1</source>
        <translation type="obsolete">Szukaj %1</translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="obsolete">Zawartość</translation>
    </message>
    <message>
        <source>List</source>
        <translation type="obsolete">Lista</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Mapa serwisu</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation type="obsolete">Moje szkice</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation type="obsolete">Ustawienia</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation type="obsolete">Klasy</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation type="obsolete">Sekcje</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation type="obsolete">Workflows</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="obsolete">Triggers</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation type="obsolete">Przeszukuj statystyki</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation type="obsolete">Sklep</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="obsolete">Lista zamówień</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation type="obsolete">Rodzaje VAT-u</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="obsolete">Zniżka</translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="obsolete">Użytkownicy</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation type="obsolete">Role</translation>
    </message>
    <message>
        <source>My Notifications</source>
        <translation type="obsolete">Moje powiadomienia</translation>
    </message>
    <message>
        <source>My Tasks</source>
        <translation type="obsolete">Moje zadania</translation>
    </message>
    <message>
        <source>New article</source>
        <translation type="obsolete">Nowy artykuł</translation>
    </message>
    <message>
        <source>New link</source>
        <translation type="obsolete">Nowy link</translation>
    </message>
    <message>
        <source>New product</source>
        <translation type="obsolete">Nowy produkt</translation>
    </message>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Witamy w panelu administracyjnym eZ publish</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Wpisz prawidłową nazwę użytkownika i hasło aby się zalogować.</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Szukanie zaawansowane</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Zmień Hasło</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <source>About eZ publish</source>
        <translation type="obsolete">O eZ publish</translation>
    </message>
    <message>
        <source>About eZ publish 3</source>
        <translation type="obsolete">o eZ publish 3</translation>
    </message>
    <message>
        <source>Installation &amp; configuration</source>
        <translation type="obsolete">Instalacja &amp; konfiguracja</translation>
    </message>
    <message>
        <source>Install using installers</source>
        <translation type="obsolete">Instaluj używając instalatorów</translation>
    </message>
    <message>
        <source>Install manually</source>
        <translation type="obsolete">Instaluj ręcznie</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation type="obsolete">Odinstaluj</translation>
    </message>
    <message>
        <source>SDK &amp; Technical references</source>
        <translation type="obsolete">SDK &amp; Noty techniczne</translation>
    </message>
    <message>
        <source>eZ publish SDK</source>
        <translation type="obsolete">ez publish SDK</translation>
    </message>
    <message>
        <source>Redirecting to:</source>
        <translation type="obsolete">Przekierowanie do:</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Przekieruj</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation type="obsolete">Uruchom ponownie</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Błąd w ładowaniu modułu</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Niezdefiniowany moduł:</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="obsolete">Strona:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="obsolete">Wersja:</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Front</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Własne</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Kosz</translation>
    </message>
    <message>
        <source>Redirecting to %1</source>
        <translation type="obsolete">Przeniesienie do %1</translation>
    </message>
    <message>
        <source>more</source>
        <translation>więcej</translation>
    </message>
    <message>
        <source>%sitetitle front page</source>
        <translation>%sitetitle Front</translation>
    </message>
    <message>
        <source>Search %sitetitle</source>
        <translation>Szukaj %sitetitle</translation>
    </message>
    <message>
        <source>eZ publish redirection - %url</source>
        <translation>Przekierowanie eZ publish  - %url</translation>
    </message>
    <message>
        <source>Redirecting to %url</source>
        <translation>Przekierowanie do %url</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Poprzedni</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Następny</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove</source>
        <translation type="obsolete">Czy jesteś pewien, że chcesz usunąć</translation>
    </message>
    <message>
        <source>from node</source>
        <translation type="obsolete">z węzła</translation>
    </message>
    <message>
        <source>?</source>
        <translation type="obsolete">?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s</source>
        <translation type="obsolete">Usunięcie oznaczenia, także usunie jego</translation>
    </message>
    <message>
        <source>!</source>
        <translation type="obsolete">!</translation>
    </message>
    <message>
        <source>Removing node assignment of</source>
        <translation type="obsolete">Usuwanie oznaczenia węzła dla</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Are you sure you want to remove this(these) node(s)?</source>
        <translation type="obsolete">Czy jesteś pewien, że chcesz usunąć ten(te) węzeł(ły)?</translation>
    </message>
    <message>
        <source>Removing</source>
        <translation type="obsolete">Usuwanie</translation>
    </message>
    <message>
        <source>will remove the node itself and it&apos;s</source>
        <translation type="obsolete">usunie sam węzeł i jego</translation>
    </message>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Czy na pewno chcesz usunąć %1 z węzła %2?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1!</source>
        <translation type="obsolete">Usunięcie tego przypisania usunie również jego %1!</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Notatka:</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Usunięte węzły można odzyskać później. Znajdziesz je w koszu.</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these nodes?</source>
        <translation type="obsolete">Czy na pewno chcesz usunąć ten węzeł?</translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2! %3</source>
        <translation type="obsolete">Usunięcie węzła %1 pociągnie za sobą usunięcie jego %2! %3</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Następujące obiekty zostały usunięte z kosza dlatego, że produkty zostały zmienione</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1 children.</source>
        <translation type="obsolete">Usunięcie tego przypisania usunie także jego %1 dzieci.</translation>
    </message>
    <message>
        <source>Removing node assignment of %1</source>
        <translation>Usunięcie przypisania węzła %1</translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2 children. %3</source>
        <translation type="obsolete">Usunięcie %1 spowoduje usunięcie tego węzła i jego %2 dzieci. %3</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these items?</source>
        <translation>Czy na pewno chcesz usunąć te pozycje?</translation>
    </message>
    <message>
        <source>Move to trash</source>
        <translation>Przenieś do kosza</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove its %1 children.</source>
        <translation>Usunięcie tego przypisania spowoduje usunięcie jego %1 dzieci.</translation>
    </message>
    <message>
        <source>%nodename and its %childcount children. %additionalwarning</source>
        <translation>%nodename i jego %childcount dzieci. %additionalwarning</translation>
    </message>
    <message>
        <source>%nodename %additionalwarning</source>
        <translation>%nodename %additionalwarning</translation>
    </message>
    <message>
        <source>If %trashname is checked you will find the removed items in the trash afterwards.</source>
        <translation>Jeśli %trashname jest zaznaczony, znajdziesz poźniej usuwane pozycje w Koszu.</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>m.nam</source>
        <translation type="obsolete">m.nam</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation type="obsolete">Sklep</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Related products:</source>
        <translation type="obsolete">Produkty pokrewne</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Mapa serwisu</translation>
    </message>
    <message>
        <source>Bookmark</source>
        <translation>Do Preferowanych</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Śledź aktualizacje</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Utwórz tutaj</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcja</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualizuj</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Grupa użytkowników</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Add to Bookmarks</source>
        <translation>Do Preferowanych</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Śledź aktualizacje</translation>
    </message>
    <message>
        <source>Default object view.</source>
        <translation>Bieżący widok obiektu.</translation>
    </message>
    <message>
        <source>Click to create a custom template</source>
        <translation>Kliknij aby utworzyć własny szablon</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <source>Romove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>$ContentAction:item.name</source>
        <translation type="obsolete">Witamy w kreatorze operatorów szablonów.&lt;br/&gt;
Operatory szablonów są używane podczas paracy nad elementami szablonów&lt;br/&gt;
takimi jak zmienne i łańcuchy i mogą być użyte do tworzenia nowych danych.&lt;br/&gt;
Kreator poprowadzi poprzez szereg kolejnych kroków w których będzie można dokonać&lt;br/&gt;
odpowiedniego wyboru warunków i danych wejściowych, kiedy zakończysz&lt;br/&gt;
nowy operator zostanie utworzony i stanie się dostępny do pobrania.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>of</source>
        <translation>z</translation>
    </message>
    <message>
        <source>Front page</source>
        <translation>Front</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Domowa</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Zaznacz wszystkie</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Odznacz wszystkie</translation>
    </message>
    <message>
        <source>New image</source>
        <translation>Nowy obraz</translation>
    </message>
    <message>
        <source>New gallery</source>
        <translation>Nowa galeria</translation>
    </message>
    <message>
        <source>New album</source>
        <translation>Nowy album</translation>
    </message>
    <message>
        <source>New file</source>
        <translation>Nowy plik</translation>
    </message>
    <message>
        <source>New article</source>
        <translation>Nowy artykuł</translation>
    </message>
    <message>
        <source>New person</source>
        <translation>Nowa osoba</translation>
    </message>
    <message>
        <source>New company</source>
        <translation>Nowa firma</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Dane wejściowe błędne</translation>
    </message>
    <message>
        <source>New log</source>
        <translation>Nowy log</translation>
    </message>
    <message>
        <source>Node ID</source>
        <translation>ID węzła</translation>
    </message>
    <message>
        <source>Object ID</source>
        <translation>ID obiektu</translation>
    </message>
    <message>
        <source>Collected info</source>
        <translation>Zebrano i wysłano informacje</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">Szukaj</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>system&quot;</source>
        <translation type="obsolete">system&quot;</translation>
    </message>
    <message>
        <source>Notification registration form</source>
        <translation type="obsolete">Formularz rejestracyjny zawiadomienia</translation>
    </message>
    <message>
        <source>Send Method:</source>
        <translation type="obsolete">Metoda wysyłki:</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="obsolete">Email</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation type="obsolete">SMS</translation>
    </message>
    <message>
        <source>Internal message</source>
        <translation type="obsolete">Wiadomość wewnętrzna</translation>
    </message>
    <message>
        <source>Send day:</source>
        <translation type="obsolete">Wysłano dnia:</translation>
    </message>
    <message>
        <source>Immediately</source>
        <translation type="obsolete">tychmiast</translation>
    </message>
    <message>
        <source>Monday</source>
        <translation type="obsolete">Poniedziałek</translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation type="obsolete">Wtorek</translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation type="obsolete">Środa</translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation type="obsolete">Czwartek</translation>
    </message>
    <message>
        <source>Friday</source>
        <translation type="obsolete">Piątek</translation>
    </message>
    <message>
        <source>Saturday</source>
        <translation type="obsolete">Sobota</translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation type="obsolete">Niedziela</translation>
    </message>
    <message>
        <source>Send time:</source>
        <translation type="obsolete">Czas wysłania:</translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="obsolete">Zarejestruj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete">Odrzuć</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Rule Type:</source>
        <translation type="obsolete">Rodzaj Reguły:</translation>
    </message>
    <message>
        <source>Class Name:</source>
        <translation type="obsolete">Nazwa Klasy:</translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="obsolete">Ścieżka:</translation>
    </message>
    <message>
        <source>Keyword:</source>
        <translation type="obsolete">Słowo kluczowe:</translation>
    </message>
    <message>
        <source>Additional constraint:</source>
        <translation type="obsolete">Dodatkowe ograniczenia:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Edycja:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Usuń:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Edycja</translation>
    </message>
    <message>
        <source>New Rule</source>
        <translation type="obsolete">Nowa Reguła</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="obsolete">Wyślij Wiadomość</translation>
    </message>
    <message>
        <source>Do you want to receive messages combined in digest</source>
        <translation>Czy chcesz otrzymywać wiadomości zebrane w raport</translation>
    </message>
    <message>
        <source>Digest settings</source>
        <translation>Przetwarzanie</translation>
    </message>
    <message>
        <source>Day the week</source>
        <translation type="obsolete">Dzień tygodnia</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>%sitename.&quot;
</source>
        <translation type="obsolete">%sitename.&quot;</translation>
    </message>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>Jeżeli nie chcesz więcej otrzymywać te powiadomienia, zmień swoje ustawienia na:</translation>
    </message>
    <message>
        <source>system&quot;
</source>
        <translation type="obsolete">system&quot;</translation>
    </message>
    <message>
        <source>below.&quot;
</source>
        <translation type="obsolete">below.&quot;</translation>
    </message>
    <message>
        <source>Notification admin</source>
        <translation>Administrowanie powiadamianiem</translation>
    </message>
    <message>
        <source>Notification filter proccessed all available notification events</source>
        <translation>Filtr powiadamiania przetworzył wszystkie dostępne zdarzenia powiadamiania</translation>
    </message>
    <message>
        <source>Time event was spawned</source>
        <translation>Zadarzenie czasowe zostało wygenerowane</translation>
    </message>
    <message>
        <source>Run notification filter</source>
        <translation>Uruchom filtr powiadamiania</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Uruchom</translation>
    </message>
    <message>
        <source>Spawn time event</source>
        <translation>Generuj zdarzenie czasowe</translation>
    </message>
    <message>
        <source>Spawn</source>
        <translation>Generuj</translation>
    </message>
    <message>
        <source>Receive all messages combined in one digest</source>
        <translation>Otrzymywanie wszystkich wiadomości zebranych w jeden raport</translation>
    </message>
    <message>
        <source>Send out</source>
        <translation>Wyślij</translation>
    </message>
    <message>
        <source>Day of the week</source>
        <translation>Dzień tygodnia</translation>
    </message>
    <message>
        <source>This email is to inform you that a new item has been publish at %sitename.
The item can viewed by using the URL below.</source>
        <translation type="obsolete">Ten Email jest informacją o tym, że nowa pozycja została opublikowana za %sitename.
Pozycję możesz zobaczyć używając poniższego adresu URL.</translation>
    </message>
    <message>
        <source>%sitename notification system</source>
        <translation>System powiadamiania %sitename</translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation>Ustawienia powiadomień</translation>
    </message>
    <message>
        <source>This email is to inform you that a new collaboration item is awaiting your attention at %sitename.
The item can viewed by using the URL below.</source>
        <translation>Ten email informuje Cię, że nowa pozycja współpracy oczekuje Twej reakcji na %sitename.
Pozycję możesz zobaczyć klikając na poniższy URL.</translation>
    </message>
    <message>
        <source>This email is to inform you on news at %sitename.</source>
        <translation>Ten email informuje Cię o nowince na %sitename.</translation>
    </message>
    <message>
        <source>[%sitename] New collaboration item</source>
        <translation>[%sitename] Nowe pozycje współpracy</translation>
    </message>
    <message>
        <source>[%sitename] Digest for %date</source>
        <translation>[%sitename] Skrót z %date</translation>
    </message>
    <message>
        <source>This digest email is to inform you on new items at %sitename.</source>
        <translation>Ten email ze streszczeniem informuje Cię o nowościach na %sitename.</translation>
    </message>
</context>
<context>
    <name>design/standard/notification/collaboration</name>
    <message>
        <source>Collaboration notification</source>
        <translation>Powiadomienia współpracy</translation>
    </message>
    <message>
        <source>Choose which collaboration items you wish to get notifications for.</source>
        <translation>Wybierz o którch pozycjach współpracy życzysz sobie powiadamiania.</translation>
    </message>
</context>
<context>
    <name>design/standard/package</name>
    <message>
        <source>Packages</source>
        <translation>Pakiety</translation>
    </message>
    <message>
        <source>The following packages are available on this system</source>
        <translation>Następujące pakiety są dostępne w tym systemie</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Podsumowanie</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Upload package</source>
        <translation>Ładuj pakiet</translation>
    </message>
    <message>
        <source>Select the file containing your package and click the upload button</source>
        <translation>Wybierz plik zawierający pakiet i kliknij na klawisz Ładuj</translation>
    </message>
    <message>
        <source>Install package</source>
        <translation>Instaluj pakiet</translation>
    </message>
    <message>
        <source>Please provide information on the changes.</source>
        <translation>Proszę wprowadzić informację o zmianach.</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Zmiany</translation>
    </message>
    <message>
        <source>Please provide some basic information for your package.</source>
        <translation>Proszę wprowadzić podstawowe informacje o Twym pakiecie.</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Nazwa pakietu</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Licence</source>
        <translation>Licencja</translation>
    </message>
    <message>
        <source>Package host</source>
        <translation>Host pakietu</translation>
    </message>
    <message>
        <source>Packager</source>
        <translation>Archiwizator</translation>
    </message>
    <message>
        <source>Please provide information on the maintainer of the package.</source>
        <translation>Proszę wprowadzić podstawowe informacje o konserwatorze tego pakietu.</translation>
    </message>
    <message>
        <source>Please select a thumbnail file to be included in the package,
if you do not wish to have a thumbnail simply click Next.</source>
        <translation>Proszę wybrać ikonę załączoną do pakietu, 
jeśli życzysz sobie ikony przykładowej kliknij na Dalej. </translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Twórz pakiet</translation>
    </message>
    <message>
        <source>Available wizards</source>
        <translation>Dostępne skórki</translation>
    </message>
    <message>
        <source>Choose one of the following wizards for creating a package</source>
        <translation>Wybierz jednę z dostępnych skórek w celu utworzenia pakietu</translation>
    </message>
    <message>
        <source>Please choose the content classes you wish to be included in the package.</source>
        <translation>Proszę wybrać klasy zawartości, które mają zostać zawarte w pakiecie.</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Lista klas</translation>
    </message>
    <message>
        <source>Please select a CSS file to be included in the package.</source>
        <translation>Proszę wybrać plik CSS, który ma zostać zawarty w pakiecie.</translation>
    </message>
    <message>
        <source>Select an image file to be included in the package and click Next.
When you are done with adding images click Next without choosing an image.</source>
        <translation>Wybierz plik z obrazem który ma zostać załączony do pakietu i kliknij na Dalej.
Jeśli nie chcesz załączać obrazu kliknij tylko na Dalej.</translation>
    </message>
    <message>
        <source>Currently added image files</source>
        <translation>Aktualnie dodany plik obrazu</translation>
    </message>
    <message>
        <source>The package can be installed on your system, installing the package will copy files, create content classes etc. all depending on the package.
If you do not wish to install the package at this time you can do so later on the view page for the package.</source>
        <translation>Pakiet może zostać zainstalowany w Twym systemie, instalacja pakietu skopiuje pliki, utworzy klasy etc. wszystko zależnie od zawartości pakietu.
Jeśli nie życzysz sobie instalacji pakietu w tym momencie możesz dokonać tego później poprzez wyświetlenie strony pakietu.</translation>
    </message>
    <message>
        <source>Install items</source>
        <translation>Instaluj pozycje</translation>
    </message>
    <message>
        <source>Skip installation</source>
        <translation>Przerwij instalację</translation>
    </message>
    <message>
        <source>Removal of packages</source>
        <translation>Usuwanie pakietów</translation>
    </message>
    <message>
        <source>Are you sure you wish to remove the following packages?
The packages will be lost forever.
Note: The packages will not be uninstalled.</source>
        <translation>Czy na pewno chcesz usunąć następujące pakiety?
Pakiety zostaną utracone na zawsze.
Uwaga: pakiety nie będą mogły być odinstalowane.</translation>
    </message>
    <message>
        <source>Confirm removal</source>
        <translation>Potwierdź usunięcie</translation>
    </message>
    <message>
        <source>Keep packages</source>
        <translation>Pakiety utrzymują</translation>
    </message>
    <message>
        <source>Package removal was cancelled.</source>
        <translation>Usunięcie pakietu anulowane.</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selekcja</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation>Zainstalowano</translation>
    </message>
    <message>
        <source>Not installed</source>
        <translation>Nie zainstalowano</translation>
    </message>
    <message>
        <source>Imported</source>
        <translation>Importowane</translation>
    </message>
    <message>
        <source>Remove package</source>
        <translation>Usuń pakiet</translation>
    </message>
    <message>
        <source>Import package</source>
        <translation>Import pakietu</translation>
    </message>
    <message>
        <source>Uninstall package</source>
        <translation>Odinstaluj pakiet</translation>
    </message>
    <message>
        <source>The package can be uninstalled from your system, uninstalling the package will remove any installed files, content classes etc. all depending on the package.
If you do not wish to uninstall the package at this time you can do so later on the view page for the package.
You may also remove the package without uninstalling it from the package list.</source>
        <translation>Pakiet może zostać odinstalowany z Twego systemu, deinstalacja usunie wszystkie zainstalowane wcześniej pliki, klasy zawartości etc. wszystko, co było zawarte w pakiecie.
Jeśli nie życzysz sobie odinstalowywania pakietu w tym momencie możesz to zrobić później wchodząc na stronę pakietu.
Możesz także usunąć pakiet tylko z listy pakietów bez dokonywania deinstalacji.</translation>
    </message>
    <message>
        <source>Uninstall items</source>
        <translation>Odinstaluj pozycje</translation>
    </message>
    <message>
        <source>Skip uninstallation</source>
        <translation>Przerwij odinstalowywanie</translation>
    </message>
    <message>
        <source>Files [%collectionname]</source>
        <translation>Pliki [%collectionname]</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Szczegóły</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Stan</translation>
    </message>
    <message>
        <source>Maintainers</source>
        <translation>Konserwatorzy</translation>
    </message>
    <message>
        <source>Regarding eZ publish package &apos;%packagename&apos;</source>
        <translation>Przeglądanie pakietu eZ publish &apos;%packagename&apos;</translation>
    </message>
    <message>
        <source>Send E-Mail to the maintainer</source>
        <translation>Wyślij E-Mail do konserwatora</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Log zmian</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Lista plików</translation>
    </message>
    <message>
        <source>Start an entry with a marker ( %emstart-%emend (dash) or %emstart*%emend (asterix) ) at the beginning of the line.
The change will continue to the next change marker.</source>
        <translation>Zacznij wpis od znacznika zmian ( %emstart-%emend (dash) lub %emstart*%emend (asterix) ) na początku linii.
Informacja o zmianie będzie kontynuowana do następnego znacznika zmian.</translation>
    </message>
    <message>
        <source>Role</source>
        <translation type="obsolete">Rola</translation>
    </message>
    <message>
        <source>Package wizard: %wizardname</source>
        <translation>Skórka pakietu: %wizardname</translation>
    </message>
    <message>
        <source>Next %arrowright</source>
        <translation>Dalej %arrowright</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Koniec</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Odinstaluj</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Instaluj</translation>
    </message>
    <message>
        <source>Export to file</source>
        <translation>Eksport do pliku</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Maintainer name</comment>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Role</source>
        <comment>Maintainer role</comment>
        <translation>Rola</translation>
    </message>
</context>
<context>
    <name>design/standard/pdf/list</name>
    <message>
        <source>PDF Exports</source>
        <translation>PDF eksport</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Utworzył</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Utworzono</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Nowy eksport</translation>
    </message>
</context>
<context>
    <name>design/standard/reference/ez</name>
    <message>
        <source>No generated documentation found</source>
        <translation></translation>
    </message>
    <message>
        <source>To create the reference documentation you must do the following step</source>
        <translation></translation>
    </message>
    <message>
        <source>Download and install doxygen</source>
        <translation></translation>
    </message>
    <message>
        <source>Generate the documentation by running the following command</source>
        <translation></translation>
    </message>
    <message>
        <source>Download doxygen from %doxygenurl.</source>
        <translation>Pobierz doxygen z %doxygenurl.</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Główna</translation>
    </message>
    <message>
        <source>Modules</source>
        <translation>Moduły</translation>
    </message>
    <message>
        <source>Class hierarchy</source>
        <translation>Hierarchia klas</translation>
    </message>
    <message>
        <source>Compound list</source>
        <translation>Lista klas</translation>
    </message>
    <message>
        <source>File list</source>
        <translation>Lista plików</translation>
    </message>
    <message>
        <source>Compound members</source>
        <translation>Składowe klas</translation>
    </message>
    <message>
        <source>File members</source>
        <translation>Składowe plików</translation>
    </message>
    <message>
        <source>Related pages</source>
        <translation>Powiązane strony</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Wprowadzenie</translation>
    </message>
    <message>
        <source>The Reference Documentation for eZ publish consists of multiple sections which
each have a different view on the documentation. The sections can be accessed at
menu on the top.</source>
        <translation>Dokumentacja eZPublish zawiera kilka sekcji,
każda z nich to oddzielny widok. Dostęp do sekcji porzez górne menu. </translation>
    </message>
    <message>
        <source>The documentation will give an overview of the API of eZ publish.</source>
        <translation>Dokumentacja zawiera przegląd API dla eZ publish.</translation>
    </message>
    <message>
        <source>All reference documentation has been made with %doxygenurl</source>
        <translation>Całość dokumentacji wytworzono za pomocą %doxygenurl</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Twórz polisę dla</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Krok 1</translation>
    </message>
    <message>
        <source>Give access to module:</source>
        <translation type="obsolete">Zezwól na dostęp modułu:</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Każdy modół</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Zezwól wszystkim</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Ograniczone pozwolenie</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Module:</source>
        <translation type="obsolete">Moduł:</translation>
    </message>
    <message>
        <source>Access:</source>
        <translation type="obsolete">Dostęp:</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Ograniczony</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Wróć do kroku 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>Nie jesteś w stanie zezwolić na dostęp dla ograniczonych funkcji modułu </translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>ponieważ lista funkcji dla niego nie jest zdefiniowana.</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Krok 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Określ funkcje dla modułu</translation>
    </message>
    <message>
        <source>Function:</source>
        <translation type="obsolete">Funkcja:</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Wróć do kroku 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Krok 3</translation>
    </message>
    <message>
        <source>Specify limitations in function</source>
        <translation type="obsolete">Określ ograniczenia dla funcji</translation>
    </message>
    <message>
        <source>in module</source>
        <translation type="obsolete">w module</translation>
    </message>
    <message>
        <source>&apos;Any&apos; means no limitation by this parameter.</source>
        <translation type="obsolete">&apos;Każdy&apos; znaczy brak ograniczeń przez ten parametr.</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Każdy</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Role edit</source>
        <translation type="obsolete">Edycja Ról</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Current policies:</source>
        <translation type="obsolete">Obecne polisy:</translation>
    </message>
    <message>
        <source>Limitation list:</source>
        <translation type="obsolete">Lista ograniczeń:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Usuń:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Zastosuj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete">Odrzuć</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Lista ról</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation type="obsolete">Przydziel:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Edycja:</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Widok Roli</translation>
    </message>
    <message>
        <source>edit</source>
        <translation type="obsolete">edycja</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Polisy Roli</translation>
    </message>
    <message>
        <source>Limitation:</source>
        <translation type="obsolete">Ograniczenia:</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Użytkownicy i grupy przydzielone do tej roli</translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="obsolete">Użytkownik:</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Przydziel</translation>
    </message>
    <message>
        <source>Give access to module</source>
        <translation>Udziel praw do modułu</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Moduł</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Dostęp</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Funkcja</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Bieżąca polisa</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Ograniczenia</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Wycofaj zmiany</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Limity</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <source>Role edit %1</source>
        <translation>Rola edycji %1</translation>
    </message>
    <message>
        <source>Edit policy</source>
        <translation>Polityka edycji</translation>
    </message>
    <message>
        <source>Policy</source>
        <translation>Polityka</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Węzeł</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Nie wyszczególnione.</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Poddrzewo</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualizuj</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Rola</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Znajdź</translation>
    </message>
    <message>
        <source>Remove selected policies</source>
        <translation>Usuń wybrane polisy</translation>
    </message>
    <message>
        <source>Edit role</source>
        <translation>Edycja roli</translation>
    </message>
    <message>
        <source>Assign role to user or group</source>
        <translation>Przypisz rolę do użytkownika lub grupy </translation>
    </message>
    <message>
        <source>Remove selected roles</source>
        <translation>Usuń wybrane role</translation>
    </message>
    <message>
        <source>Edit current role</source>
        <translation>Edytuj bieżącą rolę</translation>
    </message>
    <message>
        <source>Remove selected assignments</source>
        <translation>Usuń wybrane przypisania</translation>
    </message>
    <message>
        <source>Specify limitations for function %functionname in module %modulename. &apos;Any&apos; means no limitation by this parameter</source>
        <translation>Określ ograniczenia dla funkcji %functionname w module %modulename. &apos;Każdy&apos; oznacza brak obraniczeń dla tego parametru</translation>
    </message>
</context>
<context>
    <name>design/standard/rss</name>
    <message>
        <source>Choose export node</source>
        <translation>Wybierz eksportowany węzeł</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Wybierz</translation>
    </message>
    <message>
        <source>Choose import destination</source>
        <translation>Wybierz miejsce przeznaczenia dla importu</translation>
    </message>
    <message>
        <source>Choose RSS image</source>
        <translation>Wybierz obraz RSS </translation>
    </message>
    <message>
        <source>Choose export source</source>
        <translation>Wybierz źródło eksportu</translation>
    </message>
    <message>
        <source>Choose owner of imported objects</source>
        <translation>Wybierz właściciela dla importowanych obiektów</translation>
    </message>
    <message>
        <source>Please choose where to export from.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać skąd dokonać eksportu.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
    <message>
        <source>Please choose where to store imported items.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać położenie dla zapisu importu.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
    <message>
        <source>Please choose image to use in RSS export.

    Select your placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać obraz, który zostanie zalączony do eksportu RSS.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
    <message>
        <source>Please select the owner of the objects to import

    Select the user and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać skąd wykonać eksport.

Wybierz położenie i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie pozycji w celu zmiany przeglądanej listy.</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/edit</name>
    <message>
        <source>Display frontpage</source>
        <translation>Wyświetl stronę główną</translation>
    </message>
    <message>
        <source>RSS Export</source>
        <translation>RSS eksport</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tytuł</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Site URL</source>
        <translation>Adres URL strony</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Przejrzyj</translation>
    </message>
    <message>
        <source>Site Access</source>
        <translation>Dostęp do stron</translation>
    </message>
    <message>
        <source>RSS version</source>
        <translation>Wersja RSS</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Aktywny</translation>
    </message>
    <message>
        <source>Access URL</source>
        <translation>Adres URL dostępu</translation>
    </message>
    <message>
        <source>Source path</source>
        <translation>Ścieżka źródłowa</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualizuj</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Add Source</source>
        <translation>Dodaj źródło</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>RSS Import</source>
        <translation>RSS import</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Destination path</source>
        <translation>Ścieżka docelowa</translation>
    </message>
    <message>
        <source>Imported objects owner</source>
        <translation>Właściciel importowanych obiektów</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Wybierz</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignoruj</translation>
    </message>
    <message>
        <source>Note. Each source only fetch 5 objects from 1 level below.</source>
        <translation>Nota. Każde źródło pobiera tylko 5 obiektów z poniżej określonego 1 poziomu.</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/list</name>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Aktywny</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modyfikujący</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Zmodyfikowane</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>RSS Feeds</source>
        <translation>Pobieranie RSS</translation>
    </message>
    <message>
        <source>RSS Exports</source>
        <translation>Eksporty RSS</translation>
    </message>
    <message>
        <source>New Export</source>
        <translation>Nowy eksport</translation>
    </message>
    <message>
        <source>RSS Imports</source>
        <translation>Importy RSS</translation>
    </message>
    <message>
        <source>New Import</source>
        <translation>Nowy import</translation>
    </message>
</context>
<context>
    <name>design/standard/rss/view</name>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Statystyki wyszukiwania</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Najczęściej wyszukiwane wyrażenia</translation>
    </message>
    <message>
        <source>Phrase:</source>
        <translation type="obsolete">Wyrażenie:</translation>
    </message>
    <message>
        <source>Number of phrases:</source>
        <translation type="obsolete">Liczba wyrażeń:</translation>
    </message>
    <message>
        <source>Average result returned:</source>
        <translation type="obsolete">Przeciętny wynik:</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Fraza</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Liczba poszukiwań frazy</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Średnia z rezultatów</translation>
    </message>
    <message>
        <source>Reset statistics</source>
        <translation>Wyczyść statystyki</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Assign section</source>
        <translation type="obsolete">Przypisz sekcję</translation>
    </message>
    <message>
        <source>Assign section to node</source>
        <translation>Przypisz sekcję do węzła</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Edycja sekcji</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Lista sekcji</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="obsolete">ID:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Edycja:</translation>
    </message>
    <message>
        <source>Assign:</source>
        <translation type="obsolete">Przypisz:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Usuń:</translation>
    </message>
    <message>
        <source>edit</source>
        <translation type="obsolete">edycja</translation>
    </message>
    <message>
        <source>assign</source>
        <translation type="obsolete">przypisz</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Czy na pewno chcesz usunąć tę klasę?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>Skasowanie tej sekcji może uszkodzić uprawnienia, układ stron, i inne rzeczy w systemie. Nie rób tego, jeżeli nie wiesz dokładnie co robisz.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Część nawigacyjna</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Zawartość</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Sklep</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Użytkownicy</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Własne</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>O części nawigacyjnej</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>Interfejs administracyjny jest podzielony na części. W ten sposób można pogrupować różne obszary administrowania. Wybierz części, które mają być wyświetlone.</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Nr</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Przydziel</translation>
    </message>
    <message>
        <source>Node notification</source>
        <translation>Węzły powiadamiania</translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation type="obsolete">Powiadamianie</translation>
    </message>
    <message>
        <source>Choose section assignment</source>
        <translation>Wybierz przypisanie sekcji</translation>
    </message>
    <message>
        <source>Please choose where you want to start the section assignment for section %sectionname.

    Select the placements and click the %buttonname button.
    Using the recent and bookmark items for quick placement is also possible.
    Click on placement names to change the browse listing.</source>
        <translation>Proszę wybrać gdzie ustawić punkt startowy przypisania sekcji %sectionname.

Wybierz położenie i kliknij na klawisz %buttonname.
Użycie Ostatnich i Preferowanych pozycji w celu szybszego przypisywania, o ile to możliwe.
Kliknij na na wybraną nazwę w celu zmiany wyświetlanej listy.</translation>
    </message>
    <message>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <source>Assign section - %section</source>
        <translation>Przypisz sekcję - %section</translation>
    </message>
    <message>
        <source>Remove selected sections</source>
        <translation>Usuń wybrane sekcje</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>site registration</source>
        <translation type="obsolete">Rejestracja strony</translation>
    </message>
    <message>
        <source>Site info:</source>
        <translation type="obsolete">Informacje o witrynie:</translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="obsolete">Tytuł</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="obsolete">URL</translation>
    </message>
    <message>
        <source>PHP info:</source>
        <translation type="obsolete">Informacje o PHP:</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="obsolete">Wersja</translation>
    </message>
    <message>
        <source>OS info:</source>
        <translation type="obsolete">Informacje o systemie operacyjnym:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Database info:</source>
        <translation type="obsolete">Informacje o bazie danych:</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="obsolete">Typ</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation type="obsolete">Sterownik</translation>
    </message>
    <message>
        <source>Unicode</source>
        <translation type="obsolete">Unicode</translation>
    </message>
    <message>
        <source>Supported</source>
        <translation type="obsolete">Obsługiwany</translation>
    </message>
    <message>
        <source>Unsupported</source>
        <translation type="obsolete">Nieobsługiwany</translation>
    </message>
    <message>
        <source>Demo data:</source>
        <translation type="obsolete">Dane Demo:</translation>
    </message>
    <message>
        <source>Demo data was installed.</source>
        <translation type="obsolete">Dane Demo zostały zainstalowane.</translation>
    </message>
    <message>
        <source>Demo data was not installed.</source>
        <translation type="obsolete">Dane Demo nie zostały zainstalowane.</translation>
    </message>
    <message>
        <source>Email info:</source>
        <translation type="obsolete">Email info:</translation>
    </message>
    <message>
        <source>Transport</source>
        <translation type="obsolete">Transport</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation type="obsolete">wyślij pocztę</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation type="obsolete">SMTP</translation>
    </message>
    <message>
        <source>Image conversion:</source>
        <translation type="obsolete">Konwersja obrazu:</translation>
    </message>
    <message>
        <source>ImageMagick was found and used.</source>
        <translation type="obsolete">ImageMagick został znaleziony i użyty.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Ścieżka</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation type="obsolete">Wykonywalny</translation>
    </message>
    <message>
        <source>ImageGD extension was found and used.</source>
        <translation type="obsolete">Znaleziono i użyto rozszerzenie ImageGD.</translation>
    </message>
    <message>
        <source>Regional info:</source>
        <translation type="obsolete">Informacje lokalne:</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation type="obsolete">Monojęzyczny</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation type="obsolete">Wielojęzyczny</translation>
    </message>
    <message>
        <source>Primary</source>
        <translation type="obsolete">Podstawowy</translation>
    </message>
    <message>
        <source>Additional</source>
        <translation type="obsolete">Dodatkowy</translation>
    </message>
    <message>
        <source>Critical tests:</source>
        <translation type="obsolete">Testy krytyczne:</translation>
    </message>
    <message>
        <source>Success</source>
        <translation type="obsolete">Sukces</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation type="obsolete">Niepowodzenie</translation>
    </message>
    <message>
        <source>Other tests:</source>
        <translation type="obsolete">Inne testy:</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation type="obsolete">Komentarze:</translation>
    </message>
    <message>
        <source>setup</source>
        <translation type="obsolete">setup</translation>
    </message>
    <message>
        <source>Cache admin</source>
        <translation>Administracja plikami tymczasowymi</translation>
    </message>
    <message>
        <source>Content view cache was cleared.</source>
        <translation>Pliki tymczasowe widoków zostały usunięte.</translation>
    </message>
    <message>
        <source>Ini file cache was cleared.</source>
        <translation>Pliki tymczasowe ini zostały usunięte.</translation>
    </message>
    <message>
        <source>Template cache was cleared.</source>
        <translation>Pliki tymczasowe cache zostały usunięte.</translation>
    </message>
    <message>
        <source>View cache is enabled.</source>
        <translation>Pliki tymczasowe cache są włączone.</translation>
    </message>
    <message>
        <source>View cache is disabled.</source>
        <translation>Pliki tymczasowe widoku są wyłączone.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Wyczyść</translation>
    </message>
    <message>
        <source>Ini cache</source>
        <translation>Pliki tymczasowe ini</translation>
    </message>
    <message>
        <source>Ini cache is always enabled.</source>
        <translation>Pliki tymczasowe ini są zawsze włączone.</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Pliki tymczasowe szablonów</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>O systemie</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation type="obsolete">Rozszerzenia</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>Safe mode włączony.</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>Safe mode wyłączony.</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>Zabezpieczenie bazowego katalogu jest włączone i ustawione na %1.</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>Zabezpieczenie bazowego katalogu jest wyłączone.</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>Rejestracja zmiennych globalnych jest włączona.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>Rejestracja zmiennych globalnych jest wyłączona.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>Ładowanie plików jest włączone.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>Ładowanie plików jest wyłaczone.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>Maksymalna wielkość wysyłanych danych (tekstu i plików) to %1.</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>Ograniczenie pamięci skryptu jest ustawione na %1.</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>Maksymalny czas wykonywania %1 sekund.</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Baza Danych</translation>
    </message>
    <message>
        <source>Charset</source>
        <translation type="obsolete">Kodowanie czcionki</translation>
    </message>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Narzędzia Rapid Application Development</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
        <translation>Narzędzia Rapid Application Development (RAD) pozwalają z łatwością rozpocząć tworzenie nowej funkcjonalności dla eZ publish.</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Narzędzia</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Kreator operatorów szablonów</translation>
    </message>
    <message>
        <source>Create new template override for</source>
        <translation>Utwórz nowy override szablonu dla</translation>
    </message>
    <message>
        <source>Template will be placed in</source>
        <translation>Szablon będzie umieszczony w</translation>
    </message>
    <message>
        <source>Template name</source>
        <translation>Nazwa szablonu</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Klucze nadpisywania</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcja</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Węzeł</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Bazowy szablon włączony</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Pusty plik</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Kopia domyślengo szablonu</translation>
    </message>
    <message>
        <source>Container ( with children )</source>
        <translation>Kontener ( widok z dziećmi )</translation>
    </message>
    <message>
        <source>View ( without children )</source>
        <translation>Widok ( bez dzieci )</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Spis szablonów</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Najczęściej używane szablony</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Szablon</translation>
    </message>
    <message>
        <source>Design Resource</source>
        <translation>Źródło układu stron</translation>
    </message>
    <message>
        <source>Complete template list</source>
        <translation>Kompletny spis szablonów</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="obsolete">Start</translation>
    </message>
    <message>
        <source>Basic information</source>
        <translation>Podstawowe informacje</translation>
    </message>
    <message>
        <source>Name of operator</source>
        <translation type="obsolete">Nazwa operatora</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Ustawienia</translation>
    </message>
    <message>
        <source>One operator in class</source>
        <translation type="obsolete">Jeden operator w klasie</translation>
    </message>
    <message>
        <source>Handles operator input</source>
        <translation type="obsolete">Przchwytuje wejście operatora</translation>
    </message>
    <message>
        <source>Generates operator output</source>
        <translation type="obsolete">Generuje wyjścia operatora</translation>
    </message>
    <message>
        <source>Parameter handling</source>
        <translation type="obsolete">Przekazywanie parametrów</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Następny</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation type="obsolete">Uruchom ponownie</translation>
    </message>
    <message>
        <source>Optional information</source>
        <translation>Informacje nieobowiązkowe</translation>
    </message>
    <message>
        <source>Name of class</source>
        <translation type="obsolete">Nazwa klasy</translation>
    </message>
    <message>
        <source>The creator of the operator</source>
        <translation type="obsolete">Twórca operatora</translation>
    </message>
    <message>
        <source>Description of your operator</source>
        <translation type="obsolete">Opis twojego operatora</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <translation type="obsolete">Pierwsza linia będzie wykorzystana jako krótki opis a pozostałe jako dokumentacja operatorów.</translation>
    </message>
    <message>
        <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
        <translation type="obsolete">Handles szablon operatora %operatorname
Używając %operatorname możesz...</translation>
    </message>
    <message>
        <source>Example code</source>
        <translation type="obsolete">Przykładowy kod</translation>
    </message>
    <message>
        <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
        <translation type="obsolete">Jeżeli życzysz sobie możesz dodać przykładowy skrypt wyjaśniający jak twój operator powinien działać.
Domyślny skrypt został wygenerowany korzystając z podstawowych parametrów które wybrałeś. </translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <translation type="obsolete">Gdy przycisk &lt;i&gt;pobierz&lt;/i&gt; zostanie wciśnięty, kod zostanie wygenerowany i zostaniesz poproszony o zapisanie wygenerowanego pliku.</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="obsolete">Pobierz</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Widok szablonu</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Domyślne żródło szablonów</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Zaznacz</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Override</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Warunki dopasowania</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Utwórz nowy</translation>
    </message>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Nie można utworzyć szablonu. Dostęp zabroniony.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Niepoprawna nazwa. Możesz używać wyłącznie znaków a-z, liczb i _.</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <translation type="obsolete">SVN revision</translation>
    </message>
    <message>
        <source>Content view cache</source>
        <translation>Pliki tymczasowe zawartości</translation>
    </message>
    <message>
        <source>re&lt;br/&gt;
    done a new operator is created for you and will be available for download.&lt;br/&gt;</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>OperatorStep</source>
        <translation type="obsolete">OperatorStep</translation>
    </message>
    <message>
        <source>No parameters</source>
        <translation type="obsolete">Brak parametrów</translation>
    </message>
    <message>
        <source>Named parameters</source>
        <translation type="obsolete">Parametry nazwane</translation>
    </message>
    <message>
        <source>Sequential parameters</source>
        <translation type="obsolete">Parametry sekwencyjne</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="obsolete">Własny</translation>
    </message>
    <message>
        <source>Welcome to the wizard for creating a new template operator.&lt;br/&gt;
    Template operators are used for working on template elements such as&lt;br/&gt;
    variables and strings and can also be used to create new data.&lt;br/&gt;
    This wizard will take you trough a couple of steps where you have to&lt;br/&gt;
    make some choices and input some data for the wizard, when you&apos;re&lt;br/&gt;
    done a new operator is created for you and will be available for download.&lt;br/&gt;</source>
        <translation type="obsolete">Witamy w kreatorze operatorów szablonów&lt;br/&gt;
Operatory szablonów są używane podczas paracy nad elementami szablonów&lt;br/&gt;
takimi jak zmienne i łańcuchy i mogą być użyte do tworzenia nowych danych.&lt;br/&gt;
Kreator poprowadzi poprzez szereg kolejnych kroków w których będzie można dokonać&lt;br/&gt;
odpowiedniego wyboru warunków i danych wejściowych, kiedy zakończysz&lt;br/&gt;
nowy operator zostanie utworzony i stanie się dostępny do pobrania.&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Datatype wizard</source>
        <translation>Kreator typów danych</translation>
    </message>
    <message>
        <source>Name of datatype</source>
        <translation type="obsolete">Nazwa typu danych</translation>
    </message>
    <message>
        <source>Descriptive name of datatype</source>
        <translation type="obsolete">Opisowa nazwa typu danych</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <translation type="obsolete">Wejście danych powiąż z klasą</translation>
    </message>
    <message>
        <source>Constant name</source>
        <translation type="obsolete">Nazwa stałej</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <translation type="obsolete">Kreator typu danych</translation>
    </message>
    <message>
        <source>Description of your datatype</source>
        <translation type="obsolete">Opis typu danych</translation>
    </message>
    <message>
        <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Extension setup</source>
        <translation>Konfiguracja rozszerzeń</translation>
    </message>
    <message>
        <source>Here you can activate/deactivate you extensions. Only system wide extensions can be activated, for site access spesific extensions, modify these configuration files.</source>
        <translation>Tutaj możesz aktywować/dezaktywować rozszerzenia. Tylko rozszerzenia dla całego systemu mogą być tu aktywowane. Rozszerzenia specyficzne dla siteaccess modyfikuj poprzez pliki konfiguracyjne.</translation>
    </message>
    <message>
        <source>Available extensions</source>
        <translation>Dostępne rozszerzenia</translation>
    </message>
    <message>
        <source>PHP Accelerator is enabled.</source>
        <translation type="obsolete">PHP Akcelerator włączony.</translation>
    </message>
    <message>
        <source>PHP Accelerator is disabled.</source>
        <translation type="obsolete">PHP Akcelerator wyłączony.</translation>
    </message>
    <message>
        <source>There is no known PHP accelerator active.</source>
        <translation>Brak aktywnego akceleratora PHP.</translation>
    </message>
    <message>
        <source>Fill out the details for each site.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>&amp;percent% completed</source>
        <translation>&amp;percent% wykonane</translation>
    </message>
    <message>
        <source>System check</source>
        <translation type="obsolete">Kontrola systemu</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">Ok</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation type="obsolete">Języki</translation>
    </message>
    <message>
        <source>Mail server</source>
        <translation type="obsolete">Mail serwer</translation>
    </message>
    <message>
        <source>Sitedesign</source>
        <translation type="obsolete">Design strony</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Podsumowanie</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Utwórz</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Strona:</translation>
    </message>
    <message>
        <source>System:</source>
        <translation>System:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Image system:</source>
        <translation>System obrazów:</translation>
    </message>
    <message>
        <source>Mail:</source>
        <translation>Poczta:</translation>
    </message>
    <message>
        <source>Database:</source>
        <translation>Baza danych:</translation>
    </message>
    <message>
        <source>Language(s):</source>
        <translation type="obsolete">Język(i):</translation>
    </message>
    <message>
        <source>Site(s):</source>
        <translation type="obsolete">Strona(y):</translation>
    </message>
    <message>
        <source>All caches were cleared.</source>
        <translation>Wszystkie pliki tymczasowe usunięto.</translation>
    </message>
    <message>
        <source>was cleared</source>
        <translation>zostały usunięte</translation>
    </message>
    <message>
        <source>Cache collections</source>
        <translation>Lista tymczasowych</translation>
    </message>
    <message>
        <source>Click a button to clear a collection of caches.</source>
        <translation>Kliknij na klawisz by wykasować listę plików tymczasowych.</translation>
    </message>
    <message>
        <source>All caches.</source>
        <translation>Wszystkie cache.</translation>
    </message>
    <message>
        <source>All caches</source>
        <translation>Wszystkie cache</translation>
    </message>
    <message>
        <source>All caches are disabled</source>
        <translation>Wszystki cache są wyłączone</translation>
    </message>
    <message>
        <source>Content views and template blocks.</source>
        <translation>Widoki zawartości i bloki szablonów.</translation>
    </message>
    <message>
        <source>Content caches</source>
        <translation>Cache zawartości</translation>
    </message>
    <message>
        <source>Content caches is disabled</source>
        <translation>Cache zawartości wyłączone</translation>
    </message>
    <message>
        <source>Template overrides and template compiling.</source>
        <translation>Szablony override i skompilowane.</translation>
    </message>
    <message>
        <source>Template caches</source>
        <translation>Cache szablonów</translation>
    </message>
    <message>
        <source>Template caches are disabled</source>
        <translation>Cache szablonów wyłączone</translation>
    </message>
    <message>
        <source>INI caches.</source>
        <translation>Cache INI.</translation>
    </message>
    <message>
        <source>INI caches</source>
        <translation>Cache INI</translation>
    </message>
    <message>
        <source>INI cache is disabled</source>
        <translation>Cache INI wyłączone</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Wybór</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Wyłączone</translation>
    </message>
    <message>
        <source>Clear selected</source>
        <translation>Kasuj wybrane</translation>
    </message>
    <message>
        <source>Could not detect version</source>
        <translation>Nie można wykryć wersji</translation>
    </message>
    <message>
        <source>The PHP Accelerator is enabled.</source>
        <translation>Akcelerator PHP jest włączony.</translation>
    </message>
    <message>
        <source>The PHP Accelerator is disabled.</source>
        <translation>Akcelerator PHP jest wyłączony.</translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Socket path</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Internal</source>
        <translation>Wewnętrzne</translation>
    </message>
    <message>
        <source>Current read-only database (Slave)</source>
        <translation>Bieżąca baza read-only (Slave)</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Język:</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorytet</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualizuj</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Datatype start</comment>
        <translation>Start</translation>
    </message>
    <message>
        <source>Name of datatype</source>
        <comment>Datatype</comment>
        <translation>Nazwa typu danych</translation>
    </message>
    <message>
        <source>Descriptive name of datatype</source>
        <comment>Datatype</comment>
        <translation>Opisowa nazwa typu danych</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Datatype</comment>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Handle input on class level</source>
        <comment>Datatype</comment>
        <translation>Wejście danych powiąż z klasą</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Datatype next</comment>
        <translation>Następny</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Datatype restart</comment>
        <translation>Uruchom ponownie</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Datatype</comment>
        <translation>Nazwa klasy</translation>
    </message>
    <message>
        <source>Constant name</source>
        <comment>Datatype</comment>
        <translation>Nazwa stałej</translation>
    </message>
    <message>
        <source>The creator of the datatype</source>
        <comment>Datatype</comment>
        <translation>Kreator typu danych</translation>
    </message>
    <message>
        <source>Description of your datatype</source>
        <comment>Datatype</comment>
        <translation>Opis typu danych</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Datatype</comment>
        <translation>Pierwsza linia będzie wykorzystana jako krótki opis a pozostałe jako dokumentacja operatorów.</translation>
    </message>
    <message>
        <source>Handles the datatype %datatypename
By using %datatypename you can ...</source>
        <comment>Datatype default description</comment>
        <translation>Powiązany typ danych %datatypename
Używając %datatypename możesz...</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Datatype</comment>
        <translation>Gdy przycisk &lt;i&gt;pobierz&lt;/i&gt; zostanie wciśnięty, kod zostanie wygenerowany i zostaniesz poproszony o zapisanie wygenerowanego pliku.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Datatype download</comment>
        <translation>Pobierz</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>eZ publish version</comment>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <comment>eZ publish version</comment>
        <translation>SVN revision</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>eZ publish extensions</comment>
        <translation>Rozszerzenia</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP version</comment>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Extensions</source>
        <comment>PHP extensions</comment>
        <translation>Rozszerzenia</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>PHP Accelerator name</comment>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Version</source>
        <comment>PHP Accelerator version</comment>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>Database type</comment>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Server</source>
        <comment>Database server</comment>
        <translation>Serwer</translation>
    </message>
    <message>
        <source>Socket path</source>
        <comment>Database socket path</comment>
        <translation>Scieżka do gniazda (socket)</translation>
    </message>
    <message>
        <source>Database</source>
        <comment>Database name</comment>
        <translation>Baza Danych</translation>
    </message>
    <message>
        <source>Connection retry count</source>
        <comment>Database retry count</comment>
        <translation>Liczba powtórzeń połączenia</translation>
    </message>
    <message>
        <source>Charset</source>
        <comment>Database charset</comment>
        <translation>Kodowanie czcionki</translation>
    </message>
    <message>
        <source>Tools</source>
        <comment>RAD Tools</comment>
        <translation>Narzędzia</translation>
    </message>
    <message>
        <source>Start</source>
        <comment>Template operator start</comment>
        <translation>Start</translation>
    </message>
    <message>
        <source>Name of operator</source>
        <comment>Template operator</comment>
        <translation>Nazwa operatora</translation>
    </message>
    <message>
        <source>Settings</source>
        <comment>Template operator</comment>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>One operator in class</source>
        <comment>Template operator</comment>
        <translation>Jeden operator w klasie</translation>
    </message>
    <message>
        <source>Handles operator input</source>
        <comment>Template operator</comment>
        <translation>Przchwytuje wejście operatora</translation>
    </message>
    <message>
        <source>Generates operator output</source>
        <comment>Template operator</comment>
        <translation>Generuje wyjście operatora</translation>
    </message>
    <message>
        <source>Parameter handling</source>
        <comment>Template operator</comment>
        <translation>Przekazywanie parametrów</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>Template operator next</comment>
        <translation>Następny</translation>
    </message>
    <message>
        <source>Restart</source>
        <comment>Template operator restart</comment>
        <translation>Uruchom ponownie</translation>
    </message>
    <message>
        <source>Name of class</source>
        <comment>Template operator</comment>
        <translation>Nazwa klasy</translation>
    </message>
    <message>
        <source>The creator of the operator</source>
        <comment>Template operator</comment>
        <translation>Twórca operatora</translation>
    </message>
    <message>
        <source>Description of your operator</source>
        <comment>Template operator</comment>
        <translation>Opis twojego operatora</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <comment>Template operator</comment>
        <translation>Pierwsza linia będzie wykorzystana jako krótki opis a pozostałe jako dokumentacja operatora.</translation>
    </message>
    <message>
        <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
        <comment>Template operator default description</comment>
        <translation>Powiązany szablon operatora %operatorname
Używając %operatorname możesz...</translation>
    </message>
    <message>
        <source>Example code</source>
        <comment>Template operator</comment>
        <translation>Przykładowy kod</translation>
    </message>
    <message>
        <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
        <comment>Template operator</comment>
        <translation>Jeżeli życzysz sobie możesz dodać przykładowy skrypt wyjaśniający jak twój operator powinien działać.
Domyślny skrypt został wygenerowany korzystając z podstawowych parametrów które wybrałeś. </translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <comment>Template operator</comment>
        <translation>Gdy klikniesz na pobierz, kod zostanie wygenerowany i zostaniesz poproszony o zapisanie wygenerowanego pliku.</translation>
    </message>
    <message>
        <source>Download</source>
        <comment>Template operator download</comment>
        <translation>Pobierz</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Każda</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/datatypecode</name>
    <message>
        <source>Constructor</source>
        <translation>Konstruktor</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Jeśli masz problem z połączeniem się z Twoją bazą danych powinieneś zajrzeć na</translation>
    </message>
    <message>
        <source>at</source>
        <translation>na</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Wprowadzenie</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL jest to system zarządzania bazami danych stworzony przez MySQL AB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>Jest obecnie jednym z najpopularniejszych systemów bazodanowych w środowisku Otwartego Oprogramowania oraz najczęstszy sytem bazy danych na platformie PHP.</translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation>Z ich strony domowej:</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL jest najpopularniejszą, zaprojektowaną do szybkiego, dokładnego i intensywnego wykorzystania, bazą danych w środowisku Open Source.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Więcej informacji można znaleźć na</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Szczegóły</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL doskonale sprawdza się w pracy z większością języków zachodnich, jednak nie jest najlepszym narzędziem w przypadku obsługi Unicode lub nie-zachodnich języków.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Instalacja</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>Używając</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>opcji konfiguracyjnych, umożliwiasz skryptom PHP dostęp do bazy danych MySQL. Jeśli użyjesz tej opcji bez podania ścieżki do MySQL, PHP będzie korzystał z domyślnych, wbudowanych bibliotek klienta MySQL.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Więcej informacji na temat rozszerzeMySQL można znaleźć na</translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreeSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL jest systemem bazodanowym opracowanym na Uniwersytecie Kalifornijskim przez Wydział Informatyczny Berkeley.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>Jest to bardzo popularna baza danych w środowisku Open Source, która dostarcza wysoce zaawansowaną funkcjonalność dla społeczeństwa.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>PostgreSQL jest wyrafinowanym DBMS, wspomagającym prawie wszystkie wyrażenia SQL, włączając obsługę żądań i zdefiniowane przez użytkownika funkcje. Jest to najbardziej zaawansowana baza danych Środowiska Open Source.</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL jest dobrym wyborem, jeśli chodzi o obsługę wielu języków, włączając Unicode, ale może wymagać paru czynności konfiguracyjnych aby działać z odpowiednią szybkością.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>Aby umożliwić obsługę PostgreSQL,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>jest wymagane podczas kompilacji PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Więcej informacji na temat rozszerzeń PostgreSQLmożna znależć na </translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>The database is ready for initialization, click the</source>
        <translation type="obsolete">Baza danych jest gotowa do uruchomienia, kliknij</translation>
    </message>
    <message>
        <source>Create Database</source>
        <translation type="obsolete">Utwórz Bazę Danych</translation>
    </message>
    <message>
        <source>button when ready.</source>
        <translation type="obsolete">przycisk, kiedy będziesz gotów.</translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation>Jeśli chcesz setup może dodać dane demonstracyjne do Twojej bazy danych, to będzie stanowiło dobry przykład do zaprezentowania możliwości eZ publish </translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation>Zaleca się początkowym użytkownikom zainstalowanie danych przykładowych.</translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation>Czy zainstalować dane przykładowe?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>Nie można zainstalować danych przykładowych, w instalacji PHP brakuje rozszerzenia zlib.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation>w tym miejscu nie ma wsparcia dla instalacji danych przykładowych.</translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Błąd danych przykładowych</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>Nie można rozpakować danych przykładowych.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>Powinieneś spróbować instalacji bez danych przykładowych.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Uruchomienie nie powiodło się</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>Baza danych nie może zostać poprawnie uruchomiona.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Ostrzeżenie</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>Twoja baza danych zawiera już dane.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>Program instalacyjny może kontynuować uruchomienie co wiąże się z uszkodzeniem obecnych danych.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>Co ma zrobić program instalacyjny?</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Kontynuuj i zostaw obecne dane niezmienione.</translation>
    </message>
    <message>
        <source>Continue and remove the data.</source>
        <translation type="obsolete">Kontynuuj i usune dane.</translation>
    </message>
    <message>
        <source>Continue and skip database initialization.</source>
        <translation type="obsolete">Kontynuuj i pomiń uruchomienie bazy danych.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Pozwól mi wybrać nową bazę danych.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Notatka:</translation>
    </message>
    <message>
        <source>It can take some time creating the database so please be patient and wait until the new page is finished.</source>
        <translation type="obsolete">Tworzenie nowej bazy danych może zająć trochę czasu, proszę o czekać na zakończenie procesu.</translation>
    </message>
    <message>
        <source>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</source>
        <translation type="obsolete">Pora na wybór Twojej bazy danych, która zdeterminuje wsparcie językowe. Jak skończysz kliknij</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Opcje Językowe</translation>
    </message>
    <message>
        <source>to continue the setup.</source>
        <translation type="obsolete">aby kontynuować instalację.</translation>
    </message>
    <message>
        <source>Your system has support for one database only, it is</source>
        <translation type="obsolete">Twój system pozwala na obsługę tylko jednej bazy danych, to jest</translation>
    </message>
    <message>
        <source>, click</source>
        <translation type="obsolete">. klik</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Typ:</translation>
    </message>
    <message>
        <source>Driver:</source>
        <translation type="obsolete">Sterownik:</translation>
    </message>
    <message>
        <source>Unicode support:</source>
        <translation type="obsolete">Wsparcie dla Unicode:</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nie</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>tak</translation>
    </message>
    <message>
        <source>The database was succesfully initialized, you are now ready for some post configuration of the site. Click the</source>
        <translation type="obsolete">Baza danych została pomyślnie uruchomiona, jesteś gotowy do końcowych ustawień witryny. Kliknij</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Konfiguruj</translation>
    </message>
    <message>
        <source>button to start the configuration process.</source>
        <translation type="obsolete">przycisk, aby rozpocząć proces konfiguracji.</translation>
    </message>
    <message>
        <source>No database connection</source>
        <translation type="obsolete">Brak połączenia z bazą danych</translation>
    </message>
    <message>
        <source>Could not connect to database.</source>
        <translation type="obsolete">Nie mogę podłączyę do bazy danych.</translation>
    </message>
    <message>
        <source>The database would not accept the connection , please review your settings and try again.</source>
        <translation type="obsolete">Baza danych nie akceptuje połączenia . sprawdź swoje ustawienia i spróbuj ponownie.</translation>
    </message>
    <message>
        <source>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</source>
        <translation type="obsolete">Wszystko gotowe do uruchomienia bazy danych. Zostanie utworzona podstawowa struktura. Aby rozpocząć proces uruchamiania bazy danych wpisz w pola poniżej odpowiednie dane i hasło dostępu do danych oraz kliknij</translation>
    </message>
    <message>
        <source>Connect To Database</source>
        <translation type="obsolete">Połącz z Bazą Danych</translation>
    </message>
    <message>
        <source>button.</source>
        <translation>przycisk.</translation>
    </message>
    <message>
        <source>If you have an already existing eZ publish database enter the information and the setup will use that as database.</source>
        <translation type="obsolete">Jeżeli posiadasz istniejącą bazę eZpublish podaj te informacje a program instalacyjny urzyje tych danych do utworzenia bazy danych. </translation>
    </message>
    <message>
        <source>Empty password</source>
        <translation type="obsolete">Puste hasło</translation>
    </message>
    <message>
        <source>You must supply a password for the database.</source>
        <translation type="obsolete">Musisz podać hasło dostępu do bazy danych.</translation>
    </message>
    <message>
        <source>Password does not match</source>
        <translation type="obsolete">Hasła nie zgadzają się</translation>
    </message>
    <message>
        <source>The password and confirmation password must match.</source>
        <translation type="obsolete">Hasło i jego potwierdzenie muszą być identyczne.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="obsolete">Nieznany błąd</translation>
    </message>
    <message>
        <source>Servername:</source>
        <translation>Nazwa serwera:</translation>
    </message>
    <message>
        <source>Databasename:</source>
        <translation type="obsolete">Nazwa Bazy Danych:</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nazwa użytkownika:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Hasło:</translation>
    </message>
    <message>
        <source>Confirm password:</source>
        <translation type="obsolete">Potwierdź hasło:</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation>Twój system nie wymaga szczegółowej konfiguracji, kliknij aby kontynuować</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Dalej</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>System odkrył braki, których uzupełnienie może znacząco wpłynąć na poprawę i wydajność pracy. Poniżej znajdują się szczegółowe informacje dotyczące tego co można zrobić w celu ulepszenia instalacji.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>Po naprawieniu usterki kliknij</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Uruchom ponownie sprawdzenie systemu</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>przycisk aby powtórnie sprawdzić system. Jest to opcja rekomendowana w przypadku zmian systemowych w celu uniknięcia błędów krytycznych. Możesz także kliknąć</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Sprawdź jeszcze raz</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>przycisk, aby powrócić do sprawdzenia dokładnej konfiguracji. Możesz pominąć ten etap i kontynuować klikając</translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Problemy</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Błąd zapisu</translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>Program instalacyjny nie może zapisać zmian do pliku.</translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>Program instalacyjny nie może uzyskać praw zapisu do</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation>katalogu. Jest to wymagane do zaniechania inicjalizacji. Postępuj zgodnie z instrukcjami podanymi w</translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation>aby uzyskać prawo zapisu kliknij </translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Spróbuj jeszcze raz</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation>Opcjonalnie, możesz wyłączyć to ręcznie, przez edycję &lt;i&gt;settings/site.ini&lt;/i&gt; pliku, idź do linii, która zawiera wyrażenie:</translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Zmień drugą linię od</translation>
    </message>
    <message>
        <source>to</source>
        <translation>do</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation>Program instalacyjny jest teraz unieruchomiony, kliknij</translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation>aby powrócić do witryny.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</source>
        <translation type="obsolete">Email jest używany do przesyłania ważnych powiadomień takich jak informacje rejestracyjne, czy też zgody na publikację oraz do wysłania rejestracji witryny.</translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>Możesz wybierać z</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>wyślij e-mail</translation>
    </message>
    <message>
        <source>which must available on the server or</source>
        <translation type="obsolete">które musi być osiągalne na serwerze</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</source>
        <translation type="obsolete">co prześle emaila. Jeżeli nie jesteś pewien co wpisać, zapytaj swojego administratora, niektóre sieci nie udostępniają</translation>
    </message>
    <message>
        <source>Configuration of sendmail is done on the server, consult your webhost.</source>
        <translation type="obsolete">Zakończono konfigurację wysyłanie e-maili na serwerze, skonsultuj te ustawienia ze swoim dostawcą usług sieciowych.</translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</source>
        <translation type="obsolete">Transport e-maila za pomocą protokołu SMTP wymaga podania nazwy serwera. Jeżeli serwer wymaga autoryzacji, musisz podać login i hasło.</translation>
    </message>
    <message>
        <source>Server name</source>
        <translation type="obsolete">Nazwa serwera</translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="obsolete">Nazwa użytkownika</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <source>Site Details</source>
        <translation type="obsolete">Szczegóły Strony</translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation>Nie powiodło się wysłanie e-maila</translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation>Nie powiodło się wysłanie rejestracji strony emailem za pomocą</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation>Gratulacje. eZ publish jest uruchomiony na Twoim systemie.</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to the</source>
        <translation type="obsolete">Jeśli potrzebujesz pomocy od eZpublish, możesz udać się </translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>Strona internetowa eZ publish</translation>
    </message>
    <message>
        <source>If you find a bug (error), please go to</source>
        <translation type="obsolete">Jeśli znajdziesz błąd (bug), udaj się</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>Raport błędów eZ publish</translation>
    </message>
    <message>
        <source>and report it.</source>
        <translation type="obsolete">i zgłoś ten błąd.</translation>
    </message>
    <message>
        <source>With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation type="obsolete">Z Twoją pomocą możemy naprawić błędy, które eZ publish może posiadać oraz implementacje nowych funkcji.</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file</source>
        <translation type="obsolete">Jeśli kiedykolwiek będziesz chciał uruchomić ponownie ten program instalacyjny, to będziesz musiał wyedytować plik</translation>
    </message>
    <message>
        <source>and look for a line that says:</source>
        <translation type="obsolete">i poszukać linii z wyrażeniem:</translation>
    </message>
    <message>
        <source>Click on the URL to access your new</source>
        <translation type="obsolete">Kliknij na URL w celu przejścia do Twojej nowej</translation>
    </message>
    <message>
        <source>or click the</source>
        <translation type="obsolete">lub kliknij </translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Zrobione</translation>
    </message>
    <message>
        <source>button. Enjoy one of the most successful web content management systems!</source>
        <translation type="obsolete">przycisk. Życzymy zadowolenia z użytkowania eZ publish!</translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation>Pora wybrać język, jaki ma obsługiwać ta witryna.</translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation>Wybierz swój język i kliknij</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Podsumowanie</translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation>przycisk, lub</translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation>Szczegóły Języka</translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation>przycisk aby wybrać odmianę języka.</translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation>Już czas wybrać język witryny. Wybierz swój podstawowy język i sprawdź dodatkowe języki.</translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation>Jak to zrobisz kliknij</translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation>Języki, które wybrałeś pomogą ustawić domyślny charakter znaków używany w witrynie.</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Nazwa języka</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Wybór</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation>Istnieje możliwość wyboru kilku odmian dla języka. Różnice polegają na drobnych zmianach i ustawieniach językowych, takich jak dodanie waluty Euro lub format daty i czasu. Użycie odmian jest opcjonalne i można bezpiecznie pominąć ten etap. Kliknij</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation>Istnieje możliwość wyboru kilku odmian dla języka. Różnice polegają na drobnych zmianach i ustawieniach językowych, takich jak dodanie waluty Euro lub format daty i czasu. Użycie odmian jest opcjonalne i można bezpiecznie pominąć ten etap. Kliknij</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Domyślnie</translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</source>
        <translation type="obsolete">Jeśli chcesz możesz zarejestrować swoją instalację poprzez wysłanie pewnych informacji do eZ systems. Żadne poufne dane nie będą przesyłane a eZ Systems nie wykorzysta Twoich danych osobowych do wysyłania niechcianych e-maili. Dane zebrane mają służyć ulepszeniu przyszłych wersji eZ publish.</translation>
    </message>
    <message>
        <source>The following data will be sent to eZ systems:</source>
        <translation type="obsolete">Następujące dane zostaną wysłane do eZ systems:</translation>
    </message>
    <message>
        <source>Details of your system, like OS type etc.</source>
        <translation type="obsolete">Szczegóły Twojego systemu, jak rodzaj OS-u itp.</translation>
    </message>
    <message>
        <source>The test results for your system</source>
        <translation type="obsolete">Wyniki testu dla Twojego systemu</translation>
    </message>
    <message>
        <source>The database type you are using</source>
        <translation type="obsolete">Typ bazy danych jaki używasz</translation>
    </message>
    <message>
        <source>The name of your site</source>
        <translation type="obsolete">Nazwa Twojej strony</translation>
    </message>
    <message>
        <source>The url of your site</source>
        <translation type="obsolete">Adres URL Twojej strony</translation>
    </message>
    <message>
        <source>The languages you chose</source>
        <translation type="obsolete">Język jaki wybrałeś</translation>
    </message>
    <message>
        <source>If you wish you can also add some comments which will be included in the registration.</source>
        <translation type="obsolete">Jeśli chcesz możesz dodać jakieś komentarze, które będą załączone do Twojej rejestracji.</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Komentarze</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Wyślij Rejestrację</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Pomiń Rejestrację</translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.</source>
        <translation type="obsolete">Czas na podanie nazwy i adresu Twojej strony, który będzie widoczny w tytule i zostanie użyty do wysyłania e-maili.</translation>
    </message>
    <message>
        <source>Title of your site:</source>
        <translation type="obsolete">Tytuł strony:</translation>
    </message>
    <message>
        <source>URL to your site:</source>
        <translation type="obsolete">URL Twojej strony:</translation>
    </message>
    <message>
        <source>Register Site</source>
        <translation type="obsolete">Zarejestruj stronę</translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation>Jaki rodzaj wsparcia językowego powinna mieć ta witryna. Rodzaj wsparcia determinuje wybór języka i zestawu znaków.</translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Monojęzyczny (jeden język)</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Wielojęzyczny (Kilka języków z tym samym zestawem znaków)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Wielojęzyczny (Unicode, bez ograniczeń)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Opcje Regionalne</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation>Tutaj znajduje się podsumowanie podstawowych ustawień Twojej witryny. Jeśli to Ci odpowiada kliknij</translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Ustawienia Bazy Danych</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation>Jeśli chcesz zmienić swoje ustawienia kliknij</translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation>Rozpocznij jeszcze raz</translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation>przycisk który zrestartuje zbieranie informacji (Istniejące ustawienia są zachowane).</translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation>Ustawienia Bazy Danych</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Baza Danych</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Sterownik</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Wsparcie Unicode</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Ustawienia języka</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Typ Języka</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Monojęzyczny</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Wielojęzykowy</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Języki</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>Twój system działa bez zarzutu, możesz kontynuować klikając</translation>
    </message>
    <message>
        <source>However if you wish to finetune your system you should click the</source>
        <translation type="obsolete">Jeśli chcesz szczegółowo skonfigurować swój system powinieneś kliknąć</translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Dokładna Konfiguracja</translation>
    </message>
    <message>
        <source>The system check found some issues that needs to be resolve before the setup can continue.</source>
        <translation type="obsolete">Po sprawdzeniu systemu okazało się, że jest parę problemów, które trzeba rozwiązać zanim posuniemy się dalej.</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Przejrzyj szczegółowe informacje o problemach znalezionych w Twoim systemie.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>Każdy opis problemu zawiera instrukcję jego naprawy.</translation>
    </message>
    <message>
        <source>button to re-run the system checking.</source>
        <translation type="obsolete">przycisk aby ponownie uruchomić sprawdzenie systemu.</translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish</source>
        <translation type="obsolete">Wiatmy w programie instalacyjnym eZ publish</translation>
    </message>
    <message>
        <source>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</source>
        <translation type="obsolete">Ta część programu za pomocą szczegółowych instrukcji ułatwi poprawną instalację eZ publish na Twoim Systemie</translation>
    </message>
    <message>
        <source>Click the button below to proceed to the next step which will start the system check.</source>
        <translation type="obsolete">Kliknij przycisk poniżej, aby przejść do następnego etapu i rozpocząć sprawdzenie systemu.</translation>
    </message>
    <message>
        <source>However if you wish to setup the site manually press the</source>
        <translation type="obsolete">Jeśli chcesz ustawić stronę ręcznie naciśnij</translation>
    </message>
    <message>
        <source>Disable Setup</source>
        <translation type="obsolete">Pomiń Setup</translation>
    </message>
    <message>
        <source>System Check</source>
        <translation type="obsolete">Sprawdź System</translation>
    </message>
    <message>
        <source>The database is ready for initialization, click the %1 button when ready.</source>
        <translation>Baza danych gotowa do inicjalizacji, kliknij klawisz %1  jeśli wszystko gotowe.</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Kontynuuj</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to loose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Continue but remove the data first.</source>
        <translation>Kontynuuj, ale najpierw wyczyść dane.</translation>
    </message>
    <message>
        <source>Keep data and skip database initialization.</source>
        <translation>Zachowaj dane i opóść krok inicjalizacji bazy danych.</translation>
    </message>
    <message>
        <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
        <translation>Inicjalizacja bazy danych może potrwać przez dłuższy czas. Prosimy więc o cierpliwość aż wczyta się nowa strona.</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>The database was succesfully initialized. You are now ready for some post configuration of the site.</source>
        <translation>Baza danych została pomyślnie zainicjalizowana. Możesz przejść do etapu konigurowania poczty elektronicznej.</translation>
    </message>
    <message>
        <source>Click the %1 button to start the configuration process.</source>
        <translation>Kliknij na %1 aby rozpocząć proces koonfiguracji.</translation>
    </message>
    <message>
        <source>Servername</source>
        <translation type="obsolete">Nazwa serwera</translation>
    </message>
    <message>
        <source>Socket</source>
        <translation type="obsolete">Socket</translation>
    </message>
    <message>
        <source>Databasename</source>
        <translation type="obsolete">Nazwa bazy</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nazwa użytkownika</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation type="obsolete">Potwierdzenie hasła</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>ez.no</source>
        <translation>ez.no</translation>
    </message>
    <message>
        <source>The default username for the administrator is %1 and the default password is %2.</source>
        <translation>Domyślną nazwa użytkownika administratora jest %1 a domyślnym hasłem jest %2.</translation>
    </message>
    <message>
        <source>Sending out the email might take a couple of seconds so please wait until the next page loads. Clicking the button again will only send out duplicate emails.</source>
        <translation type="obsolete">Wysyłanie poczty może potrwać jakiś czas, więc bądź cierpliwy i zaczekaj aż się wczyta nowa strona.</translation>
    </message>
    <message>
        <source>You&apos;re site is running in virtualhost mode and is considered secure. You may safely continue.</source>
        <translation type="obsolete">Twój site jest uruchomiony w trybie wirtualnego hosta i jest uważany za bezpiieczny. Możesz bezpiecznie kontynuować.</translation>
    </message>
    <message>
        <source>Your site is running in non-virtualhost mode which is considered an unsecure mode. It&apos;s recommended to run eZ publish in virtualhost mode.
If you do not have the possiblity to use virtualhost mode you should follow the instructions below on howto install a .htaccess file, the file tells the webserver to only give access to certain files.</source>
        <translation type="obsolete">Twój site nie jest uruchomiony w trybie wirtualnego hosta który nie jest uwazany za bezpieczny. Jest zalecne uruchamiać eZ publish w trybie wirtualnego hosta. Jeżeli nie masz możliwości korzystania z trybu wirtualnego hosta, powinieneś wykonać poniższe instrukcje aby zainstalować plik .htaccess, który powie serwerowi www aby udostępnić tylko wybrane pliki.</translation>
    </message>
    <message>
        <source>Title of your site</source>
        <translation type="obsolete">Nazwa twojej stroony</translation>
    </message>
    <message>
        <source>URL to your site</source>
        <translation type="obsolete">URL twojej strony</translation>
    </message>
    <message>
        <source>Securing Site</source>
        <translation type="obsolete">Zabezpiczenie strony</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the checkboxes.</source>
        <translation type="obsolete">Po tym jak zlikwidujesz problem wciśnij przycisk %1 aby ponownie uruchomić sprawdzanie systemu. Możesz równięż ominąć niektóre testy odznaczając niektóre checkboxy.</translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish %1.</source>
        <translation type="obsolete">Witamy w programie instalacyjnym eZ publish %1.</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation>Program instalacyjny nie zrobi upgradu od starszych wersji eZ publish (takich jak 2.2.7) jeżeli pozostawisz dane w tej postaci, w jakiej one są,To jest istotne tylko dla ludzi co msają taki dane które nie chcą utracić. Jeżeli posiadasz dane z eZpublish 3.0 (tak jak w wydaniu RC), powinieneś opuścić krok inicjalizacji bazy danych. W takiej sytuacji oczywiście będziesz musial zrobić ręczny upgradee.</translation>
    </message>
    <message>
        <source>which must be available on the server or</source>
        <translation>który musi być dostępny na serwerza albo</translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.
       The administrator email is used as sender email from all emails sent from eZ publish, it&apos;s adviced to set this correctly.</source>
        <translation type="obsolete">Nadszedł czas, aby podać nazwe i url twojej strony.Będzie to wykorzystane w nagłówku strony i dla wysyłaniaa e-maili. Admnistrator bedzie nadawcą wsszelkich listów wychodzących od ezPublish. Zalecanie wiec ustawienia poprawnej e-maila.</translation>
    </message>
    <message>
        <source>Administator E-Mail</source>
        <translation type="obsolete">e-mail do administratora</translation>
    </message>
    <message>
        <source>features.&quot;
</source>
        <translation type="obsolete">możliwości.&quot;</translation>
    </message>
    <message>
        <source>systems!&quot;
</source>
        <translation type="obsolete">systemy!&quot;</translation>
    </message>
    <message>
        <source>Database choice</source>
        <translation>Wybór bazy danych</translation>
    </message>
    <message>
        <source>The database would not accept the connection, please review your settings and try again.</source>
        <translation>Baza danych nie akceptuje połączenia, sprawdź ustawienia i spróbuj ponownie.</translation>
    </message>
    <message>
        <source>Password entries did not match.</source>
        <translation>Wprowadzone hasło nie jest poprawne.</translation>
    </message>
    <message>
        <source>The selected database was not empty, please choose from the alternatives below.</source>
        <translation>Wybrana baza danych nie jest pusta, proszę dokonać poniższego wyboru.</translation>
    </message>
    <message>
        <source>The selected selected user has not got access to any databases. Change user or create a database for the user.</source>
        <translation>Wybranyżytkownik nie posiada dostępu do żadnej bazy danych. Zmień użytkownika lub stwórz bazę danych dla niego.</translation>
    </message>
    <message>
        <source>Database initalization</source>
        <translation>Inicjalizacja bazy danych</translation>
    </message>
    <message>
        <source>Email settings</source>
        <translation>Ustawienia Email</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Zakończono</translation>
    </message>
    <message>
        <source>Language options</source>
        <translation>Opcje języka</translation>
    </message>
    <message>
        <source>Registration</source>
        <translation>Rejestracja</translation>
    </message>
    <message>
        <source>Securing site</source>
        <translation>Strona bezpieczeństwa</translation>
    </message>
    <message>
        <source>Site access</source>
        <translation>Dostęp do stron</translation>
    </message>
    <message>
        <source>Site details</source>
        <translation>Szczegóły witryny</translation>
    </message>
    <message>
        <source>No templates choosen.</source>
        <translation>Nie wybrano szablonu.</translation>
    </message>
    <message>
        <source>Site template selection</source>
        <translation>Wybór szablonów stron</translation>
    </message>
    <message>
        <source>System check</source>
        <translation>Kontrola systemu</translation>
    </message>
    <message>
        <source>Welcome to eZ publish</source>
        <translation>Witamy w eZ publish</translation>
    </message>
    <message>
        <source>Choose database system</source>
        <translation>Wybierz system dla bazy danych</translation>
    </message>
    <message>
        <source>We detected both MySQL and PostgreSQL support on your system. Which database system would you like to use?</source>
        <translation type="obsolete">Wybryto oba systemy MySQL i PostgreSQL w tym systemie. Którego systemu baz danych chcesz używać?</translation>
    </message>
    <message>
        <source>eZ publish support both MySQL and PostgreSQL.</source>
        <translation type="obsolete">eZ publish obsługuje MySQL i  PostgreSQL.</translation>
    </message>
    <message>
        <source>PostgreSQL or MySQL &gt;= 4.1 are required for unicode support in eZ publish.</source>
        <translation>PostgreSQL lub MySQL &gt;= 4.1 jest niezbędny dla obsługi Unicodów w eZ publish.</translation>
    </message>
    <message>
        <source>More information about eZ publish and unicode support can be found %1.</source>
        <translation>Więcej informacji o eZ publish i wsparciu dla unicodów znajdziesz na %1.</translation>
    </message>
    <message>
        <source>here</source>
        <translation type="obsolete">tutaj</translation>
    </message>
    <message>
        <source>Database initialization</source>
        <translation>Inicjalizacja bazy danych</translation>
    </message>
    <message>
        <source>Enter database system user information in the boxes below</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Socket (optional)</source>
        <translation type="obsolete">Socket (opcjonalnie)</translation>
    </message>
    <message>
        <source>It is recommended to create the databases for eZ publish now. If you are uncertain on how to do this, see the database system user manual.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>PostgreSQL user name and password is not tested until database names are selected.</source>
        <translation>Nazwa użytkownika i hasło bazy PostgreSQL nie zostaną przetestowane jeśli nie wybrano nazwy bazy.</translation>
    </message>
    <message>
        <source>If you are using MySQL and do not know what to enter in the socket field, leave it blank</source>
        <translation>Jeśli używasz bazy MySQL i nie wiesz jak wypełnić pole gniazda (socket), pozostaw je puste</translation>
    </message>
    <message>
        <source>E-mail settings</source>
        <translation type="obsolete">Ustawienia E-mail</translation>
    </message>
    <message>
        <source>Specify email settings for eZ publish</source>
        <translation type="obsolete">Specyfikacja ustawień email dla eZ publish</translation>
    </message>
    <message>
        <source>SMTP is recommended for MS Windows users</source>
        <translation type="obsolete">SMTP jest rekomendowane dla użytkowników MS Windows</translation>
    </message>
    <message>
        <source>Mail system</source>
        <translation type="obsolete">System Mail</translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a user name and password as well.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Finished!</source>
        <translation type="obsolete">Zakończono!</translation>
    </message>
    <message>
        <source>eZ publish has been installed with the following site(s)</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Tytuł</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>User site</source>
        <translation>Strona użytkownika</translation>
    </message>
    <message>
        <source>Admin site</source>
        <translation>Strona administratora</translation>
    </message>
    <message>
        <source>Admin e-mail</source>
        <translation>E-mail administratora</translation>
    </message>
    <message>
        <source>Tip: Store this page as an html file by clicking Save-As in your web browser, alternatively you may write down the urls for your sites.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Make sure to visit the %1 and the %2 web site.</source>
        <translation>Odwiedź koniecznie witryny web %1 oraz %2.</translation>
    </message>
    <message>
        <source>forum</source>
        <translation type="obsolete">forum</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <translation type="obsolete">eZ publish</translation>
    </message>
    <message>
        <source>Language and country selection</source>
        <translation type="obsolete">Wybór języka i kraju</translation>
    </message>
    <message>
        <source>Use the radio button to choose primary language, and check boxes to choose additional languages. You may choose more than one additional language.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>No Unicode support</source>
        <translation>Brak obsługi Unicodów</translation>
    </message>
    <message>
        <source>The database server you connected to does not support Unicode which means that you cannot choose all the languages as you did.
To fix this problem you must do one of the following:</source>
        <translation>Baza danych do której się podłączono nie obsługuje Unicodów, to zaś oznacza że nie możesz wybrać obsługi wszystkich języków które chcesz. 
Aby pokonać ten problem musisz wybrać jedno z poniższych rozwiązań:</translation>
    </message>
    <message>
        <source>Choose only languages that use similar characters, for instance: English and Norwegian will work together while English and Russian won&apos;t work.</source>
        <translation>Wybierz tylko języki, które używają podobnego zestawu znaków, przykładowo: Angielski i Norweski będą wspólnie funkcjonować podczas gdy Angielski i Rosyjski nie będą.</translation>
    </message>
    <message>
        <source>Make sure the database server is configured to use Unicode or that it has the latest software which supports Unicode.</source>
        <translation>Upewnij się żę twój serwer baz danych jest skonfigurowany do obsługi Unicodów i że software go obsługujący jest z wersji uwzględniającej obsługę Unicodów.</translation>
    </message>
    <message>
        <source>Primary/Additional</source>
        <translation>Podstawowy/Dodatkowy</translation>
    </message>
    <message>
        <source>eZ publish supports multiple languages.</source>
        <translation>eZ publish obsługuje wiele języków.</translation>
    </message>
    <message>
        <source>The selected languages are used to determine character sets, date format, number format, etc.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>These and other additional languages can also be installed later.</source>
        <translation>Te i inne dodatkowe języki mogą zostać zainstalowane później.</translation>
    </message>
    <message>
        <source>For more information about language customization, see the %1.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>documentation</source>
        <translation type="obsolete">dokumentacja</translation>
    </message>
    <message>
        <source>Site registration</source>
        <translation>Rejestracja witryny</translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>The registration email:</source>
        <translation>Email rejestracyjny:</translation>
    </message>
    <message>
        <source>Sending out the email and generating your site might take a couple of seconds so please wait until the next page loads. Clicking the button again will only send out duplicate emails, and may corrupt your installation.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>By sending registration the following data will be sent to eZ systems</source>
        <translation>Wysyłając rejestrację następujące dane zostaną przesłane do eZ systems</translation>
    </message>
    <message>
        <source>This data will help to improve eZ publish for future releases.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Your site is running in non-virtualhost mode which is considered an unsecure mode. It&apos;s recommended to run eZ publish in virtualhost mode.
If you do not have the possibility to use virtualhost mode you should follow the instructions below on howto install a .htaccess file, the file tells the webserver to only give access to certain files.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>If you have shell access to the site you can run the following commmand to install the file.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>If you do not have shell access you will have to copy the file using the ftp client or ask your hosting provider to do this for you.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>This security measure is to ensure that your settings are not accessible for other users.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Site access configuration</source>
        <translation>Konfiguracja dostępów (site acess) do stron</translation>
    </message>
    <message>
        <source>Choose which access method you would like to use for your site(s).The access method determines how people will access your site.
 If unsure choose URL.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>URL (recommended)</source>
        <translation>URL (rekomendowany)</translation>
    </message>
    <message>
        <source>Port. Note: Requires web server configuration </source>
        <translation>Port. Uwaga: Wymaga konfiguracji web serwera</translation>
    </message>
    <message>
        <source>Hostname. Note: Requires DNS setup.</source>
        <translation>Nazwa hosta. Uwaga: Wymaga ustawień DNS.</translation>
    </message>
    <message>
        <source>The path determines access.</source>
        <translation>Ścieżka determinuje dostęp (access).</translation>
    </message>
    <message>
        <source>e.g. %adminsite and %usersite</source>
        <translation>np. %adminsite i %usersite</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>The port number determines access.*</source>
        <translation>Numer portu determinuje dostęp (access).*</translation>
    </message>
    <message>
        <source>* This requires that your web server is setup to handle the port numbers.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Hostname</source>
        <translation>Nazwa hosta</translation>
    </message>
    <message>
        <source>The hostname determines access.*</source>
        <translation>Nazwa hosta determinuje dostęp (access).*</translation>
    </message>
    <message>
        <source>* This requires that you have a DNS setup for your hostname.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>For more detailed information on site access see the %1</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>online documentation</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>You need to specify some information about every site you&apos;ve chosen to install.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Do not use &apos;admin&apos;, &apos;user&apos; or equal site access values. Please change site illegal access values on sites indicated by *</source>
        <translation>Nie używaj nazw &apos;admin&apos;, &apos;user&apos; lub podobnych dla nazwania dostępów (site access). Porszę zmienić niewłaściwe wartości w pozycjach oznaczonych *</translation>
    </message>
    <message>
        <source>You have chosen the same database for two or more site templates. Please change where indicated by *</source>
        <translation>Ta sama baza została wybrana dla dwu lub więcej szablonów stron. Proszę zmienić informację w polach oznaczonych przez *</translation>
    </message>
    <message>
        <source>One or more of your databases already contain data.</source>
        <translation>Jedna lub więcej Twych baz danych już zawiera dane.</translation>
    </message>
    <message>
        <source>Select what to do from the drop down box(es).</source>
        <translation>Wybierz co należy zrobić.</translation>
    </message>
    <message>
        <source>Site url</source>
        <translation>URL witryny</translation>
    </message>
    <message>
        <source>URL for access</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Port for access</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Hostname for access</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>URL for admin access</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Port for admin access</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Hostname for admin access</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Database not empty</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Leave the data and add new</source>
        <translation>Pozostaw dane i dodaj nowe</translation>
    </message>
    <message>
        <source>Remove existing data</source>
        <translation>Usuń istniejące dane</translation>
    </message>
    <message>
        <source>Leave the data and do nothing</source>
        <translation>Pozostaw dane i nic nie rób</translation>
    </message>
    <message>
        <source>I&apos;ve chosen a new database</source>
        <translation>Wybieram nową bazę danych</translation>
    </message>
    <message>
        <source>i18n(&quot;design/standard/setup&quot;)}
&lt;p&gt;&lt;/p&gt;
{&quot;For more information on how to configure site access, see the %1&quot;</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Choose site templates</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Choose one or more site templates for your site</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Select which sites you would like to install on your system.</source>
        <translation>Wybierz, które witryny życzysz sobie zainstalować w swym systemie.</translation>
    </message>
    <message>
        <source>Each site template will create a unique web site.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Since each web site is unique, each site template require a unique database.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the check boxes.</source>
        <translation>Kiedy problem zostanie już rozwiązany kliknij na klawisz %1 w celu uruchomienia systemu kontorli. Możesz zignorować poszczególne testy poprzez odpowiednie zaznaczenie pól wyboru.</translation>
    </message>
    <message>
        <source>Ignore this test</source>
        <translation>Zignoruj ten test</translation>
    </message>
    <message>
        <source>The setup has detected some system settings which must be changed.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>If this is not corrected, eZ publish will probably not install correctly and work properly.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Welcome to eZ publish %1</source>
        <translation>Witamy w eZ publish %1</translation>
    </message>
    <message>
        <source>Welcome to the installation of eZ publish content management system and development framework. The setup wizard will now guide you through the installation of eZ publish.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>You will need to have information about a database server you can connect to. You need to have a database which you can use for eZ publish. MySQL and PostgreSQL are supported.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Click &gt;&gt; to continue the installation of eZ publish</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Your system cannot install eZ publish as it is. You need to do some modifications. Click &gt;&gt; to see what you have to do.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Help on each installation step will be presented here.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>The summary area below will contain information of selected settings.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>No data will be stored in the database until the final step of the installation.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Information on how to install eZ publish manually is available %1.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Enter database system user information in the boxes below.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Socket (optional):</source>
        <translation>Gniazdo (socket) (opcjonalnie):</translation>
    </message>
    <message>
        <source>Outgoing E-mail</source>
        <translation>Wychodzący E-Mail</translation>
    </message>
    <message>
        <source>This section is used to configure how eZ publish delivers its outgoing E-mail.</source>
        <translation>Ta sekcja jest używana do konfiguracji zasad wysyłania E-mail przez eZ publish.</translation>
    </message>
    <message>
        <source>There are two options:&lt;br&gt;- Direct delivery through sendmail (sendmail must be available on the server where eZ publish is installed)&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use, ask your webhost. Some webhosts do not support</source>
        <translation>który będzie przekazywał pocztę. Jeśli niebyt wiesz co masz użyć, zapytaj swego providera. Niektórzy providerzy nie dostarczają obsługi</translation>
    </message>
    <message>
        <source>SMTP is recommended for MS Windows users.</source>
        <translation>SMTP jest rekomendowane dla użytkowników Windows.</translation>
    </message>
    <message>
        <source>E-mail delivery</source>
        <translation>Dostarczanie E-mail</translation>
    </message>
    <message>
        <source>Server name: </source>
        <translation>Nazwa serwera:</translation>
    </message>
    <message>
        <source>Username (optional): </source>
        <translation>Nazwa użytkownika (opcjonalnie):</translation>
    </message>
    <message>
        <source>Password (optional): </source>
        <translation>Hasło (opcjonalnie):</translation>
    </message>
    <message>
        <source>The eZ publish system uses E-mail to send out important notices such as user registration and content approval. On Linux/UNIX: try to use sendmail. On Windows: use an SMTP server.</source>
        <translation>eZ publish używa system E-mail do rozsyłania ważnych wiadomości takich jak np.  rejestracja użytkownika czy aprobata publikacji. W systemie Linux/UNIX możesz użyć protokołu sendmail. W systemie Windows użyj serwera SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Sendmail:&lt;/b&gt;&lt;br&gt;Mail is delivered directly using the sendmail transfer agent. The sendmail binary is usually available on most Linux/UNIX systems. If sendmail is not available then SMTP should be used.</source>
        <translation>&lt;b&gt;Sendmail:&lt;/b&gt;&lt;br&gt;Poczta będzie dostarczana bezpośrednio za pomocą protokołu sendmail. Sendmail jest używany w większości systemów Linux/UNIX. Jeśli sendmail jest nie dostępny należy użyć SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Mail is delivered through an SMTP server. At the minimum, the hostname of the SMTP server must be specified. Hint: check the SMTP settings in your E-mail application.</source>
        <translation>&lt;b&gt;SMTP:&lt;/b&gt;&lt;br&gt;Poczta będzie dostarczana poprzez serwer SMTP. Co najmniej nazwa hosta serwera SMTP musi być wyspecyfikowana. Podpowiedź: zaznacz ustawienie SMTP w swojej aplikacji do obsługi E-mail.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval.</source>
        <translation> E-mail jest używany do rozsyłania ważnych wiadomości takich jak np. rejestracja użytkownika czy aprobata publikacji.</translation>
    </message>
    <message>
        <source>Most Unix systems support sendmail, while windows users must choose SMTP.</source>
        <translation>Większość sustemów Unix obsługuje protokół sendmail, podczas gdy użytkownicy Windows muszą wybrać SMTP.</translation>
    </message>
    <message>
        <source>&lt;b&gt;SMTP&lt;/b&gt;: If you&apos;re unsure what to enter, take a look at the settings in your e-mail application.</source>
        <translation>&lt;b&gt;SMTP:&lt;/b&gt; Jeśli nie masz pewności co tu wpisać, zajrzyj do ustawień swej poczty e-mail.</translation>
    </message>
    <message>
        <source>eZ publish has been installed with the following site(s). You will find the username and password mentioned for each site.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Tip: Store this page as an html file by clicking Save-As in your web browser menu, alternatively you may write down the urls for your sites.</source>
        <translation>Porada: Zapisz tę stronę jako plik html poprzez kliknięcie na &quot;Zapisz jako&quot; w swej przeglądarce web, ewentualnie możesz zapisać linki do swych stron.</translation>
    </message>
    <message>
        <source>forums</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Language support</source>
        <translation>Obsługa języków</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the primary language, and checkboxes to choose additional languages. You may choose more than one additional language.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>For more information about language customization, please refer to the online %1.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to only give access to certain files.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>This security tweak takes care of protecting configuration files and other important files.</source>
        <translation>System bezpieczeństwa troszczy się o zabezpieczenie ważnych plików i konfiguracji.</translation>
    </message>
    <message>
        <source>Please choose the access method you wish to use for your site(s).The access method determines how the site can be accessed from within a web browser.
If unsure: choose URL.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Port*</source>
        <translation>Port*</translation>
    </message>
    <message>
        <source>* Requires web server setup.</source>
        <translation>* Wymaga ustawienia web serwera.</translation>
    </message>
    <message>
        <source>Hostname*</source>
        <translation>Nazwa hosta*</translation>
    </message>
    <message>
        <source>* Requires DNS setup.</source>
        <translation>* Wymaga ustawienia DNS.</translation>
    </message>
    <message>
        <source>This page lets you modify information about the sites you&apos;ve chosen to install. In addition, it also lets you choose a database for each site.</source>
        <translation>Ta strona pozwoli Ci zmodyfikować informacje o witrynach, które wybrano do instalacji. Dodatkowo, pozwoli Ci wybrać bazy dancyh dla każdej z witryn.</translation>
    </message>
    <message>
        <source>User path</source>
        <translation>Ścieżka dla użytkownika</translation>
    </message>
    <message>
        <source>User port</source>
        <translation>Port dla użytkownika</translation>
    </message>
    <message>
        <source>User hostname</source>
        <translation>Nazwa hosta dla użytkownika</translation>
    </message>
    <message>
        <source>Admin path</source>
        <translation>Ścieżka dla administratora</translation>
    </message>
    <message>
        <source>Admin port</source>
        <translation>Port dla administratora</translation>
    </message>
    <message>
        <source>Admin hostname</source>
        <translation>Nazwa hosta dla administratora</translation>
    </message>
    <message>
        <source>Fill out the details for each site.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>For more information on how to configure site access, see the %1</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Use the refresh button to update database listing(s).</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Site templates</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Use Plain if you would like to start from scratch.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Since each web site is unique, each site template requires a unique database.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Next &amp;gt;</source>
        <translation>Dalej &amp;gt;</translation>
    </message>
    <message>
        <source>There are some important issues that have to be resolved. A list of issues / problems is presented below. Each section contains a description and a suggested / recommended solution.</source>
        <translation>Oto niektóre ważne problemy, które należy rozwiązać. Lista problemów poniżej. Każda sekcja zawiera opis i ewentualne sugestie / rekomendacje rozwiązań.</translation>
    </message>
    <message>
        <source>Once the problems / issues are fixed, you may click the &lt;i&gt;Next&lt;/i&gt; button to continue. The system check will be run again. If everything is okay, the setup will go to the next stage. If there are problems, the system check page will reappear.</source>
        <translation>Jeśli problemy / kwestie zostały usunięte, możesz kliknąć na &lt;i&gt;Dalej&lt;/i&gt; w celu kontynuacji. Kontrola systemu zostanie uruchomiona ponownie. Jeśli wszystko będzie dobrze, proces instalacji przejdzie do kolejnego stanu. Jeśli znowu zostaną wykryte problemy, strona kontrolna pojawi się ponownie.</translation>
    </message>
    <message>
        <source>Some issues may be ignored by checking the &lt;i&gt;Ignore this test&lt;/i&gt; checkbox(es); however, this is not recommended.</source>
        <translation>Niektóre pozycje mogą zostać zignorowane poprzez zaznaczenie pola wyboru &lt;i&gt;ignoruj test&lt;/i&gt;; jednak to nie jest rekomendowane.</translation>
    </message>
    <message>
        <source>The system check found some issues that need to be resolved before the setup can continue.</source>
        <translation>System sprawdzi poprawność wybranych ustawień niezbędnych do kontunuowania instalacji.</translation>
    </message>
    <message>
        <source>The system check page is being displayed. This means that there are some problems/issues present.</source>
        <translation>Wyniki działania systemu kontroli. Poszczególne kwestie/problemy są zaprezentowane.</translation>
    </message>
    <message>
        <source>These issues have to be resolved/fixed, or else, eZ publish will not function properly.</source>
        <translation>Te kwestie winny być rozwiązane/poprawione, w przeciwnym razie eZ publish nie będzie funkcjonował poprawnie.</translation>
    </message>
    <message>
        <source>The problems are usually file-system related and can be easily fixed by copy / paste / run-ing the suggested commands in a system shell.</source>
        <translation>Problemy są zwykle związane z systemem plików i mogą być prosto rozwiązane poprzez skopiowanie / wklejenie / uruchomienie sugerowanych komend w powłoce sysytemowej.</translation>
    </message>
    <message>
        <source>Welcome to the eZ publish content management system and development framework. This wizard will help you set up eZ publish.&lt;br&gt;Click &lt;i&gt;Next&lt;/i&gt; to continue.</source>
        <translation>Witamy w systemie CMS eZ publish. Pomożemy Ci przygotować eZ publish do pracy.&lt;br&gt; Kliknij na &lt;i&gt;Dalej&lt;/i&gt; w celu kontynuacji.</translation>
    </message>
    <message>
        <source>This section will contain information/help about each step in the setup wizard.</source>
        <translation>Ta sekcja będzie zawierać informacje pomocnicze dla każdego kroku procesu instalacji.</translation>
    </message>
    <message>
        <source>The summary section below will contain information about configured settings.</source>
        <translation>Sekcja podsumowania będzie zawierać informacje o wybranych ustawieniach.</translation>
    </message>
    <message>
        <source>No data will be stored in the database until the final step of the setup.</source>
        <translation>Żadne dane nie zostaną zapisane do bazy danych do czasu wykonania ostatniego kroku instalacji.</translation>
    </message>
    <message>
        <source>Information about how to set up eZ publish manually is available %1.</source>
        <translation>Informacje o tym jak skonfigurować ręcznie eZ publish są dostępne na stronie %1</translation>
    </message>
    <message>
        <source>Both MySQL and PostgreSQL support was detected on your system. Please choose the database system you would like to use.</source>
        <translation>Zarówno obsługa MySQL jak i PostgresSQL została wykryta w Twym systemie. Proszę wybrać system baz danych, który chcesz używać.</translation>
    </message>
    <message>
        <source>eZ publish supports both MySQL and PostgreSQL.</source>
        <translation>eZ publish obsługuje zarówno MySQL jak i PostgreSQL.</translation>
    </message>
    <message>
        <source>Please input database access information in the form below.</source>
        <translation></translation>
    </message>
    <message>
        <source>If you don&apos;t have access to a database, you should obtain access now. eZ publish is capable of running multiple sites, each site needs its own database. This means that you need to create several databases if you plan to run multiple sites. Please refer to the database system user manual if you&apos;re unsure about how to create a database.</source>
        <translation>Jeśli nie masz dostępu do bazy danych, musisz go uzyskać teraz. eZ publish jest zdolny uruchamiać różne schematy witryn, każda z nich wymaga własnej bazy dancyh. Potrzebujesz różnych baz jeśli planujesz użycie różnych schematów stron. Proszę zapoznać się z dokumentacją systemu baz danych jeśli nie wiesz jak je utworzyć.</translation>
    </message>
    <message>
        <source>There are two options:&lt;br&gt;- Direct delivery through sendmail (must be available on the server).&lt;br&gt;- Indirect delivery using an SMTP relay server.</source>
        <translation>Możliwe są dwa rozwiązania:&lt;br&gt; - Bezpośrednie dostarczanie poprzez sendmail (musi być dostępny w systemie).&lt;br&gt; - Pośrednie dostarczanie za pomocą serwera SMTP.</translation>
    </message>
    <message>
        <source>Use the radio buttons to choose the primary language, and the checkboxes to choose additional languages. You may choose more than one additional language.</source>
        <translation>Wybierz język podstawowy poprzez zaznaczenie jednego z pól wyboru, oraz jeżyki dodatkowe poprzez zaznaczenie odpowiednich pozycji. Możesz wybrać więcej niż jeden dodatkowy język. </translation>
    </message>
    <message>
        <source>The selected languages are used to determine character sets, date / number formats, etc.</source>
        <translation>Wybrane języki będą używane do określenia ustawień kodowania znaków, daty liczb, formatów itp.</translation>
    </message>
    <message>
        <source>For more information about language customization, please refer to the %1.</source>
        <translation>Po więcej szczegółowych informacji o tym, jak konfigurować języki, przejdź na %1.</translation>
    </message>
    <message>
        <source>If you wish, you can register this installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your details for unsolicited emails.</source>
        <translation>Jeśli chcesz, możesz zarejestrować swą instalację poprzez wysłanie informacji do eZ Systems. Żadne poufne dane nie będą transmitowane a eZ system nie będzie używać lub sprzedawać szczegółów tego emaila.</translation>
    </message>
    <message>
        <source>If you wish, you can also add some comments, which will be included in the registration E-mail.</source>
        <translation>Jeśli chcesz, możesz załączyć komentarz, który zostanie dołączony do rejestracyjnego E-mail.</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Komentarze:</translation>
    </message>
    <message>
        <source>Sending out the email and generating your site might take a couple of seconds. Please wait until the next page loads. Clicking the button again will only send out duplicate emails, and may corrupt the installation.</source>
        <translation>Wysłanie poczty email i wygenerowanie stron może potrwać kilkanaście sekund. Poczekaj zanim załaduje się kolejna strona. Ponowne kliknięcie na klawisz tylko spowoduje ponowne wysłanie poczty i dodatkowo może uszkodzić instalację.</translation>
    </message>
    <message>
        <source>Send registration</source>
        <translation>Wyślij rejestrację</translation>
    </message>
    <message>
        <source>System details (OS type, etc)</source>
        <translation>Szczegóły o systemie (Typ OS, etc.)</translation>
    </message>
    <message>
        <source>The test results</source>
        <translation>Rezultaty testu</translation>
    </message>
    <message>
        <source>The database type</source>
        <translation>Typ bazy danych</translation>
    </message>
    <message>
        <source>The site name</source>
        <translation>Nazwa witryny</translation>
    </message>
    <message>
        <source>The url of the site</source>
        <translation>URL witryny</translation>
    </message>
    <message>
        <source>Languages chosen</source>
        <translation>Wybrane języki</translation>
    </message>
    <message>
        <source>This data will help to improve future releases of eZ publish.</source>
        <translation>Te dane pomogą ulepszyć przyszłe wersje eZ publish.</translation>
    </message>
    <message>
        <source>Site security</source>
        <translation>Zabezpieczenia stron</translation>
    </message>
    <message>
        <source>Your site is not running in a virtual host mode, this is insecure. It is recommended to run eZ publish in virtual host mode. If you do not have the possibility to use virtual host mode, you should follow the instructions below about how to install an .htaccess file. The .htaccess file tells the web server to restrict the access to certain files.</source>
        <translation>Twoje strony nie są uruchomione w trybie hosta wirtualnego., to jest niebezpieczne. Rekomendujemy używanie eZ publish w trybie hosta wirtualnego. Jeśli nie masz możliwości użycia takiego trybu musisz postąpić zgodnie z instrukcją poniżej w celu zmiany pliku .htaccess. Plik .htaccess informuje serwer web o prawach dostępu do określonych plików.</translation>
    </message>
    <message>
        <source>If you have shell access, you can run the following commmands.</source>
        <translation>Jeśli posiadasz dostęp typu shell, możesz wprowadzić następujące komendy.</translation>
    </message>
    <message>
        <source>If you do not have shell access, you will have to copy the file using an FTP client or ask your hosting provider to do this for you.</source>
        <translation>Jeśli nie posiadasz dostępu typu shell, musisz skopiować plik za pomocą klienta FTP lub zapytać swego provider-a, co należy zrobić.</translation>
    </message>
    <message>
        <source>Please choose the access method you wish to use for your site(s). The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>For more detailed information on site access, please refer to the %1</source>
        <translation>Po więcej szczegółowych informacji o dostępie (site access), przejdź na %1</translation>
    </message>
    <message>
        <source>Database not empty: </source>
        <translation>Baza danych nie jest pusta:</translation>
    </message>
    <message>
        <source>You may modify the details for each site.</source>
        <translation>Możesz modyfikować szczegóły dla każdej witryny.</translation>
    </message>
    <message>
        <source>For more information about how to configure site access, please refer to the %1</source>
        <translation>Po więcej szczegółowych informacji o tym, jak konfigurować dostępy (site access), przejdź na %1</translation>
    </message>
    <message>
        <source>Use the refresh button to update the database listing(s).</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>eZ publish has been installed with the following sites. You will find the username and password mentioned for each site.</source>
        <translation>eZ publish został zainstalowany z następującymi witrynami. Dla dostępu do każdej z nich potrzebna będzie znajomość nazwy użytkownika i hasła.</translation>
    </message>
    <message>
        <source>Please choose the access method you wish to use for your site. The access method determines how the site will be accessed from within a web browser. If unsure: choose URL.</source>
        <translation>Proszę określić metodę dostępu do stron. Metoda dostępu (site access) determinuje sposób współpracy z przeglądarkami. Jeśli nie wiesz co zrobić: wybierz URL.</translation>
    </message>
    <message>
        <source>Use the refresh button to update the database listing.</source>
        <translation>Użyj klawisza Odśwież w celu uzyskania ponownych informacji o bazie danych. </translation>
    </message>
    <message>
        <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the %documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Site packages</source>
        <translation>Pakiety witryn</translation>
    </message>
    <message>
        <source>Each package will create a unique web site.</source>
        <translation>Każdy pakiet tworzy unikalne strony web. </translation>
    </message>
    <message>
        <source>Since each web site is unique, each package requires a unique database.</source>
        <translation>Ponieważ każda witryna web jest unikalna,, każdy pakiet wymaga oddzielnej bazy danych.</translation>
    </message>
    <message>
        <source>here</source>
        <comment>link to unicode info</comment>
        <translation>tutaj</translation>
    </message>
    <message>
        <source>forums</source>
        <comment>forum link</comment>
        <translation>Fora dyskusyjne</translation>
    </message>
    <message>
        <source>eZ publish</source>
        <comment>eZ publish 3 link</comment>
        <translation>eZ publish</translation>
    </message>
    <message>
        <source>If you need help with eZ publish, you can go to %ezlink and get help in the forums.
  If you find a bug (error), please go to %buglink and report it.
  With your help we can fix the errors eZ publish might have and implement new features.</source>
        <translation>Jeśli potrzebujesz pomocy od zespołu eZ publish, kliknij na %ezlink i postaraj się uzyskać ją na forum. 
Jeśli znajdziesz błąd, prosimy kliknij na %buglink i zgłoś go.
Dzięki Twej pomocy będziemy mogli poprawić błedy eZ publish w nowych wersjach.</translation>
    </message>
    <message>
        <source>Click on the URL to access your new %ezlink or click the %donebutton button. Enjoy one of the most successful web content management systems!</source>
        <translation>Kliknij na URL aby uzyskać dostęp do swej nowej %ezlink lub kliknij na klawisz %donebutton. Korzystaj z powodzeniem z systemu CMS!</translation>
    </message>
    <message>
        <source>If you ever want to restart this setup, edit the file %filename and look for a line that says:</source>
        <translation>Jeśli konieczne okaże się ponowne przeprowadzenie procesu instalacji, edytuj plik %filename i znajdź linię zawierającą:</translation>
    </message>
    <message>
        <source>Change the second line from %false to %true.</source>
        <translation>Zmień zawartość drugiej linii z %false na %true.</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>language information link</comment>
        <translation>dokumentacja</translation>
    </message>
    <message>
        <source>Back</source>
        <comment>back button in installation</comment>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>Refresh</source>
        <comment>Refresh button in installation</comment>
        <translation>Odśwież</translation>
    </message>
    <message>
        <source>Next</source>
        <comment>next button in installation</comment>
        <translation>Dalej</translation>
    </message>
    <message>
        <source>online documentation</source>
        <comment>site access documentation link</comment>
        <translation>dokumentacja online</translation>
    </message>
    <message>
        <source>documentation</source>
        <comment>site access documentation link</comment>
        <translation>dokumentacja</translation>
    </message>
    <message>
        <source>here</source>
        <comment>manual installation link</comment>
        <translation>tutaj</translation>
    </message>
    <message>
        <source>Please make sure that the username and the password is correct. Verify that your PostgreSQL database is configured correctly.&lt;br&gt;See the %documentation for more information about this.&lt;br&gt;Remember to start postmaster with the -i option.&lt;br&gt;Note that Postgre 7.2 and 7.4 are not supported.</source>
        <translation>Upewnij się że nazwa użytkownika i hasło są poprawne. Sprawdź czy Twa baza PostgreSQL jest skonfigurowana poprawnie.&lt;br&gt; Przeczytaj %dokumentation aby uzyskać więcej informacji. &lt;br&gt; Pamiętaj o wystartowaniu demona postmaster z opcją -i. &lt;br&gt; Uwaga: Postgre 7.2 i 7.4 nie są obsługiwane.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Przykład</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Domyślnie konstruksor nie ma nic.</translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>Zwraca tablice z nazwą szablonów operatorów.</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Uruchamia funkcje  PHP dla czyszczenia operatowów i   modfiles \a $operatorValue.</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Przykłądowy skrypt.Skrypt powinien być zmodyfikowany aby zrobć co opweator chce zronić.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Brakujący program obsługi bazy danych</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Twoja instalacja PHP nie obsługuje tylu baz danych co eZ publish.</translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>eZ publish może pracować bez tego, ale może chcesz mieć wsparcie dla tej bazy danych.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>Także niektóre bazy danych mają bardziej zaawansowane możliwości, takie jak ustawianie strony kodowej, od innych.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Aby Twoje PHP obsługiwało więcej baz danych należy zrekompilować je ponownie, dokładne opcje rekompilacji wymienione są poniżej.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Brak programu obsługującego bazę danych</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>Znaleziono nieobsługiwane programy obsługi baz danych. eZ publish wymaga od bazy danych zapisywania danych, bez tej mości system nie będzie funkcjonował.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Aby Twoje PHP obsługiwało więcej baz danych należy zrekompilować je ponownie, dokładne opcje rekompilacji wymienione są poniżej.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Niewystarczające atrybuty dla zapisu do katalogu</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish nie może zapisać niektórych ważnych katalogów, bez tego setup nie może skończyć instalacji i część eZ publish nie będzie funkcjonować.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>Zaleca się naprawienie tego poprzez wydanie poniższej komendy.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Komendy shella</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>Brakujące wsparcie dla konwersji obrazków</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>Brak możliwości konwersji  obrazów, co oznacza, że eZ publish nie jest w stanie skalować ani wykrywać typów plików graficznych. To jest bardzo ważna właściwość eZ publish i musi działać poprawnie.</translation>
    </message>
    <message>
        <source>Missing imagegd extension</source>
        <translation type="obsolete">Brak rozszerzenia imagegd</translation>
    </message>
    <message>
        <source>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation type="obsolete">Niedostępne rozszerzenie imagegd. Bez tego eZ publish może tylko konwertować ograzki za pomocą ImageMagic i</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>wzór operatora jest niedostępny.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Notatka:</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>Przyszłe wydania eZ publish będą zawierały bardziej zaawansowane wsparcie dla plików graficznych poprzez rozszerzenie imagegd.</translation>
    </message>
    <message>
        <source>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation type="obsolete">Aby udostępnić imagegd należy zrekompilować PHP, więcej informacji na ten temat dostępnych jest </translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Brak programu ImageMagick</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>ImageMagick jest niedostępny dla eZ publish. Bez tego programu eZ publish nie będzie w stanie konwertować plików graficznych.</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>Jeśli wiesz gdzie program jest zainstalowany (pliki uruchamiające nazywają się</translation>
    </message>
    <message>
        <source>or</source>
        <translation>lub</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>)wtedy wprowadź katalog w polu poniżej i ponownie sprawdź (Oddziel wielokrotne katalogi z</translation>
    </message>
    <message>
        <source>colon</source>
        <translation>dwukropek</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>średnik</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Instalacja</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>ImageMagic można pobrać z</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>Brakujące rozszerzenie MBString</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>eZ publish jest wyposażony w obszerną listę stron z zestawami znaków, które dzięki temu, że są napisane w czystym PHP mogą trochę spowalniać działanie. Na szczęście eZpublish posiada wsparcie dla rozszerzeń mbstring służących do obsługi stron kodowych.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>Przez uruchomienie rozszerzeń mbstring ez publish będzie miał dostęp do stron z różnym kodowaniem oraz może przyspieszyć to ich ładowanie. Jest to zalecane dla stron wielojęzycznych.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation>Kompletna lista znaków obsługiwanych przez mbstring:</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>Instalacji rozszerzeń mbstrings dokonujemy poprzez kompilację PHP z </translation>
    </message>
    <message>
        <source>option.</source>
        <translation>opcje.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>Więcej informacji na temat rozszerzeń można znaleźć na</translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>Nie włączaj funkcji mbstring overloading . eZ publish wykorzysta rozszerzenia tylko wtedy kiedy ich na prawdę potrzebuje.</translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>Opcje PHP</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>jest włączone</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish będzie działał z tą opcją, jednakże doproadzić to może do sytuacji, w której trzeba będzie przekonwertować wszystkie znaki z powrotem do</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normalny</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your</source>
        <translation type="obsolete">Zalecane jest  wyłączenie tej opcji. Aby to zrobić wyedytuj swoją</translation>
    </message>
    <message>
        <source>configuration and set</source>
        <translation type="obsolete">konfigurację i ustaw</translation>
    </message>
    <message>
        <source>and</source>
        <translation type="obsolete">i</translation>
    </message>
    <message>
        <source>to</source>
        <translation type="obsolete">do</translation>
    </message>
    <message>
        <source>More information on the subject can be found at</source>
        <translation type="obsolete">Więcej informacji na temat na stronie</translation>
    </message>
    <message>
        <source>Configuration example:</source>
        <translation type="obsolete">Przykład konfiguracjji:</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Za mała wersja PHP</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Twoja wersja PHP </translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>. nie spełnia minimalnych wymagań</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>Nowszą wersję PHP można pobrać z</translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>Musisz uaktualnić do wersji co najmniej </translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation>. ale polecane są nowsze wersje, takie jak 4.2.3.</translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish nie ma uprawnień do zapisu w</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>katalogu. bez tych uprawnień program konfiguracyjny nie może sam się zdezaktywować.</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>Brakujące rozszerzenie zlib</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>Rozszerzenie zlib jest niedostępne dla eZ publish. Bez niego eZ publish nie jest w stanie zainstalować danych przykładowych, jednak jeśli chcesz zrezygnować z danych przykładowych możesz bezpiecznie zignorować ten komunikat.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>Aby udostępnić rozszerzenia zlib, należy zrekompilować PHP. Musisz skonfigurować PHP</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>Więcej informacji na temat na stronie</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>Uploadowannie plików jest wylączone

</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>Uploadowanie plików jest wyłączone. Oznacza to, że nie będzie możliwe uploadować pliki do eZ publish. Wszystkie pozostałe cześci eZpublish nadal działają ale jest zalecane włączenie uploadowania plików.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Konfiguracja</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>Włączenie ładowania plików jest realizowane przy pomocy ustawienia %1 w php.ini. Odsyłamy do instrukcjii PHP dla głębszego zrozumienia konfigurowania</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Więcej informacji o włączaniu rozszerzeń możesz znależć czytając %1 i %2</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 and %3 to %4.</source>
        <translation type="obsolete">Jest zalecane aby ta opcja była wyłączona. Aby ją wyłączyć wyedytuj Twój %1 plik konfiguracyjny i ustaw %2 i %3 na %4.</translation>
    </message>
    <message>
        <source>More information on the subject can be found at %1.</source>
        <translation>Więcej informacji na temat będziesz mógł uzyskać na %1.</translation>
    </message>
    <message>
        <source>php.ini example:</source>
        <translation>Przyklad pliku php.ini:</translation>
    </message>
    <message>
        <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following:</source>
        <translation>Można również stworzyć plik z nazwą %1 w katalogu głównym eZ publish i dodać następujące:</translation>
    </message>
    <message>
        <source>.htaccess example:</source>
        <translation>Przyładowy plik .htaccess:</translation>
    </message>
    <message>
        <source>PHP option %1 is enabled</source>
        <translation>Opcja %1 PHP jest włączona</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
        <translation>eZ publish będzie działał z tą opcją. Jednakże doprowadzi to do zmniejszenia wydajności ponieważ wszystkie zmienne lokalne będą konwertowane na globalne podczas uruchamiania każdego skryptu.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
        <translation>Jest zalecane, aby ta opcja była wyłączona. Aby ją wyłączyć wyedytuj plik konfiguracyjny %1 i ustaw %2 na %3.</translation>
    </message>
    <message>
        <source>PHP safe mode is enabled</source>
        <translation>Tryb bezpieczny (safe mode) jest włoczony</translation>
    </message>
    <message>
        <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are:</source>
        <translation>eZ publish może funkcjonować z włączonym trybem bezpicznym (safe mode). Jednakże niektóre funkcjonalności będą niedostępne. Niektóre z tych rzeczy to:</translation>
    </message>
    <message>
        <source>Insufficient execution time allowed to install eZ publish</source>
        <translation>Zbyt krótki czas wykonywania dla poprawnej instalacji eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a execution time limit of %1.</source>
        <translation>eZ publish nie będzie działał poprawnie z limitem czasu wykonania %1.</translation>
    </message>
    <message>
        <source>It&apos;s highly recommended that you fix this.</source>
        <translation>Zdecydowanie zalecamy poprawienie tego.</translation>
    </message>
    <message>
        <source>Locate the php.ini settings file for your PHP installation. On unix systems, this is normally located at /etc/php.ini, on windows systems check the PHP installation path.</source>
        <translation>Zlokalizuj plik ustawień php.ini w systemie PHP. W systemie unix, zwykle jest on zlokalizowany w /etc/php.ini, w sytemie Windows sprawdź ścieżkę instalacyjną PHP.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the max_execution_time value to at least %1, and press %2</source>
        <translation>Otwórz plik php.ini i zmień max_execution_time na co najmniej %1 i kliknij na %2</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Dalej</translation>
    </message>
    <message>
        <source>If you are running eZ publish in a shared host environment, contant your ISP to perform the changes</source>
        <translation>Jeśli uruchamiasz eZ publish w środowisku współużytkowanego hosta, skontaktuj się ze swym ISP w celu dokonania zmian</translation>
    </message>
    <message>
        <source>Insufficient memory allocated to install eZ publish</source>
        <translation>Zbyt mało dostępnej pamięci do instalacji eZ publish</translation>
    </message>
    <message>
        <source>eZ publish will not work correctly with a memory limit of %1.</source>
        <translation>eZ publish nie będzie działał poprawnie z limitem pamięci %1.</translation>
    </message>
    <message>
        <source>Open the php.ini file and change the memory_limit value to at least %1, and press %2</source>
        <translation>Otwórz plik php.ini i zmień memory_limit na co najmniej %1, i kliknij na %2</translation>
    </message>
    <message>
        <source>eZ publish will not work properly with this option on.</source>
        <translation>eZ publish nie będzie działał poprawnie z włączoną tą opcją.</translation>
    </message>
    <message>
        <source>Unstable PHP version</source>
        <translation>Wersja PHP jest niestabilna</translation>
    </message>
    <message>
        <source>, is known to be unstable</source>
        <translation>, jest uważana za niestabilną</translation>
    </message>
    <message>
        <source>Another version of PHP can be download at</source>
        <translation>Pobierz inną wersję PHP z</translation>
    </message>
    <message>
        <source>Missing imagegd2 extension</source>
        <translation>Brak rozszerzenia imagegd2</translation>
    </message>
    <message>
        <source>The imagegd2 extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>Rozszerzenie imagegd2 jest niedostępne dla eZ publish. Bez niego eZ publish będzie w stanie dokonywać konwersji tylko za pomocą ImageMagick i</translation>
    </message>
    <message>
        <source>To enable imagegd2 you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>W celu włączenia rozszerzenia imagegd2 należy dokonać rekompilacji PHP z włączonym wsparciem dla niego, więcej informacji na ten temat znajdziesz na</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %phpini configuration and set %magic_quotes_gpc and %magic_quotes_runtime to %offtext.</source>
        <translation>Jest rekomendowane wyłączenie tej opcji. W celu jej wyłączenia edytuj plik konfiguracyjny %phpini i ustaw %magic_quotes_gpc oraz %magic_quotes_runtime na %offtext.</translation>
    </message>
    <message>
        <source>To turn it off edit your %phpini configuration and set %magic_quotes_runtime to %offtext.</source>
        <translation>W celu wyłączenia tej opcji edytuj plik konfiguracyjny %phpini i ustaw %magic_quotes_runtime na %offtext.</translation>
    </message>
    <message>
        <source>AcceptPathInfo disabled</source>
        <translation>AcceptPathInfo wyłączone</translation>
    </message>
    <message>
        <source>You need enable AcceptPathInfo in your Apache config file.</source>
        <translation>Musisz włączyć AcceptPathInfo w pliku konfiguracyjnym Apache.</translation>
    </message>
    <message>
        <source>enter the following into your httpd.conf file.</source>
        <translation>wprowadź następujące dane do pliku konfiguracyjnego httpd.conf.</translation>
    </message>
    <message>
        <source>Remember to restart your web server afterwards.</source>
        <translation>Pamiętaj o zrestartowaniu Twego serwera web póżniej.</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Basket</source>
        <translation>Koszyk</translation>
    </message>
    <message>
        <source>Product:</source>
        <translation type="obsolete">Produkt:</translation>
    </message>
    <message>
        <source>Count:</source>
        <translation type="obsolete">Liczba:</translation>
    </message>
    <message>
        <source>VAT:</source>
        <translation type="obsolete">VAT:</translation>
    </message>
    <message>
        <source>Price ex. VAT:</source>
        <translation type="obsolete">Cena bez VAT-u:</translation>
    </message>
    <message>
        <source>Price inc. VAT:</source>
        <translation type="obsolete">Cena zawierająca VAT:</translation>
    </message>
    <message>
        <source>Discount:</source>
        <translation type="obsolete">Zniżka:</translation>
    </message>
    <message>
        <source>Total Price ex. VAT:</source>
        <translation type="obsolete">Cena całkowita  bez VAT-u:</translation>
    </message>
    <message>
        <source>Total Price inc. VAT:</source>
        <translation type="obsolete">Cena całkowita z VAT-em:</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation>Suma bez VAT:</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation>Suma z VAT:</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Kontynuuj zakupy</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Do zamówienia</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>Nie masz żadnych produktów w koszyku</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Potwierdź zamówienie</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Lista produktów</translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation>Zamówienie  łącznie:</translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation>Suma pozycji:</translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation>Całość zamówienia:</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Potwierdź</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Defined discount groups</source>
        <translation type="obsolete">Zdefiniowane grupy zniżek</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Editing discount group</source>
        <translation type="obsolete">Edytuj grupę zniżek</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Zastosuj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Widok grupy</translation>
    </message>
    <message>
        <source>Group Name:</source>
        <translation type="obsolete">Nazwa grupy:</translation>
    </message>
    <message>
        <source>Defined rules:</source>
        <translation type="obsolete">Zdefiniowane reguły:</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Procent</translation>
    </message>
    <message>
        <source>Apply to:</source>
        <translation type="obsolete">Zastosuj do:</translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Dodaj regułę</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Usuń regułę</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Klienci</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Dodaj klienta</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Usuń klienta</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Edycja reguły</translation>
    </message>
    <message>
        <source>Discount percent:</source>
        <translation type="obsolete">Procent upustu:</translation>
    </message>
    <message>
        <source>Choose which classes or sections applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation type="obsolete">Wybierz, które klasy lub sekcje mają zastosowanie do tej podreguły. &apos;Każda&apos; znaczy, że reguła ma zastosowanie do wszystkiego.</translation>
    </message>
    <message>
        <source>Class:</source>
        <translation type="obsolete">Klasa:</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Każda</translation>
    </message>
    <message>
        <source>Section:</source>
        <translation type="obsolete">Sekcja:</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Lista zamówień</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Nr</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Klient</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Suma bez VAT</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Suma z VAT</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Zamówienie</translation>
    </message>
    <message>
        <source>Customer:</source>
        <translation type="obsolete">Klient:</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Typy VAT</translation>
    </message>
    <message>
        <source>Percentage:</source>
        <translation type="obsolete">Procent:</translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Lista życzeń</translation>
    </message>
    <message>
        <source>Remove item(s)</source>
        <translation type="obsolete">Usuń przedmiot(y)</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Opróżnij listę życzeń</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produkt</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Ilość</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>VAT</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Cena bez VAT</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Cena z VAT</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Rabat</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Wartość bez VAT</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Wartość z VAT</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Grupy rabatowe</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Edycja grupy rabatowej</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Nazwa grupy</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Zdefiniowane reguły</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Zastosuj do</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Rabat procentowo</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Sekcja</translation>
    </message>
    <message>
        <source>Order:</source>
        <translation type="obsolete">Zamówienie:</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Suma pozycji</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>Lista zmówień jest pusta</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Całość zamówienia</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Rejestruj informacje o koncie użytkownika</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>Wprowadzanie nie zostało zaakceptowane. Wypełnij pola jeszcze raz</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Procentowo</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Znajdź</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atrybuty</translation>
    </message>
    <message>
        <source>Rule settings</source>
        <translation>Ustawienia ról</translation>
    </message>
    <message>
        <source>Choose which classes, sections or objects ( products ) applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Wybierz które klasy, sekcje albo obiekty (produkty) podlegają pod tę zasadę. &apos;Dowolny&apos; oznacza, że zasada zostanie zastosowana do wszystkich.</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Nie określone.</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Sortowanie</translation>
    </message>
    <message>
        <source>Sort Result by:</source>
        <translation type="obsolete">Sortuj wg:</translation>
    </message>
    <message>
        <source>Order Time</source>
        <translation>Czasu zamówienia</translation>
    </message>
    <message>
        <source>User Name</source>
        <translation>Nazwy klienta</translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation>Nr zamówienia</translation>
    </message>
    <message>
        <source>First name</source>
        <translation>Imię</translation>
    </message>
    <message>
        <source>Last name</source>
        <translation>Nazwisko</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation type="obsolete">E-Mail</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation>Wybrane opcje</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Payment was cancelled for an unknown reason. Please try to buy again.</source>
        <translation>Płatność została anulowana z nieznanego powodu. Proszę dokonać zakupu ponownie.</translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation>Zamówienie sumarycznie</translation>
    </message>
    <message>
        <source>Sort Result by</source>
        <translation>Sortuj rezultaty wg</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Rosnąco</translation>
    </message>
    <message>
        <source>Sort ascending</source>
        <translation>Sortowanie rosnąco</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Malejąco</translation>
    </message>
    <message>
        <source>Sort descending</source>
        <translation>Sortowanie malejąco</translation>
    </message>
    <message>
        <source>Order %1</source>
        <translation>Zamówienie %1</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation>Twoje konto zostało aktywowane.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account was not activated.</source>
        <translation>Niestety wprowadzony klucz nie jest właściwy. Konto nie zostało aktywowane.</translation>
    </message>
    <message>
        <source>ez.no: Orderconfirmation %1</source>
        <translation>Potwierdzenie zamówienia %1</translation>
    </message>
    <message>
        <source>Remove items</source>
        <translation>Usuń pozycje</translation>
    </message>
    <message>
        <source>Name</source>
        <comment>Customer name</comment>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Informacje o Twoim koncie</translation>
    </message>
    <message>
        <source>Input did not validate, all fields marked with * must be filled in</source>
        <translation>Niepoprawne dane, wszystkie pola oznaczone * muszą zostać wypełnione</translation>
    </message>
    <message>
        <source>First name:*</source>
        <translation>Imię:*</translation>
    </message>
    <message>
        <source>Last name:*</source>
        <translation>Nazwisko:*</translation>
    </message>
    <message>
        <source>E-mail:*</source>
        <translation>E-mail:*</translation>
    </message>
    <message>
        <source>Company:</source>
        <translation>Firma:</translation>
    </message>
    <message>
        <source>Street:*</source>
        <translation>Ulica:*</translation>
    </message>
    <message>
        <source>Zip:*</source>
        <translation>Kod:*</translation>
    </message>
    <message>
        <source>Place:*</source>
        <translation>Miejscowość:*</translation>
    </message>
    <message>
        <source>State:</source>
        <translation>Poczta:</translation>
    </message>
    <message>
        <source>Country:*</source>
        <translation>Kraj:*</translation>
    </message>
    <message>
        <source>Comment:</source>
        <translation>Komentarz:</translation>
    </message>
    <message>
        <source>All fields marked with * must be filled in.</source>
        <translation>Wszystkie pola oznaczone * muszą zostać wypełnione.</translation>
    </message>
</context>
<context>
    <name>design/standard/shop/view</name>
    <message>
        <source>Choose customers</source>
        <translation>Wybierz klienta</translation>
    </message>
    <message>
        <source>Please choose the customers you want to add to discount group %groupname.

    Select your customers and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on object names to change the browse listing.</source>
        <translation>Wybierz klienta, którego chcesz dodać do grupy rabatowej %groupname.

Wybierz klienta i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszej selekcji, o ile to możliwe.
Klikaj na nazwie obiektu w celu zmiany wyświetlanej listy.</translation>
    </message>
    <message>
        <source>Choose product for discount</source>
        <translation>Wybierz produkt dla rabatu</translation>
    </message>
    <message>
        <source>Please choose the products you want to add to discount rule %discountname in discount group %groupname.

    Select your products and click the %buttonname button.
    Using the recent and bookmark items for quick selection is also possible.
    Click on product names to change the browse listing.</source>
        <translation>Proszę wybrać produkty, które chcesz dodać do reguł rabatowych %discountname w grupie rabatowej %groupname.

Wybierz produkt i kliknij na klawisz %buttonname.
Używaj Ostatnich i Preferowanych w celu szybszego ustalania położenia, o ile to możliwe.
Kliknij na nazwie produktu w celu zmiany przeglądanej listy.</translation>
    </message>
</context>
<context>
    <name>design/standard/templates/</name>
    <message>
        <source>Logout</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Triggers list</source>
        <translation type="obsolete">Lista procedur uruchamiających</translation>
    </message>
    <message>
        <source>Triggers editing</source>
        <translation type="obsolete">Edycja procedur uruchamiających</translation>
    </message>
    <message>
        <source>Module Name</source>
        <translation type="obsolete">Nazwa modułu</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation type="obsolete">Nazwa funkcji</translation>
    </message>
    <message>
        <source>Connect Type</source>
        <translation type="obsolete">Typ Zawartości</translation>
    </message>
    <message>
        <source>Workflow ID</source>
        <translation type="obsolete">Workflow ID</translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>Bez przepływu</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Trigger list</source>
        <translation>Lista procedur</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Przepływ</translation>
    </message>
    <message>
        <source>Module name</source>
        <translation>Nazwa modułu</translation>
    </message>
    <message>
        <source>Function name</source>
        <translation>Nazwa funkcji</translation>
    </message>
    <message>
        <source>Connect type</source>
        <translation>Typ połączenia</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Wszystko</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Ważne</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Nieważne</translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation>URL nie jest już uważany za ważny.</translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation>To oznacza, że URL już nie jest aktualny albo był przeniesiony.</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>URL wskazuje na %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Ostatnio zmodyfikowane %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>URL nie posiada daty modyfikacji</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Ostatnio sprawdzone %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>URL nie został sprawdzony</translation>
    </message>
    <message>
        <source>Objects which use this link:</source>
        <translation type="obsolete">Obiekty które używają ten link:</translation>
    </message>
    <message>
        <source>Information on URL</source>
        <translation>Informacje o adresach URL</translation>
    </message>
    <message>
        <source>version</source>
        <translation>wersja</translation>
    </message>
    <message>
        <source>No object available</source>
        <translation>Brak dostępnych obiektów</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtr</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Last checked</source>
        <translation>Ostatnio sprawdzono</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Zmodyfikowane</translation>
    </message>
    <message>
        <source>Popup</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>All URLs</source>
        <translation>Wszystkie URL</translation>
    </message>
    <message>
        <source>Invalid URLs</source>
        <translation>Nieważne URL</translation>
    </message>
    <message>
        <source>Valid URLs</source>
        <translation>Ważne URL</translation>
    </message>
    <message>
        <source>Objects which use this link</source>
        <translation>Obiekty używające tego linku</translation>
    </message>
</context>
<context>
    <name>design/standard/url/edit</name>
    <message>
        <source>Editing URL - %1</source>
        <translation>Edycja URL - %1</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Activate account</source>
        <translation>Aktywuj konto</translation>
    </message>
    <message>
        <source>Login ID:</source>
        <translation type="obsolete">Login ID:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="obsolete">Hasło:</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation type="obsolete">Aktywuj</translation>
    </message>
    <message>
        <source>Registed user profile</source>
        <translation type="obsolete">Profil zarejestrowanego użytkownika</translation>
    </message>
    <message>
        <source>Login:</source>
        <translation type="obsolete">Login:</translation>
    </message>
    <message>
        <source>e-mail:</source>
        <translation type="obsolete">e-mail:</translation>
    </message>
    <message>
        <source>Update Profile</source>
        <translation type="obsolete">Zaktualizuj profil</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation type="obsolete">Zmień Hasło</translation>
    </message>
    <message>
        <source>Change Setting</source>
        <translation type="obsolete">Zmień Ustawienia</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Nie można zalogować</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Do zalogowania wymagane jest ważna nazwa użytkownika i hasło.</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <translation type="obsolete">Zarejestruj się</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Zmień hasło użytkownika</translation>
    </message>
    <message>
        <source>Old Password:</source>
        <translation type="obsolete">Stare hasło:</translation>
    </message>
    <message>
        <source>New Password:</source>
        <translation type="obsolete">Nowe hasło:</translation>
    </message>
    <message>
        <source>Retype Password:</source>
        <translation type="obsolete">Powtórz hasło:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Zarejestruj użytkownika</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Wprowadzone dane nie zostały zatwierdzone</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>Dane zapisane pomyślnie</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Zarejestruj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Ustawienia użytkownika</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Max login</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Jest włączone</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aktualizuj</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Użytkownik zarejestrowany</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Twoje konto zostało pomyślnie utworzone.</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>Dostęp zabroniony</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Nie posiadasz praw dostępu do %1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <source>Old Password</source>
        <translation type="obsolete">Stare hasło</translation>
    </message>
    <message>
        <source>New Password</source>
        <translation type="obsolete">Nowe hasło</translation>
    </message>
    <message>
        <source>Retype Password</source>
        <translation type="obsolete">Powtórz hasło</translation>
    </message>
    <message>
        <source>User profile</source>
        <translation>Profile użytkownika</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Edit Profile</source>
        <translation type="obsolete">Edytuj Profile</translation>
    </message>
    <message>
        <source>Please retype your old password.</source>
        <translation>Wpisz jeszcze raz Twoje nowe haslo.</translation>
    </message>
    <message>
        <source>Password didn&apos;t match, please retype your new password.</source>
        <translation>Hasla się różnią. Wpisz jeszcze raz nowe hasło.</translation>
    </message>
    <message>
        <source>Password successfully updated.</source>
        <translation>Hasło zostało pomyślnie zaktualizowane.</translation>
    </message>
    <message>
        <source>Your account is now activated.</source>
        <translation type="obsolete">Twoje konto zostało aktywowane.</translation>
    </message>
    <message>
        <source>Sorry, the key submitted was not a valid key. Account &lt;b&gt;not&lt;/b&gt; activated.</source>
        <translation type="obsolete">Przepraszamy, przesłany klucz jest nieważny. Konto &lt;b&gt;nie&lt;/b&gt; zostało aktywowane.</translation>
    </message>
    <message>
        <source>Your account was successfully created. An e-mail will be sent to the specified
e-mail address. You need to follow the instructions in that mail to activate
your account.</source>
        <translation>Twoje konto zostało pomyślnie utworzone. E-mail został wysłany pod podany adres.
Wykonaj instrukcję podaną w tym E-mail w celu aktywacji Twego konta.</translation>
    </message>
    <message>
        <source>Edit profile</source>
        <translation>Edytuj profil</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Zmień hasło</translation>
    </message>
    <message>
        <source>Change setting</source>
        <translation>Zmień ustawienia</translation>
    </message>
    <message>
        <source>Old password</source>
        <translation>Stare hasło</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Nowe hasło</translation>
    </message>
    <message>
        <source>Retype password</source>
        <translation>Powtórz hasło</translation>
    </message>
    <message>
        <source>You need to log in to get access to the intranet.</source>
        <translation>Aby uzyskać dostęp do Intranetu trzeba być zalogowanym.</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation>Login</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation>Zarejestruj się</translation>
    </message>
</context>
<context>
    <name>design/standard/user/forgotpassword</name>
    <message>
        <source>A mail has been send to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Została wysłana poczta na następujący adres e-mail: %1. Ten e-mail zawiera link, na który musisz kliknąć aby potwierdzić swoje dane.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>Użytkownik z takim adresem e-mail nie istnieje.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to:</source>
        <translation type="obsolete">Twoje konto zostało pomyślnie utworzone i wysłane do:</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Zapomnialeś hasla?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Jeżeli zapomniałeś hasła, system może wygenerowane nowe. Jedyne co musisz to wpisać swój e-mail na który prześlemy ci twoje nowe haslo.</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation type="obsolete">E-mail:</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Generuj nowe haslo</translation>
    </message>
    <message>
        <source>%1 new password</source>
        <translation type="obsolete">%1 nowe hasło</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Informacje o twoim koncie</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation type="obsolete">Email:</translation>
    </message>
    <message>
        <source>Click here to get new password:</source>
        <translation type="obsolete">Kliknij tutaj oby otrzymać nowe haslo:</translation>
    </message>
    <message>
        <source>New password:</source>
        <translation type="obsolete">Nowe hasło:</translation>
    </message>
    <message>
        <source>The key is invalid or has been used. </source>
        <translation>Błędny lub już użyty klucz.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to: %1</source>
        <translation>Wygenerowane z powodzeniem hasło zostało wysłane do: %1</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>%siteurl new password</source>
        <translation>%siteurl nowe hasło</translation>
    </message>
    <message>
        <source>Click here to get new password</source>
        <translation>Kliknij tu by wygenerować nowe hasło</translation>
    </message>
    <message>
        <source>New password</source>
        <translation>Nowe hasło</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>Confirm user registration at %1</source>
        <translation type="obsolete">Potwierdź rejestrację użytkownika %1</translation>
    </message>
    <message>
        <source>New user registered at %1</source>
        <translation type="obsolete">Zarejestrowano nowego użytkownika %1</translation>
    </message>
    <message>
        <source>%1 registration info</source>
        <translation>%1 informacje rejestracyjne</translation>
    </message>
    <message>
        <source>Digest from site %1</source>
        <translation type="obsolete">Przekierowany ze strony %1</translation>
    </message>
    <message>
        <source>New article was published at %1</source>
        <translation type="obsolete">Nowy artykł został opublikowany na %1</translation>
    </message>
    <message>
        <source>New %1 was published at %2</source>
        <translation type="obsolete">Nowy %1 został opublikowany na %2</translation>
    </message>
    <message>
        <source>New %1 was published. Click to the link to view</source>
        <translation type="obsolete">Nowy %1 został opublikowany. Wciśnij link dla obeżenia</translation>
    </message>
    <message>
        <source>Your user account at</source>
        <translation type="obsolete">Twoje konto na</translation>
    </message>
    <message>
        <source>has been created</source>
        <translation type="obsolete">zostało utowrzone</translation>
    </message>
    <message>
        <source>Account information:</source>
        <translation type="obsolete">Informacje o koncie:</translation>
    </message>
    <message>
        <source>Click the following URL to confirm your account</source>
        <translation>Kliknij na ten link w celu aktywacji Twego konta</translation>
    </message>
    <message>
        <source>Confirm user registration at %siteurl</source>
        <translation>Potwierdź rejestrację użytkownika na %siteurl</translation>
    </message>
    <message>
        <source>Your user account at %siteurl has been created</source>
        <translation>Twoje konto użytkownika na %siteurl zostało utworzone</translation>
    </message>
    <message>
        <source>Account information</source>
        <translation>Informacje o koncie</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>New user registered at %siteurl</source>
        <translation>Zarejestrowano nowego użytkownika na %siteurl</translation>
    </message>
    <message>
        <source>A new user has registered.</source>
        <translation>Nowy użytkownik zarejestrowany.</translation>
    </message>
    <message>
        <source>Account information.</source>
        <translation>Informacje o koncie.</translation>
    </message>
    <message>
        <source>Link to user information</source>
        <translation>Link do informacji o koncie użytkownika</translation>
    </message>
    <message>
        <source>Thank you for registering at %siteurl.</source>
        <translation>Dziękujemy za rejestrację na %siteurl.</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Informacje o twoim koncie</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Login name</comment>
        <translation>Login</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Editing workflow</source>
        <translation>Edycja przepływu</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>Przepływ zapisany</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Dane wymagają poprawki</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="obsolete">Nazwa:</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Grupy</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>Zdarzenia</translation>
    </message>
    <message>
        <source>Pos:</source>
        <translation type="obsolete">Pos:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="obsolete">Opis:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Typ:</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Editing workflow group</source>
        <translation type="obsolete">Edycja grup łańcucha</translation>
    </message>
    <message>
        <source>Created by</source>
        <translation type="obsolete">Utworzone przez</translation>
    </message>
    <message>
        <source>on</source>
        <translation>wł</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Zmodyfikowane przez</translation>
    </message>
    <message>
        <source>Defined workflow groups</source>
        <translation type="obsolete">Zdefiniowane grupy łańcucha</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>Proces przepływu</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>Proces przepływu został utworzony</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>i zmodyfikowane</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Przepływ</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>Używanie przepływu</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>do przetwarzania.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>Ten przepływ jest uruchamiany dla użytkownika</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>Obiekt zawartości</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>Przepływ został stworzony dla zawartości</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>wersja użytkownika</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>w katalogu nadrzędnym</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>Zdarzenie przepływu</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>Przepływ nie został uruchomiony, pozycja głównego zdarzenia w przepływie to</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>Pozycja obecnego zdarzenia to</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>Zdarzenie, które ma zostać uruchomione to</translation>
    </message>
    <message>
        <source>event</source>
        <translation>zdarzenie</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>Ostatni zwrócony status zdarzenia</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>Lista zdarzeń przepływu</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Wyzeruj</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Następny krok</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>Log zdarzeń przepływu</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <source>Defined workflows for</source>
        <translation type="obsolete">Zdefiniowane łańcuchy dla</translation>
    </message>
    <message>
        <source>Modifier:</source>
        <translation type="obsolete">Modyfikator:</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="obsolete">Zmodyfikowany:</translation>
    </message>
    <message>
        <source>Edit:</source>
        <translation type="obsolete">Edycja:</translation>
    </message>
    <message>
        <source>Remove:</source>
        <translation type="obsolete">Usuń:</translation>
    </message>
    <message>
        <source>Temporary workflows for</source>
        <translation type="obsolete">Tymczasowy łańcuch dla</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>Poz</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>Grupy przepływów</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Nowa grupa</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <translation type="obsolete">Przepływy w %1</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modyfikujący</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Zmodyfikowane</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Nowy przepływ</translation>
    </message>
    <message>
        <source>Add group</source>
        <translation>Dodaj grupę</translation>
    </message>
    <message>
        <source>Editing workflow group - %1</source>
        <translation>Edytuj grupę przepływów - %1</translation>
    </message>
    <message>
        <source>Modified by %username on %time</source>
        <translation>Zmodyfikowano przez %username o %time</translation>
    </message>
    <message>
        <source>Edit workflow</source>
        <translation>Edytuj przepływ</translation>
    </message>
    <message>
        <source>Remove selected workflows</source>
        <translation>Usuń wybrane przepływy</translation>
    </message>
    <message>
        <source>Workflow process was created at %creation and modified at %modification.</source>
        <translation>Proces przepływu utworzony  %creation i zmodyfikowany %modyfication.</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <comment>%1 is workflow group</comment>
        <translation>Przepływy w %1</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/event</name>
    <message>
        <source>Checkout</source>
        <translation>Kontrola</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Dalej</translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation type="obsolete">Opakowanie</translation>
    </message>
    <message>
        <source>Do you want wrapping in Christmas paper?</source>
        <translation type="obsolete">Czy życzysz sobie opakowanie świąteczne?</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Nie</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">Tak</translation>
    </message>
    <message>
        <source>Hello</source>
        <translation type="obsolete">Witaj Użytkowniku</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor:</source>
        <translation type="obsolete">Edytor:</translation>
    </message>
    <message>
        <source>Sections:</source>
        <translation type="obsolete">Sekcje:</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Dowolna</translation>
    </message>
    <message>
        <source>Users without approval:</source>
        <translation type="obsolete">Użytkownicy bez autoryzacji:</translation>
    </message>
    <message>
        <source>Checkout text:</source>
        <translation type="obsolete">Sprawdź tekst:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="obsolete">Wiadomość:</translation>
    </message>
    <message>
        <source>Section IDs:</source>
        <translation type="obsolete">Identyfikatory sekcji:</translation>
    </message>
    <message>
        <source>Users without workflow IDs:</source>
        <translation type="obsolete">Użytkownicy bez identyfikatorów łańcucha:</translation>
    </message>
    <message>
        <source>Unpublish object</source>
        <translation>Wycofaj obiekt z publikacji</translation>
    </message>
    <message>
        <source>Publish object</source>
        <translation>Publikuj obiekt</translation>
    </message>
    <message>
        <source>Days:</source>
        <translation type="obsolete">Dni:</translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="obsolete">Godziny:</translation>
    </message>
    <message>
        <source>Minutes:</source>
        <translation type="obsolete">Minuty:</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation>Edytor</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sekcje</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Nie muszą aprobować</translation>
    </message>
    <message>
        <source>Checkout text</source>
        <translation>Sprawdzanie tekstu</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Wiadomość</translation>
    </message>
    <message>
        <source>Section IDs</source>
        <translation type="obsolete">ID Sekcji</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Wyklucz z przepływu</translation>
    </message>
    <message>
        <source>Days</source>
        <translation>Dni</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation>Godzin</translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation>Minut</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation type="obsolete">Nowe Wejście</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation type="obsolete">Usuń Zaznaczenie</translation>
    </message>
    <message>
        <source>Load Attributes</source>
        <translation type="obsolete">Ładuj atrybuty</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Klasa</translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation>Atrybuty klasy:</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Przepływ dla klas</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>Przepływ do uruchomienia</translation>
    </message>
    <message>
        <source>New entry</source>
        <translation>Nowe wejście</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Usuń wybrane</translation>
    </message>
    <message>
        <source>Load attributes</source>
        <translation>Ładuj atrybuty</translation>
    </message>
    <message>
        <source>Modify publish date</source>
        <translation>Modyfikuj datę publikacji</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Klasy w grupie</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Grupy klas</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Usuń klasę</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Edycja klasy</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Klasy</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Lista klas</translation>
    </message>
    <message>
        <source> object</source>
        <translation>obiekt</translation>
    </message>
    <message>
        <source> objects</source>
        <translation>obiektów</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>Usuń klasy</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(brak klas)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Usuń grupy klas</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Aprobata</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Obserwator</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Właściciel</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Aprobujący</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Skrzynka odbiorcza</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Wciąż nie ma statusu </translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>Przepływ uruchomiony</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>Przepływ zakończony</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>Błąd przepływu na zdarzeniu</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>Przepływ został dopisany do zadań cron&apos;a</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>Przepływ anulowano</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>Przepływ został zresetowany dla ponownego użycia</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Akceptowane zdarzenia</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Odrzucane zdarzenia</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>Zdarzenie zostało dopisane do zadań cron&apos;a</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>Zdarzenie zostało dopisane do zadań cron&apos;a. To zdarzenie będzie uruchomione ponownie</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>Zdarzenie wywołało zdarzenie pochodne</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Cały przepływ został zaniechany</translation>
    </message>
    <message>
        <source>Workflow fetches template</source>
        <translation>Przepływ pobrał szablony</translation>
    </message>
    <message>
        <source>Workflow redirects user view</source>
        <translation>Przepływ przekierował widok dla użytkownika</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>At least one author is requied.</source>
        <comment>eZAuthorType</comment>
        <translation type="obsolete">Wymagany conajmniej jeden autor.</translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <comment>eZAuthorType</comment>
        <translation type="obsolete">Wymagane nazwisko autora.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZAuthorType</comment>
        <translation type="obsolete">Nieprawidłowy adres e-mail.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZBinaryFileType</comment>
        <translation type="obsolete">Wymagany odpowiedni plik.</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <comment>eZEmailType</comment>
        <translation type="obsolete">Wymagane prawidłowe konto e-mail.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZEmailType</comment>
        <translation type="obsolete">Nieprawidłowy adres e-mail.</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <comment>eZEnumType</comment>
        <translation type="obsolete">Należy wybrać co najmniej jedno pole.</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <comment>eZFloatType</comment>
        <translation type="obsolete">Niewłaściwe dane.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZFloatType</comment>
        <translation type="obsolete">Dane wejściowe muszą być większe od %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZFloatType</comment>
        <translation type="obsolete">Dane wejściowe muszą być mniejsze od %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZFloatType</comment>
        <translation type="obsolete">Dane nie mieszczą się w dopuszczalnym zakresie %1 - %2</translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <comment>eZImageType</comment>
        <translation type="obsolete">Wymagany prawidłowy plik graficzny.</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <comment>eZIntegerType</comment>
        <translation type="obsolete">Dane nie są liczbą całkowitą.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZIntegerType</comment>
        <translation type="obsolete">Dane wejściowe muszą być większe od %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZIntegerType</comment>
        <translation type="obsolete">Dane wejściowe muszą być mniejsze od %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZIntegerType</comment>
        <translation type="obsolete">Dane nie mieszczą się w dopuszczalnym zakresie %1 - %2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <comment>eZISBNType</comment>
        <translation type="obsolete">Numer ISBN jest nieprawidłowy. Proszę sprawdzić dane</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <comment>eZISBNType</comment>
        <translation type="obsolete">Format ISBN jest nieprawidłowy.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZMediaType</comment>
        <translation type="obsolete">Wymagany ważny plik.</translation>
    </message>
    <message>
        <source>At least one option is requied.</source>
        <comment>eZOptionType</comment>
        <translation type="obsolete">Wymagana co najmniej jedna opcja.</translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <comment>eZOptionType</comment>
        <translation type="obsolete">Należy podać wartość opcji.</translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation type="obsolete">Linia tekstu jest pusta, wymagana zawartość.</translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <comment>eZStringType</comment>
        <translation type="obsolete">Linia tekstu za długa, dozwolone min to %1.</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation type="obsolete">Pole tekstowe jest puste, wymagana zawartość.</translation>
    </message>
    <message>
        <source>An user account must be filled up</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Należy wypełnić dane konta użytkownika</translation>
    </message>
    <message>
        <source>Login name exist, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Taki użytkownik już istnieje, wybierz inną nazwwę użytkownika.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Nieprawidłowy adres e-mail.</translation>
    </message>
    <message>
        <source>Please confirm your password.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Potwierdź hasło.</translation>
    </message>
    <message>
        <source>The minimum length of password should be 3.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Minimalna długość hasła wynosi 3 znaki.</translation>
    </message>
    <message>
        <source>Object </source>
        <translation type="obsolete">Obiekt</translation>
    </message>
    <message>
        <source>Link </source>
        <translation type="obsolete">Link</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <comment>eZAuthorType</comment>
        <translation type="obsolete">Co najmniej jeden autor jest wymagany.</translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation>Nie podano daty.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Nie podano daty i czasu.</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <comment>eZOptionType</comment>
        <translation type="obsolete">Co najmniej jedna opcja jest wymagana.</translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <comment>eZOptionType</comment>
        <translation type="obsolete">Dodatkowa cena dla opcji jest niewłaściwa.</translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation>Nie podano czasu.</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Musisz podać Login</translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Taki Login już istnieje, proszę wybrać inny.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Nieprawidłowy adres E-mail. </translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Użytkownik z tym adresem E-mail już istnieje.</translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation>Potwierdzenie hasła nie jest identyczne.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <comment>eZUserType</comment>
        <translation type="obsolete">Hasło musi mięć co najmniej 3 znaki.</translation>
    </message>
    <message>
        <source>Author</source>
        <comment>Datatype name</comment>
        <translation>Autor</translation>
    </message>
    <message>
        <source>At least one author is required.</source>
        <translation>Co najmniej jeden autor jest wymagany.</translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <translation>Wymagane nazwisko autora.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <translation>Nieprawidłowy adres e-mail.</translation>
    </message>
    <message>
        <source>BinaryFile</source>
        <comment>Datatype name</comment>
        <translation>Plik binarny</translation>
    </message>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation>Ładowanie plików nie zostało włączone, obsługa pliku nie powiedzie się.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <translation>Poprawny plik jest niezbędny.</translation>
    </message>
    <message>
        <source>Checkbox</source>
        <comment>Datatype name</comment>
        <translation>Zaznaczenie</translation>
    </message>
    <message>
        <source>Date field</source>
        <comment>Datatype name</comment>
        <translation>Pole daty</translation>
    </message>
    <message>
        <source>Datetime field</source>
        <comment>Datatype name</comment>
        <translation>Pole czasu i daty</translation>
    </message>
    <message>
        <source>Email</source>
        <comment>Datatype name</comment>
        <translation>Email</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <translation>Wymagane prawidłowe konto e-mail.</translation>
    </message>
    <message>
        <source>Enum</source>
        <comment>Datatype name</comment>
        <translation>Element policzalny</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <translation>Należy wybrać co najmniej jedno pole.</translation>
    </message>
    <message>
        <source>Float</source>
        <comment>Datatype name</comment>
        <translation>Liczba dowolna</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <translation>Dane nie są liczbą.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <translation>Dane wejściowe muszą być większe od %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <translation>Dane wejściowe muszą być mniejsze od %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <translation>Dane nie mieszczą się w dopuszczalnym zakresie %1 - %2</translation>
    </message>
    <message>
        <source>Image</source>
        <comment>Datatype name</comment>
        <translation>Obraz</translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <translation type="obsolete">Wymagany prawidłowy plik graficzny.</translation>
    </message>
    <message>
        <source>Integer</source>
        <comment>Datatype name</comment>
        <translation>Liczba całkowita</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <translation>Dane nie są liczbą całkowitą.</translation>
    </message>
    <message>
        <source>ISBN</source>
        <comment>Datatype name</comment>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <translation>Numer ISBN jest nieprawidłowy. Proszę sprawdzić dane</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <translation>Format ISBN jest nieprawidłowy.</translation>
    </message>
    <message>
        <source>Keyword</source>
        <comment>Datatype name</comment>
        <translation>Słowo kluczowe</translation>
    </message>
    <message>
        <source>Matrix</source>
        <comment>Datatype name</comment>
        <translation>Macierz</translation>
    </message>
    <message>
        <source>Media</source>
        <comment>Datatype name</comment>
        <translation>Media</translation>
    </message>
    <message>
        <source>Object relation</source>
        <comment>Datatype name</comment>
        <translation>Powiązanie do obiektu</translation>
    </message>
    <message>
        <source>Object relation list</source>
        <comment>Datatype name</comment>
        <translation>Lista powiązań do obiektów</translation>
    </message>
    <message>
        <source>Option</source>
        <comment>Datatype name</comment>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <translation>Co najmniej jedna opcja jest wymagana.</translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <translation>Należy podać wartość opcji.</translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <translation>Dodatkowa cena dla opcji jest niewłaściwa.</translation>
    </message>
    <message>
        <source>Price</source>
        <comment>Datatype name</comment>
        <translation>Cena</translation>
    </message>
    <message>
        <source>Add to basket</source>
        <translation>Do koszyka</translation>
    </message>
    <message>
        <source>Add to wish list</source>
        <translation>Do listy życzeń</translation>
    </message>
    <message>
        <source>Range option</source>
        <comment>Datatype name</comment>
        <translation>Opcja z zakresem</translation>
    </message>
    <message>
        <source>Selection</source>
        <comment>Datatype name</comment>
        <translation>Wybór</translation>
    </message>
    <message>
        <source>Text line</source>
        <comment>Datatype name</comment>
        <translation>Linia tekstu</translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <translation>Linia tekstu jest pusta, wymagana zawartość.</translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <translation>Linia tekstu za długa, dozwolone min to %1.</translation>
    </message>
    <message>
        <source>Subtree subscription</source>
        <comment>Datatype name</comment>
        <translation>Subskrypcja poddrzewa</translation>
    </message>
    <message>
        <source>Text field</source>
        <comment>Datatype name</comment>
        <translation>Pole tekstowe</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <translation>Pole tekstowe jest puste, wymagana zawartość.</translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="obsolete">Wyślij</translation>
    </message>
    <message>
        <source>Time field</source>
        <comment>Datatype name</comment>
        <translation>Pole czasu</translation>
    </message>
    <message>
        <source>URL</source>
        <comment>Datatype name</comment>
        <translation>URL</translation>
    </message>
    <message>
        <source>User account</source>
        <comment>Datatype name</comment>
        <translation>Konto użytkownika</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <translation>Musisz podać Login</translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <translation>Taki Login już istnieje, proszę wybrać inny.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <translation>Nieprawidłowy adres E-mail. </translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <translation>Użytkownik z tym adresem E-mail już istnieje.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <translation>Hasło musi mięć co najmniej 3 znaki.</translation>
    </message>
    <message>
        <source>XML Text field</source>
        <comment>Datatype name</comment>
        <translation>Pole tekstowe XML</translation>
    </message>
    <message>
        <source>Object %1 does not exist.</source>
        <translation>Obiekt %1 nie istnieje.</translation>
    </message>
    <message>
        <source>Link %1 does not exist.</source>
        <translation>Link %1 nie istnieje.</translation>
    </message>
    <message>
        <source>A valid country account is required.</source>
        <comment>eZCountryType</comment>
        <translation>Poprawny wybór kraju jest wymagany.</translation>
    </message>
    <message>
        <source>Country address is not valid.</source>
        <comment>eZCountryType</comment>
        <translation>Niewłaściwy kraj.</translation>
    </message>
    <message>
        <source>Identifier</source>
        <comment>Datatype name</comment>
        <translation>Identyfikator</translation>
    </message>
    <message>
        <source>image</source>
        <comment>Default image name</comment>
        <translation>obraz</translation>
    </message>
    <message>
        <source>Ini Setting</source>
        <comment>Datatype name</comment>
        <translation>Ustawienia Ini</translation>
    </message>
    <message>
        <source>Could not locate ini file</source>
        <translation>Nie można zlokalizować pliku ini</translation>
    </message>
    <message>
        <source>Package</source>
        <comment>Datatype name</comment>
        <translation>Pakiet</translation>
    </message>
    <message>
        <source>Send</source>
        <comment>Datatype information collector action</comment>
        <translation>Wyślij</translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Scalanie pojedyńczych akcji</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Współpraca</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Zaawansowane</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Nie wybrano głównego węzła, proszę go wybrać.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Zawartość</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Edycja</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Szkice</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Usuń edytowaną wersję</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Usuń obiekt</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Polecił %1: %2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>Niepoprawny adres email nadawcy</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>Niepoprawny adres email adresata</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Poleć znajomemu</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Przetłumacz</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Tłumaczenie</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Tłumaczenia zawartości</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Kosz</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Wersje</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Preferowane</translation>
    </message>
    <message>
        <source>My pending list</source>
        <translation>Oczekujące</translation>
    </message>
    <message>
        <source>URL translator</source>
        <translation>URL translator</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Słowa kluczowe</translation>
    </message>
    <message>
        <source>PDF Export</source>
        <translation type="obsolete">PDF eksport</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>dziecko</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>dzieci</translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation>Jednocześnie skasuje węzły:</translation>
    </message>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation type="obsolete">dziecko</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation type="obsolete">dzieci</translation>
    </message>
</context>
<context>
    <name>kernel/contentclass</name>
    <message>
        <source>New %1</source>
        <translation>Now(y/a) %1</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
</context>
<context>
    <name>kernel/form</name>
    <message>
        <source>Form processing</source>
        <translation>Przetwarzanie formularza</translation>
    </message>
</context>
<context>
    <name>kernel/notification</name>
    <message>
        <source>Notification settings</source>
        <translation>Powiadomienia</translation>
    </message>
</context>
<context>
    <name>kernel/package</name>
    <message>
        <source>Packages</source>
        <translation>Pakiety</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation>Załaduj</translation>
    </message>
    <message>
        <source>Package information</source>
        <translation>Informacje o pakiecie</translation>
    </message>
    <message>
        <source>Package maintainer</source>
        <translation>Konserwator pakietu</translation>
    </message>
    <message>
        <source>Package changelog</source>
        <translation>Log zmian w pakiecie</translation>
    </message>
    <message>
        <source>Package thumbnail</source>
        <translation>Logo pakietu</translation>
    </message>
    <message>
        <source>Package name</source>
        <translation>Nazwa pakietu</translation>
    </message>
    <message>
        <source>Package name is missing</source>
        <translation>Brak nazwy pakietu</translation>
    </message>
    <message>
        <source>A package named %packagename already exists, please give another name</source>
        <translation>Pakiet o nazwie %packagename już istnieje, proszę wybrać inną nazwę</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Podsumowanie</translation>
    </message>
    <message>
        <source>Summary is missing</source>
        <translation>Brak podsumowania</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Wersja</translation>
    </message>
    <message>
        <source>The version must only contain numbers and must be delimited by dots (.), e.g. 1.0</source>
        <translation>Numer wersji musi zawierać wyłącznie cyfry i musi być oddzielany kropkami, np. 1.0</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>You must enter a name for the changelog</source>
        <translation>Musisz wprowadzić nazwę Logu dla zmian</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>E-Mail</translation>
    </message>
    <message>
        <source>You must enter an e-mail for the changelog</source>
        <translation>Musisz wprowadzić adres e-mail dla zmian w logu</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation>Log zmian</translation>
    </message>
    <message>
        <source>You must supply some text for the changelog entry</source>
        <translation>Musisz wprowadzić jakiś tekst do logu rejestracji zmian</translation>
    </message>
    <message>
        <source>You must enter a name of the maintainer</source>
        <translation>Musisz podać nazwę konserwatora</translation>
    </message>
    <message>
        <source>You must enter an e-mail address of the maintainer</source>
        <translation>Musisz podać adres e-mail konserwatora</translation>
    </message>
    <message>
        <source>Content classes to include</source>
        <translation>Klasy zawartości do załączenia</translation>
    </message>
    <message>
        <source>Content class export</source>
        <translation>Eksport klas zawartości</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Lista klas</translation>
    </message>
    <message>
        <source>You must select at least one class for inclusion</source>
        <translation>Musisz wybrać i załączyć co najmniej jedną klasę</translation>
    </message>
    <message>
        <source>CSS file</source>
        <translation>Pilk CSS</translation>
    </message>
    <message>
        <source>Image files</source>
        <translation>Pliki obrazów</translation>
    </message>
    <message>
        <source>Site style</source>
        <translation>Styl strony</translation>
    </message>
    <message>
        <source>You must upload a CSS file</source>
        <translation>Musisz załadować plik CSS</translation>
    </message>
    <message>
        <source>File did not have a .css suffix, this is most likely not a CSS file</source>
        <translation>Plik nie posiada rozszerzenia .css, najprawdopodobniej to nie jest plik typu CSS</translation>
    </message>
    <message>
        <source>Content class %classname (%classidentifier)</source>
        <translation>Klasa zawartości %classname (%classidentifier)</translation>
    </message>
    <message>
        <source>Create package</source>
        <translation>Twórz pakiet</translation>
    </message>
    <message>
        <source>Install</source>
        <translation>Instaluj</translation>
    </message>
    <message>
        <source>Uninstall</source>
        <translation>Odinstaluj</translation>
    </message>
    <message>
        <source>Package %packagename already exists, cannot import the package</source>
        <translation>Pakiet %packagename już istnieje, import nie możliwy</translation>
    </message>
</context>
<context>
    <name>kernel/pdf</name>
    <message>
        <source>PDF Export</source>
        <translation>PDF eksport</translation>
    </message>
</context>
<context>
    <name>kernel/reference</name>
    <message>
        <source>Reference documentation</source>
        <translation>Dokumentacja</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation>Tworzenie polisy - krok 2 - Wybierz funkcję</translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation>Tworzenie polisy - krok 3 - Wybierz ograniczenia</translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation>Tworzenie polisy - krok 1 - Wybierz moduł</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Lista ról</translation>
    </message>
    <message>
        <source>Editing policy</source>
        <translation>Polityka edytowania</translation>
    </message>
</context>
<context>
    <name>kernel/rss</name>
    <message>
        <source>Really Simple Syndication</source>
        <translation>Really Simple Syndication</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Statystyki szukania</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Edytuj sekcję</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Aprobata</translation>
    </message>
</context>
<context>
    <name>kernel/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Administracja plikami tymczasowymi</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>O systemie</translation>
    </message>
    <message>
        <source>Rapid Application Development</source>
        <translation>Szybkie Tworzenie aplikacji</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Spis szablonów</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Widok szablonu</translation>
    </message>
    <message>
        <source>Create new template</source>
        <translation>Utwórz nowy szablon</translation>
    </message>
    <message>
        <source>Template edit</source>
        <translation>Edycja szablonu</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Kreator operatorów szablonów</translation>
    </message>
    <message>
        <source>Extension configuration</source>
        <translation>Rozszerzenia</translation>
    </message>
    <message>
        <source>Activate extensions</source>
        <translation>Aktywuj rozszerzenia</translation>
    </message>
    <message>
        <source>Setup menu</source>
        <translation>Setup menu</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Koszyk</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Kontrola</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Do kasy</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Grupa rabatowa</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>Widok grup rabatowych</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Edycja reguły</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Lista zamówień</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation>Wygląd zamówienia</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Wprowadź informacje o koncie użytkownika</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Typ VAT</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Procedura</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Widok</translation>
    </message>
    <message>
        <source>URL edit</source>
        <translation>Edytuj URL</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Przypomnienie hasła</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Zmień hasło</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Zarejestruj</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Informacje rejestracyjne</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Zarejestrowano nowego użytkownika</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Edytuj przepływ</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Przepływ</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Edcja grup przepływu</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Edycja grupy</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Grupy przepływu</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>Grupy</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Przepływy</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Grupy przepływów</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Lista</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/event</name>
    <message>
        <source>Event</source>
        <translation>Zdarzenie</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Aprobuj</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Sprawdzenie</translation>
    </message>
    <message>
        <source>Multiplexer</source>
        <translation>Multiplekser</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publikuj</translation>
    </message>
    <message>
        <source>Publish on time</source>
        <translation>Publikuj o czasie</translation>
    </message>
    <message>
        <source>Simple shipping</source>
        <translation>Koszt dostawy</translation>
    </message>
    <message>
        <source>Timing</source>
        <translation>Opóźnienie</translation>
    </message>
    <message>
        <source>Unpublish</source>
        <translation>Wycofaj z publikacji</translation>
    </message>
    <message>
        <source>Wait until date</source>
        <translation>Czekaj do daty</translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation type="obsolete">Opakowanie</translation>
    </message>
    <message>
        <source>Hello User</source>
        <translation type="obsolete">Witaj Użytkowniku</translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation>Dostawa</translation>
    </message>
</context>
<context>
    <name>kernel/workflow/group</name>
    <message>
        <source>Group</source>
        <translation>Grupa</translation>
    </message>
    <message>
        <source>Serial</source>
        <translation>Seria</translation>
    </message>
</context>
<context>
    <name>lib/ezpdf/classes</name>
    <message>
        <source>Contents</source>
        <comment>Table of contents</comment>
        <translation>Zawartość</translation>
    </message>
    <message>
        <source>Index</source>
        <comment>Keyword index name</comment>
        <translation>Indeks</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Nieokreślone błędy szablonu, obejrzyj debug w celu uzyskania dokładniejszych informacji.</translation>
    </message>
</context>
<context>
    <name>pdf/edit</name>
    <message>
        <source>PDF Export</source>
        <translation>PDF eksport</translation>
    </message>
</context>
<context>
    <name>settings/edit</name>
    <message>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edycja</translation>
    </message>
</context>
<context>
    <name>settings/view</name>
    <message>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Widok</translation>
    </message>
</context>
<context>
    <name>setup/templateadmin</name>
    <message>
        <source>Template edit</source>
        <translation>Edycja szablonu</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zachowaj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
</context>
</TS>
