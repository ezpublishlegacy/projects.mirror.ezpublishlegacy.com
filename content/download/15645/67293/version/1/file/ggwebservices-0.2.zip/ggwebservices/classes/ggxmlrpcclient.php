<?php
/**
 * Class used to communicate with XMLRPC servers
 *
 * @author G. Giunta
 * @version $Id: ggxmlrpcclient.php 4 2009-01-21 16:00:12Z gg $
 * @copyright (C) G. Giunta 2009
 */

class ggXMLRPCClient extends ggWebservicesClient
{
    function __construct( $server, $path = '/', $port = 80, $protocol=null )
    {
        $this->ResponseClass = 'ggXMLRPCResponse';
        $this->UserAgent = 'gg eZ XMLRPC client';
        $this->ContentType = 'text/xml';
        parent::__construct( $server, $path, $port, $protocol );
    }

    /**
      Sends a XMLRPC message and returns the response object.
    */
    function send( $request )
    {
        $response = parent::send( $request );
        if ( is_object( $response ) )
        {
            // we need to set the response name into the response, since for XMLRPC calls there is no call name in response
        }
        return $response;
    }
}

?>