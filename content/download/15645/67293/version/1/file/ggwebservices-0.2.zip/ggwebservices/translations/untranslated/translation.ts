<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Webservices Debugger</source>
        <translation type="unfinished"></translation>
        <comment>Navigation part</comment>
    </message>
</context>
<context>
    <name>extension/ggwebservices</name>
    <message>
        <source>WS Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remote servers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>