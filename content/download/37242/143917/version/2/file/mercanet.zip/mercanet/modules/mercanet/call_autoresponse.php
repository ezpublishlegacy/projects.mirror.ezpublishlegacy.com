<?php
/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Wed February 20 11:02:56 CEST 2008
# Fabrice PEREZ <fp@internethic.com>
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

ext_activate( 'mercanet', 'classes/mercanetchecker.php' );

$logger =& eZPaymentLogger::CreateForAdd( 'var/log/mercanet_call_autoresponse.log' );
$checker =& new mercanetChecker( 'mercanet.ini' );

$logger->writeTimedString( 'call_autoresponse' );

if ($checker->createDataFromPOST() )
{
	unset($_POST);
	if ( $checker->checkPaymentStatus() )
	{
		/*Modif Internethic du 31 Mai 2007
		A cause d'une erreur dans le fichier mis a jour, erreur de Mercanet, un decalage est apparut sur le retour des infos de la banque
		On modifi le champ appele pour garder une trace de l'ancien appel surtout si Mercanet corrige ce bug dans les prochains jours
		*/
		//$orderID = $checker->getFieldValue( 'order_id' );
		$orderID = $checker->getFieldValue( 'customer_email' );
		$logger->writeTimedString( "order_id : $orderID" );
		if ( $checker->setupOrderAndPaymentObject( $orderID ) )
		{
			$amount = $checker->getFieldValue( 'amount' );
			$currency = $checker->getFieldValue( 'currency' );
			if ($checker->checkAmount( $amount ) && $checker->checkCurrency( $currency ) )
			{
				$toto = $checker->approvePayment();
				$logger->writeTimedString( "retour approve: $toto" );
			}
		}
	}
	
}
else {
	$logger->writeTimedString( 'Could not create Data from POST' );
}

$logger->writeTimedString( 'call_autoresponse.php was properly ended' );
?>

