<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Wed February 20 11:02:56 CEST 2008
# Fabrice PEREZ <fp@internethic.com>
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

include_once('kernel/shop/classes/ezpaymentcallbackchecker.php');

class mercanetChecker extends eZPaymentCallbackChecker 
{
	
	function mercanetChecker ( $iniFile )
	{
		$this->eZPaymentCallbackChecker( $iniFile );
		$this->logger =& eZPaymentLogger::CreateForAdd( 'var/log/mercanetChecker.log' );		
		$this->logger->writeTimedString( "Creation" );
	}


	function createDataFromPOST( ) 
	{
		$MERCANET = $_POST[DATA];
		$message="message=$MERCANET";
		$this->logger->writeTimedString( "Data received: $MERCANET" );
		$root = getenv("DOCUMENT_ROOT");
		$this->logger->writeTimedString( "$root" );
		$pathfile = "pathfile=".$root."/extension/mercanet/classes/pathfile";
		$path_bin= "/usr/local/bin/response";
		// $path_bin= $root."/extension/mercanet/bin/response";

		// exec("LD_PRELOAD=/lib/libc.so.6 $path_bin $message $pathfile",$res);
		exec("$path_bin $message $pathfile",$res);
		$this->logger->writeTimedString( "Result: $res[0]" );
		$tableau = explode("!", $res[0]);

		$this->callbackData = array();

		$this->callbackData[code] = $tableau[1];
		$this->callbackData[error] = $tableau[2];
		$this->callbackData[merchant_id] = $tableau[3];
		$this->callbackData[merchant_country] = $tableau[4];
		$this->callbackData[amount] = $tableau[5];
		$this->callbackData[transaction_id] = $tableau[6];
		$this->callbackData[payment_means] = $tableau[7];
		$this->callbackData[transmission_date] = $tableau[8];
		$this->callbackData[payment_time] = $tableau[9];
		$this->callbackData[payment_date] = $tableau[10];
		$this->callbackData[response_code] = $tableau[11];
		$this->callbackData[payment_certificate] = $tableau[12];
		$this->callbackData[authorisation_id] = $tableau[13];
		$this->callbackData[currency] = $tableau[14];
		$this->callbackData[card_number] = $tableau[15];
		$this->callbackData[cvv_flag] = $tableau[16];
		$this->callbackData[cvv_response_code] = $tableau[17];
		$this->callbackData[bank_response_code] = $tableau[18];
		$this->logger->writeTimedString( "bank_response_code: $tableau[18]");
		$this->callbackData[complementary_code] = $tableau[19];
		$this->callbackData[return_context] = $tableau[20];
		$this->callbackData[caddie] = $tableau[21];
		$this->callbackData[receipt_complement] = $tableau[22];
		$this->callbackData[merchant_language] = $tableau[23];
		$this->callbackData[language] = $tableau[24];
		$this->callbackData[customer_id] = $tableau[25];
		$this->callbackData[order_id] = $tableau[26];
		$this->callbackData[customer_email] = $tableau[27];
		$this->callbackData[customer_ip_address] = $tableau[28];
		$this->callbackData[capture_day] = $tableau[29];
		$this->callbackData[capture_mode] = $tableau[30];
		$this->callbackData[data] = $tableau[31];

		$this->logger->writeTimedString( "callbackData created" );
		return ( count( $this->callbackData ) > 0 );
	}

	function checkPaymentStatus() 
	{
		if ( $this->callbackData[code] == 0 && isset( $this->callbackData[order_id] ) && $this->callbackData[bank_response_code]=="00")	
		{
			$this->logger->writeTimedString("checkPaymentStatus true");
			return true;
		} else {
			$this->logger->writeTimedString("checkPaymentStatus failed");
			return false;
		}
	}

	function setupOrderAndPaymentObject( $orderID ) 
	{
		if (isset( $orderID ) && $orderID > 0 )
		{
			$this->paymentObject =& eZPaymentObject::fetchByOrderID( $orderID );
			if ( isset( $this->paymentObject ) )
			{
				$this->order = eZOrder::fetch( $orderID );
				if ( isset( $this->order ) )
				{
					return true;
				}
				return false;
			}
			return false;
		}
		return false;
	}

	function getFieldValue( $field )
	{
		if ( isset( $this->callbackData[$field] ) )
		{
			return $this->callbackData[$field];
		}
		return null;
	}

	function approvePayment( $continueWorkflow=true )
	{
		if ( $this->paymentObject )
		{
			$this->logger->writeTimedString("approvePayment");
			$this->paymentObject->approve();
			$this->paymentObject->store();

			return ( $continueWorkflow ? $this->continueWorkflow() : null );
		}
		return null;
	}

	function continueWorkflow() 
	{
		if ( $this->paymentObject )
		{
			$workflowID = $this->paymentObject->attribute( 'workflowprocess_id' );
			if ( $workflowID )
			{
				$this->logger->writeTimedString( "ContinueWorkflow $workflowID" );
				$this->logger->writeTimedString( "Envoi a eZPaymentObject::continueWorkflow" );
				$return = eZPaymentObject::continueWorkflow( $workflowID );
				$this->logger->writeTimedString("Retour ".$return);
				return $return;
			}
			return null;
		}
		return null;
	}

	function checkAmount( $amount )
	{
		$orderAmount = $this->order->attribute( 'total_inc_vat' );
		$orderAmount = $orderAmount*100;
		if ( (int)$orderAmount - (int)$amount < 0.01 )
		{
			$this->logger->writeTimedString(" Amount is ok" );
			return true;
		}
		else
		{
			$this->logger->writeTimedString( "Order id=".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).", 'checkamount failed');
			$message = "Order id= ".$this->order->attribute( 'id' )." Amount ($orderAmount) and received amount ($amount).";
			mail('nospam@ez.no', 'MERCANET Probleme paiement', $message);
			return false;
		}
	}

	function checkCurrency( $currency )
	{
		include_once( 'lib/ezlocale/classes/ezlocale.php' );
		$locale =& eZLocale::instance();
		$orderCurrency = $locale->currencyShortName();

		if ($orderCurrency == "EUR" && $currency == "978") 
		{
			return true;			
		}
		$this->logger->writeTimedString( "Order currency ($orderCurrency) and received currency ($currency).", 'checkcurrency failed');
		return false;
	}
}

?>
