<?php

/*
##############################################################################
#
# Copyright (c) 2008 INTERNETHIC SSLL. (http://internethic.com)
# Wed February 20 11:02:56 CEST 2008
# Fabrice PEREZ <fp@internethic.com>
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
*/

//
// Definition of eZPaypalGateway class
//
// Created on: <18-Jul-2004 14:18:58 dl>
//
// SOFTWARE NAME: eZ publish
// SOFTWARE RELEASE: 3.8.0beta1
// BUILD VERSION: 15541
// COPYRIGHT NOTICE: Copyright (C) 1999-2006 eZ systems AS
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
// 
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

/*! \file ezpaypalgateway.php
*/

/*!
  \class mercanetGateway mercanetgateway.php
  \brief The class mercanetGateway implements
*/

include_once( 'kernel/shop/classes/ezpaymentobject.php' );
include_once( 'kernel/shop/classes/ezpaymentgateway.php' );

//__DEBUG__
include_once( 'kernel/classes/workflowtypes/event/ezpaymentgateway/ezpaymentlogger.php' );
//___end____

define( "EZ_PAYMENT_GATEWAY_TYPE_MERCANET", "mercanet" );
define( "EZ_GATEWAY_OBJECT_NOT_CREATED", 1 );
define( "EZ_GATEWAY_OBJECT_CREATED", 2 );

class mercanetGateway extends eZPaymentGateway
{
    /*!
        Constructor.
    */
    function mercanetGateway()
    {
        //__DEBUG__
            $this->logger   = eZPaymentLogger::CreateForAdd( "var/log/mercanetType.log" );
            $this->logger->writeTimedString( 'mercanetGateway::mercanetGateway()' );
        //___end____
    }

    /*!
        Creates new mercanetGateway object.
    */
    function &createPaymentObject( &$processID, &$orderID )
    {
        //__DEBUG__
            $this->logger->writeTimedString("createPaymentObject");
        //___end____

        return eZPaymentObject::createNew( $processID, $orderID, 'Mercanet' );
    }

    function generateRequestForm( $orderID)
    {
	$form = "";
	$parm="merchant_id=048XXXXXXXXXX";

	$parm="$parm merchant_country=fr";

 	$order =& eZOrder::fetch( $orderID );
	//$amount = (int)$order->attribute( 'total_inc_vat' );
	$amount = (float)$order->attribute( 'total_inc_vat' );
	$amount = $amount * 100;
	
	$siteIni =& eZINI::instance( 'site.ini' );
  	$siteUrl = 'http://'.$siteIni->variable( 'SiteSettings', 'SiteURL' );
  
	$parm="$parm amount=$amount";
	$parm="$parm currency_code=978";
	$root = getenv("DOCUMENT_ROOT");
	$parm = "$parm pathfile=".$root."/extension/mercanet/classes/pathfile";
	$parm = "$parm order_id=$orderID";
	// $path_bin = $root."/extension/mercanet/bin/request";
	$parm = "$parm normal_return_url=".$siteUrl."/shop/checkout";
	$parm = "$parm capture_day=1";
	$parm = "$parm cancel_return_url=".$siteUrl."/shop/basket";
	$parm = "$parm automatic_response_url=".$siteUrl."/mercanet/call_autoresponse";
	$this->logger->writeTimedString($parm);
	$path_bin = "/usr/local/bin/request";
	// exec("LD_PRELOAD=/lib/libc.so.6 $path_bin $parm",$res);
	exec("$path_bin $parm",$res);

	$tableau = explode("!", "$res[0]");
	
	$code = $tableau[1];
	$error = $tableau[2];
	$message = $tableau[3];

	if (( $code == "") && ($error == "" ) )
	{
		$form = "<BR><CENTER>erreur appel request</CENTER><BR>executable request non trouve $path_bin";
	} 
	else if ($code != 0){
		$form = "erreur: $error <br>";
	} 
	else {
		$form = $message."<br/>";
	}
	return $form;
    }
    function execute ( &$process, &$event )
    {
	
	$processParameters =& $process->attribute( 'parameter_list' );
	$processID = $process->attribute( 'id' );

	switch( $process->attribute( 'event_state') )
	{
		case EZ_GATEWAY_OBJECT_CREATED:
		{
        //__DEBUG__
            $this->logger->writeTimedString( 'mercanetGateway::EZ_GATEWAY_OBJECT_CREATED' );
        //___end____

			$thePayment = eZPaymentObject::fetchByProcessID( $processID );
			//if (is_object( $thePayment ) )
			if (is_object( $thePayment ) && $thePayment->approved() )
			{
				return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
			}
			else
			{
				return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
			}
			return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
		}
		break;
		case EZ_GATEWAY_OBJECT_NOT_CREATED:
        //__DEBUG__
            $this->logger->writeTimedString( 'mercanetGateway::EZ_GATEWAY_OBJECT_NOT_CREATED' );
        //___end____
		default:
		{
			$orderID = $processParameters['order_id'];
			$paymentObject =& $this->createPaymentObject( $processID, $orderID );

			if (is_object( $paymentObject ))
			{
				$paymentObject->store();
				$process->setAttribute( 'event_state', EZ_GATEWAY_OBJECT_CREATED );
				$form = $this->generateRequestForm( $orderID );
				$process->Template = array();
				$process->Template['templateName'] = 'design:call_request.tpl'; 
				$process->Template['templateVars'] = array( 'form' => $form );
			}
			else 
			{
				$this->logger->writeTimedString( "Unable to create 'eZPaymentObject'. Payment rejected." );
        //__DEBUG__
            $this->logger->writeTimedString( 'mercanetGateway::EZ_WORKFLOW_TYPE_STATUS_REJECTED' );
        //___end____
				return EZ_WORKFLOW_TYPE_STATUS_REJECTED;
			}
		}
		break;
	};
        //__DEBUG__
            $this->logger->writeTimedString( 'mercanetGateway::EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT' );
        //___end____
	return EZ_WORKFLOW_TYPE_STATUS_FETCH_TEMPLATE_REPEAT;
    }
    

}

eZPaymentGatewayType::registerGateway( EZ_PAYMENT_GATEWAY_TYPE_MERCANET, "mercanetgateway", "Mercanet" );

?>
