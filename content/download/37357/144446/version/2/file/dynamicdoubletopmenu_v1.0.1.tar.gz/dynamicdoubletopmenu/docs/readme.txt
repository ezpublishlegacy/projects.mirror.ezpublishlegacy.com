---------------------------------------------------------------
                      Dynamic Menu Extension
---------------------------------------------------------------

What is it?
-----------
This extension provides a dynamic tree menu, inspired from ezSystems scripts ( http://www.ez.no ) .
It also includes a basic rollover mecanism.

Installation
------------
- Unpack the archive in the folder 'extensions'
- The menu now has to be made available for siteaccesses.
  In order to achieve this, edit your siteaccess menu.ini.append overriding file ( folder settings/siteaccess/yourSiteaccess ) and add the line:
   AvailableMenuArray[]=DynamicDoubleTopRollover
  below section [MenuSettings]
- Activate the extension and clear your caches.
- Browse the menu design tab in ezpublish admin interface.
  Set the desired siteaccess, a new item should appear at the bottom, named "DynamicDoubleTopRollover".
  Select it and submit your choice.
- The Menu should now be available

Configuration
-------------
Menu.ini.append
- Root node: The root node of the tree menu.
- Delay: The delay for the dynamic children to disappear after they were moused out. Set in milliseconds
- Node exclusions: Some nodes can be excluded of the treemenu. Use [Exclude] section, Node attribute (array) to achieve this.
                   Excluded nodes don't appear in main menu, they're placed in an external <div>. The div style settings can then be modified in the template to handle different behaviors.
Rollover
  The menu handles some images as background. To use this feature, you need to add some attributes in the content classes shown. The current identifiers for attributes are:
  - attribute "menu_background_image", datatype "image". The background image to show instead of the standard text
  - attribute "menu_background_image_rollover", datatype "image". The rollover image that will be shown when the pointer is over the item.
  - attribute "label", datatype "text line". A label that appears in the menu instead of the standard shortname. This will allow menu-specific naming constraints. If not defined, the short-name is kept.

Bugs/Limits
------------
	
Author
------
Alexandre Nion (alexandre.nion@linagora.com)
  with an active testing help from Pascal Boyer