<?php /* #?ini charset="utf-8"?

[full_flash_video]
Source=node/view/full.tpl
MatchFile=full/flash_video.tpl
Subdir=templates
Match[class_identifier]=flash_video

[line_flash_video]
Source=node/view/line.tpl
MatchFile=line/flash_video.tpl
Subdir=templates
Match[class_identifier]=flash_video

[audio_full]
Source=node/view/full.tpl
MatchFile=full/audio.tpl
Subdir=templates
Match[class_identifier]=audio

[audio_line]
Source=node/view/line.tpl
MatchFile=line/audio.tpl
Subdir=templates
Match[class_identifier]=audio

[audio_listitem]
Source=node/view/listitem.tpl
MatchFile=listitem/audio.tpl
Subdir=templates
Match[class_identifier]=audio

[listitem_flash_video]
Source=node/view/listitem.tpl
MatchFile=listitem/flash_video.tpl
Subdir=templates
Match[class_identifier]=flash_video


*/ ?>