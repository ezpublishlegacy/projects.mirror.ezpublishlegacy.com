<?php
/*

[ModuleSettings]
ExtensionRepositories[]=ngflashvideo
ModuleList[]=ngflashvideo

*/
?>
