[xspfSettings]
MaxFlvTracksInXspf=50
MaxMp3TracksInXspf=30

# Cache Time in Seconds
#
# cache in seconds.
# "CacheTime = 0" turns off cacheing.
CacheTime=300