<?php

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = eZTemplate::factory();

$Module				= $Params['Module'];

$tokenArray = eZIG::fetchAll( );

$user = eZUser::currentUser();

$tpl->setVariable( 'connected_users', $tokenArray );


$Result = array();
$Result['left_menu'] = "design:ig/backoffice_left_menu.tpl";
$Result['content'] = $tpl->fetch( 'design:ig/connected_users.tpl' );
$Result['path'] = array( array( 'text' => ezpI18n::tr( 'extension/ig', 'Connected Users' ),
                                'url' => false ) );

return $Result;

