<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
	<name>ngpush/status</name>
	<message>
		<source>Waiting...</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Please wait, requesting...</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>This entry has already been pushed.</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Message is too long!</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>No defined push services.</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>You have %number characters remaining.</source>
		<translation type="unfinished"></translation>
	</message>
</context>
<context>
	<name>ngpush/ui</name>
	<message>
		<source>Insert hashtags</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Insert full link</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Insert short link</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Reset</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Push</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Push to all services</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Access token has been successfully obtained and saved.%brYou can continue using your Netgen Push application.</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>An error has occured.%brYour access token could not be saved, please contact your Netgen Push administrator.</source>
		<translation type="unfinished"></translation>
	</message>
	<message>
		<source>Close this window</source>
		<translation type="unfinished"></translation>
	</message>
</context>
</TS>
