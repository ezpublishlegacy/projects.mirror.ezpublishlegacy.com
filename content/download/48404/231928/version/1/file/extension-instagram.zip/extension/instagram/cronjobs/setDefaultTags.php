<?php

$cli->output( 'Instagram set default tags STARTED');

$IGIni = eZINI::instance( 'instagram.ini' );

$importUserID =  $IGIni->variable( 'ImportSettings', 'ImportUserID' );

$user = eZUser::fetch( $importUserID );

$db = eZDB::instance();

eZIGFunctionCollection::fetchAllImages( );

$allImageArray = eZIGPhotos::fetchAll();
 
$config = array(
    'client_id' => $IGIni->variable( 'instagram', 'ClientId' ),
    'client_secret' => $IGIni->variable( 'instagram', 'ClientSecret' ),
    'grant_type' => 'authorization_code',
    'redirect_uri' => $IGIni->variable( 'instagram', 'RedirectURI' )
);
$tokenArray = eZIG::fetchAll( );
if( count( $tokenArray ) > 0 )
{
	/*
	foreach( $tokenArray as $token )
	{
		$accessToken = $tokenArray[0]->attribute('accessToken');	
	}
	*/
	foreach( $tokenArray as $item )
	{
		$userArray[ $item->attribute('ig_id') ] = $item->attribute('accessToken');
	}

}
else
	return;

$defaultTagsArray = $IGIni->variable( 'DefaultTagsSettings', 'DefaultTags' );
//$defaultTagsArray = shuffle( $defaultTagsArray );
$setLikesArray = array( 10, 15, 20, 25, 30, 40, 50, 100 );
//Looping through all the collected images.
foreach( $allImageArray as $image )
{
	
	$instagram = new Instagram($config);
	$instagram->setAccessToken( $userArray[ $image->attribute('user_id')] );
	
	$tagCount = count( explode( " #", $image->attribute('tags') ) );

	$newTags = array();
	shuffle( $defaultTagsArray );
	foreach( $defaultTagsArray as $tag )
	{
		if( !strstr( $image->attribute('tags'), $tag) )
			$newTags[] = ' #'.$tag;
		if( ( count( $newTags ) + $tagCount ) > 29 )
			break;
	}
	
	for( $i=$image->attribute('likes');  $i > 0; $i=$i-5 )
	{
		if( in_array( $i, $setLikesArray ) )
		{ 
			$tag = $i."likes";
			//$newTags .= ( strstr( $image->attribute('tags'), $tag) ) ? '' :  ' #'.$tag;
			if( !strstr( $image->attribute('tags'), $tag) )
				$newTags[] = ' #'.$tag;
			if( ( count( $newTags ) + $tagCount ) > 29 )
				break;
		}
		
	}
	if( count( $newTags ) )
		$ret = $instagram->postMediaComment( $image->attribute('id'), implode("",$newTags) );

}

$cli->notice("Instagram set default tags FINISHED");

?>