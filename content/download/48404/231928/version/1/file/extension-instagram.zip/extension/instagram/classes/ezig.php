<?php

/*
CREATE TABLE `ezig` (
`id` INT( 11 ) NOT NULL ,
`accessToken` VARCHAR( 255 ) NOT NULL ,
`ig_username` VARCHAR( 255 ) NOT NULL ,
`ig_profile_picture` VARCHAR( 255 ) NOT NULL ,
`ig_full_name` VARCHAR( 255 ) NOT NULL ,
`ig_id` INT( 11 ) NOT NULL ,
PRIMARY KEY ( `id` )
) ENGINE = InnoDB 
*/


class eZIG extends eZPersistentObject
{
	function eZIG( $row )
	{
		$this->PersistentDataDirty = false;
		if ( is_numeric( $row ) )
		$row = $this->fetch( $row, false );
		$this->fill( $row );
	}

	static function definition()
	{
		return array ("fields" => array (
			"id" => array ('name' => 'ID', 'datatype' => 'integer', 'default' => 0, 'required' => true ),
			"accessToken" => array ('name' => "accessToken", 'datatype' => 'string', 'default' => '', 'required' => true ),
			"ig_username" => array ('name' => "ig_username", 'datatype' => 'string', 'default' => '', 'required' => true ),
			"ig_profile_picture" => array ('name' => "ig_profile_picture", 'datatype' => 'string', 'default' => '', 'required' => true ),
			"ig_full_name" => array ('name' => "ig_full_name", 'datatype' => 'string', 'default' => '', 'required' => true ),
			"ig_id" => array ('name' => "ig_id", 'datatype' => 'integer', 'default' => 0, 'required' => true )		),
		"keys" => array( "id" ),
		"increment_key" => "id",
		"class_name" => "eZIG",
		"name" => "ezig" );
	}
	static function fetch( $ig_id, $asObject = true )
	{
		return eZPersistentObject::fetchObject( eZIG::definition(),
		null,
		array( "ig_id" => $ig_id ),
		$asObject );
	}


	static function fetchAll(  $asObject = true )
    {
        return eZPersistentObject::fetchObjectList( eZIG::definition(),
                                                    null,
                                                    null,
                                                    array( "id" => "desc" ), null,
                                                    $asObject );
		
	
    }	
}
