<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=instagram
ModuleList[]=ig


*/ ?>
