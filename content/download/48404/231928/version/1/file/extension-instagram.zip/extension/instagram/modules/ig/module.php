<?php

$Module = array( 'name' => 'ig' );

$ViewList = array();

$ViewList['feed'] = array(
	"functions"=>array('read'), 
	'script'	=> 'feed.php',
    'default_navigation_part' => 'instagramnavigationpart',
	'params'	=> array( 'UserID' ),
    'unordered_params' => array( 'offset' => 'Offset' )
);

$ViewList['connect_user'] = array(
	"functions"=>array('read'), 
    'default_navigation_part' => 'instagramnavigationpart',
	'script'	=> 'connect_user.php'
);

$ViewList['connected_users'] = array(
	"functions"=>array('read'), 
    'default_navigation_part' => 'instagramnavigationpart',
	'script'	=> 'connected_users.php'
);
$ViewList['view'] = array(
	'script'	=> 'view.php'
);

$FunctionList = array();
$FunctionList['read'] = array();

?>
