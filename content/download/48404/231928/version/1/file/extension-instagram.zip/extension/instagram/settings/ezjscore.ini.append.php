<?php /* #?ini charset="utf-8"?

# some ezjsc functions might be handy in the future
# so I leave this for later

#[ezigServer]
#FunctionList[]=ezig
#
#[ezjscServer_ezig]
#Class=ezjscoreNGPush
#TemplateFunction=false
#File=extension/ngpush/classes/ezjscorengpush.php
*/ ?>
