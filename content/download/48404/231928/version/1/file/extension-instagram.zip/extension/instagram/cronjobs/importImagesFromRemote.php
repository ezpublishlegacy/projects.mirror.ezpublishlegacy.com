<?php

$cli->output( 'Instagram Photosync started');

// from URL:
// http://share.ez.no/blogs/sebastiaan-van-der-vliet/importing-image-objects-from-a-rss-feed
//call this script as follows:
//php extension/[name of your extension]/scripts/importrssimages.php --node=43 --feed="http://api.flickr.com/services/feeds/photos_public.gne?id=11398192@N02&lang=en-us&format=rss_200"

//You could put the import user id in a config file

$IGIni = eZINI::instance( 'instagram.ini' );

$importUserID =  $IGIni->variable( 'ImportSettings', 'ImportUserID' );

$user = eZUser::fetch( $importUserID );

$db = eZDB::instance();

$importNodeID = $IGIni->variable( 'ImportSettings', 'ImportNodeID' );


if ( $importNodeID )
{
    $folderID = $importNodeID;
    $folderNode = eZContentObjectTreeNode::fetch( $folderID );
    
    if (!$folderNode)
    {
        $cli->error( "Folder with ID ".$folderID." does not exist." );
    }
}
else
{
     $cli->error( "Specify a folder NodeID where the image objects should be stored." );
}

// fetch all images via IG api and store them to the database
eZIGFunctionCollection::fetchAllImages( );

$allConnectedUsers = eZIG::fetchAll();
$userParentFolder = array();
foreach( $allConnectedUsers as $connectedUser )
{
	$params = array();
	$params['class_identifier'] = 'folder';
	$params['creator_id'] = $user->attribute( 'contentobject_id' ); 
	$params['parent_node_id'] = $folderID;
	$attributesData = array();   
	$attributesData['name'] = ( trim( $connectedUser->attribute('ig_username') ) != "" ) ? $connectedUser->attribute('ig_username') : $connectedUser->attribute('ig_id'); 
	$params['attributes'] = $attributesData;
	$params['remote_id'] = "IG_USER_FOLDER_".$connectedUser->attribute('ig_id');
	
	$contentObject = eZContentObject::fetchByRemoteID( $params['remote_id'] );

	if( $contentObject instanceof eZContentObject )
	{
		eZContentFunctions::updateAndPublishObject( $contentObject, $params );
		$userFolder = $contentObject;
	}
	else 
	{	
		$userFolder = eZContentFunctions::createAndPublishObject( $params );
	}
	
	$userParentFolder[$connectedUser->attribute('ig_id')] = $userFolder->attribute('main_node_id');
}
// print_R($userParentFolder);
$allImageArray = eZIGPhotos::fetchAllUnimported();

//Looping through all the collected images.
$limit = 0;
foreach( $allImageArray as $image )
{
	$tmp = unserialize( $image->images );
	$item['image'] = $tmp['standard_resolution']['url'];

	//strip GET stuff.
    $item['image']=preg_replace('/\\?.*/', '', $item['image']);
    
    if ( $item['image'] )
    {
        //this part is mostly based on http://share.ez.no/learn/ez-publish/creating-ez-publish-objects-in-php/
        $params = array();
        $params['class_identifier'] = 'image';
        $params['creator_id'] = $user->attribute( 'contentobject_id' ); 
		$params['parent_node_id'] = ( $userParentFolder[ $image->attribute('user_id') ] > 0 ) ? $userParentFolder[ $image->attribute('user_id') ] : $folderID;
		
		//things might be better if the function eZImageAliasHandler::initializeFromFile would use
        //if ( !@fopen($f ilename,"r") ) instead of if ( !file_exists( $filename ) ) 
        //so image files could be retrieved across servers. Now we need to store the files locally twice.
        
        $sys = eZSys::instance();
        $storage_dir = $sys->storageDirectory();
        $tempDir = $storage_dir . '/instagram/orginal/'.$folderID.'/';
        $imageName = basename( $item['image'] );
        if ( file_exists( $tempDir.$imageName) )
        {
            $cli->notice("Item already exists");
            continue;
        }
    
        if ( @fopen($item['image'],"r") )
        {
            $buf = eZHTTPTool::sendHTTPRequest( $item['image'], 80, false, 'eZ Publish', false );
            $header = false;
            $body = false;
            if ( eZHTTPTool::parseHTTPResponse( $buf, $header, $body ) )
            {
                eZFile::create( $imageName, $tempDir, $body );
            }
            $sourceMimeData = eZMimeType::findByFileContents( $imageName );
        }
        $params ['storage_dir' ] = $tempDir;    
        $item['image'] = $imageName;
        //extra code ends here

        $attributesData = array(); 
        $attributesData['name'] = ( trim( $image->attribute('caption') ) != "" ) ? $image->attribute('caption') : $image->attribute('id'); 
        $attributesData['image'] = $sourceMimeData['filename']; 
        
        $XMLContent = strip_tags('');
        $parser = new eZSimplifiedXMLInputParser( false, true, eZXMLInputParser::ERROR_ALL, true );
        $parser->setParseLineBreaks( true );
        $document = $parser->process( $XMLContent );
        $xmlString = eZXMLTextType::domString( $document );
        $attributesData['caption'] = $xmlString;
        
        $params['attributes'] = $attributesData;


		$params['remote_id'] = "IG_IMAGE_".$image->id;
		
		$imageObject = eZContentObject::fetchByRemoteID( $params['remote_id'] );
	
		if( $imageObject instanceof eZContentObject )
		{
			eZContentFunctions::updateAndPublishObject( $imageObject, $params );
		}
		else 
		{	
			$imageObject = eZContentFunctions::createAndPublishObject( $params );
		}

        if ($imageObject)
        {
        	
            $cli->notice("Created image IG ID: ".$image->id ." -> ContentObjectID: ".$imageObject->attribute('id') );
            $image->setAttribute('contentobject_id', $imageObject->attribute('id') );
            $image->store();
        }
    }
  	if( $limit > 100 )
  		break;
  		
    $limit++;
  	  
}

$cli->notice("Instagram Photosync is done.");

?>