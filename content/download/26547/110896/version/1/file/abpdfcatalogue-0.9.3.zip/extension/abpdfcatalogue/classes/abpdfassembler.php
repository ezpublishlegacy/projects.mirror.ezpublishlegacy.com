<?php

/**

    PDF catalogue extension for eZ Publish - Class abPDFAssembler

    Copyright (C) 2010 Alexander Block

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

require_once( eZExtension::baseDirectory() . '/abpdfcatalogue/lib/FPDI/fpdi.php' );

abstract class abPDFAssembler extends PDFBookmark
{

    private $documentList    = array(),
            $creatingTOC     = false,
            $currentPage     = 0,
            $currentDocument = '',
            $pageCount       = 0,
            $pageOrientation = 'P',
            $pageFormat      = 'A4';

    protected      $metaData = array(),
              $tocMaxEntries = 20,
                 $tocMargins = array( '15', '15', '15' ); // left, top and right margin in mm

    const DOCUMENT_TYPE_TOC  = 1,
          DOCUMENT_TYPE_FILE = 2;

    abstract protected function putCurrentPageNumber( $page, $pagecount );

    abstract protected function putTableOfContentsEntry( $index, $title, $pagenumber );

    abstract protected function putPDFMetaData();

    abstract protected function putTableOfContentsTitle();

    public function __construct( $orientation = 'P', $format = 'A4' )
    {
        $this->pageOrientation = $orientation;
        $this->pageFormat      = $format;
        $this->creatingTOC     = false;

        parent::__construct( $this->pageOrientation, 'mm', $format );
    }

    public function usePDFCompression( $compression )
    {
        if ( $compression == true )
        {
            $this->SetCompression( true );
        }
        else
        {
            $this->SetCompression( false );
        }
    }

    public function AddPage( $enableTOC = true, $orientation = false )
    {
        $orientation = $orientation != false ? $orientation : $this->pageOrientation;

        parent::addPage( $orientation );

        if ( $enableTOC === true )
        {
            $this->currentPage++;
        }
    }

    public function Footer()
    {
        if ( is_array( $this->currentDocument ) &&
             array_key_exists( 'toc', $this->currentDocument ) &&
             $this->currentDocument['toc'] === true
           )
        {
            $this->putCurrentPageNumber( $this->currentPage, $this->pageCount );
        }
    }

    public function AcceptPageBreak()
    {
        if ( $this->creatingTOC )
        {
            $this->AddPage();
        }
    }

    public function setTableOfContentsMargins( $marginArray )
    {
        if ( !is_array( $marginArray ) || count( $marginArray ) != 3 )
        {
            return false;
        }
        for ( $i = 0; $i < 3; ++$i )
        {
            if ( is_numeric( $marginArray[$i] ) && $marginArray[$i] >= 0 &&
                 $marginArray[$i] < 100
               )
            {
                $this->tocMargins[$i] = (int)$marginArray[$i];
            }
        }
        return true;
    }

    public function setTableOfContentsMaxEntries( $maxEntries )
    {
        $this->tocMaxEntries = $maxEntries;
    }

    public function setDocumentList( $documentList )
    {
        $this->documentList = $documentList;

        $this->SetAutoPageBreak( false );
    }

    public function setMetaData( $metaData )
    {
        if ( is_array( $metaData ) )
        {
            $this->metaData = $metaData;
        }
        else
        {
            eZDebug::writeDebug( 'Meta data is expected to be an array', __METHOD__ );
        }
    }

    public function mergeDocuments()
    {
        $this->putPDFMetaData();

        $this->currentPage = 0;

        foreach ( $this->documentList as $document )
        {
            if ( array_key_exists( 'type', $document ) )
            {
                switch ( $document['type'] )
                {
                    case self::DOCUMENT_TYPE_TOC:
                    {
                        $backgroundFile = false;
                        if ( array_key_exists( 'bg', $document ) )
                        {
                            $backgroundFile = $document['bg'];
                        }
                        $this->addTableOfContents( $backgroundFile );
                    }
                    break;
                    case self::DOCUMENT_TYPE_FILE:
                    {
                        $this->addDocument( $document );
                    }
                    break;
                    default:
                    {
                        eZDebug::writeDebug( 'Unsupported document type: ' . $document['type'], __METHOD__ );
                    }
                    break;
                }
            }
            else
            {
                eZDebug::writeDebug( 'Document type not set', __METHOD__ );
            }
        }
    }

    protected function addDocument( $document )
    {
        if ( !array_key_exists( 'file', $document ) )
        {
            eZDebug::writeDebug( 'No file to add document', __METHOD__ );
            return;
        }

        $pagecount = $this->setSourceFile( $document['file'] );

        for ( $i = 1; $i <= $pagecount; $i++ )
        {
            $writeTOCLine = true;
            if ( array_key_exists( 'toc', $document ) )
            {
                $writeTOCLine = $document['toc'];
            }
            $templateIndex = $this->importPage( $i );
            $templateSize  = $this->getTemplatesize( $templateIndex );

            $this->AddPage( $writeTOCLine, ( $templateSize['h'] > $templateSize['w'] ? 'P' : 'L' ) );

            if ( $writeTOCLine )
            {
                if ( array_key_exists( 'title', $document ) )
                {
                    $this->addPDFBookmark( $document['title'] );
                }
                else
                {
                    eZDebug::writeDebug( 'Missing title for document, can not create entry in table of contents', __METHOD__ );
                }
            }

            $this->currentDocument = $document;

            $this->useTemplate( $templateIndex );
        }
    }

    protected function addTableOfContentsPage( $backgroundFile = false )
    {
        $tplidx = false;

        if ( $backgroundFile !== false )
        {
            $pagecount = $this->setSourceFile( $backgroundFile );
            $tplidx    = $this->importPage( 1 );
        }

        $this->AddPage();

        if ( $tplidx !== false )
        {
            $this->useTemplate( $tplidx );
        }
    }

    protected function addTableOfContents( $backgroundFile )
    {
        $this->creatingTOC = true;

        $this->SetMargins( $this->tocMargins[0], $this->tocMargins[1], $this->tocMargins[2] );

        $this->addTableOfContentsPage( $backgroundFile );

        parent::BookmarkUTF8( $this->putTableOfContentsTitle() );

        $tocItemCount = 1;
        foreach ( $this->documentList as $document )
        {
            if ( !array_key_exists( 'toc', $document ) )
            {
                continue;
            }
            if ( $document['toc'] === true )
            {
                if ( !array_key_exists( 'title', $document ) || !array_key_exists( 'file', $document ) )
                {
                    continue;
                }
                ++$tocItemCount;
            }
        }

        $index        = 1;
        $pagenumber   = 1;
        $entryCounter = 0;

        foreach ( $this->documentList as $document )
        {
            if ( !array_key_exists( 'toc', $document ) )
            {
                eZDebug::writeDebug( 'No information about table of contents available for current document. Skipping.',
                                     __METHOD__
                                   );
                continue;
            }
            if ( $document['toc'] === true )
            {
                if ( !array_key_exists( 'title', $document ) || !array_key_exists( 'file', $document ) )
                {
                    eZDebug::writeWarning( 'Missing information about document file and title required to create an entry in the table of contents',
                                           __METHOD__
                                         );
                    continue;
                }
                $this->putTableOfContentsEntry( ++$index, $document['title'], $pagenumber  );
                $pagenumber += $this->setSourceFile( $document['file'] );
                ++$entryCounter;
            }
            if ( $entryCounter == $this->tocMaxEntries && $index < $tocItemCount )
            {
                $entryCounter = 0;
                $this->addTableOfContentsPage( $backgroundFile );
            }
        }

        $this->pageCount   = ( $pagenumber - 1 );
        $this->currentPage = 0;
        $this->creatingTOC = false;
    }

    protected function addPDFBookmark( $text )
    {
        parent::BookmarkUTF8( $text );
    }

}

?>