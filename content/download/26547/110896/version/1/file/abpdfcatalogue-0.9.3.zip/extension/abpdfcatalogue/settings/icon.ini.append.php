<?php /* #?ini charset="utf-8"?

#[ClassIcons]
#ClassMap[pdfcatalogue]=filesystems/folder_txt.png
#ClassMap[pdfcataloguechapter]=filesystems/folder_txt.png
#ClassMap[pdfcataloguedocument]=mimetypes/pdf.png

*/ ?>
