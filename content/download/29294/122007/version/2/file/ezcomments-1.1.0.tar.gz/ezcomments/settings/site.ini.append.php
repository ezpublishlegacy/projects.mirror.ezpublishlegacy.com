<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezcomcomments

[RegionalSettings]
TranslationExtensions[]=ezcomments

*/ ?>