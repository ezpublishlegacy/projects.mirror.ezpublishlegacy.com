<!DOCTYPE TS><TS>
<context>
    <name>&quot;design/standard/navigator&quot;</name>
    <message>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
</context>
<context>
    <name>&quot;design/standard/node/view&quot;</name>
    <message>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
</context>
<context>
    <name>&apos;design/standard/node/view&apos;</name>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Mise à jour</translation>
    </message>
</context>
<context>
    <name>design/admin/layout</name>
    <message>
        <source>Content</source>
        <translation>Contenu</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Boutique</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Utilisateurs</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Configuration</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personnel</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Page de garde</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Plan du site</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Corbeille</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mes brouillons</translation>
    </message>
    <message>
        <source>My notification settings</source>
        <translation>Mes paramètres de notification</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Mes signets</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Collaboration</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Modifier le mot de passe</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Classes</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sections</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Modèles</translation>
    </message>
    <message>
        <source>RAD</source>
        <translation>&quot;R.A.D.&quot;</translation>
    </message>
    <message>
        <source>Workflows</source>
        <translation>Workflows</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Déclencheurs</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation>Notification</translation>
    </message>
    <message>
        <source>Search stats</source>
        <translation>Statistiques de recherche</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Info système</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Liste des commandes</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Type de TVA</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Rabais</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Rôles</translation>
    </message>
</context>
<context>
    <name>design/shop</name>
    <message>
        <source>Payment was canceled. Try to buy again.</source>
        <translation>Le payment a été annulé. Essayez d&apos;acheter de nouveau.</translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max file size</source>
        <translation>Taille maximum de fichier</translation>
    </message>
    <message>
        <source>Default value</source>
        <translation>Valeur par défaut</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Vide</translation>
    </message>
    <message>
        <source>Current date</source>
        <translation>Date actuelle</translation>
    </message>
    <message>
        <source>Current datetime</source>
        <translation>Date et heure actuelles</translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation>Choix multiples</translation>
    </message>
    <message>
        <source>Option style</source>
        <translation>Style de l&apos;option</translation>
    </message>
    <message>
        <source>Checkbox style</source>
        <translation>Style de la case à cocher</translation>
    </message>
    <message>
        <source>Enum Element</source>
        <translation>Élément d&apos;énumération</translation>
    </message>
    <message>
        <source>Enum Value</source>
        <translation>Valeur de l&apos;énumération</translation>
    </message>
    <message>
        <source>New Enum Element</source>
        <translation>Nouvel élément d&apos;énumération</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Suprimmer la sélection</translation>
    </message>
    <message>
        <source>Min float value</source>
        <translation>Valeur flottante minimum</translation>
    </message>
    <message>
        <source>Max float value</source>
        <translation>Valeur flottante maximum</translation>
    </message>
    <message>
        <source>Min integer value</source>
        <translation>Valeur entière minimum</translation>
    </message>
    <message>
        <source>Max integer value</source>
        <translation>Valeur entière maximum</translation>
    </message>
    <message>
        <source>Media player type</source>
        <translation>Type de lecteur multimedia</translation>
    </message>
    <message>
        <source>Flash</source>
        <translation>Flash</translation>
    </message>
    <message>
        <source>QuickTime</source>
        <translation>QuickTime</translation>
    </message>
    <message>
        <source>Real player</source>
        <translation>Real Player</translation>
    </message>
    <message>
        <source>Windows media player</source>
        <translation>Windows media player</translation>
    </message>
    <message>
        <source>Default name</source>
        <translation>Nom par défaut</translation>
    </message>
    <message>
        <source>VAT type</source>
        <translation>Type TVA</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Prix TTC</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Prix HT</translation>
    </message>
    <message>
        <source>Max string length</source>
        <translation>Longueur maximum de la chaîne</translation>
    </message>
    <message>
        <source>Preferred number of rows</source>
        <translation>Nombre optimal de lignes</translation>
    </message>
    <message>
        <source>Current time</source>
        <translation>Temps présent</translation>
    </message>
</context>
<context>
    <name>design/standard/class/edit</name>
    <message>
        <source>Editing class - %1</source>
        <translation>Édition de la classe - %1</translation>
    </message>
    <message>
        <source>Last modified by</source>
        <translation>Dernière modification par</translation>
    </message>
    <message>
        <source>on</source>
        <translation>sur</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation>Modèle de nom d&apos;objet</translation>
    </message>
    <message>
        <source>Member of groups</source>
        <translation>Membre des groupes</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Add to group</source>
        <translation>Ajouter au groupe</translation>
    </message>
    <message>
        <source>Remove from groups</source>
        <translation>Supprimer des groupes</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Entrée non valide</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>L&apos;entrée a été enregistrée</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Attributs</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Obligatoire</translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation>Interrogeable</translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation>Collecteur d&apos;information</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Abaisser</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Monter</translation>
    </message>
    <message>
        <source>Datatypes</source>
        <translation>Datatypes</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Appliquer</translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation>Abandonner les modifications</translation>
    </message>
    <message>
        <source>Editing class group - %1</source>
        <translation>Édition du groupe de classe - %1</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Modifié par</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abandonner</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these classes?</source>
        <translation>Voulez-vous vraiment supprimer ces classes?</translation>
    </message>
    <message>
        <source>Removing class %1 will remove %2!</source>
        <translation>Supprimer la classe %1 supprimera %2!</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these class groups?</source>
        <translation>Voulez-vous vraiment supprimer ces groupes de classes</translation>
    </message>
    <message>
        <source>Removing class group %1 will remove the classes %2!</source>
        <translation>Supprimer le groupe %1 supprimera les classes %2!</translation>
    </message>
</context>
<context>
    <name>design/standard/class/list</name>
    <message>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <source>Class groups</source>
        <translation>Groupes de classes</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificateur</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Nouveau groupe</translation>
    </message>
</context>
<context>
    <name>design/standard/class/view</name>
    <message>
        <source>No classes in </source>
        <translation>Aucune classe dans </translation>
    </message>
    <message>
        <source>Classes in</source>
        <translation>Classes dans</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificateur</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>New class</source>
        <translation>Nouvelle classe</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration</name>
    <message>
        <source>Group list for &apos;%1&apos;</source>
        <translation>Liste des groupes pour &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No items in group.</source>
        <translation>Aucun item dans le groupe.</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Groupes</translation>
    </message>
    <message>
        <source>Approval</source>
        <translation>Approbation</translation>
    </message>
    <message>
        <source>%1 awaits approval by editor</source>
        <translation>%1 attend l&apos;approbation de l&apos;éditeur</translation>
    </message>
    <message>
        <source>%1 was approved for publishing</source>
        <translation>%1 a été approuvé pour publication</translation>
    </message>
    <message>
        <source>%1 was not approved for publishing</source>
        <translation>%1 n&apos;a pas été approuvé pour publication</translation>
    </message>
    <message>
        <source>%1 was deferred for reediting</source>
        <translation>%1 a été reporté pour réédition</translation>
    </message>
    <message>
        <source>%1 awaits your approval</source>
        <translation>%1 attend de votre approbation</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Read</source>
        <translation>Lu</translation>
    </message>
    <message>
        <source>Unread</source>
        <translation>Non lu</translation>
    </message>
    <message>
        <source>Inactive</source>
        <translation>Inactif</translation>
    </message>
    <message>
        <source>Posted: %1</source>
        <translation>Posté : %1</translation>
    </message>
    <message>
        <source>No new items to be handled.</source>
        <translation>Aucun nouvel item à manipuler</translation>
    </message>
</context>
<context>
    <name>design/standard/collaboration/approval</name>
    <message>
        <source>Approval</source>
        <translation>Approbation</translation>
    </message>
    <message>
        <source>The content object %1 awaits approval before it can be published.</source>
        <translation>L&apos;objet de contenu %1 attend l&apos;approbation pour publication</translation>
    </message>
    <message>
        <source>If you wish you may send a message to the person approving it?</source>
        <translation>Voulez-vous envoyer un message à la personne qui l&apos;approuvera ?</translation>
    </message>
    <message>
        <source>The content object %1 needs your approval before it can be published.</source>
        <translation>L&apos;objet de contenu %1 doit être approuvé avant d&apos;être publié.</translation>
    </message>
    <message>
        <source>Do you approve of the content object being published?</source>
        <translation>Approuvez-vous la publication de l&apos;objet de contenu ?</translation>
    </message>
    <message>
        <source>The content object %1 was approved and will be published once the publishing workflow continues.</source>
        <translation>L&apos;objet de contenu %1 a été approuvé et sera publié bientôt.</translation>
    </message>
    <message>
        <source>The content object %1 was not approved and will be archived. If you wish you may publish a new version of the object by clicking the edit link.</source>
        <translation>L&apos;objet de contenu %1 n&apos;a pas été approuvé et sera archivé. Vous pouvez en produire une nouvelle version en cliquant sur le lien d&apos;édition</translation>
    </message>
    <message>
        <source>Edit the object</source>
        <translation>Éditer l&apos;objet</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but is available as a draft again.</source>
L&apos;objet de contenu %1 a été refusé et est disponible à nouveau en brouillon.</translation>
    </message>
    <message>
        <source>You must reedit the draft and publish it again for the approval to continue.</source>
        <translation>Vous devez rééditer le brouillon et le retourner pour approbation pour continuer.</translation>
    </message>
    <message>
        <source>If the approver finds the new changes satisfying the object will be accepted.</source>
        <translation>Si l&apos;approbateur est satisfait des modifications l&apos;objet sera accepté.</translation>
    </message>
    <message>
        <source>The content object %1 was not accepted but will be available as a draft for the author.</source>
        <translation>L&apos;objet de contenu %1 a été refusé mais sera disponible en brouillon pour l&apos;auteur.</translation>
    </message>
    <message>
        <source>The author must reedit the draft and publish it again for the approval to continue.</source>
        <translation>L&apos;auteur doit rééditer le brouillon et le republier pour que l&apos;approbation continue.</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <source>Add Comment</source>
        <translation>Ajouter un commentaire</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation>Approuver</translation>
    </message>
    <message>
        <source>Deny</source>
        <translation>Refuser</translation>
    </message>
    <message>
        <source>Pushback</source>
        <translation>Retourner</translation>
    </message>
    <message>
        <source>Participants</source>
        <translation>Participants</translation>
    </message>
    <message>
        <source>Content object class - %1</source>
        <translation>Objet de contenu - %1</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>Messages</translation>
    </message>
</context>
<context>
    <name>design/standard/content</name>
    <message>
        <source>Are you sure you want to remove this translation?</source>
        <translation>Êtes-vous certains de vouloir supprimer cette traduction?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Change translation for content</source>
        <translation>Modifier la traduction pour le contenu</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to change to or enter a new custom one in the input fields.</source>
        <translation>Sélectionnez une des traductions de la liste pour la modifier ou entrez-en une personnalisée dans le champs.</translation>
    </message>
    <message>
        <source>New translation for content</source>
        <translation>Nouvelle traduction pour le contenu</translation>
    </message>
    <message>
        <source>Pick one of the translations from the list to add or enter a new custom one in the input fields.</source>
        <translation>Sélectionnez une des traductions de la liste pour l&apos;ajouter ou entrez-en une personnalisée dans le champs.</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personnalisé</translation>
    </message>
    <message>
        <source>Name of translation</source>
        <translation>Nom de la traduction</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Paramètre de localisation</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Modifier</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Créer</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Traductions de contenu</translation>
    </message>
    <message>
        <source>Below you&apos;ll find a list of active translations which content objects may be translated into.</source>
        <translation>Vous trouverez, ci-dessous, une liste de traductions disponibles pour les objets de contenu.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Langage</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Pays</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>design/standard/content/copy</name>
    <message>
        <source>Copying %1</source>
        <translation>Copie de %1</translation>
    </message>
    <message>
        <source>Version count is %1, and current version is %2.</source>
        <translation>le nombre de versions est %1 et la version courante est %2</translation>
    </message>
    <message>
        <source>Copy all versions</source>
        <translation>Copier toutes les versions</translation>
    </message>
    <message>
        <source>Copy current version</source>
        <translation>Copier la version courante</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/standard/content/create</name>
    <message>
        <source>Create new</source>
        <translation>Céer nouveau</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>Courriel</translation>
    </message>
    <message>
        <source>New author</source>
        <translation>Nouvel auteur</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Suprimmer la sélection</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Nom du fichier</translation>
    </message>
    <message>
        <source>MIME Type</source>
        <translation>Type MIME</translation>
    </message>
    <message>
        <source>Filesize</source>
        <translation>Taille du fichier</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Year</source>
        <translation>Année</translation>
    </message>
    <message>
        <source>Month</source>
        <translation>Mois</translation>
    </message>
    <message>
        <source>Day</source>
        <translation>Jour</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation>Heure</translation>
    </message>
    <message>
        <source>Minute</source>
        <translation>Minute</translation>
    </message>
    <message>
        <source>Image filename</source>
        <translation>Nom de fichier de l&apos;image</translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation>Texte alternatif de l&apos;image</translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation>Supprimer l&apos;image</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <source>Quality</source>
        <translation>Qualité</translation>
    </message>
    <message>
        <source>High</source>
        <translation>Haute</translation>
    </message>
    <message>
        <source>Best</source>
        <translation>Meilleure</translation>
    </message>
    <message>
        <source>Low</source>
        <translation>Basse</translation>
    </message>
    <message>
        <source>Autohigh</source>
        <translation>Haute résolution automatique</translation>
    </message>
    <message>
        <source>Autolow</source>
        <translation>Basse résolution automatique</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Jouer automatiquement</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Boucle</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Contrôleur</translation>
    </message>
    <message>
        <source>Controls</source>
        <translation>Contrôles</translation>
    </message>
    <message>
        <source>ImageWindow</source>
        <translation>Fenêtre image</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Tout</translation>
    </message>
    <message>
        <source>ControlPanel</source>
        <translation>Panneau de configuration</translation>
    </message>
    <message>
        <source>InfoVolumePanel</source>
        <translation>Panneau InfoVolume</translation>
    </message>
    <message>
        <source>InfoPanel</source>
        <translation>Panneau info</translation>
    </message>
    <message>
        <source>Existing filename</source>
        <translation>Nom actuel du fichier</translation>
    </message>
    <message>
        <source>Existing orignal filename</source>
        <translation>Nom orginal actuel du fichier</translation>
    </message>
    <message>
        <source>Existing mime/type</source>
        <translation>mime/type actuel</translation>
    </message>
    <message>
        <source>No relation</source>
        <translation>Aucune relation</translation>
    </message>
    <message>
        <source>Replace object</source>
        <translation>Remplacer l&apos;objet</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Supprimer l&apos;objet</translation>
    </message>
    <message>
        <source>Find object</source>
        <translation>Trouver un objet</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <source>New option</source>
        <translation>Nouvelle option</translation>
    </message>
    <message>
        <source>Start value</source>
        <translation>Valeur de départ</translation>
    </message>
    <message>
        <source>Stop value</source>
        <translation>Valeur d&apos;arrêt</translation>
    </message>
    <message>
        <source>Step value</source>
        <translation>Valeur des incréments</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <source>User ID</source>
        <translation>ID de l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Nom d&apos;usager</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Confirmer le mot de passe</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <source>Price:</source>
        <translation>Prix :</translation>
    </message>
    <message>
        <source>Your price:</source>
        <translation>Votre prix :</translation>
    </message>
    <message>
        <source>You save:</source>
        <translation>Vous économisez :</translation>
    </message>
    <message>
        <source>Price</source>
        <translation>Prix</translation>
    </message>
    <message>
        <source>User account information</source>
        <translation>Information sur le compte utilisateur</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Courriel</translation>
    </message>
</context>
<context>
    <name>design/standard/content/edit</name>
    <message>
        <source>Collected information from %1</source>
        <translation>Information collectée à partir de %1</translation>
    </message>
    <message>
        <source>The following information was collected:</source>
        <translation>L&apos;information suivante a été collectée:</translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation>Éditer %1 - %2</translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation>Envoyer pour publication</translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation>Enregistrer le brouillon</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abandonner</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>New draft</source>
        <translation>Nouveau brouillon</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Emplacement</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Trier par</translation>
    </message>
    <message>
        <source>Ordering</source>
        <translation>Classement</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Déplacer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publié</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Depth</source>
        <translation>Profondeur</translation>
    </message>
    <message>
        <source>Class Identifier</source>
        <translation>Identifiant de classe</translation>
    </message>
    <message>
        <source>Class Name</source>
        <translation>Nom de classe</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
    <message>
        <source>Add locations</source>
        <translation>Ajouter des emplacements</translation>
    </message>
    <message>
        <source>Object info</source>
        <translation>Information sur l&apos;objet</translation>
    </message>
    <message>
        <source>Created</source>
        <translation>Créé</translation>
    </message>
    <message>
        <source>Not yet published</source>
        <translation>Pas encore publié</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versions</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Édition</translation>
    </message>
    <message>
        <source>Current</source>
        <translation>Courant</translation>
    </message>
    <message>
        <source>Manage</source>
        <translation>Gérer</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Prévisualisation</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>%1 (No locale information available)</source>
        <translation>%1 (Aucun paramètre de localisation n&apos;est disponible)</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objets en relation</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Trouver</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Validation failed</source>
        <translation>La validion a échoué</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Entrée non valide</translation>
    </message>
    <message>
        <source>Location did not validate</source>
        <translation>Emplacement non valide</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>L&apos;entrée a été enregistrée</translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation>Voulez-vous vraiment supprimer le brouillon?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/standard/content/search</name>
    <message>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <source>For more options try the %1Advanced search%2</source>
        <translation>Pour plus d&apos;options, essayez la %1Recherche avancée%2</translation>
    </message>
    <message>
        <source>The following words were excluded from the search:</source>
        <translation>Les mots suivants ont été excus de la recherche :</translation>
    </message>
    <message>
        <source>No results were found when searching for &quot;%1&quot;</source>
        <translation>Aucun résultat n&apos;a été trouvé pour &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Search for &quot;%1&quot; returned %2 matches</source>
        <translation>%2 résultats pour la recherche de &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Recherche avancée</translation>
    </message>
    <message>
        <source>Search all the words</source>
        <translation>Rechercher tous les mots</translation>
    </message>
    <message>
        <source>Search the exact phrase</source>
        <translation>Rechercher la phrase exacte</translation>
    </message>
    <message>
        <source>Search with at least one of the words</source>
        <translation>Rechercher avec au moins l&apos;un des mots</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Any class</source>
        <translation>N&apos;importe quelle classe</translation>
    </message>
    <message>
        <source>Class attribute</source>
        <translation>Attribut de classe</translation>
    </message>
    <message>
        <source>Update attributes</source>
        <translation>Mettre à jour les attributs</translation>
    </message>
    <message>
        <source>In</source>
        <translation>Dans</translation>
    </message>
    <message>
        <source>Any section</source>
        <translation>N&apos;importe quelle section</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Publié</translation>
    </message>
    <message>
        <source>Any time</source>
        <translation>N&apos;importe quand</translation>
    </message>
    <message>
        <source>Last day</source>
        <translation>Dernier jour</translation>
    </message>
    <message>
        <source>Last week</source>
        <translation>Dernière semaine</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Dernier mois</translation>
    </message>
    <message>
        <source>Last three months</source>
        <translation>Derniers trois mois</translation>
    </message>
    <message>
        <source>Last year</source>
        <translation>Dernière année</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
</context>
<context>
    <name>design/standard/content/tipafriend</name>
    <message>
        <source>Tip a friend</source>
        <translation>Suggérer à un ami</translation>
    </message>
    <message>
        <source>The message was sent.</source>
        <translation>Le message a été envoyé.</translation>
    </message>
    <message>
        <source>Click here to return to the original page.</source>
        <translation>Cliquez ici pour retourner à la page d&apos;origine.</translation>
    </message>
    <message>
        <source>The message was not sent.</source>
        <translation>Le message n&apos;a pas été envoyé.</translation>
    </message>
    <message>
        <source>The message was not sent due to an unknown error. Please notify the site administrator about this error.</source>
        <translation>Le message n&apos;a pas été envoyé car une erreur inconnue est survenue. S.V.P. avisez l&apos;administrateur du Site.</translation>
    </message>
    <message>
        <source>Please correct the following errors:</source>
        <translation>S.V.P. corrigez les erreurs suivantes :</translation>
    </message>
    <message>
        <source>Your name</source>
        <translation>Votre nom</translation>
    </message>
    <message>
        <source>Your email address</source>
        <translation>Votre courriel</translation>
    </message>
    <message>
        <source>Receivers name</source>
        <translation>Nom du destinataire</translation>
    </message>
    <message>
        <source>Receivers email address</source>
        <translation>Courriel du destinataire</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Envoyer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>This message was sent to you because &quot;%1 &lt;%2&gt;&quot; thought you might find the page &quot;%3&quot; at %4 interesting.</source>
        <translation>Ce message vous a été envoyé parce que &quot;%1 &lt;%2&gt;&quot; pense que vous trouverez la page &quot;%3&quot; %4 intéressante.</translation>
    </message>
    <message>
        <source>This is the link to the page:</source>
        <translation>Voici le lien vers la page :</translation>
    </message>
    <message>
        <source>Comment by &quot;%1 &lt;%2&gt;&quot;:</source>
        <translation>Commentaire de &quot;%1 &lt;%2&gt;&quot; :</translation>
    </message>
</context>
<context>
    <name>design/standard/content/translate</name>
    <message>
        <source>Translating &apos;%1&apos;</source>
        <translation>Traduction de &apos;%1&apos;</translation>
    </message>
    <message>
        <source>%1 input was stored successfully</source>
        <translation>%1 a été enregistré avec succes</translation>
    </message>
    <message>
        <source>Remove the following translations from &apos;%1&apos;</source>
        <translation>Supprimer les traductions suivantes de &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Paramètre de localisation</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Langage</translation>
    </message>
    <message>
        <source>(No locale information available)</source>
        <translation>(Aucun paramètre de localisation n&apos;est disponible)</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traduire</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
</context>
<context>
    <name>design/standard/content/trash</name>
    <message>
        <source>Trash</source>
        <translation>Corbeille</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Version courante</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Restorer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Trash is empty</source>
        <translation>La corbeille est vide</translation>
    </message>
</context>
<context>
    <name>design/standard/content/version</name>
    <message>
        <source>Versions for: %1</source>
        <translation>Versions pour : %1</translation>
    </message>
    <message>
        <source>Version not a draft</source>
        <translation>Cette version n&apos;est pas un brouillon</translation>
    </message>
    <message>
        <source>Version %1 is not available for editing anymore, only drafts can be edited.</source>
        <translation>La version %1 ne peut plus être édité, seuls les brouillons peuvent être édités.</translation>
    </message>
    <message>
        <source>To edit this version create a copy of it.</source>
        <translation>Pour éditer cette version, créez-en une copie.</translation>
    </message>
    <message>
        <source>Version not yours</source>
        <translation>Cette version ne vous appartient pas</translation>
    </message>
    <message>
        <source>Version %1 was not created by you, only your own drafts can be edited.</source>
        <translation>La version %1 ne vous appartient pas, vous ne pouvez éditer que vos propres brouillons.</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Versions :</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Statut :</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Traductions :</translation>
    </message>
    <message>
        <source>Creator:</source>
        <translation>Créateur :</translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation>Modifié :</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Copy and edit</source>
        <translation>Copier et éditer</translation>
    </message>
</context>
<context>
    <name>design/standard/content/view</name>
    <message>
        <source>My bookmarks</source>
        <translation>Mes signets</translation>
    </message>
    <message>
        <source>Add bookmarks</source>
        <translation>Ajouter des signets</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>You have no bookmarks</source>
        <translation>Vous n&apos;avez pas de signet</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Naviguer</translation>
    </message>
    <message>
        <source>To select objects, choose the appriate radiobutton or checkbox(es), and click the &quot;Choose&quot; button.</source>
        <translation>Pour sélectionner des objets, choisissez la case d&apos;option appropriée et cliquez sur le bouton &quot;Choisir&quot;.</translation>
    </message>
    <message>
        <source>To select an object that is a child of one of the displayed objects, click the object name and you will get a list of the children of the object.</source>
        <translation>Pour sélectionner un objet qui est enfant d&apos;un des objets affichés, cliquez sur le nom de l&apos;objet et vous recevrez une liste de ses enfants.</translation>
    </message>
    <message>
        <source>Up one level</source>
        <translation>Monter d&apos;un niveau</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Sélectionner</translation>
    </message>
    <message>
        <source>Top levels</source>
        <translation>Niveaux supérieurs</translation>
    </message>
    <message>
        <source>Switch top levels by clicking one of these items.</source>
        <translation>Passer aux niveaux supérieurs en cliquant sur l&apos;un des items.</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Signets</translation>
    </message>
    <message>
        <source>Recent items</source>
        <translation>Items récemment manipulés</translation>
    </message>
    <message>
        <source>Recent items are added on publishing.</source>
        <translation>Les items récemment manipulés sont ajoutés lors de la publication.</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mes brouillons</translation>
    </message>
    <message>
        <source>These are the current objects you are working on. The drafts are owned by you and can only be seen by you.
      You can either edit the drafts or remove them if you don&apos;t need them anymore.</source>
        <translation>Voici les objets sur lesquels vous travaillez actuellement. Les brouillons vous appartiennent et ne peuvent être vus que par vous.
      vous pouvez les éditer ou les supprimer si vous n&apos;en avez plus besoin.</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation>Dernière modification</translation>
    </message>
    <message>
        <source>You have no drafts</source>
        <translation>Vous n&apos;avez pas de brouillon</translation>
    </message>
    <message>
        <source>Current version</source>
        <translation>Version courante</translation>
    </message>
    <message>
        <source>Related objects</source>
        <translation>Objets en relation</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traduction</translation>
    </message>
    <message>
        <source>Placement</source>
        <translation>Emplacement</translation>
    </message>
    <message>
        <source>Site Design</source>
        <translation>Site Design</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Modifier</translation>
    </message>
    <message>
        <source>Publish</source>
        <translation>Publier</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versions</translation>
    </message>
</context>
<context>
    <name>design/standard/error/kernel</name>
    <message>
        <source>Access denied</source>
        <translation>Accès refusé</translation>
    </message>
    <message>
        <source>You don&apos;t have permission to access this area.</source>
        <translation>Vous n&apos;avez pas l&apos;autorisation d&apos;accéder à cette section.</translation>
    </message>
    <message>
        <source>Login to get proper permissions.</source>
        <translation>Ouvrez une session pour obtenir les permissions nécessaires.</translation>
    </message>
    <message>
        <source>Click the Login button to login.</source>
        <translation>Cliquez sur le bouton d&apos;ouverture de session pour vous connecter.</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
    </message>
    <message>
        <source>Module not found</source>
        <translation>Module non trouvé</translation>
    </message>
    <message>
        <source>The requested module &apos;%1&apos; could not be found.</source>
        <translation>Le module demandé &apos;%1&apos; n&apos;a pu être trouvé.</translation>
    </message>
    <message>
        <source>View not found</source>
        <translation>Affichage non trouvé</translation>
    </message>
    <message>
        <source>The requested view &apos;%1&apos; could not be found in module: &apos;%2&apos;</source>
        <translation>L&apos;affichage demandé &apos;%1&quot; n&apos;a pu être trouvé dans le module &apos;%2&apos;</translation>
    </message>
    <message>
        <source>View is disabled</source>
        <translation>L&apos;affichage est désactivé</translation>
    </message>
    <message>
        <source>The view %2/%1 is disabled and cannot be accessed.</source>
        <translation>L&apos;affichage %2/%1 est désactivé et est donc inaccessible</translation>
    </message>
    <message>
        <source>Module is disabled</source>
        <translation>Le module est désactivé</translation>
    </message>
    <message>
        <source>The module %1 is disabled and cannot be accessed.</source>
        <translation>Le module %1 est désactivé et est donc inaccessible.</translation>
    </message>
    <message>
        <source>Unavailable</source>
        <translation>Non disponible</translation>
    </message>
    <message>
        <source>The object is not available.</source>
        <translation>L&apos;objet n&apos;est pas disponible.</translation>
    </message>
</context>
<context>
    <name>design/standard/layout</name>
    <message>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <source>Welcome to eZ publish administration</source>
        <translation>Bienvenue dans l&apos;administration</translation>
    </message>
    <message>
        <source>To log in enter a valid login and password.</source>
        <translation>Pour ouvrir une session entrez un nom d&apos;usager et un mot de passe valides.</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation>Site :</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Version :</translation>
    </message>
    <message>
        <source>Revision:</source>
        <translation>Révision :</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Ouverture de session</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Fermeture de session</translation>
    </message>
    <message>
        <source>%1 front page</source>
        <translation>Page de garde %1</translation>
    </message>
    <message>
        <source>Search %1</source>
        <translation>Chercher %1</translation>
    </message>
    <message>
        <source>Printable version</source>
        <translation>Version imprimable</translation>
    </message>
    <message>
        <source>Advanced search</source>
        <translation>Recherche avancée</translation>
    </message>
    <message>
        <source>Frontpage</source>
        <translation>Page de garde</translation>
    </message>
    <message>
        <source>Sitemap</source>
        <translation>Plan du site</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personnel</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Corbeille</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Modifier le mot de passe</translation>
    </message>
    <message>
        <source>Redirecting to %1</source>
        <translation>Redirection vers %1</translation>
    </message>
    <message>
        <source>Redirect</source>
        <translation>Redirige</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Redémarrer</translation>
    </message>
    <message>
        <source>Module load failed</source>
        <translation>Échec de chargement du module</translation>
    </message>
    <message>
        <source>Undefined module: </source>
        <translation>Module indéfini :</translation>
    </message>
</context>
<context>
    <name>design/standard/navigator</name>
    <message>
        <source>Previous</source>
        <translation>Précédent</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
</context>
<context>
    <name>design/standard/node</name>
    <message>
        <source>Are you sure you want to remove %1 from node %2?</source>
        <translation>Voulez-vous vraiment supprimer %1 du noeud %2?</translation>
    </message>
    <message>
        <source>Removing this assignment will also remove it&apos;s %1!</source>
        <translation>Si vous supprimez cet assignation, vous supprimerez aussi son %1!</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note :</translation>
    </message>
    <message>
        <source>Removed nodes can be retrieved later. You will find them in the trash.</source>
        <translation>Les noeuds supprimés peuvent être récupérés ultérieurement. Vous les trouverez dans la corbeille.</translation>
    </message>
    <message>
        <source>Removing node assignment of</source>
        <translation>Supprimer l&apos;assignement du noeud de</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these nodes?</source>
        <translation>Voulez-vous vraiment supprimer ces noeuds?</translation>
    </message>
    <message>
        <source>Removing %1 will remove the node itself and it&apos;s %2! %3</source>
        <translation>Si vous supprimez %1, vous supprimerez le noeud lui-même et son %2! %3</translation>
    </message>
    <message>
        <source>The following items were removed from your basket, because the products were changed</source>
        <translation>Les items suivants ont été supprimés de votre panier parce que les produits ont changés</translation>
    </message>
</context>
<context>
    <name>design/standard/node/view</name>
    <message>
        <source>Bookmark</source>
        <translation>Signé</translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation>Tenez-moi au courant</translation>
    </message>
    <message>
        <source>Create here</source>
        <translation>Créer ici</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Mise à jour</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Utilisateur</translation>
    </message>
    <message>
        <source>User group</source>
        <translation>Groupe d&apos;utilisateur</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Add to Bookmarks</source>
        <translation>Ajouter aux signets</translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation>Avisez-moi des mise à jour</translation>
    </message>
    <message>
        <source>Site map</source>
        <translation>Plan du site</translation>
    </message>
</context>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Do you want to receive messages combined in digest</source>
        <translation>Vous voulez recevoir des messages combinés en résumé</translation>
    </message>
    <message>
        <source>Digest settings</source>
        <translation>paramètres de résumé</translation>
    </message>
    <message>
        <source>Day the week</source>
        <translation>Jour de la semaine</translation>
    </message>
    <message>
        <source>%sitename.&quot;
</source>
        <translation>%sitename.&quot;
</translation>
    </message>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation>Si vous ne souhaitez plus recvoir ces avis,
modifiez vos paramètres à :</translation>
    </message>
    <message>
        <source>system&quot;
</source>
        <translation>système&quot;
</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>below.&quot;
</source>
        <translation>ci dessous.&quot;
</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>design/standard/role</name>
    <message>
        <source>Create policy for</source>
        <translation>Créer une règle d&apos;action pour</translation>
    </message>
    <message>
        <source>Step 1</source>
        <translation>Étape 1</translation>
    </message>
    <message>
        <source>Give access to module</source>
p        <translation>Donner accès au module</translation>
    </message>
    <message>
        <source>Every module</source>
        <translation>Tous les modules</translation>
    </message>
    <message>
        <source>Allow all</source>
        <translation>Permettre tout</translation>
    </message>
    <message>
        <source>Allow limited</source>
        <translation>Permettre avec limite</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Module</source>
        <translation>Module</translation>
    </message>
    <message>
        <source>Access</source>
        <translation>Accès</translation>
    </message>
    <message>
        <source>Limited</source>
        <translation>Limité</translation>
    </message>
    <message>
        <source>Go back to step 1</source>
        <translation>Retourner à l&apos;étape 1</translation>
    </message>
    <message>
        <source>You are not able to give access to limited functions of module</source>
        <translation>Vous ne pouvez pas donner l&apos;accès aux fonctions limitées du module</translation>
    </message>
    <message>
        <source>because function list for it is not defined.</source>
        <translation>parce que la liste de ses fonctions n&apos;est pas définie</translation>
    </message>
    <message>
        <source>Step 2</source>
        <translation>Étape 2</translation>
    </message>
    <message>
        <source>Specify function in module</source>
        <translation>Spécifier la fonction dans le module</translation>
    </message>
    <message>
        <source>Function</source>
        <translation>Fonction</translation>
    </message>
    <message>
        <source>Go back to step 2</source>
        <translation>Retourner à l&apos;étape 2</translation>
    </message>
    <message>
        <source>Step 3</source>
        <translation>Étape 3</translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation>Limites</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>N&apos;importe quel</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <source>Role edit %1</source>
        <translation>Éditer le rôle : %1</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Current policies</source>
        <translation>Règles courantes</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>Abandonner les modifications</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Liste des rôles</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Assigner</translation>
    </message>
    <message>
        <source>Edit policy</source>
        <translation>Éditer la règle</translation>
    </message>
    <message>
        <source>Policy</source>
        <translation>Règle</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Node</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Non spécifié</translation>
    </message>
    <message>
        <source>Subtree</source>
        <translation>Sous-arborescence</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Mise à jour</translation>
    </message>
    <message>
        <source>Role view</source>
        <translation>Affichage du rôle</translation>
    </message>
    <message>
        <source>Role</source>
        <translation>Rôle</translation>
    </message>
    <message>
        <source>Role policies</source>
        <translation>Règles d&apos;action du rôle</translation>
    </message>
    <message>
        <source>Limitation</source>
        <translation>Limite</translation>
    </message>
    <message>
        <source>Users and groups assigned to this role</source>
        <translation>Utilisateurs et groupes assignés à ce rôle</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Utilisateur</translation>
    </message>
</context>
<context>
    <name>design/standard/search</name>
    <message>
        <source>Search statistics</source>
        <translation>Statistiques de recherche</translation>
    </message>
    <message>
        <source>Most frequent search phrases</source>
        <translation>Phrases de recherche qui reviennent le plus</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>Phrase</translation>
    </message>
    <message>
        <source>Number of phrases</source>
        <translation>Nombre de phrases</translation>
    </message>
    <message>
        <source>Average result returned</source>
        <translation>Résultats moyens retournés</translation>
    </message>
</context>
<context>
    <name>design/standard/section</name>
    <message>
        <source>Node notification</source>
        <translation>Noeud d&apos;avis </translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation>Paramètres des avis</translation>
    </message>
    <message>
        <source>Assign section</source>
        <translation>Assigner la section</translation>
    </message>
    <message>
        <source>Assign section to node</source>
        <translation>Assigner une section au noeud</translation>
    </message>
    <message>
        <source>Are you sure you want to remove these sections?</source>
        <translation>Voulez-vous vraiment supprimer ces sections?</translation>
    </message>
    <message>
        <source>Removing these sections can corrupt permissions, sitedesigns, and other things in the system. Do not do this unless you know exactly what are you doing.</source>
        <translation>La suppression de ces sections peut corrompre les permissions, design du site et autres éléments du système. Si vous ne savez pas exactement ce que vous faites, veuillez vous en abstenir.</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Section edit</source>
        <translation>Éditer la section</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Navigation Part</source>
        <translation>Partie de navigation</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenu</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Boutique</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Utilisateurs</translation>
    </message>
    <message>
        <source>Set up</source>
        <translation>Configuration</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personnel</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>About Navigation Parts</source>
        <translation>À propos des &quot;ensembles&quot; de navigation</translation>
    </message>
    <message>
        <source>The eZ publish admin interface is divided into navigation parts. This is a way to group different areas of the site administration. Select the navigation part that should be active when this section is browsed.</source>
        <translation>L&apos;interface d&apos;administration est divisée en ensembles de navigation. Cet une façon de grouper les différentes zones de l&apos;administration du Site. Sélectionnez l&apos;ensemble de navigation qui doit être actif lorsqu&apos;on navige dans cette section.</translation>
    </message>
    <message>
        <source>Section list</source>
        <translation>Liste des sections</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Assign</source>
        <translation>Assigner</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
</context>
<context>
    <name>design/standard/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Adlministration du cache</translation>
    </message>
    <message>
        <source>Content view cache was cleared.</source>
        <translation>Le cache d&apos;affichage de contenu a été vidé</translation>
    </message>
    <message>
        <source>Ini file cache was cleared.</source>
        <translation>>Le cache de fichier ini a été vidé</translation>
    </message>
    <message>
        <source>Template cache was cleared.</source>
        <translation>>Le cache de modèle a été vidé</translation>
    </message>
    <message>
        <source>View cache is enabled.</source>
        <translation>Le cache d&apos;affichage est activé</translation>
    </message>
    <message>
        <source>View cache is disabled.</source>
        <translation>Le cache d&apos;affichage est désactivé</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Vider</translation>
    </message>
    <message>
        <source>Ini cache</source>
        <translation>Cache Ini</translation>
    </message>
    <message>
        <source>Ini cache is always enabled.</source>
        <translation>Le cache Ini est toujours activé</translation>
    </message>
    <message>
        <source>Template cache</source>
        <translation>Cache de modèle</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Informations système</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>SVN revision</source>
        <translation>Révision SVN</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Extentions</translation>
    </message>
    <message>
        <source>Safe mode is on.</source>
        <translation>Le mode &quot;Safe&quot; est actif</translation>
    </message>
    <message>
        <source>Safe mode is off.</source>
        <translation>Le mode &quot;Safe&quot; est inactif</translation>
    </message>
    <message>
        <source>Basedir restriction is on and set to %1.</source>
        <translation>La restriction de &quot;Basedir&quot; est active et positionnée à %1</translation>
    </message>
    <message>
        <source>Basedir restriction is off.</source>
        <translation>La restriction de &quot;Basedir&quot; est inactive</translation>
    </message>
    <message>
        <source>Global variable registration is on.</source>
        <translation>L&apos;enregistrement des variables globales est actif.</translation>
    </message>
    <message>
        <source>Global variable registration is off.</source>
        <translation>L&apos;enregistrement des variables globales est inactif.</translation>
    </message>
    <message>
        <source>File uploading is enabled.</source>
        <translation>Le chargement de fichiers es actif.</translation>
    </message>
    <message>
        <source>File uploading is disabled.</source>
        <translation>Le chargement de fichiers es inactif.</translation>
    </message>
    <message>
        <source>Maximum size of post data (text and files) is %1.</source>
        <translation>La taille de données (texte ou fichier) chargeable est %1</translation>
    </message>
    <message>
        <source>Script memory limit is %1.</source>
        <translation>La limite de mémoire pour les scripts est %1</translation>
    </message>
    <message>
        <source>Maximum execution time is %1 seconds.</source>
        <translation>Le temps maximum d&apos;exécution est de %1 secondes.</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de données</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Charset</source>
        <translation>Jeu de caractères</translation>
    </message>
    <message>
        <source>Rapid Application Development Tools</source>
        <translation>Outils de dévreloppement rapide d&apos;application</translation>
    </message>
    <message>
        <source>The rapid application development (RAD) tools allow you to easily get started with creating new functionality for eZ publish.</source>
        <translation>Les outils de développement rapide d&apos;application (R.A.D.) vous permet de commencer facilement à créer de nouvelles fonctionnalités pour eZ publish</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Outils</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Guide de création d&apos;opérateur de modèle</translation>
    </message>
    <message>
        <source>site registration</source>
        <translation>Enregistrement du site</translation>
    </message>
    <message>
        <source>Site info:</source>
        <translation>Informations sur le site :</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titre</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>URL :</translation>
    </message>
    <message>
        <source>PHP info:</source>
        <translation>Information sur PHP:</translation>
    </message>
    <message>
        <source>OS info:</source>
        <translation>Informations sur le système d&apos;exploitation:</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Database info:</source>
        <translation>Informations sur la base de données:</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Pilote</translation>
    </message>
    <message>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <source>Supported</source>
        <translation>Supporté</translation>
    </message>
    <message>
        <source>Unsupported</source>
        <translation>Non supporté</translation>
    </message>
    <message>
        <source>Demo data:</source>
        <translation>Données de démo :</translation>
    </message>
    <message>
        <source>Demo data was installed.</source>
        <translation>Les données de démo ont été installées.</translation>
    </message>
    <message>
        <source>Demo data was not installed.</source>
        <translation>Les données de démo n&apos;ont pas été installées.</translation>
    </message>
    <message>
        <source>Email info:</source>
        <translation>Informations sur le courriel:</translation>
    </message>
    <message>
        <source>Transport</source>
        <translation>Transport</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>Sendmail</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Image conversion:</source>
        <translation>Conversion des images :</translation>
    </message>
    <message>
        <source>ImageMagick was found and used.</source>
        <translation>ImageMagick a été trouvé et utilisé.</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Chemin</translation>
    </message>
    <message>
        <source>Executable</source>
        <translation>Exécutable</translation>
    </message>
    <message>
        <source>ImageGD extension was found and used.</source>
        <translation>l&apos;extension ImageGD a été trouvée et utilisée.</translation>
    </message>
    <message>
        <source>Regional info:</source>
        <translation>Information sur la région:</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Unilingue</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Multilingue</translation>
    </message>
    <message>
        <source>Primary</source>
        <translation>Primaire</translation>
    </message>
    <message>
        <source>Additional</source>
        <translation>Aditionnel</translation>
    </message>
    <message>
        <source>Critical tests:</source>
        <translation>Tests critiques:</translation>
    </message>
    <message>
        <source>Success</source>
        <translation>Succès</translation>
    </message>
    <message>
        <source>Failure</source>
        <translation>Échec</translation>
    </message>
    <message>
        <source>Other tests:</source>
        <translation>Autres tests :</translation>
    </message>
    <message>
        <source>Comments:</source>
        <translation>Commentaires :</translation>
    </message>
    <message>
        <source>setup</source>
        <translation>Configuration</translation>
    </message>
    <message>
        <source>Create new template override for</source>
        <translation>Créer une nouvelle surcharge de modèle pour</translation>
    </message>
    <message>
        <source>Could not create template, permission denied.</source>
        <translation>Le modèle n&apos; pas pu être >Créé, permission refusée.</translation>
    </message>
    <message>
        <source>Invalid name. You can only use the characters a-z, numbers and _.</source>
        <translation>Nom invalide. Utilisez uniquement les caractères a à z, les chiffres et _.</translation>
    </message>
    <message>
        <source>Template will be placed in</source>
        <translation>Le modèle sera placé dans</translation>
    </message>
    <message>
        <source>Template name</source>
        <translation>Nom du modèle</translation>
    </message>
    <message>
        <source>Override keys</source>
        <translation>Clefs de surcharge</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Noeud</translation>
    </message>
    <message>
        <source>Base template on</source>
        <translation>Produire le modèle à partir de</translation>
    </message>
    <message>
        <source>Empty file</source>
        <translation>Fichier vide</translation>
    </message>
    <message>
        <source>Copy of default template</source>
        <translation>Copie du modèle par défaut</translation>
    </message>
    <message>
        <source>Container ( with children )</source>
        <translation>Conténaire (avec ses enfants)</translation>
    </message>
    <message>
        <source>View ( without children )</source>
        <translation>Affichage (sans les enfants)</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objet</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Liste des modèles</translation>
    </message>
    <message>
        <source>Most common templates</source>
        <translation>Modèles les plus courants</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Modèle</translation>
    </message>
    <message>
        <source>Design Resource</source>
        <translation>Ressource de Design</translation>
    </message>
    <message>
        <source>Complete template list</source>
        <translation>Liste complète des modèles</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Commencer</translation>
    </message>
    <message>
        <source>Basic information</source>
        <translation>Informations de base</translation>
    </message>
    <message>
        <source>Name of operator</source>
        <translation>Nom de l&apos;opérateur</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <source>One operator in class</source>
        <translation>Un opérateur dans la classe</translation>
    </message>
    <message>
        <source>Handles operator input</source>
        <translation>Manipule les opérateurs d&apos;entrée</translation>
    </message>
    <message>
        <source>Generates operator output</source>
        <translation>Génère les opérateurs de sortie</translation>
    </message>
    <message>
        <source>Parameter handling</source>
        <translation>Manipulation des Paramètres</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Recommencer</translation>
    </message>
    <message>
        <source>Optional information</source>
        <translation>Information optionnelle</translation>
    </message>
    <message>
        <source>Name of class</source>
        <translation>Nom de classe</translation>
    </message>
    <message>
        <source>The creator of the operator</source>
        <translation>Le créateur de l&apos;opérateur</translation>
    </message>
    <message>
        <source>Description of your operator</source>
        <translation>Description de votre opérateur</translation>
    </message>
    <message>
        <source>The first line will be used as the brief description and the rest are operator documentation.</source>
        <translation>La première ligne est utilisée pour une brève description et le reste pour la documentation de l&apos;opérateur</translation>
    </message>
    <message>
        <source>Handles template operator %operatorname
By using %operatorname you can ...</source>
        <translation>Manipulation de l&apos;opérateur de modèle %operatorname
en utilisant %operatorname vous pouvez...</translation>
    </message>
    <message>
        <source>Example code</source>
        <translation>Code d&apos;exemple</translation>
    </message>
    <message>
        <source>If you wish you can add some example code to explain how your operator should work.
The default code was made from the basic parameters you chose.</source>
        <translation>vous pouvez ajouter du code d&apos;exemple pour expliquer comment votre opérateur fonctionne.
The code par défaut a été fait à partir des paramètres de base que vous avez choisis.</translation>
    </message>
    <message>
        <source>Once the download button is clicked the code will be generated and the browser will ask you to store the generated file.</source>
        <translation>Quand vous cliquerez sur le bouton &quot;Télécharger&quot;, le code sera généré et votre navigateur vous demandera d&apos;enregistrer le fichier généré</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Télécharger</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>Affichage des modèles</translation>
    </message>
    <message>
        <source>Default template resource</source>
        <translation>Ressource de modèle par défaut</translation>
    </message>
    <message>
        <source>Set</source>
        <translation>Positionner</translation>
    </message>
    <message>
        <source>Override</source>
        <translation>Surcharger</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <source>Match conditions</source>
        <translation>Conditions à remplir</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Céer nouveau</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/db</name>
    <message>
        <source>If you are having problems connecting to your database you should take a look at</source>
        <translation>Si vous éprouvez des problèmes pour vous connecter à la base de données, vérifiez</translation>
    </message>
    <message>
        <source>at</source>
        <translation>à</translation>
    </message>
    <message>
        <source>MySQL</source>
        <translation>MySQL</translation>
    </message>
    <message>
        <source>Introduction</source>
        <translation>Introduction</translation>
    </message>
    <message>
        <source>MySQL is a database management system created by MySQL AB.</source>
        <translation>MySQL est un système de gestion de bases de données créé par MySQL AB.</translation>
    </message>
    <message>
        <source>It&apos;s currently one of the most popular databases in the Open Source community and most often on by default in PHP.</source>
        <translation>C&apos;est actuellement la base de données la plus populaire dans la communauté du logiciel libre et la plus souvent utilisée par défaut en PHP.</translation>
    </message>
    <message>
        <source>From their homepage:</source>
        <translation>De leur page d&apos;accueil:</translation>
    </message>
    <message>
        <source>MySQL is the world&apos;s most popular Open Source Database, designed for speed, power and precision in mission critical, heavy load use.</source>
        <translation>MySQL est la base de données en logiciel libre la plus populaire au monde, conçue pour la rapidité, la puissance et la précision d&apos;exécution, même lors d&apos;un usage excessif.</translation>
    </message>
    <message>
        <source>More information can be found on</source>
        <translation>Vous trouverez plus d&apos;informations sur</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Détails</translation>
    </message>
    <message>
        <source>MySQL is a good choice for handling most western languages, however it&apos;s currently not the best choice for Unicode or non-western languages.</source>
        <translation>MySQL gère très bien la plupart des langages d&apos;Europe occidentale. Cependant, ce n&apos;est pas le meilleur choix en ce qui concerne Unicode et les autres langages.</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Installation</translation>
    </message>
    <message>
        <source>By using the</source>
        <translation>En utilisant le</translation>
    </message>
    <message>
        <source>configuration option you enable PHP to access MySQL databases. If you use this option without specifying the path to MySQL, PHP will use the built-in MySQL client libraries.</source>
        <translation>option de configuration, vous permettez à PHP d&apos;accéder aux bases de données MySQL. Si vous utilisez cette option sans préciser le chemin vers MySQL, PHP utilisera ses propres bibliothèques de programmes client.</translation>
    </message>
    <message>
        <source>More information on the MySQL extension can be found at</source>
        <translation>Vous trouverez plus d&apos;informations sur les extensions MySQL à</translation>
    </message>
    <message>
        <source>PostgreSQL</source>
        <translation>PostgreSQL</translation>
    </message>
    <message>
        <source>PostgreSQL is a database management system developed at the University of California at Berkeley Computer Science Department.</source>
        <translation>PostgreSQL est un outil de gestion des bases de données développé è l&apos;Université de la Californie, au département d&apos;informatique de Berkeley.</translation>
    </message>
    <message>
        <source>It&apos;s a very popular database in the Open Source community and provides highly advanced database functionality.</source>
        <translation>C&apos;est une base de données très populaire dans la communauté du logiciel libre et fourni des fonctions de base de données de très haut niveau.</translation>
    </message>
    <message>
        <source>PostgreSQL is a sophisticated Object-Relational DBMS, supporting almost all SQL constructs, including subselects, transactions, and user-defined types and functions. It is the most advanced open-source database available anywhere.</source>
        <translation>Postgre est un système de gestion de base de données (SGBD) relationnel-objet sophistiqué, supportant quasiment toutes les structures SQL, y compris les sous-sélections, les transactions et les types et fonctions définies par l&apos;utilisateur. C&apos;est la base de données en logiciel libre la plus sophistiquée que l&apos;on puisse trouver.</translation>
    </message>
    <message>
        <source>PostgreSQL is a good choice for handling most languages, including Unicode, but may require some configuration to get good speed.</source>
        <translation>PostgreSQL gère très bien la plupart des langages, y compris Unicode, mais peut nécessiter un peu de configuration pour obtenir une bonne rapidité.</translation>
    </message>
    <message>
        <source>In order to enable PostgreSQL support,</source>
        <translation>Pour activer le support de PostgreSQL,</translation>
    </message>
    <message>
        <source>is required when you compile PHP.</source>
        <translation>est requis lorsque vous compilez PHP.</translation>
    </message>
    <message>
        <source>More information on the PostgreSQL extension can be found at</source>
        <translation>Vous trouverez plus d&apos;informations sur les extensions PostgreSQL à</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/init</name>
    <message>
        <source>The database is ready for initialization, click the %1 button when ready.</source>
        <translation>La base de données est prête pour l&apos;initialisation, cliquez le bouton %1 quand vous serez prêt</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuer</translation>
    </message>
    <message>
        <source>If you want you can let the setup add some demo data to your database, this demo data will give a good demonstration of the capabilites of eZ publish</source>
        <translation>Vous pouvez permettre l&apos;ajout de données de démo à votre base de données; elles montreront bien les capacités de eZ publish</translation>
    </message>
    <message>
        <source>First time users are adviced to install the demo data.</source>
        <translation>L&apos;installation des données de démo est recommandée aux utilisateurs débutants.</translation>
    </message>
    <message>
        <source>Install demo data?</source>
        <translation>Installer les données de démo ?</translation>
    </message>
    <message>
        <source>Cannot install demo data, the zlib extension is missing from your PHP installation.</source>
        <translation>les données de démo ne peuvent être installées, l&apos;extension zlib n&apos;apparaît pas dans l&apos;installation PHP.</translation>
    </message>
    <message>
        <source>does not support installing demo data at this point.</source>
        <translation>ne peut installer les données de démo pour l&apos;instant.</translation>
    </message>
    <message>
        <source>Demo data failure</source>
        <translation>Échec des données de démo</translation>
    </message>
    <message>
        <source>Could not unpack the demo data.</source>
        <translation>Impossible de décompresser les données de démo.</translation>
    </message>
    <message>
        <source>You should try to install without demo data.</source>
        <translation>Essayez l&apos;installation sans les données de démo.</translation>
    </message>
    <message>
        <source>Initialization failed</source>
        <translation>Échec de l&apos;initialisation</translation>
    </message>
    <message>
        <source>The database could not be properly initialized.</source>
        <translation>La base de données n&apos;a pu être correctement initialisée.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Avertissement</translation>
    </message>
    <message>
        <source>Your database already contains data.</source>
        <translation>Votre base de données contient déjà des données.</translation>
    </message>
    <message>
        <source>The setup can continue with the initialization but may damage the present data.</source>
        <translation>La configuration peut passer à l&apos;étape de l&apos;initialisation mais peut endommager les données existantes.</translation>
    </message>
    <message>
        <source>What do you want the setup to do?</source>
        <translation>Quel est votre choix pour la configuration?</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note :</translation>
    </message>
    <message>
        <source>The setup will not do an upgrade from older eZ publish versions (such as 2.2.7) if you leave the data as it is. This is only meant for people who have existing data that they don&apos;t want to lose. If you have existing eZ publish 3.0 data (such as from an RC release) you should skip DB initialization, however you will then need to do a manual upgrade.</source>
        <translation>La configuration ne fera pas mise à niveau de vieilles version de eZPublish (tel que 2.2.7) si vous laissez les données comme elles sont. Ceci ne s&apos;applique qu&apos;aux personnes possédant des données qu&apos;ils ne veulent pas perdre. Si vous possédez des données de eZPublish 3.0 (tel qu&apos;une version candidate) vous devez sauter l&apos;initialisation de la base de donnée. Vous devez plutôt faire un mise à niveau manuelle.</translation>
    </message>
    <message>
        <source>Continue but leave the data as it is.</source>
        <translation>Continuer mais laisser les données intactes.</translation>
    </message>
    <message>
        <source>Continue but remove the data first.</source>
        <translation>Continuer mais supprimer les données.</translation>
    </message>
    <message>
        <source>Keep data and skip database initialization.</source>
        <translation>Garder les données et sauter l&apos;initialisation de la base de données.</translation>
    </message>
    <message>
        <source>Let me choose a new database.</source>
        <translation>Je veux choisir une nouvelle base de données.</translation>
    </message>
    <message>
        <source>It can take some time initializing the database so please be patient and wait until the new page is finished.</source>
        <translation>L&apos;initilisation de la base de données peut prendre du temps alors veuillez être patient et attendre que la nouvelle page soit finie.</translation>
    </message>
    <message>
        <source>It&apos;s time to choose your database, the choice will determine the language support. Once you are done click</source>
        <translation>Choisissez maintenant votre base de données, votre choix déterminera le support de langage. Après avoir choisi, cliquez</translation>
    </message>
    <message>
        <source>Language Options</source>
        <translation>Options de langages</translation>
    </message>
    <message>
        <source>to continue the setup.</source>
        <translation>continuer la configuration.</translation>
    </message>
    <message>
        <source>Your system has support for one database only, it is</source>
        <translation>Votre système ne peut supporter qu&apos;une seule base de données, c&apos;est</translation>
    </message>
    <message>
        <source>, click</source>
        <translation>, cliquez</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>Pilote</translation>
    </message>
    <message>
        <source>Unicode support</source>
        <translation>Support Unicode</translation>
    </message>
    <message>
        <source>no</source>
        <translation>Non</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <source>The database was succesfully initialized. You are now ready for some post configuration of the site.</source>
        <translation>La base de données a été initialisée avec succès. Vous pouvez maintenant passer à la configuration du site.</translation>
    </message>
    <message>
        <source>Click the %1 button to start the configuration process.</source>
        <translation>Cliquez sur le bouton %1 pour commencer le processus de configuration.</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation>Configurer</translation>
    </message>
    <message>
        <source>No database connection</source>
        <translation>Pas de connexion à la base de données</translation>
    </message>
    <message>
        <source>Could not connect to database.</source>
        <translation>Impossible de se connecter à la base de données.</translation>
    </message>
    <message>
        <source>The database would not accept the connection , please review your settings and try again.</source>
        <translation>La base de données n&apos;accepte pas la connexion, veuillez revoir vos paramètres et essayer de nouveau.</translation>
    </message>
    <message>
        <source>We&apos;re now ready to initialize the database. The basic structure will be initialized. To start the initialization, please enter the relevant information in the boxes below, and the password you want on the database and click the</source>
        <translation>Vous êtes prêt à initialiser la base de données. La structure de base sera initialisée. Pour débuter l&apos;initialisation, veuillez entrer les informations pertinentes dans les boîtes ci-dessous ainsi que le mot de passe désiré et cliquez sur</translation>
    </message>
    <message>
        <source>Connect To Database</source>
        <translation>Connecter à la base de données</translation>
    </message>
    <message>
        <source>button.</source>
        <translation>bouton.</translation>
    </message>
    <message>
        <source>If you have an already existing eZ publish database enter the information and the setup will use that as database.</source>
        <translation>Si vous avez déjà une base de données eZ publish, entrez l&apos;information et l&apos;outil de configuration l&apos;utilisera comme base de données.</translation>
    </message>
    <message>
        <source>Empty password</source>
        <translation>Mot de passe vide</translation>
    </message>
    <message>
        <source>You must supply a password for the database.</source>
        <translation>Vous devez fournir un mot de passe pour la base de données.</translation>
    </message>
    <message>
        <source>Password does not match</source>
        <translation>Le mot de passe ne correspond pas</translation>
    </message>
    <message>
        <source>The password and confirmation password must match.</source>
        <translation>Le mot de passe et la confirmation du mot de passe doivent correspondre.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Erreur inconnue</translation>
    </message>
    <message>
        <source>Servername</source>
        <translation>Nom du serveur</translation>
    </message>
    <message>
        <source>Socket</source>
        <translation>Socket (Interface de connexion)</translation>
    </message>
    <message>
        <source>Databasename</source>
        <translation>Nom de la base de données</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nom d&apos;usager</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation>Confirmation du mot de passe</translation>
    </message>
    <message>
        <source>No finetuning is required on your system, you can continue by clicking the</source>
        <translation>Aucune mise au point n&apos;est nécessaire pour votre système, vous pouvez continuer en cliquant sur</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <source>The system check found some issues that, when resolved, may give improved performance or more features. Please have a look through the results below for more information on what might be done. Each issue will give you instructions on how to do the finetuning.</source>
        <translation>La vérification du système a montré quelques problèmes qui, une fois réglés, pourront améliorer la performance de certaines fonctions. Veuillez examiner les résultats ci-dessous pour davantage d&apos;informations sur les solutions possibles. Chaque description de problème vous donnera des instructions sur la façon de le régler.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the</source>
        <translation>Une fois tous les problèmes réglés, cliquez sur</translation>
    </message>
    <message>
        <source>Rerun System Check</source>
        <translation>Refaire la vérification du système</translation>
    </message>
    <message>
        <source>button to re-run the system checking. This is recommended after system changes to check for critical failures. You can also click the</source>
        <translation>pour revérifier le sytème. Ceci est fortement recommandé après avoir effectué des changements visant à régler des problèmes. Vous pouvez aussi cliquer sur</translation>
    </message>
    <message>
        <source>Check Again</source>
        <translation>Vérifier encore</translation>
    </message>
    <message>
        <source>button to rerun the finetuning checks. However if you wish you can skip straight to the next step by clicking the</source>
        <translation>pour redémarrer la mise au point. Si vous le souhaitez, vous pouvez passer immédiatement à la prochaine étape en cliquant sur</translation>
    </message>
    <message>
        <source>Issues</source>
        <translation>Problèmes</translation>
    </message>
    <message>
        <source>Failed writing</source>
        <translation>Erreur d&apos;écriture</translation>
    </message>
    <message>
        <source>The setup could not write to the file.</source>
        <translation>L&apos;outil de configuration ne peut écrire sur le fichier.</translation>
    </message>
    <message>
        <source>The setup could not get write access to the</source>
        <translation>L&apos;outil de configuration n&apos;a pes le droit d&apos;écrire sur le</translation>
    </message>
    <message>
        <source>directory. This is required to disable the initialization. Following the instructions found in</source>
        <translation>répertoire. Ceci est nécessaire pour désactiver l&apos;initialisation. Selon les instructions trouvées dans</translation>
    </message>
    <message>
        <source>to enable write access and click the</source>
        <translation>pour permettre l&apos;écriture et cliquez le</translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Essayez de nouveau</translation>
    </message>
    <message>
        <source>Optionally you may disable this manually, edit the &lt;i&gt;settings/site.ini&lt;/i&gt; file and look for a line that says:</source>
        <translation>En option, pour désactiver cela manuellement, éditez le fichier &lt;i&gt;settings/site.ini/&lt;/i&gt; et recherchez cette ligne:</translation>
    </message>
    <message>
        <source>Change the second line from</source>
        <translation>Changez la deuxième ligne à partir de</translation>
    </message>
    <message>
        <source>to</source>
        <translation>à</translation>
    </message>
    <message>
        <source>The setup is now disabled, click</source>
        <translation>L&apos;outil de configuration est maintenant désactivé, cliquez</translation>
    </message>
    <message>
        <source>to get back to the site.</source>
        <translation>pour retourner au site.</translation>
    </message>
    <message>
        <source>Email is used for sending out important notices such as user registration and content approval, and is used to send the site registration.</source>
        <translation>Le courriel est utilisé pour envoyer des notices importantes telles que l&apos;enregistrement de l&apos;utilisateur et l&apos;approbation du contenu et est utilisé pour envoyer l&apos;inscription au site.</translation>
    </message>
    <message>
        <source>You can choose from either</source>
        <translation>Vous pouvez choisir</translation>
    </message>
    <message>
        <source>sendmail</source>
        <translation>Sendmail</translation>
    </message>
    <message>
        <source>which must be available on the server or</source>
        <translation>qui doit être disponible sur le serveur ou</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>which will relay the emails. If unsure what to use ask your webhost, some webhosts do not support</source>
        <translation>qui relaiera les courriels. Si vous n&apos;êtes pas certains de l&apos;option à utiliser, contactez l&apos;hébergeur du site, car certains ne supportent pas</translation>
    </message>
    <message>
        <source>Configuration of sendmail is done on the server, consult your webhost.</source>
        <translation>La configuration de Sendmail est faite directement sur le serveur, consultez l&apos;hébergeur du site.</translation>
    </message>
    <message>
        <source>Email transport by SMTP requires a server name. If the server requires authentication you must enter a username and password as well.</source>
        <translation>L&apos;envoi du courriel via SMTP requiert un nom de serveur. Si le serveur l&apos;exige, entrez un nom d&apos;utilisateur et un mot de passe.</translation>
    </message>
    <message>
        <source>Server name</source>
        <translation>Nom du serveur</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Nom de l&apos;utilisateur:</translation>
    </message>
    <message>
        <source>Site Details</source>
        <translation>Détails sur le site</translation>
    </message>
    <message>
        <source>Email sending failed</source>
        <translation>Échec de l&apos;envoi du courriel</translation>
    </message>
    <message>
        <source>Failed sending registration email using</source>
        <translation>Échec de l&apos;envoi de l&apos;inscription par courriel en utilisant</translation>
    </message>
    <message>
        <source>Congratulations, eZ publish should now run on your system.</source>
        <translation>Félicitations, eZ publish est maintenant fonctionnel sur votre système.</translation>
    </message>
    <message>
        <source>features.&quot;
</source>
        <translation>fonctionnalit�s.&quot;
</translation>
    </message>
    <message>
        <source>eZ publish bug reports</source>
        <translation>Rapport de bug sur eZ Publish</translation>
    </message>
    <message>
        <source>ez.no</source>
        <translation>ez.no</translation>
    </message>
    <message>
        <source>systems!&quot;
</source>
        <translation>systèmes!&quot;
</translation>
    </message>
    <message>
        <source>eZ publish website</source>
        <translation>site web de eZ publish</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <source>The default username for the administrator is %1 and the default password is %2.</source>
        <translation>Le nom d&apos;usager par défaut pour l&apos;administration est %1 et le mot de passe  par défaut est %2</translation>
    </message>
    <message>
        <source>It&apos;s time to select the language this site should support.</source>
        <translation>Choisissez maintenant le langage du site.</translation>
    </message>
    <message>
        <source>Select your language and click the</source>
        <translation>Sélectionnez votre langage et cliquez sur</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation>Sommaire</translation>
    </message>
    <message>
        <source>button, or the</source>
        <translation>ou sur</translation>
    </message>
    <message>
        <source>Language Details</source>
        <translation>Détails sur le langage</translation>
    </message>
    <message>
        <source>button to select language variations.</source>
        <translation>pour sélectionner d&apos;autres langages.</translation>
    </message>
    <message>
        <source>It&apos;s time to select the languages this site should support. Select your primary language and check any additional languages.</source>
        <translation>Il est temps de sélectionner les langages supportés par le site. Sélectionez votre langage principal et cochez tous les langages additionnels.</translation>
    </message>
    <message>
        <source>Once you&apos;re done click the</source>
        <translation>Une fois vos choix faits, cliquez sur</translation>
    </message>
    <message>
        <source>The languages you choose will help determine the charset to use on the site.</source>
        <translation>Les langages choisis aideront à déterminer le jeu de caractères à utiliser sur ce site.</translation>
    </message>
    <message>
        <source>Language name</source>
        <translation>Nom du langage</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Sélection</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select a variation for your language. A variation does small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once your&apos;re done click the</source>
        <translation>Vous pouvez choisir une variation pour votre langage. Une variation effectue de petits ajustements au langage, tels que l&apos;ajout du support Euro ou le changement du format de date. Les variations sont optionnelles, vous pouvez passer cette étape. Lorsque votre choix est fait cliquez sur</translation>
    </message>
    <message>
        <source>It&apos;s now possible to select variations for your languages. Variations do small adjustments to the language, such as adding Euro support or date format changes. Using variations are optional so you may safely skip this step. Once you are done click the</source>
        <translation>Vous pouvez choisir une variation pour votre langage. Une variation effectue de petits ajustements au langage, tels que l&apos;ajout du support Euro ou le changement du format de date. Les variations sont optionnelles, vous pouvez passer cette étape. Lorsque votre choix est fait cliquez sur</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Par défaut</translation>
    </message>
    <message>
        <source>If you wish you can register your installation by sending some information to eZ systems. No confidential data will be transmitted and eZ systems will not use or sell your personal details for unsolicited emails. This data will help to improve eZ publish for future releases.</source>
        <translation>Vous pouvez inscrire votre installation en envoyant quelques informations à eZ systems. Aucune donnée confidentielle ne sera transmise et eZ systems n&apos;utilisera et ne vendra pas ces données personnelles pour éviter les courriels non désirés. Cette information aidera à améliorer les prochaines versions de eZ publish.</translation>
    </message>
    <message>
        <source>The following data will be sent to eZ systems:</source>
        <translation>L&apos;information suivante sera envoyé à eZ systems :</translation>
    </message>
    <message>
        <source>Details of your system, like OS type etc.</source>
        <translation>Informations générales sur votre système : système d&apos;exploitation, etc.</translation>
    </message>
    <message>
        <source>The test results for your system</source>
        <translation>Les résultats des tests sur votre système</translation>
    </message>
    <message>
        <source>The database type you are using</source>
        <translation>Le type de base de données utilisé</translation>
    </message>
    <message>
        <source>The name of your site</source>
        <translation>Le nom de votre site</translation>
    </message>
    <message>
        <source>The url of your site</source>
        <translation>L&apos;URL de votre site</translation>
    </message>
    <message>
        <source>The languages you chose</source>
        <translation>Les langages choisis</translation>
    </message>
    <message>
        <source>If you wish you can also add some comments which will be included in the registration.</source>
        <translation>Vous pouvez aussi ajouter des commentaires, lesquels seront ajoutés à l&apos;inscription.</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <source>Sending out the email might take a couple of seconds so please wait until the next page loads. Clicking the button again will only send out duplicate emails.</source>
        <translation>L&apos;envoi du courriel peut prendre quelques secondes, donc attendez le chargement de la page suivante. Cliquer de nouveau sur le  bouton ne fera qu&apos;envoyer des courriel supplémentaires.</translation>
    </message>
    <message>
        <source>Send Registration</source>
        <translation>Envoyer l&apos;inscription</translation>
    </message>
    <message>
        <source>Skip Registration</source>
        <translation>Sauter l&apos;inscription</translation>
    </message>
    <message>
        <source>You&apos;re site is running in virtualhost mode and is considered secure. You may safely continue.</source>
        <translation>Votre site fonctionne en mode &apos;virtualhost&apos; et est donc sécurisé. Vous pouvez continuer sans soucis.</translation>
    </message>
    <message>
        <source>Your site is running in non-virtualhost mode which is considered an unsecure mode. It&apos;s recommended to run eZ publish in virtualhost mode.
If you do not have the possiblity to use virtualhost mode you should follow the instructions below on howto install a .htaccess file, the file tells the webserver to only give access to certain files.</source>
        <translation>Votre site fonctionne en mode &apos;non-virtualhost&apos;, mode qui est considéré comme non sécurisé.Il est recommandé de faire fonctionner eZ publish en mode &apos;virtualhost&apos;.
Si vous ne pouvez pas utiliser le mode &apos;virtualhost&apos;, suivez les instructions suivantes sur comment installer un fichier .htaccess qui imposera au serveur WEB de ne donner accès qu&apos;à certains fichiers.</translation>
    </message>
    <message>
        <source>Register Site</source>
        <translation>Inscrire le site</translation>
    </message>
    <message>
        <source>It&apos;s time to specify the title and url of your site, this will be used in the title of the webpage and for sending out email with the site url.
       The administrator email is used as sender email from all emails sent from eZ publish, it&apos;s adviced to set this correctly.</source>
        <translation>Indiquez le titre et l&apos;URL de votre site, qui seront utilisés pour le titre de la page web et pour l&apos;envoi de courriel mentionnant l&apos;URL du site.
       le compte de courrier de l&apos;administrateur est utilisé pour tous les courriels envoyés depuis eZ publish. Il est donc important de bien le renseigner.</translation>
    </message>
    <message>
        <source>Title of your site</source>
        <translation>Titre de votre Site</translation>
    </message>
    <message>
        <source>URL to your site</source>
        <translation>URL de votre Site</translation>
    </message>
    <message>
        <source>Administator E-Mail</source>
        <translation>Courriel de l&apos;administrateur</translation>
    </message>
    <message>
        <source>Securing Site</source>
        <translation>Sécuriser le site</translation>
    </message>
    <message>
        <source>What kind of language support should this site have. The type of support determines the language selection and charset.</source>
        <translation>Quel support de langage ce site devrait-il avoir. Le type de support détermine la sélection du langage et le jeu de caractères.</translation>
    </message>
    <message>
        <source>Monolingual (one language)</source>
        <translation>Unilingue (un langage)</translation>
    </message>
    <message>
        <source>Multilingual (multiple languages with one charset)</source>
        <translation>Multilingue (plusieurs langages mais un seul jeu de caractères)</translation>
    </message>
    <message>
        <source>Multilingual (Unicode, no limit)</source>
        <translation>Multilingue (Unicode, sans limites)</translation>
    </message>
    <message>
        <source>Regional Options</source>
        <translation>Options de régions</translation>
    </message>
    <message>
        <source>Here you will see a summary of the basic settings for your site. If you are satisfied with the settings you can click the</source>
        <translation>Voici un sommaire des paramères de base de votre site. Si vous en êtes satisfaits, cliquez sur</translation>
    </message>
    <message>
        <source>Setup Database</source>
        <translation>Configurer la base de données</translation>
    </message>
    <message>
        <source>However if you want to change your settings click the</source>
        <translation>Si vous souhaitez modifier les paramètres, cliquez sur</translation>
    </message>
    <message>
        <source>Start Over</source>
        <translation>Recommencer</translation>
    </message>
    <message>
        <source>button which will restart the collecting of information (Existing settings are kept).</source>
        <translation> qui recommencera la collecte d&apos;informations (les paramètres existants sont conservés).</translation>
    </message>
    <message>
        <source>Database settings</source>
        <translation>Paramètres de la base de données</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de données</translation>
    </message>
    <message>
        <source>Language settings</source>
        <translation>Paramètres de langage</translation>
    </message>
    <message>
        <source>Language type</source>
        <translation>Type de langage</translation>
    </message>
    <message>
        <source>Monolingual</source>
        <translation>Unilingue</translation>
    </message>
    <message>
        <source>Multilingual</source>
        <translation>Multilingue</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Langages</translation>
    </message>
    <message>
        <source>No problems was found with your system, you can continue by clicking the</source>
        <translation>Aucun problème n&apos;a été trouvé. Vous pouvez continuer en cliquant sur</translation>
    </message>
    <message>
        <source>However if you wish to finetune your system you should click the</source>
        <translation>Cependant si vous souhaitez faire la mise au point de votre système, cliquez sur</translation>
    </message>
    <message>
        <source>Finetune System</source>
        <translation>Mise au point du système</translation>
    </message>
    <message>
        <source>The system check found some issues that needs to be resolve before the setup can continue.</source>
        <translation>Le vérificateur système a trouvé certains problèmes qui doivent être réglés avant que la configuration se poursuive.</translation>
    </message>
    <message>
        <source>Please have a look through the results below for more information on what the problems are.</source>
        <translation>Veuillez examiner les résultats ci-dessous pour plus d&apos;informations sur les problèmes à régler.</translation>
    </message>
    <message>
        <source>Each problem will give you instructions on how to fix the problem.</source>
        <translation>La description de chaque problème vous donnera des instructions sur la façon de régler ce problème.</translation>
    </message>
    <message>
        <source>After you have fixed the problems click the %1 button to re-run the system checking. You may also ignore specific tests by clicking the checkboxes.</source>
        <translation>Après avoir réglé les problèmes, cliquez sur %1 pour recommencer la vérification. Vous pouvez aussi ignorer certains tests en cochant les cases.</translation>
    </message>
    <message>
        <source>Welcome to the setup program for eZ publish %1.</source>
        <translation>Bienvenue au programme de configuration de eZ publish %1.</translation>
    </message>
    <message>
        <source>This part of the setup system will guide you trough the necessary steps to make sure eZ publish is properly initialized</source>
        <translation>Cette section vous guidera à travers toutes les étapes de configuration afin d&apos;assurer une bonne initialisation de eZ publish</translation>
    </message>
    <message>
        <source>Click the button below to proceed to the next step which will start the system check.</source>
        <translation>Cliquez sur le bouton ci-dessous pour aller à l&apos;étape suivante et commencer la vérification du système.</translation>
    </message>
    <message>
        <source>However if you wish to setup the site manually press the</source>
        <translation>Cependant si vous souhaitez configurer le site manuellement cliquez sur</translation>
    </message>
    <message>
        <source>Disable Setup</source>
        <translation>Désactiver l&apos;outil de configuration</translation>
    </message>
    <message>
        <source>System Check</source>
        <translation>Vérifier le système</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/operatorcode</name>
    <message>
        <source>Example</source>
        <translation>Exemple</translation>
    </message>
    <message>
        <source>Constructor, does nothing by default.</source>
        <translation>Constructeur, par défaut ne fait rien.</translation>
    </message>
    <message>
        <source>\return an array with the template operator name.</source>
        <translation>retourne un tableau de noms d&apos;opérateur de modèle</translation>
    </message>
    <message>
        <source>Executes the PHP function for the operator cleanup and modifies \a $operatorValue.</source>
        <translation>Exécute la fonction PHP correspondant à l&apos;opérateur &quot;cleanup&quot; et modifie \a $operatorValue.</translation>
    </message>
    <message>
        <source>Example code, this code must be modified to do what the operator should do, currently it only trims text.</source>
        <translation>Code d&apos;exemple : ce code actuellement il �quilibre seulement le texte.</translation>
    </message>
</context>
<context>
    <name>design/standard/setup/tests</name>
    <message>
        <source>Missing database handlers</source>
        <translation>Gestionnaires de base de données absents</translation>
    </message>
    <message>
        <source>Your PHP does not have support for all databases that eZ publish support.</source>
        <translation>Votre PHP ne supporte pas toutes les bases de données supportées par eZ publish.</translation>
    </message>
    <message>
        <source>Allthough eZ publish will work without it, it might be that you want to have support for this database.</source>
        <translation>Bien que eZ publish soit tout de même fonctionnel, il est préférable que cette base de données soit supportée.</translation>
    </message>
    <message>
        <source>Also some databases has more advanced features, such as charset, than others.</source>
        <translation>Par ailleurs certaines bases de données offrent des fonctions plus avancées que les autres, telles que les jeux de caractères.</translation>
    </message>
    <message>
        <source>To obtain more database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Pour d&apos;obtenir le support de plus de bases de données vous devez recompiler PHP en utilisant les options ci-dessous.</translation>
    </message>
    <message>
        <source>Missing database handler</source>
        <translation>Gestionnaire de base de données absent</translation>
    </message>
    <message>
        <source>No supported database handlers were found. eZ publish requires a database to store it&apos;s data, without one the system will fail.</source>
        <translation>Aucun gestionnaire de base de données supporté n&apos;a été trouvé.  eZ publish nécessite une base de données pour stocker ses données, sinon le système ne fonctionnera pas.</translation>
    </message>
    <message>
        <source>To obtain database support you need to recompile PHP, the exact recompile options are specified below.</source>
        <translation>Afin d&apos;obtenir le support pour cette base de données vous devez recompiler PHP en utilisant les options ci-dessous.</translation>
    </message>
    <message>
        <source>Insufficient directory permissions</source>
        <translation>Les permissions du répertoire sont insuffisantes</translation>
    </message>
    <message>
        <source>eZ publish cannot write to some important directories, without this the setup cannot finish and parts of eZ publish will fail.</source>
        <translation>eZ publish n&apos;a pas accès en écriture à certains répertoires importants. En conséquence, la configuration ne peut se poursuivre et certaines parties de eZ publish ne fonctionneront pas.</translation>
    </message>
    <message>
        <source>It&apos;s recommended that you fix this by running the commands below.</source>
        <translation>Nous vous recommandons régler ce problème en utilisant les commandes ci-desous.</translation>
    </message>
    <message>
        <source>Shell commands</source>
        <translation>Commandes &quot;Shell&quot; du système</translation>
    </message>
    <message>
        <source>File uploading is disabled</source>
        <translation>Le chargement dd fichier est désactivé</translation>
    </message>
    <message>
        <source>File uploading is not enabled which means that it&apos;s impossible for eZ publish to handle file uploading. All other parts of eZ publish will still work fine but it&apos;s recommended to enable file uploads.</source>
        <translation>Le chargement du fichier n&apos;est pas activé, ce qui signifie que eZ publish ne peut effectuer le chargement. eZ publish continuera de fonctionner normalement mais il est recommandé d&apos;activer le chargement de fichiers.</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Configuration</translation>
    </message>
    <message>
        <source>Enabling file uploads is done by setting %1 in php.ini. Refer to the PHP manual for how to set configuration switches</source>
        <translation>Vous pouvez activer le chargement des fichiers en réglant %1 dans php.ini. Référez-vous au manuel PHP pour plus de détails.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found by reading %1 and %2</source>
        <translation>Vous trouverez plus d&apos;informations sur l&apos;activation d&apos;extensions dans %1 et %2</translation>
    </message>
    <message>
        <source>Missing image conversion support</source>
        <translation>Support de conversion d&apos;image absent</translation>
    </message>
    <message>
        <source>No image conversion capabilities was detected, this means that eZ publish cannot scale any images or detect their type. This is vital functionality in eZ publish and must be supported.</source>
        <translation>Aucune fonction de conversion d&apos;image n&apos;a été détectée, ce qui signifie que eZ publish ne peut modifier la taille ou détecter le type d&apos;une image. C&apos;est une fonction essentielle dans eZ publish et elle &quot;doit&quot; être supportée.</translation>
    </message>
    <message>
        <source>Missing imagegd extension</source>
        <translation>Extension d&apos;imagegd absente</translation>
    </message>
    <message>
        <source>The imagegd extension is not available to eZ publish. Without it eZ publish will only be able to do conversion using ImageMagick and the</source>
        <translation>L&apos;extension imagegd n&apos;est pas disponible pour eZ publish. Sans cette extention, eZ publish effectuera la conversion avec ImageMagick et le</translation>
    </message>
    <message>
        <source>template operator will not be available.</source>
        <translation>Les opérateurs de modèle ne seront pas disponibles.</translation>
    </message>
    <message>
        <source>Note:</source>
        <translation>Note :</translation>
    </message>
    <message>
        <source>Future releases of eZ publish will have more advanced image support by using the imagegd extension.</source>
        <translation>De prochaines versions de eZ publish aurontun support des images plus avancé avec l&apos;utilisation de l&apos;extension imagegd.</translation>
    </message>
    <message>
        <source>To enable imagegd you need to recompile PHP with support for it, more information on that subject is available at</source>
        <translation>Pour activer imagegd vous devez compiler PHP avec le support nécessaire. Vous trouverez plus d&apos;information sur ce sujet à</translation>
    </message>
    <message>
        <source>Missing ImageMagick program</source>
        <translation>Le programme ImageMagick est absent</translation>
    </message>
    <message>
        <source>The ImageMagick program is not available to eZ publish. Without it eZ publish will not be able to do image conversion unless the imagegd extension is available.</source>
        <translation>Le programme ImageMagick n&apos;est pas disponible pour eZ publish. Sans ce programme, eZ publish ne peut effectuer de conversions d&apos;images, sauf si l&apos;extension imagegd est disponible.</translation>
    </message>
    <message>
        <source>If you known where the program is installed (the executable is called</source>
        <translation>Si vous connaissez l&apos;emplacement du programme (L&apos;éxécutable s&apos;appelle</translation>
    </message>
    <message>
        <source>or</source>
        <translation>ou</translation>
    </message>
    <message>
        <source>)then enter the directory in the input field below and do a recheck (Separate multiple directories with a</source>
        <translation>) alors entrez le nom du répertoire dans le champ ci-dessous et revérifiez (Répertoires multiples distincts avec</translation>
    </message>
    <message>
        <source>colon</source>
        <translation>virgule</translation>
    </message>
    <message>
        <source>semicolon</source>
        <translation>point-virgule</translation>
    </message>
    <message>
        <source>Installation</source>
        <translation>Installation</translation>
    </message>
    <message>
        <source>ImageMagick may be downloaded from</source>
        <translation>ImageMagick peut être téléchargé à partir de</translation>
    </message>
    <message>
        <source>Missing MBString extension</source>
        <translation>L&apos;extension MBString est absente</translation>
    </message>
    <message>
        <source>eZ publish comes with a good list of supported charsets by default, however they can be a bit slow due to being made in pure PHP code. Luckily eZ publish supports the mbstring extension for handling some of the charsets.</source>
        <translation>Par défault, eZ publish fournit plusieurs jeux de caractères. Cependant, leur rapidité d&apos;exécution peut être fible en raison de leur conception exclusive en code PHP. Heureusement, eZ publish supporte l&apos;extension mbstring, laquelle facilite la manipulation de certains jeux de caractères.</translation>
    </message>
    <message>
        <source>By enabling the mbstring extension eZ publish will have access to more charsets and also be able to process some of them faster, such as Unicode and iso-8859-*. This is recommended for multilingual sites and sites with more exotic charsets.</source>
        <translation>En activant l&apos;extension mbstring, eZ publish aura accès à une plus grande variété de jeux de caractères tels que Unicode et iso-8859-*, et pourra en exécuter certains plus rapidement. Ceci est recommandé pour les sites multilingues et les sites contenants des jeux de caractères non couramment utilisés.</translation>
    </message>
    <message>
        <source>The complete list of charsets mbstring supports are:</source>
        <translation>Voici la liste complète des jeux de caractères supportés par mbstring:</translation>
    </message>
    <message>
        <source>Installation of the mbstring extension is done by compiling PHP with the</source>
        <translation>L&apos;installation de l&apos;extension mbstring se fait en compilant le PHP avec l&apos;</translation>
    </message>
    <message>
        <source>option.</source>
        <translation>option.</translation>
    </message>
    <message>
        <source>More information on enabling the extension can be found at</source>
        <translation>Vous trouverez plus d&apos;information sur l&apos;activation de cette extension à</translation>
    </message>
    <message>
        <source>Do not enable mbstring function overloading, eZ publish will only use the extension whenever it&apos;s needed.</source>
        <translation>N&apos;activez pas la surcharge de la fonction mbstring. De cette façon, eZ publish utilisera l&apos;extension seulement lorsque nécessaire. </translation>
    </message>
    <message>
        <source>PHP option</source>
        <translation>Option PHP</translation>
    </message>
    <message>
        <source>is enabled</source>
        <translation>est activée</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables need to be be converted back to</source>
        <translation>eZ publish utilisera cette option si elle est activée; cependant, certains problèmes de performance mineurs se présenteront puisque toutes les variables doivent être reconverties à</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 and %3 to %4.</source>
        <translation>La désactivation de cette option est recommandée. Pour la désactiver, éditez votre configuration %1 et positionnez %2 et %3 à%4</translation>
    </message>
    <message>
        <source>More information on the subject can be found at %1.</source>
        <translation>Vous trouverez plus d&apos;informations sur ce sujet à %1.</translation>
    </message>
    <message>
        <source>php.ini example:</source>
        <translation>php.ini example :</translation>
    </message>
    <message>
        <source>Alternatively you may create a file called %1 in your eZ publish root folder and add the following:</source>
        <translation>Ou alors, vous pouvez créer un fichier appelé %1 dans le répertoire racine de eZ Publish et ajouter ce qui suit :</translation>
    </message>
    <message>
        <source>.htaccess example:</source>
        <translation>Exemple .htaccess :</translation>
    </message>
    <message>
        <source>PHP option %1 is enabled</source>
        <translation>L&apos;option PHP %1 est activée</translation>
    </message>
    <message>
        <source>eZ publish will work with this option on however it will lead to some minor performance issues since all input variables will be made global on each script execution.</source>
        <translation>eZ publish utilisera cette option si elle est activée; cependant, certains problèmes de performance mineurs se présenteront puisque toutes les variables seront contituées variables globales à chaque exécution de script</translation>
    </message>
    <message>
        <source>It&apos;s recommended that the option is turned off. To turn it off edit your %1 configuration and set %2 to %3.</source>
        <translation>La désactivation de cette option est recommandée. Pour la désactiver, éditez la configuration de %1 et positionnez %2 et %3 à %4</translation>
    </message>
    <message>
        <source>Insufficient PHP version</source>
        <translation>Version PHP insuffisante</translation>
    </message>
    <message>
        <source>Your PHP version, which is </source>
        <translation>Votre version PHP,</translation>
    </message>
    <message>
        <source>, does not meet the minimum requirements of</source>
        <translation>ne satisfait pas aux exigences minimales de</translation>
    </message>
    <message>
        <source>A newer version of PHP can be download at</source>
        <translation>Vous pouvez télécharger une version plus récente de PHP à</translation>
    </message>
    <message>
        <source>You must upgrade to at least version </source>
        <translation>Vous devez utiliser au moins la version</translation>
    </message>
    <message>
        <source>, but an even newer version, such as 4.2.3, is highly recommended.</source>
        <translation>mais l&apos;utilisation d&apos;une version encore plus récente, comme 4.2.3, est fortement recommandée.</translation>
    </message>
    <message>
        <source>PHP safe mode is enabled</source>
        <translation>Le mode &quot;safe&quot; de PHP est activé</translation>
    </message>
    <message>
        <source>eZ publish may work with safe mode on, however there might be several features that will be unavailable. Some of the things that might occur are:</source>
        <translation>eZ publish peut fonctionner avec le  mode &quot;safe&quot; activé, mais de nombreuses fonctionnalités seront indisponibles. Les éffets suivants peuvent survenir :</translation>
    </message>
    <message>
        <source>eZ publish cannot write to the</source>
        <translation>eZ publish ne peut écrire dans le</translation>
    </message>
    <message>
        <source>directory, without this the setup cannot disable itself.</source>
        <translation>répertoire, en conséquence la configuratio ne peut se désactiver d&apos;elle-même.</translation>
    </message>
    <message>
        <source>Missing zlib extension</source>
        <translation>L&apos;extension zlib est absente</translation>
    </message>
    <message>
        <source>The zlib extension is not available to eZ publish. Without it eZ publish will not be able to install the demo data, however if you do not wish the demo data you can safely ignore this.</source>
        <translation>L&apos;extension zlib n&apos;est pas disponible pour eZ publish. Sans cette extension, eZ publish ne pourra installer les données de démo. Ignorez cet avis si vous ne souhaitez pas utiliser les données de démo.</translation>
    </message>
    <message>
        <source>To enable zlib you need to recompile PHP with support for it. You will need to configure PHP with</source>
        <translation>Pour activer zlib, vous devez recompiler PHP avec le support nécessaire. Vous devrez configurer PHP avec</translation>
    </message>
    <message>
        <source>More information on that subject is available at</source>
        <translation>Vous trouverez plus d&apos;informations sur ce sujet à</translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Find</source>
        <translation>Trouver</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Basket</source>
        <translation>Panier</translation>
    </message>
    <message>
        <source>Product</source>
        <translation>Produit</translation>
    </message>
    <message>
        <source>Count</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>VAT</source>
        <translation>TVA</translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation>Prix HT</translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation>Prix TTC</translation>
    </message>
    <message>
        <source>Discount</source>
        <translation>Rabais</translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation>Prix Total HT</translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation>Prix Total TTC</translation>
    </message>
    <message>
        <source>Subtotal Ex. VAT:</source>
        <translation>Sous-total HT :</translation>
    </message>
    <message>
        <source>Subtotal Inc. VAT:</source>
        <translation>Sous-total TTC :</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation>Continuer le shopping</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Passez en caisse</translation>
    </message>
    <message>
        <source>You have no products in your basket</source>
        <translation>Votre panier est vide</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmez la commande</translation>
    </message>
    <message>
        <source>Customer:</source>
        <translation>Client :</translation>
    </message>
    <message>
        <source>Product items</source>
        <translation>Articles</translation>
    </message>
    <message>
        <source>Order summary:</source>
        <translation>Résumé de la commande :</translation>
    </message>
    <message>
        <source>Subtotal of items:</source>
        <translation>Sous-total des articles :</translation>
    </message>
    <message>
        <source>Order total:</source>
        <translation>Total de la commande :</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Discount groups</source>
        <translation>Groupe de rabais</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Edit discount group - %1</source>
        <translation>Éditer groupe de rabais - %1</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abandonner</translation>
    </message>
    <message>
        <source>Group view</source>
        <translation>Affichage du groupe</translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation>Nom du groupe</translation>
    </message>
    <message>
        <source>Defined rules</source>
        <translation>Règles définis</translation>
    </message>
    <message>
        <source>Percent</source>
        <translation>Pourcentage</translation>
    </message>
    <message>
        <source>Apply to</source>
        <translation>Appliquer à</translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation>Ajouter règle</translation>
    </message>
    <message>
        <source>Remove Rule</source>
        <translation>Supprimer règle</translation>
    </message>
    <message>
        <source>Customers</source>
        <translation>Clients</translation>
    </message>
    <message>
        <source>Add customer</source>
        <translation>Ajouter client</translation>
    </message>
    <message>
        <source>Remove customer</source>
        <translation>Supprimer client</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Éditer la règle</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Attributs</translation>
    </message>
    <message>
        <source>Discount percent</source>
        <translation>Pourcentage de rabais</translation>
    </message>
    <message>
        <source>Rule settings</source>
        <translation>Paramètres de la règle</translation>
    </message>
    <message>
        <source>Choose which classes, sections or objects ( products ) applied to this sub rule, &apos;Any&apos; means the rule will applied to all.</source>
        <translation>Déterminer à quelles classes, sections ou objets (articles) s&apos;applique cette sous-règle. &apos;TOUT&apos; signifie que la règle sera appliquée à tous.</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>TOUT</translation>
    </message>
    <message>
        <source>Section</source>
        <translation>Section</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objet</translation>
    </message>
    <message>
        <source>Not specified.</source>
        <translation>Non indiqué</translation>
    </message>
    <message>
        <source>Order:</source>
        <translation>Commande :</translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation>Sous-total des articles</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Liste des commandes</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Trier par</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Client</translation>
    </message>
    <message>
        <source>Total ex. VAT</source>
        <translation>Total HT</translation>
    </message>
    <message>
        <source>Total inc. VAT</source>
        <translation>Total TTC</translation>
    </message>
    <message>
        <source>The order list is empty</source>
        <translation>La liste de commande est vide</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Commande</translation>
    </message>
    <message>
        <source>Order total</source>
        <translation>Total de la commande</translation>
    </message>
    <message>
        <source>Register account information</source>
        <translation>Enregistrer les informations du compte</translation>
    </message>
    <message>
        <source>Input did not validate, fill in all fields</source>
        <translation>Entrée invalide, remplissez tous les champs</translation>
    </message>
    <message>
        <source>VAT Types</source>
        <translation>Types de TVA</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Pourcentage</translation>
    </message>
    <message>
        <source>Wish list</source>
        <translation>Liste de suggestions</translation>
    </message>
    <message>
        <source>Remove item(s)</source>
        <translation>Supprimer le ou les produit(s)</translation>
    </message>
    <message>
        <source>Empty wish list</source>
        <translation>Vider la liste de suggestions</translation>
    </message>
</context>
<context>
    <name>design/standard/trigger</name>
    <message>
        <source>Trigger list</source>
        <translation>Liste des déclencheurs</translation>
    </message>
    <message>
        <source>Module Name</source>
        <translation>Nom du module</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>Nom de la fonction</translation>
    </message>
    <message>
        <source>Connect Type</source>
        <translation>Type de connexion</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Processus de workflow</translation>
    </message>
    <message>
        <source>No workflow</source>
        <translation>Aucun processus de workflow</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
</context>
<context>
    <name>design/standard/url</name>
    <message>
        <source>All</source>
        <translation>Tout</translation>
    </message>
    <message>
        <source>Valid</source>
        <translation>Valide</translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation>Invalide</translation>
    </message>
    <message>
        <source>The URL is not considered valid anymore.</source>
        <translation>L&apos;URL n&apos;est plus considéré valide.</translation>
    </message>
    <message>
        <source>This means that the url is no longer available or has been moved.</source>
        <translation>Cela signifie que le lien n&apos;est plus disponible ou que le site a changé d&apos;adresse.</translation>
    </message>
    <message>
        <source>The URL points to %1.</source>
        <translation>L&apos;URL pointe vers %1.</translation>
    </message>
    <message>
        <source>Last modified at %1</source>
        <translation>Dernière modification à %1</translation>
    </message>
    <message>
        <source>URL has no modification date</source>
        <translation>L&apos;URL n&apos;a pas de date de modification</translation>
    </message>
    <message>
        <source>Last checked at %1</source>
        <translation>Dernière vérification à %1</translation>
    </message>
    <message>
        <source>URL has not been checked</source>
        <translation>L&apos;URL n&apos;a pas été vérifié</translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Login</source>
        <translation>Ouverture de session</translation>
    </message>
    <message>
        <source>Activate account</source>
        <translation>Activer le compte</translation>
    </message>
    <message>
        <source>User profile</source>
        <translation>Profil de l&apos;utilisateur</translation>
    </message>
    <message>
        <source>E-Mail</source>
        <translation>Courriel</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Edit Profile</source>
        <translation>Éditer le profil</translation>
    </message>
    <message>
        <source>Change Password</source>
        <translation>Modifier le mot de passe</translation>
    </message>
    <message>
        <source>Change Setting</source>
        <translation>Modifier les paramètres</translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation>Impossible d&apos;ouvrir une session</translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation>Un nom de connexion et un mot de passe valides sont nécessaires pour ouvrir une session.</translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation>accès non autorisé</translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation>Vous n&apos;avez pas l&apos;autorisation d&apos;accèder à %1.</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <source>Sign Up</source>
        <translation>S&apos;inscrire</translation>
    </message>
    <message>
        <source>Change password for user</source>
        <translation>Modifier le mot de passe pour l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Please retype your old password.</source>
        <translation>SVP, entrez à nouveau votre ancien mot de passe.</translation>
    </message>
    <message>
        <source>Password didn&apos;t match, please retype your new password.</source>
        <translation>Le mot de passe ne correspond pas, SVP, entrez à nouveau votre nouveau mot de passe.</translation>
    </message>
    <message>
        <source>Password successfully updated.</source>
        <translation>Le mot de passe a bien été mis à jour.</translation>
    </message>
    <message>
        <source>Old Password</source>
        <translation>Ancien mot de passe</translation>
    </message>
    <message>
        <source>New Password</source>
        <translation>Nouveau mot de passe</translation>
    </message>
    <message>
        <source>Retype Password</source>
        <translation>Réinscrire le mot de passe</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Register user</source>
        <translation>Inscrire l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation>Entrée invalide</translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation>L&apos;entrée a été Enregistrée</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>Inscrire</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abandonner</translation>
    </message>
    <message>
        <source>User setting</source>
        <translation>Paramètres de l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Maximum login</source>
        <translation>Nombre de sessions maximum</translation>
    </message>
    <message>
        <source>Is enabled</source>
        <translation>Activé</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Mise à jour</translation>
    </message>
    <message>
        <source>User registered</source>
        <translation>Utilisateur inscrit</translation>
    </message>
    <message>
        <source>Your account was successfully created.</source>
        <translation>Votre compte a bien été créé.</translation>
    </message>
</context>
<context>
    <name>design/standard/user/forgotpassword</name>
    <message>
        <source>A mail has been send to the following e-mail address: %1. This e-mail contains a link you need to click so that we can confirm that the correct user is getting the new password.</source>
        <translation>Un courriel a été envoyé à l&apos;adresse courriel suivante : %1. Ce courriel contient un lien sur lequel il vous faudra cliquer pour nous confirmer que le bon utilisateur recoit le nouveau mot de passe.</translation>
    </message>
    <message>
        <source>There is no registered user with that e-mail address.</source>
        <translation>Il n&apos;y a pas d&apos;utilisateur inscrit avec cette adresse courriel.</translation>
    </message>
    <message>
        <source>Password was successfully generated and sent to:</source>
        <translation>Mot de passe généré et envoyé à :</translation>
    </message>
    <message>
        <source>Have you forgotten your password?</source>
        <translation>Avez-vous oublié votre mot de passe ?</translation>
    </message>
    <message>
        <source>If you have forgotten your password we can generate a new one for you. All you need to do is to enter your e-mail address and we will create a new password for you.</source>
        <translation>Si vous avez oublié votre mot de passe, nous pouvons vous en générer un nouveau. Entrez simplement votre adresse courriel et votre nouveau mot de passe sera créé.</translation>
    </message>
    <message>
        <source>E-mail:</source>
        <translation>Courriel :</translation>
    </message>
    <message>
        <source>Generate new password</source>
        <translation>Générer un nouveau mot de passe</translation>
    </message>
    <message>
        <source>%1 new password</source>
        <translation>%1 nouveau mot de passe</translation>
    </message>
    <message>
        <source>Your account information</source>
        <translation>Les informations sur votre compte</translation>
    </message>
    <message>
        <source>Email:</source>
        <translation>Courriel :</translation>
    </message>
    <message>
        <source>Click here to get new password:</source>
        <translation>Cliquez ici pour obtenir un nouveau mot de passe</translation>
    </message>
    <message>
        <source>New password:</source>
        <translation>Nouveau mot de passe :</translation>
    </message>
</context>
<context>
    <name>design/standard/user/register</name>
    <message>
        <source>Confirm user registration at %1</source>
        <translation>Confirmez l&apos;inscription de l&apos;usager à %1</translation>
    </message>
    <message>
        <source>New user registered at %1</source>
        <translation>Nouvel usager inscript à %1</translation>
    </message>
    <message>
        <source>%1 registration info</source>
        <translation>Information d&apos;inscription de %1</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Editing workflow</source>
        <translation>Éditer le processus de workflow</translation>
    </message>
    <message>
        <source>Workflow stored</source>
        <translation>Processus de workflow enregistré</translation>
    </message>
    <message>
        <source>Data requires fixup</source>
        <translation>Les données doivent être réparées</translation>
    </message>
    <message>
        <source>Modified by</source>
        <translation>Modifié par</translation>
    </message>
    <message>
        <source>on</source>
        <translation>sur</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Groups</source>
        <translation>Groupes</translation>
    </message>
    <message>
        <source>Events</source>
        <translation>Événements</translation>
    </message>
    <message>
        <source>Pos</source>
        <translation>Pos</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <source>Store</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abandonner</translation>
    </message>
    <message>
        <source>Editing workflow group</source>
        <translation>Éditer le groupe de processus de workflow</translation>
    </message>
    <message>
        <source>Workflow groups</source>
        <translation>Groupes de processus de workflow</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>New group</source>
        <translation>Nouveau groupe</translation>
    </message>
    <message>
        <source>Workflow process</source>
        <translation>Processus de workflow (gestion de déroulement des opérations)</translation>
    </message>
    <message>
        <source>Workflow process was created at</source>
        <translation>Processus de workflow (gestion de déroulement des opérations) créé à</translation>
    </message>
    <message>
        <source>and modified at</source>
        <translation>et modifié à</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Gestion de déroulement des opérations (workflow)</translation>
    </message>
    <message>
        <source>Using workflow</source>
        <translation>Utilisation de la gestion de déroulement des opérations (workflow)</translation>
    </message>
    <message>
        <source>for processing.</source>
        <translation>pour le traitement.</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Utilisateur</translation>
    </message>
    <message>
        <source>This workflow is running for user</source>
        <translation>Le processus de workflow est en cours pour l&apos;utilisateur</translation>
    </message>
    <message>
        <source>Content object</source>
        <translation>Contenu de l&apos;objet</translation>
    </message>
    <message>
        <source>Workflow was created for content</source>
        <translation>Un processus de workflow a été créée pour le contenu</translation>
    </message>
    <message>
        <source>using version</source>
        <translation>utilisant la version</translation>
    </message>
    <message>
        <source>in parent</source>
        <translation>dans le parent</translation>
    </message>
    <message>
        <source>Workflow event</source>
        <translation>Événement dans le processus de workflow</translation>
    </message>
    <message>
        <source>Workflow has not started yet, number of main events in workflow is</source>
        <translation>e Lprocessus de workflow n&apos;est pas commencée, le nombre d&apos;événements principaux dans le volume de travail est</translation>
    </message>
    <message>
        <source>Current event position is</source>
        <translation>La position de l&apos;événement courant est</translation>
    </message>
    <message>
        <source>Event to be run is</source>
        <translation>L&apos;événement à être activé est</translation>
    </message>
    <message>
        <source>event</source>
        <translation>événement</translation>
    </message>
    <message>
        <source>Last event returned status</source>
        <translation>Le dernier événement a renvoyé le statut</translation>
    </message>
    <message>
        <source>Workflow event list</source>
        <translation>Liste d&apos;événements dans le processus de workflow</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Remise à zéro</translation>
    </message>
    <message>
        <source>Next step</source>
        <translation>Prochaine étape</translation>
    </message>
    <message>
        <source>Workflow event log</source>
        <translation>Journal des événements dans le processus de workflow</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Workflows in %1</source>
        <translation>processus de workflow dans %1</translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation>Modificateur</translation>
    </message>
    <message>
        <source>Modified</source>
        <translation>Modifié</translation>
    </message>
    <message>
        <source>New workflow</source>
        <translation>Nouveau processus de workflow</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Editor</source>
        <translation>Éditeur</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sections</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>N&apos;importe quel</translation>
    </message>
    <message>
        <source>Users without approval</source>
        <translation>Utilisateurs sans approbation</translation>
    </message>
    <message>
        <source>Checkout text</source>
        <translation>Texte de contrôle</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <source>Classes to run workflow</source>
        <translation>Classes pour lancer un processus de workflow</translation>
    </message>
    <message>
        <source>Users without workflow IDs</source>
        <translation>Utilisateurs sans ID de processus de workflow</translation>
    </message>
    <message>
        <source>Workflow to run</source>
        <translation>processus de workflow à lancer</translation>
    </message>
    <message>
        <source>Unpublish object</source>
        <translation>Retirer l&apos;objet de la publication</translation>
    </message>
    <message>
        <source>Publish object</source>
        <translation>Publier l&apos;objet</translation>
    </message>
    <message>
        <source>Days</source>
        <translation>Jours</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation>Heures</translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation>Minutes</translation>
    </message>
    <message>
        <source>New Entry</source>
        <translation>Nouvelle entrée</translation>
    </message>
    <message>
        <source>Remove Selected</source>
        <translation>Supprimer la sélection</translation>
    </message>
    <message>
        <source>Load Attributes</source>
        <translation>Charger les attributs</translation>
    </message>
    <message>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <source>Class Attributes:</source>
        <translation>Attributs de classe :</translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/result</name>
    <message>
        <source>Checkout</source>
        <translation>contrôler</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <source>Wrapping</source>
        <translation>Emballage</translation>
    </message>
    <message>
        <source>Hello</source>
        <translation>Bonjour</translation>
    </message>
</context>
<context>
    <name>kernel/class</name>
    <message>
        <source>Class list of group</source>
        <translation>Liste des classes du groupe</translation>
    </message>
    <message>
        <source>Class group list</source>
        <translation>Liste des groupes de classes</translation>
    </message>
    <message>
        <source>Remove class</source>
        <translation>Supprimer la classe</translation>
    </message>
    <message>
        <source>Class edit</source>
        <translation>Éditer la classe</translation>
    </message>
    <message>
        <source>Classes</source>
        <translation>Classes</translation>
    </message>
    <message>
        <source>Class list</source>
        <translation>Liste des classes</translation>
    </message>
    <message>
        <source> object</source>
        <translation> objet</translation>
    </message>
    <message>
        <source> objects</source>
        <translation> objets</translation>
    </message>
    <message>
        <source>Remove classes</source>
        <translation>Supprimer les classes</translation>
    </message>
    <message>
        <source>(no classes)</source>
        <translation>(aucune classe)</translation>
    </message>
    <message>
        <source>Remove class groups</source>
        <translation>Supprimer les groupes de classes</translation>
    </message>
</context>
<context>
    <name>kernel/classes</name>
    <message>
        <source>Approval</source>
        <translation>Approbation</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Observer</source>
        <translation>Observateur</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propriétaire</translation>
    </message>
    <message>
        <source>Approver</source>
        <translation>Responsable de l&apos;approbation</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation>Boîte de réception</translation>
    </message>
    <message>
        <source>No state yet</source>
        <translation>Pas encore d&apos;état</translation>
    </message>
    <message>
        <source>Workflow running</source>
        <translation>processus de workflow en cours</translation>
    </message>
    <message>
        <source>Workflow done</source>
        <translation>processus de workflow fini</translation>
    </message>
    <message>
        <source>Workflow failed an event</source>
        <translation>Le processus de workflow a échoué sur un événement</translation>
    </message>
    <message>
        <source>Workflow event deferred to cron job</source>
        <translation>L&apos;événement de processus de workflow est reporté à l&apos;exécution de la commande cron</translation>
    </message>
    <message>
        <source>Workflow was cancelled</source>
        <translation>Le processus de workflow est annulé</translation>
    </message>
    <message>
        <source>Workflow was reset for reuse</source>
        <translation>Le processus de workflow est remis à zéro pour réutilisation</translation>
    </message>
    <message>
        <source>Accepted event</source>
        <translation>Événement accepté</translation>
    </message>
    <message>
        <source>Rejected event</source>
        <translation>Événement refusé</translation>
    </message>
    <message>
        <source>Event deferred to cron job</source>
        <translation>L&apos;événement est reporté à l&apos;exécution de la commande cron</translation>
    </message>
    <message>
        <source>Event deferred to cron job, event will be rerun</source>
        <translation>L&apos;événement est reporté à l&apos;exécution de la commande cron; l&apos;événement sera réactivé</translation>
    </message>
    <message>
        <source>Event runs a sub event</source>
        <translation>L&apos;événement à lanc� l&apos;exécution d&apos;un sous-événement</translation>
    </message>
    <message>
        <source>Cancelled whole workflow</source>
        <translation>Toute la gestion de déroulement des opérations (workflow) est annulée</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatype/ezbinaryfiletype</name>
    <message>
        <source>File uploading is not enabled, no file handling can be performed.</source>
        <translation>Le chargement vers le serveur n&apos;est pas activé, aucune manipulation de fichiers ne peut être effectuée.</translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>At least one author is required.</source>
        <comment>eZAuthorType</comment>
        <translation>Au moins un auteur est requis.</translation>
    </message>
    <message>
        <source>Author name should be provided.</source>
        <comment>eZAuthorType</comment>
        <translation>Le nom de l&apos;auteur doit être fourni.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZAuthorType</comment>
        <translation>Le courriel est invalide.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZBinaryFileType</comment>
        <translation>Un fichier valide est requis.</translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation>Date manquante.</translation>
    </message>
    <message>
        <source>Missing datetime input.</source>
        <translation>Date et heure manquantes.</translation>
    </message>
    <message>
        <source>A valid email account is required.</source>
        <comment>eZEmailType</comment>
        <translation>Un courriel valide est requis.</translation>
    </message>
    <message>
        <source>Email address is not valid.</source>
        <comment>eZEmailType</comment>
        <translation>L&apos;adresse courriel est invalide.</translation>
    </message>
    <message>
        <source>At least one field should be chosen.</source>
        <comment>eZEnumType</comment>
        <translation>Sélectionnez au moins un champ.</translation>
    </message>
    <message>
        <source>Input is not float.</source>
        <comment>eZFloatType</comment>
        <translation>L&apos;entrée n&apos;est pas un nombre flottant.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZFloatType</comment>
        <translation>La valeur doit être plus grande que %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZFloatType</comment>
        <translation>La valeur doit être plus petite que %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZFloatType</comment>
        <translation>La valeur ne se situe pas dans la fourchette définie %1-%2</translation>
    </message>
    <message>
        <source>A valid image is required.</source>
        <comment>eZImageType</comment>
        <translation>Une image valide est nécessaire.</translation>
    </message>
    <message>
        <source>Input is not integer.</source>
        <comment>eZIntegerType</comment>
        <translation>L&apos;entrée n&apos;est pas un nombre entier.</translation>
    </message>
    <message>
        <source>Input must be greater than %1</source>
        <comment>eZIntegerType</comment>
        <translation>La valeur doit être plus grande que %1</translation>
    </message>
    <message>
        <source>Input must be less than %1</source>
        <comment>eZIntegerType</comment>
        <translation>La valeur doit être plus petite que %1</translation>
    </message>
    <message>
        <source>Input is not in defined range %1 - %2</source>
        <comment>eZIntegerType</comment>
        <translation>La valeur ne se situe pas dans la fourchette définie %1-%2</translation>
    </message>
    <message>
        <source>The ISBN number is not correct. Please recheck the input</source>
        <comment>eZISBNType</comment>
        <translation>Le numéro ISBN est incorrect. Veuillez corriger</translation>
    </message>
    <message>
        <source>The ISBN format is not valid.</source>
        <comment>eZISBNType</comment>
        <translation>Le format ISBN est invalide.</translation>
    </message>
    <message>
        <source>A valid file is required.</source>
        <comment>eZMediaType</comment>
        <translation>Un fichier valide est requis.</translation>
    </message>
    <message>
        <source>At least one option is required.</source>
        <comment>eZOptionType</comment>
        <translation>Au moins une option est requise.</translation>
    </message>
    <message>
        <source>Option value should be provided.</source>
        <comment>eZOptionType</comment>
        <translation>Une valeur doit être fournie pour l&apos;option.</translation>
    </message>
    <message>
        <source>Additional price for option value is invalid.</source>
        <comment>eZOptionType</comment>
        <translation>Le prix additionnel pour la valeur de l&apos;option est invalide.</translation>
    </message>
    <message>
        <source>Text line is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation>Le champ texte est vide. Entrez l&apos;information.</translation>
    </message>
    <message>
        <source>Text line too long, maximum allowed is %1.</source>
        <comment>eZStringType</comment>
        <translation>Le texte entré est trop long. Le maximum de caractères acceptés est de %1.</translation>
    </message>
    <message>
        <source>Text field is empty, content required.</source>
        <comment>eZStringType</comment>
        <translation>Le champ texte est vide. Entrez l&apos;information.</translation>
    </message>
    <message>
        <source>Missing time input.</source>
        <translation>Heure manquante.</translation>
    </message>
    <message>
        <source>The login must be specified</source>
        <comment>eZUserType</comment>
        <translation>Nom d&apos;usager doit être spécifié</translation>
    </message>
    <message>
        <source>Login name already exists, please choose another one.</source>
        <comment>eZUserType</comment>
        <translation>Le nom d&apos;usager existe déjà, veuillez en choisir un autre.</translation>
    </message>
    <message>
        <source>The E-Mail address is not valid.</source>
        <comment>eZUserType</comment>
        <translation>Le courriel est invalide.</translation>
    </message>
    <message>
        <source>A user with this email already exists.</source>
        <comment>eZUserType</comment>
        <translation>Un utilisateur avec ce courriel existe déjà.</translation>
    </message>
    <message>
        <source>The confirmation password did not match.</source>
        <comment>eZUserType</comment>
        <translation>La confirmation du mot de passe ne concorde pas.</translation>
    </message>
    <message>
        <source>The password must be at least 3 characters.</source>
        <comment>eZUserType</comment>
        <translation>Le mot de passe doit contenir au moins 3 caractères.</translation>
    </message>
    <message>
        <source>Object </source>
        <translation>Objet </translation>
    </message>
    <message>
        <source>Link </source>
        <translation>Lien </translation>
    </message>
</context>
<context>
    <name>kernel/collaboration</name>
    <message>
        <source>Collaboration custom action</source>
        <translation>Action de collaboration personnalisée</translation>
    </message>
    <message>
        <source>Collaboration</source>
        <translation>Collaboration</translation>
    </message>
</context>
<context>
    <name>kernel/content</name>
    <message>
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avancée</translation>
    </message>
    <message>
        <source>No main node selected, please select one.</source>
        <translation>Aucun noeud pricipal sélectionné, S.V.P. sélectionnez-en un.</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenu</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>My bookmarks</source>
        <translation>Mes signets</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <source>My drafts</source>
        <translation>Mes brouillons</translation>
    </message>
    <message>
        <source>Remove editing version</source>
        <translation>Supprimer la version éditée</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Supprimer l&apos;objet</translation>
    </message>
    <message>
        <source>Tip from %1: %2</source>
        <translation>Suggestion de %1 : %2</translation>
    </message>
    <message>
        <source>The email address of the sender is not valid</source>
        <translation>Le adresse courriel l&apos;expéditeur est invalide</translation>
    </message>
    <message>
        <source>The email address of the receiver is not valid</source>
        <translation>Le courriel du destinataire est invalide</translation>
    </message>
    <message>
        <source>Tip a friend</source>
        <translation>Suggérer à un ami</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traduire</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traduction</translation>
    </message>
    <message>
        <source>Content translations</source>
        <translation>Traductions de contenu</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Corbeille</translation>
    </message>
    <message>
        <source>Versions</source>
        <translation>Versions</translation>
    </message>
</context>
<context>
    <name>kernel/content/removenode</name>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>enfant</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>enfants</translation>
    </message>
</context>
<context>
    <name>kernel/content/removeobject</name>
    <message>
        <source>And also it will remove the nodes:</source>
        <translation>Cela supprimera aussi les noeuds :</translation>
    </message>
    <message>
        <source>child</source>
        <comment>1 child</comment>
        <translation>enfant</translation>
    </message>
    <message>
        <source>children</source>
        <comment>several children</comment>
        <translation>enfants</translation>
    </message>
</context>
<context>
    <name>kernel/error</name>
    <message>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
</context>
<context>
    <name>kernel/ezinfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>About</source>
        <translation>À propos de</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
</context>
<context>
    <name>kernel/notification</name>
    <message>
        <source>Notification settings</source>
        <translation>Paramètres de notification</translation>
    </message>
</context>
<context>
    <name>kernel/role</name>
    <message>
        <source>Create policy - step 2 - Specify function</source>
        <translation>Créer une règle - Étape 2 - Spécifiez la fonction</translation>
    </message>
    <message>
        <source>Create policy - step 3 - Specify limitations</source>
        <translation>Créer une règle - Étape 3 - Spécifiez les limites</translation>
    </message>
    <message>
        <source>Create policy - step 1 - Specify module</source>
        <translation>Créer une règle - Étape 1 - Spécifiez le module</translation>
    </message>
    <message>
        <source>Role list</source>
        <translation>Liste des rôles</translation>
    </message>
    <message>
        <source>Editing policy</source>
        <translation>Liste la règle</translation>
    </message>
</context>
<context>
    <name>kernel/search</name>
    <message>
        <source>Search stats</source>
        <translation>Statistiques de recherche</translation>
    </message>
</context>
<context>
    <name>kernel/section</name>
    <message>
        <source>Edit Section</source>
        <translation>Éditer la section</translation>
    </message>
    <message>
        <source>Sections</source>
        <translation>Sections</translation>
    </message>
</context>
<context>
    <name>kernel/setup</name>
    <message>
        <source>Cache admin</source>
        <translation>Administration du cache</translation>
    </message>
    <message>
        <source>System information</source>
        <translation>Informations système</translation>
    </message>
    <message>
        <source>Rapid Application Development</source>
        <translation>Dévreloppement rapide d&apos;application</translation>
    </message>
    <message>
        <source>Template list</source>
        <translation>Liste des modèles</translation>
    </message>
    <message>
        <source>Template view</source>
        <translation>vue du modèle</translation>
    </message>
    <message>
        <source>Create new template</source>
        <translation>Crer un nouveau modèle</translation>
    </message>
    <message>
        <source>Template edit</source>
        <translation>Édition du modèle</translation>
    </message>
    <message>
        <source>Template operator wizard</source>
        <translation>Guide de création d&apos;opérateur de modèle</translation>
    </message>
</context>
<context>
    <name>kernel/shop</name>
    <message>
        <source>Basket</source>
        <translation>Panier</translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation>Passez en caisse</translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation>Confirmez la commande</translation>
    </message>
    <message>
        <source>Discount group</source>
        <translation>Groupe de rabais</translation>
    </message>
    <message>
        <source>Group view of discount rule</source>
        <translation>Voir le groupe de règle de rabais</translation>
    </message>
    <message>
        <source>Editing rule</source>
        <translation>Éditer la règle</translation>
    </message>
    <message>
        <source>Order list</source>
        <translation>Liste des commandes</translation>
    </message>
    <message>
        <source>Order view</source>
        <translation>Voir la commande</translation>
    </message>
    <message>
        <source>Enter account information</source>
        <translation>Entez les informations du compte utilisateur</translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation>Type de TVA</translation>
    </message>
</context>
<context>
    <name>kernel/trigger</name>
    <message>
        <source>Trigger</source>
        <translation>Déclencheur</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
</context>
<context>
    <name>kernel/url</name>
    <message>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vue</translation>
    </message>
</context>
<context>
    <name>kernel/user</name>
    <message>
        <source>User</source>
        <translation>Nom d&apos;usager</translation>
    </message>
    <message>
        <source>Forgot password</source>
        <translation>Mot de passe oublié</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Ouverture de session</translation>
    </message>
    <message>
        <source>Change password</source>
        <translation>Modifier mot de passe</translation>
    </message>
    <message>
        <source>Register</source>
        <translation>S&apos;inscrire</translation>
    </message>
</context>
<context>
    <name>kernel/user/register</name>
    <message>
        <source>Registration info</source>
        <translation>Informations de l&apos;inscription</translation>
    </message>
    <message>
        <source>New user registered</source>
        <translation>Nouvel utilisateur inscript</translation>
    </message>
</context>
<context>
    <name>kernel/workflow</name>
    <message>
        <source>Edit workflow</source>
        <translation>Éditer le processus de workflow</translation>
    </message>
    <message>
        <source>Workflow</source>
        <translation>Gestion de déroulement des opérations (workflow)</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <source>Edit workflow group</source>
        <translation>Éditer le groupe de processus de workflow</translation>
    </message>
    <message>
        <source>Group edit</source>
        <translation>Éditer le groupe</translation>
    </message>
    <message>
        <source>Workflow group list</source>
        <translation>Liste des groupes de processus de workflow</translation>
    </message>
    <message>
        <source>Group list</source>
        <translation>List des groupes</translation>
    </message>
    <message>
        <source>Workflow list</source>
        <translation>Liste des processus de workflow</translation>
    </message>
    <message>
        <source>Workflow list of group</source>
        <translation>Liste des processus de workflow du groupe</translation>
    </message>
    <message>
        <source>List</source>
        <translation>Liste</translation>
    </message>
</context>
<context>
    <name>lib/eztemplate</name>
    <message>
        <source>Some template errors occured, see debug for more information.</source>
        <translation>Des erreurs de modèle sont survenues, visualisez le Debug pour plus d&apos;information.</translation>
    </message>
</context>
<context>
    <name>setup/templateadmin</name>
    <message>
        <source>Template edit</source>
        <translation>Édition du modèle</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Sauvegarder</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Abandonner</translation>
    </message>
</context>
</TS>
