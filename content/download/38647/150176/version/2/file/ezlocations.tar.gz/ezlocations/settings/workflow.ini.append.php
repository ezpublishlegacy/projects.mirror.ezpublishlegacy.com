<?php /*

[EventSettings]
ExtensionDirectories[]=ezlocations
AvailableEventTypes[]=event_ezlocations

*/ ?>