<?php
//
// Definition of eZLocationsType class
//
// Copyright (C) Lukasz Serwatka <ls@ez.no>.
//
// This file may be distributed and/or modified under the terms of the
// "GNU General Public License" version 2 as published by the Free
// Software Foundation and appearing in the file LICENSE included in
// the packaging of this file.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
// THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.
//

include_once( 'kernel/classes/ezworkflowtype.php' );

define( 'EZ_WORKFLOW_TYPE_LOCATIONS', 'ezlocations' );

class eZLocationsType extends eZWorkflowEventType
{

    function eZLocationsType()
    {
        $this->eZWorkflowEventType( EZ_WORKFLOW_TYPE_LOCATIONS, ezi18n( 'kernel/workflow/event', 'Locations' ) );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array ( 'before' ) ) ) );
    }

    function execute( &$process, &$event )
    {
    	
        $parameters = $process->attribute( 'parameter_list' );
		$objectID = $parameters['object_id'];
		
        $object =& eZContentObject::fetch( $objectID );
        
        if ( is_object( $object ) )
        	$classID = $object->attribute( 'contentclass_id' );
        
    	include_once( 'lib/ezutils/classes/ezini.php' );
    	$locationsINI =& eZINI::instance( 'ezlocations.ini' );
    	
    	$nodeIDArray = $locationsINI->variable( 'LocationsSettings', 'LocationsArray' );
		$arr = array();
		
        $db =& eZDB::instance();
        $db->begin();
        foreach ( array_keys( $nodeIDArray ) as $key )
        {
        	if ( $classID == $key ) 
        	{
        		$arr = explode( ';', $nodeIDArray[$key] );
        		
        		foreach ( $arr as $nodeID ) 
        		{
        			$arrNode =& eZContentObjectTreeNode::fetch( $nodeID );
        			
        			if ( is_object( $arrNode ) ) 
        			{
        				$arrObject =& $arrNode->attribute( 'object' );
        				$arrClass =& $arrObject->attribute( 'content_class' );
        				$isContainer = $arrClass->attribute( 'is_container' );
        			
        				
        				if ( $isContainer ) 
        				{
        					$nodeAssignment =& eZNodeAssignment::create( array(
                                                               				'contentobject_id' => $object->attribute( 'id' ),
                                                                			'contentobject_version' => $object->attribute( 'current_version' ),
                                                                			'parent_node' => $nodeID,
                                                                			'is_main' => 0
                                                              	  		  )
                                                           			);
        					$nodeAssignment->store();	
        				}
        			}
        		}
        	}
        }
        $db->commit();

        return EZ_WORKFLOW_TYPE_STATUS_ACCEPTED;
    }
}

eZWorkflowEventType::registerType( EZ_WORKFLOW_TYPE_LOCATIONS, 'ezlocationstype' );

?>