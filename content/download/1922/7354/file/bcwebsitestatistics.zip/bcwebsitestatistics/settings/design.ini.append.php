<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=bcwebsitestatistics

# [JavaScriptSettings]
# List of JavaScript files to include in pagelayout
# 
# JavaScriptList[]
# JavaScriptList[]=urchin.js

*/ ?>