<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray['GetBrowserOperator'] = array( 'script' => 'extension/get_browser/autoloads/getbrowseroperator.php',
                                    'class' => 'GetBrowserOperator',
                                    'operator_names' => array( 'get_browser' ) );

?>
