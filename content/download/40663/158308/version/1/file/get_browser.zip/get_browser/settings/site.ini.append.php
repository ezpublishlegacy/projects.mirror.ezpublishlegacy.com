<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=get_browser

*/ ?>
