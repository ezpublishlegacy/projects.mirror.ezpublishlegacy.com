<?php /* vim:set syntax=dosini:
[TemplateSettings]
ExtensionAutoloadPath[]=iframewash
*/ ?>
