<?php
 
// Which operators will load automatically? 
$eZTemplateOperatorArray = array();
 
// Operator: jacdata 
$eZTemplateOperatorArray[] = array( 'class' => 'IFrameWashOperator',
                                    'operator_names' => array( 'iframe_wash' ) ); 
?>
