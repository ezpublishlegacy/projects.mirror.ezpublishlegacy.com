<?php
// TODO: Test failures on individual patterns (such as "single src", "single iframe").
require("autoloads/iframewashoperator.php");

class MockTpl
{
	function elementValue($a, $b, $c)
	{
		return null;
	}
}

class MockIni
{
	function variable($a, $b)
	{
		return array("good-domain.com", "www.gooddomain.com");
	}
}

class MockDebug
{
	function writeError($a, $b)
	{
		return;
	}
}

$tpl = new MockTpl();

$op = new IFrameWashOperator("iframe_wash", new MockIni(), new MockDebug());


function iframeBlocked($in_value)
{
	global $op, $tpl;
	$value = $in_value;
	$op->modify($tpl, null, null, null, null, $value, null);
	return $value !== $in_value;
}

function test($value, $expect_block)
{
	if (iframeBlocked($value) == $expect_block)
		echo "\nPASS: \"$value\"";
	else
		echo "\n*** FAIL (". ($expect_block ? "expected block" : "did not expect block") ."): $value";
}

// Single src, good
foreach( array('"', "'", '') as $src_q)
	test("<iframe src={$src_q}http://good-domain.com/{$src_q}></iframe>", false);

// Multiple src, bad
foreach( array('"', "'", '') as $src_q)
	test("<iframe src={$src_q}http://good-domain.com/{$src_q} src  =  {$src_q}http://good-domain.com/{$src_q}></iframe>", true);

// Params, good
foreach( array('"', "'", '') as $src_q)
	test("<iframe width='560' height='100' src={$src_q}http://good-domain.com/{$src_q} frameborder='0' allowfullscreen></iframe>", false);

// Style and javascript, bad
foreach( array('"', "'", '') as $src_q)
	foreach( array('"', "'") as $q)
		test("<iframe src={$src_q}http://good-domain.com/{$src_q} style = {$q}background: red;{$q}></iframe> onclick = {$q}alert(null);{$q}", true);

// Complicated but approved domain, good
test('<iframe src="http://www.gooddomain.com/viewstart/versjon20.asp?Mode=Fremvisning&LokasjonUrl=http://www.neitileu.no&LokasjonId=147&IFrameWidth=600&Ratio=1.7" width="600" height="382" border="0px" frameborder="0" scrolling="no" marginheight="0px" marginwidth="0px"></iframe>', false);

echo "\n\nTestsuite completed.\n";
?>
