<?php
include_once( "lib/ezutils/classes/ezini.php" );
include_once( "lib/ezutils/classes/ezdebug.php" );

/** 
 * Checks that the argument contains a single iframe with no styles from a single approved source.
 * @author Leif Arne Storset
 */ 
class IFrameWashOperator
{ 
	public $Operators;

	public function __construct($name = 'iframe_wash', $ini = null, $debug = null)
	{ 
		$this->Operators = array( $name ); 

		if (is_null($ini))
			$this->ini = eZINI::instance("iframewash.ini");
		else
			// Mock object
			$this->ini = $ini;

		if (is_null($debug))
			$this->debug = ezDebug::instance();
		else
			// Mock object
			$this->debug = $debug;
	}
 
	/** 
	 * Returns the template operators.
	 * @return array
	 */ 
	function operatorList()
	{ 
		return $this->Operators; 
	}
 
	/**
	 * Returns true to tell the template engine that the parameter list 
	 * exists per operator type. This is needed for classes that have
	 * multiple operators.
	 */ 
	public function namedParameterPerOperator() 
	{ 
		return true;
	}
 
	/**
	 * No named parameters - everything is configured in .ini files.
	 * @see eZTemplateOperator::namedParameterList 
	 **/ 
	public function namedParameterList() 
	{ 
		return array( 'iframe_wash' => array()); 
	}
 
	/**
	 * Wash the iframe. The following is allowed:
	 * - A single <iframe ...></iframe>
	 * - A single src attribute.
	 * - No style attribute.
	 * - src attribute containing an approved domain.
	 * - No event handlers.
	 */ 
	public function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters )
	{ 
		$return_error = $tpl->elementValue($operatorParameters[0], $rootNamespace, $currentNamespace);
		if (!isset($return_error))
			$return_error = 'An error occured getting the media.';

		$success = true;
		// Single iframe
		$success &= $this->match("#^\s*<iframe.*?>\s*</iframe>\s*$#", 1, $operatorValue, $error, "Only a single iframe element is allowed.");
		// Single src
		$success &= $this->match("#src\s*=#", 1, $operatorValue, $error, "Only a single src attribute is allowed.");
		// No style
		$success &= $this->match("#style\s*=\s*[\"'].*?[\"']#", 0, $operatorValue, $error, "No style attributes allowed.");
		// No javascript
		$success &= $this->match("#\bon\w+\s*=\s*[\"'].*?[\"']#", 0, $operatorValue, $error, "No javascript allowed.");
		// Approved src domain
		$success &= $this->approvedSrc($operatorValue, $error);

		if (!$success)
		{
			$log_error = "Blocked iframe from ". $this->getDomain($operatorValue) .":\n$error";
            $this->debug->writeError($log_error, "iframe_wash");
			error_log("iframe_wash: ". str_replace("\n", " ", $log_error));

			$operatorValue = $return_error ."<!-- See error log for details. -->";
		}
	} 

	private function match($pattern, $times, $markup, &$error, $msg)
	{
		$res = preg_match_all($pattern, $markup, $matches); // $matches can be omitted as of PHP 5.4.
		if ($res === $times)
			return true;
		if ($res === false)
		{
			$error .= "Regex error ". preg_last_error() .".\n";
			return false;
		}
		$error .= $msg ."\n";
		return false;
	}

	private function getDomain($markup)
	{
		$res = preg_match("#src\s*=[\"']?https?://([\w\.-]*)/.*?[\"']?#", $markup, $src);

		if (isset($src[1]))
			return $src[1];
		else
			return "(src not found)";
	}

	private function approvedSrc($markup, &$error)
	{
		$domain = $this->getDomain($markup, $error);

		$approvedDomains = $this->ini->variable("Whitelist", "Domains");
		foreach ($approvedDomains as $approved)
		{
			if ($domain == $approved)
				return true;
		}

		$error .= "$domain is not approved for embedding.\n";
		return false;
	}
} 
?>
