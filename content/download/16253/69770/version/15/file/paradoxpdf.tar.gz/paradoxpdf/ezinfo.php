<?php
class paradoxpdfInfo
{
    function info()
    {
        return array( 'Name' => "ParadoxPDF",
                      'Version' => "2.1",
                      'Copyright' => "Copyright (C) 2009 Mohamed Karnichi www.tricinty.com",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>