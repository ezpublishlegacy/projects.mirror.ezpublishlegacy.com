<?php /*
[ExtensionSettings]
DesignExtensions[]=lacalendar

*/ ?>