<?php /* #?ini charset="iso-8859-1"?

[LAcalendar]
#It just support 3 format for now : 
#DateFormat=mm/dd/yyyy
#DateFormat=yyyy-mm-dd
#DateFormat=dd/mm/yyyy
DateFormat=dd/mm/yyyy

*/ ?>