<?
/*!
  \class   eZBrowserSniff ezbrowsersniffoperator.php
  \ingroup eZTemplateOperators
  \brief   Handles template operator sniffer
  \version 1.2
  \date    Tuesday 27 May 2004 10:45:00 am
  \author  Paul Forsyth, Alex Jones

  eZBrowserSniff detects browser/platform combinations. This script provides powerful capabilities, providing extensive information about each of the various browser/platform combinations. See http://phpsniff.sourceforge.net/ for a demonstration of the available information. Use it to pass the current browser/platform combination to your templates if you need to supply the user with different information depending on their user agent. A key example of this is to provide different style sheets for Mozilla and Internet Explorer.

Setup
1. Extract all of the files in the eZBrowserSniff archive into your extension directory within the eZ publish root. if the extension directory doesn't exist, create it.
2. Download the phpSniff package separately from http://phpsniff.sourceforge.net/ as I haven't had a chance to deal with the licensing issues.
3. Extract the following files from the phpSniff archive and place them in extension/ezbrowsersniff/:
  - phpSniff.class.php
  - phpSniff.core.php
  - phpTimer.class.php
  - user_agent.inc
4. To configure the information passed to the templates, please see line 124 below

If you want to have autoloading of this operator you should create
a eztemplateautoload.php file and add the following code to it.
The autoload file must be placed somewhere specified in AutoloadPath
under the group TemplateSettings in settings/site.ini

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezbrowsersniff/ezbrowsersniffoperator.php',
                                    'class' => 'ezbrowsersniff',
                                    'operator_names' => array( 'sniffer' ) );
  

Example:
\code
{$value|sniffer|wash}
\endcode

Example: Using eZbrowserSniff to serve browser-specific style sheets

\code
{let BrowserSniff=sniffer()}
{switch name=UserAgent match=$BrowserSniff}
  {case match='winie6'} <!-- Match Internet Explorer 6 on Windows -->
     <style type="text/css" media="all">@import {"stylesheets/winie6.css"|ezdesign};</style> 
  {/case}
  {case match='macie5'} <!-- Match Internet Explorer 5 on the Mac -->
     <style type="text/css" media="all">@import {"stylesheets/macie5.css"|ezdesign};</style> 
     <style type="text/css" media="print">@import {"stylesheets/macie5_print.css"|ezdesign};</style> 
  {/case}
  {case match='macsf74'} <!-- Match Safari 0.74 on the Mac -->
     <style type="text/css" media="all">@import {"stylesheets/macsf.css"|ezdesign};</style> 
  {/case}
  {case match='macsf125'} <!-- Match Safari 1 on the Mac (weird, I know) -->
     <style type="text/css" media="all">@import {"stylesheets/macsf.css"|ezdesign};</style> 
  {/case}
  {case match='macns4'}<!-- Match Netscape 4 on the Mac -->
     <style type="text/css" media="all">@import {"stylesheets/macn4.css"|ezdesign};</style> 
  {/case}
  {case match='winop7'} <!-- Match Opera 7 on Windows -->
     <style type="text/css" media="all">@import {"stylesheets/dom.css"|ezdesign};</style> 
  {/case}
  {case match='winmz1'} <!-- Match Mozilla on Windows -->
     <style type="text/css" media="all">@import {"stylesheets/dom.css"|ezdesign};</style> 
  {/case}
  {case}
     <!-- Anything that isn't caught in one of the cases above -->
  {/case}
{/let}
\endcode
*/

/*

*/


class eZBrowserSniff
{
    /*!
      Constructor, does nothing by default.
    */
    function eZBrowserSniff( $name = "sniffer" )
    {
    	$this->SnifferName = $name;

		$this->Operators = array( $name );
    }

    /*!
     \return an array with the template operator name.
    */
    function operatorList()
    {
        return array( 'sniffer' );
    }
    /*!
     \return true to tell the template engine that the parameter list exists per operator type,
             this is needed for operator classes that have multiple operators.
    */
    function namedParameterPerOperator()
    {
        return true;
    }    /*!
     See eZTemplateOperator::namedParameterList
    */
    function namedParameterList()
    {
        return array( 'sniffer' => array( 'first_param' => array( 'type' => 'string',
                                                                  'required' => false,
                                                                  'default' => 'default text' ),
                                          'second_param' => array( 'type' => 'integer',
                                                                   'required' => false,
                                                                   'default' => 0 ) ) );
    }
    /*!
     Executes the PHP function for the operator cleanup and modifies \a $operatorValue.
    */
    function modify( &$tpl, &$operatorName, &$operatorParameters, &$rootNamespace, &$currentNamespace, &$operatorValue, &$namedParameters )
    { 
        require_once('phpSniff.class.php');
        require_once('phpTimer.class.php');
        if(!isset($UA)) $UA = '';
        $client = new phpSniff($UA);
	/*!
	 Modify \a $osBrowserVersion to change the format of the value returned. See http://phpsniff.sourceforge.net/ for information regarding the possible information to pass to your templates.
	 
	 This example will produce a simple string that includes an abbreviation of the platform ('mac' or 'win' for example), an abbreviation of the browser being used ('ie' or 'mz' for example) and the major version of the browser ('6' or '4'). So, some possible combinations might be 'macie5' for Internet Explorer 5 on the Macintosh, 'winie6' for Internet Explorer 6 on Windows, or 'winmz1' for Mozilla Firefox on Windows.
	*/
        $osBrowserVersion = $client->property('platform') . $client->property('browser') . $client->property('maj_ver'); 
        $operatorValue = $osBrowserVersion;
    }

    /// \privatesection
    var $Operators;
    var $SnifferName;
}
?>