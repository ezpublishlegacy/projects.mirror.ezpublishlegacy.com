<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezbrowsersniff/ezbrowsersniffoperator.php',
                                    'class' => 'ezbrowsersniff',
                                    'operator_names' => array( 'sniffer' ) );
?>